package a.b.c.a;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

public final class n implements Parcelable {
    public static final Parcelable.Creator<n> CREATOR = new a();

    /* renamed from: b  reason: collision with root package name */
    public final String f109b;

    /* renamed from: c  reason: collision with root package name */
    public final int f110c;
    public final boolean d;
    public final int e;
    public final int f;
    public final String g;
    public final boolean h;
    public final boolean i;
    public final Bundle j;
    public final boolean k;
    public Bundle l;
    public e m;

    public n(e frag) {
        this.f109b = frag.getClass().getName();
        this.f110c = frag.f;
        this.d = frag.n;
        this.e = frag.y;
        this.f = frag.z;
        this.g = frag.A;
        this.h = frag.D;
        this.i = frag.C;
        this.j = frag.h;
        this.k = frag.B;
    }

    public n(Parcel in) {
        this.f109b = in.readString();
        this.f110c = in.readInt();
        boolean z = true;
        this.d = in.readInt() != 0;
        this.e = in.readInt();
        this.f = in.readInt();
        this.g = in.readString();
        this.h = in.readInt() != 0;
        this.i = in.readInt() != 0;
        this.j = in.readBundle();
        this.k = in.readInt() == 0 ? false : z;
        this.l = in.readBundle();
    }

    public e a(i host, g container, e parent, l childNonConfig, a.a.b.n viewModelStore) {
        if (this.m == null) {
            Context context = host.e();
            Bundle bundle = this.j;
            if (bundle != null) {
                bundle.setClassLoader(context.getClassLoader());
            }
            if (container != null) {
                this.m = container.a(context, this.f109b, this.j);
            } else {
                this.m = e.E(context, this.f109b, this.j);
            }
            Bundle bundle2 = this.l;
            if (bundle2 != null) {
                bundle2.setClassLoader(context.getClassLoader());
                this.m.f64c = this.l;
            }
            this.m.R0(this.f110c, parent);
            e eVar = this.m;
            eVar.n = this.d;
            eVar.p = true;
            eVar.y = this.e;
            eVar.z = this.f;
            eVar.A = this.g;
            eVar.D = this.h;
            eVar.C = this.i;
            eVar.B = this.k;
            eVar.s = host.d;
            boolean z = k.C;
        }
        e eVar2 = this.m;
        eVar2.v = childNonConfig;
        eVar2.w = viewModelStore;
        return eVar2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.f109b);
        dest.writeInt(this.f110c);
        dest.writeInt(this.d ? 1 : 0);
        dest.writeInt(this.e);
        dest.writeInt(this.f);
        dest.writeString(this.g);
        dest.writeInt(this.h ? 1 : 0);
        dest.writeInt(this.i ? 1 : 0);
        dest.writeBundle(this.j);
        dest.writeInt(this.k ? 1 : 0);
        dest.writeBundle(this.l);
    }

    public static class a implements Parcelable.Creator<n> {
        /* renamed from: a */
        public n createFromParcel(Parcel in) {
            return new n(in);
        }

        /* renamed from: b */
        public n[] newArray(int size) {
            return new n[size];
        }
    }
}
