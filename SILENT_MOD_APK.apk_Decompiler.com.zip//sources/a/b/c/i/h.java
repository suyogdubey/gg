package a.b.c.i;

import android.widget.ListView;

public class h extends a {
    public final ListView s;

    public h(ListView target) {
        super(target);
        this.s = target;
    }

    public void j(int deltaX, int deltaY) {
        i.a(this.s, deltaY);
    }

    public boolean a(int direction) {
        return false;
    }

    public boolean b(int direction) {
        ListView target = this.s;
        int itemCount = target.getCount();
        if (itemCount == 0) {
            return false;
        }
        int childCount = target.getChildCount();
        int firstPosition = target.getFirstVisiblePosition();
        int lastPosition = firstPosition + childCount;
        if (direction > 0) {
            if (lastPosition < itemCount || target.getChildAt(childCount - 1).getBottom() > target.getHeight()) {
                return true;
            }
            return false;
        } else if (direction >= 0) {
            return false;
        } else {
            if (firstPosition > 0 || target.getChildAt(0).getTop() < 0) {
                return true;
            }
            return false;
        }
    }
}
