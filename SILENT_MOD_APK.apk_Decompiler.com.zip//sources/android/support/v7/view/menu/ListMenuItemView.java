package android.support.v7.view.menu;

import a.b.d.b.a;
import a.b.d.b.f;
import a.b.d.b.g;
import a.b.d.e.j.j;
import a.b.d.e.j.p;
import a.b.d.f.t0;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

public class ListMenuItemView extends LinearLayout implements p.a, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: b  reason: collision with root package name */
    public j f610b;

    /* renamed from: c  reason: collision with root package name */
    public ImageView f611c;
    public RadioButton d;
    public TextView e;
    public CheckBox f;
    public TextView g;
    public ImageView h;
    public ImageView i;
    public LinearLayout j;
    public Drawable k;
    public int l;
    public Context m;
    public boolean n;
    public Drawable o;
    public boolean p;
    public LayoutInflater q;
    public boolean r;

    public ListMenuItemView(Context context, AttributeSet attrs) {
        this(context, attrs, a.listMenuViewStyle);
    }

    public ListMenuItemView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs);
        t0 a2 = t0.t(getContext(), attrs, a.b.d.b.j.MenuView, defStyleAttr, 0);
        this.k = a2.f(a.b.d.b.j.MenuView_android_itemBackground);
        this.l = a2.m(a.b.d.b.j.MenuView_android_itemTextAppearance, -1);
        this.n = a2.a(a.b.d.b.j.MenuView_preserveIconSpacing, false);
        this.m = context;
        this.o = a2.f(a.b.d.b.j.MenuView_subMenuArrow);
        TypedArray b2 = context.getTheme().obtainStyledAttributes((AttributeSet) null, new int[]{16843049}, a.dropDownListViewStyle, 0);
        this.p = b2.hasValue(0);
        a2.u();
        b2.recycle();
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        a.b.c.h.p.t(this, this.k);
        TextView textView = (TextView) findViewById(f.title);
        this.e = textView;
        int i2 = this.l;
        if (i2 != -1) {
            textView.setTextAppearance(this.m, i2);
        }
        this.g = (TextView) findViewById(f.shortcut);
        ImageView imageView = (ImageView) findViewById(f.submenuarrow);
        this.h = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.o);
        }
        this.i = (ImageView) findViewById(f.group_divider);
        this.j = (LinearLayout) findViewById(f.content);
    }

    public void d(j itemData, int menuType) {
        this.f610b = itemData;
        setVisibility(itemData.isVisible() ? 0 : 8);
        setTitle(itemData.i(this));
        setCheckable(itemData.isCheckable());
        boolean z = itemData.z();
        itemData.g();
        h(z);
        setIcon(itemData.getIcon());
        setEnabled(itemData.isEnabled());
        setSubMenuArrowVisible(itemData.hasSubMenu());
        setContentDescription(itemData.getContentDescription());
    }

    public final void a(View v) {
        b(v, -1);
    }

    public final void b(View v, int index) {
        LinearLayout linearLayout = this.j;
        if (linearLayout != null) {
            linearLayout.addView(v, index);
        } else {
            addView(v, index);
        }
    }

    public void setForceShowIcon(boolean forceShow) {
        this.r = forceShow;
        this.n = forceShow;
    }

    public void setTitle(CharSequence title) {
        if (title != null) {
            this.e.setText(title);
            if (this.e.getVisibility() != 0) {
                this.e.setVisibility(0);
            }
        } else if (this.e.getVisibility() != 8) {
            this.e.setVisibility(8);
        }
    }

    public j getItemData() {
        return this.f610b;
    }

    public void setCheckable(boolean checkable) {
        CompoundButton otherCompoundButton;
        CompoundButton compoundButton;
        if (checkable || this.d != null || this.f != null) {
            if (this.f610b.m()) {
                if (this.d == null) {
                    g();
                }
                compoundButton = this.d;
                otherCompoundButton = this.f;
            } else {
                if (this.f == null) {
                    e();
                }
                compoundButton = this.f;
                otherCompoundButton = this.d;
            }
            if (checkable) {
                compoundButton.setChecked(this.f610b.isChecked());
                if (compoundButton.getVisibility() != 0) {
                    compoundButton.setVisibility(0);
                }
                if (otherCompoundButton != null && otherCompoundButton.getVisibility() != 8) {
                    otherCompoundButton.setVisibility(8);
                    return;
                }
                return;
            }
            CheckBox checkBox = this.f;
            if (checkBox != null) {
                checkBox.setVisibility(8);
            }
            RadioButton radioButton = this.d;
            if (radioButton != null) {
                radioButton.setVisibility(8);
            }
        }
    }

    public void setChecked(boolean checked) {
        CompoundButton compoundButton;
        if (this.f610b.m()) {
            if (this.d == null) {
                g();
            }
            compoundButton = this.d;
        } else {
            if (this.f == null) {
                e();
            }
            compoundButton = this.f;
        }
        compoundButton.setChecked(checked);
    }

    private void setSubMenuArrowVisible(boolean hasSubmenu) {
        ImageView imageView = this.h;
        if (imageView != null) {
            imageView.setVisibility(hasSubmenu ? 0 : 8);
        }
    }

    public void h(boolean showShortcut) {
        int newVisibility = (!showShortcut || !this.f610b.z()) ? 8 : 0;
        if (newVisibility == 0) {
            this.g.setText(this.f610b.h());
        }
        if (this.g.getVisibility() != newVisibility) {
            this.g.setVisibility(newVisibility);
        }
    }

    public void setIcon(Drawable icon) {
        boolean showIcon = this.f610b.y() || this.r;
        if (!showIcon && !this.n) {
            return;
        }
        if (this.f611c != null || icon != null || this.n) {
            if (this.f611c == null) {
                f();
            }
            if (icon != null || this.n) {
                this.f611c.setImageDrawable(showIcon ? icon : null);
                if (this.f611c.getVisibility() != 0) {
                    this.f611c.setVisibility(0);
                    return;
                }
                return;
            }
            this.f611c.setVisibility(8);
        }
    }

    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (this.f611c != null && this.n) {
            ViewGroup.LayoutParams lp = getLayoutParams();
            LinearLayout.LayoutParams iconLp = (LinearLayout.LayoutParams) this.f611c.getLayoutParams();
            int i2 = lp.height;
            if (i2 > 0 && iconLp.width <= 0) {
                iconLp.width = i2;
            }
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    public final void f() {
        ImageView imageView = (ImageView) getInflater().inflate(g.abc_list_menu_item_icon, this, false);
        this.f611c = imageView;
        b(imageView, 0);
    }

    public final void g() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(g.abc_list_menu_item_radio, this, false);
        this.d = radioButton;
        a(radioButton);
    }

    public final void e() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(g.abc_list_menu_item_checkbox, this, false);
        this.f = checkBox;
        a(checkBox);
    }

    public boolean c() {
        return false;
    }

    private LayoutInflater getInflater() {
        if (this.q == null) {
            this.q = LayoutInflater.from(getContext());
        }
        return this.q;
    }

    public void setGroupDividerEnabled(boolean groupDividerEnabled) {
        ImageView imageView = this.i;
        if (imageView != null) {
            imageView.setVisibility((this.p || !groupDividerEnabled) ? 8 : 0);
        }
    }

    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.i;
        if (imageView != null && imageView.getVisibility() == 0) {
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) this.i.getLayoutParams();
            rect.top += this.i.getHeight() + lp.topMargin + lp.bottomMargin;
        }
    }
}
