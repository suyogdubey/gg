package a.b.c.h.y;

import a.b.d.b.j;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;

public class a {

    /* renamed from: a  reason: collision with root package name */
    public final AccessibilityNodeInfo f269a;

    public a(AccessibilityNodeInfo info) {
        this.f269a = info;
    }

    public static a x(AccessibilityNodeInfo info) {
        return new a(info);
    }

    public AccessibilityNodeInfo w() {
        return this.f269a;
    }

    public int c() {
        return this.f269a.getActions();
    }

    public void a(int action) {
        this.f269a.addAction(action);
    }

    public void d(Rect outBounds) {
        this.f269a.getBoundsInParent(outBounds);
    }

    public void e(Rect outBounds) {
        this.f269a.getBoundsInScreen(outBounds);
    }

    public boolean k() {
        return this.f269a.isCheckable();
    }

    public boolean l() {
        return this.f269a.isChecked();
    }

    public boolean o() {
        return this.f269a.isFocusable();
    }

    public boolean p() {
        return this.f269a.isFocused();
    }

    public boolean t() {
        return this.f269a.isSelected();
    }

    public boolean m() {
        return this.f269a.isClickable();
    }

    public boolean q() {
        return this.f269a.isLongClickable();
    }

    public boolean n() {
        return this.f269a.isEnabled();
    }

    public boolean r() {
        return this.f269a.isPassword();
    }

    public boolean s() {
        return this.f269a.isScrollable();
    }

    public void v(boolean scrollable) {
        this.f269a.setScrollable(scrollable);
    }

    public CharSequence h() {
        return this.f269a.getPackageName();
    }

    public CharSequence f() {
        return this.f269a.getClassName();
    }

    public void u(CharSequence className) {
        this.f269a.setClassName(className);
    }

    public CharSequence i() {
        return this.f269a.getText();
    }

    public CharSequence g() {
        return this.f269a.getContentDescription();
    }

    public String j() {
        return this.f269a.getViewIdResourceName();
    }

    public int hashCode() {
        AccessibilityNodeInfo accessibilityNodeInfo = this.f269a;
        if (accessibilityNodeInfo == null) {
            return 0;
        }
        return accessibilityNodeInfo.hashCode();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        a other = (a) obj;
        AccessibilityNodeInfo accessibilityNodeInfo = this.f269a;
        if (accessibilityNodeInfo == null) {
            if (other.f269a != null) {
                return false;
            }
        } else if (!accessibilityNodeInfo.equals(other.f269a)) {
            return false;
        }
        return true;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(super.toString());
        Rect bounds = new Rect();
        d(bounds);
        builder.append("; boundsInParent: " + bounds);
        e(bounds);
        builder.append("; boundsInScreen: " + bounds);
        builder.append("; packageName: ");
        builder.append(h());
        builder.append("; className: ");
        builder.append(f());
        builder.append("; text: ");
        builder.append(i());
        builder.append("; contentDescription: ");
        builder.append(g());
        builder.append("; viewId: ");
        builder.append(j());
        builder.append("; checkable: ");
        builder.append(k());
        builder.append("; checked: ");
        builder.append(l());
        builder.append("; focusable: ");
        builder.append(o());
        builder.append("; focused: ");
        builder.append(p());
        builder.append("; selected: ");
        builder.append(t());
        builder.append("; clickable: ");
        builder.append(m());
        builder.append("; longClickable: ");
        builder.append(q());
        builder.append("; enabled: ");
        builder.append(n());
        builder.append("; password: ");
        builder.append(r());
        builder.append("; scrollable: " + s());
        builder.append("; [");
        int actionBits = c();
        while (actionBits != 0) {
            int action = 1 << Integer.numberOfTrailingZeros(actionBits);
            actionBits &= action ^ -1;
            builder.append(b(action));
            if (actionBits != 0) {
                builder.append(", ");
            }
        }
        builder.append("]");
        return builder.toString();
    }

    public static String b(int action) {
        if (action == 1) {
            return "ACTION_FOCUS";
        }
        if (action == 2) {
            return "ACTION_CLEAR_FOCUS";
        }
        switch (action) {
            case 4:
                return "ACTION_SELECT";
            case 8:
                return "ACTION_CLEAR_SELECTION";
            case 16:
                return "ACTION_CLICK";
            case j.AppCompatTheme_activityChooserViewStyle /*32*/:
                return "ACTION_LONG_CLICK";
            case j.AppCompatTheme_dropDownListViewStyle /*64*/:
                return "ACTION_ACCESSIBILITY_FOCUS";
            case 128:
                return "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
            case 256:
                return "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
            case 512:
                return "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
            case 1024:
                return "ACTION_NEXT_HTML_ELEMENT";
            case 2048:
                return "ACTION_PREVIOUS_HTML_ELEMENT";
            case 4096:
                return "ACTION_SCROLL_FORWARD";
            case 8192:
                return "ACTION_SCROLL_BACKWARD";
            case 16384:
                return "ACTION_COPY";
            case 32768:
                return "ACTION_PASTE";
            case 65536:
                return "ACTION_CUT";
            case 131072:
                return "ACTION_SET_SELECTION";
            default:
                return "ACTION_UNKNOWN";
        }
    }
}
