package android.support.v7.widget;

import a.b.c.h.p;
import a.b.d.a.a;
import a.b.d.b.j;
import a.b.d.e.j.h;
import a.b.d.e.j.o;
import a.b.d.e.j.u;
import a.b.d.f.a1;
import a.b.d.f.b0;
import a.b.d.f.l0;
import a.b.d.f.m;
import a.b.d.f.o;
import a.b.d.f.t0;
import a.b.d.f.v0;
import a.b.d.f.y;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.widget.ActionMenuView;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup {
    public int A;
    public int B;
    public boolean C;
    public boolean D;
    public final ArrayList<View> E;
    public final ArrayList<View> F;
    public final int[] G;
    public f H;
    public final ActionMenuView.e I;
    public v0 J;
    public a.b.d.f.c K;
    public d L;
    public boolean M;
    public final Runnable N;

    /* renamed from: b  reason: collision with root package name */
    public ActionMenuView f646b;

    /* renamed from: c  reason: collision with root package name */
    public TextView f647c;
    public TextView d;
    public ImageButton e;
    public ImageView f;
    public Drawable g;
    public CharSequence h;
    public ImageButton i;
    public View j;
    public Context k;
    public int l;
    public int m;
    public int n;
    public int o;
    public int p;
    public int q;
    public int r;
    public int s;
    public int t;
    public l0 u;
    public int v;
    public int w;
    public int x;
    public CharSequence y;
    public CharSequence z;

    public interface f {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    public class a implements ActionMenuView.e {
        public a() {
        }

        public boolean a(MenuItem item) {
            f fVar = Toolbar.this.H;
            if (fVar != null) {
                return fVar.onMenuItemClick(item);
            }
            return false;
        }
    }

    public class b implements Runnable {
        public b() {
        }

        public void run() {
            Toolbar.this.M();
        }
    }

    public Toolbar(Context context, AttributeSet attrs) {
        this(context, attrs, a.b.d.b.a.toolbarStyle);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public Toolbar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        int i2;
        this.x = 8388627;
        this.E = new ArrayList<>();
        this.F = new ArrayList<>();
        this.G = new int[2];
        this.I = new a();
        this.N = new b();
        t0 a2 = t0.t(getContext(), attrs, j.Toolbar, defStyleAttr, 0);
        this.m = a2.m(j.Toolbar_titleTextAppearance, 0);
        this.n = a2.m(j.Toolbar_subtitleTextAppearance, 0);
        this.x = a2.k(j.Toolbar_android_gravity, this.x);
        this.o = a2.k(j.Toolbar_buttonGravity, 48);
        int titleMargin = a2.d(j.Toolbar_titleMargin, 0);
        titleMargin = a2.q(j.Toolbar_titleMargins) ? a2.d(j.Toolbar_titleMargins, titleMargin) : titleMargin;
        this.t = titleMargin;
        this.s = titleMargin;
        this.r = titleMargin;
        this.q = titleMargin;
        int marginStart = a2.d(j.Toolbar_titleMarginStart, -1);
        if (marginStart >= 0) {
            this.q = marginStart;
        }
        int marginEnd = a2.d(j.Toolbar_titleMarginEnd, -1);
        if (marginEnd >= 0) {
            this.r = marginEnd;
        }
        int marginTop = a2.d(j.Toolbar_titleMarginTop, -1);
        if (marginTop >= 0) {
            this.s = marginTop;
        }
        int marginBottom = a2.d(j.Toolbar_titleMarginBottom, -1);
        if (marginBottom >= 0) {
            this.t = marginBottom;
        }
        this.p = a2.e(j.Toolbar_maxButtonHeight, -1);
        int contentInsetStart = a2.d(j.Toolbar_contentInsetStart, Integer.MIN_VALUE);
        int contentInsetEnd = a2.d(j.Toolbar_contentInsetEnd, Integer.MIN_VALUE);
        int contentInsetLeft = a2.e(j.Toolbar_contentInsetLeft, 0);
        int contentInsetRight = a2.e(j.Toolbar_contentInsetRight, 0);
        h();
        this.u.e(contentInsetLeft, contentInsetRight);
        if (!(contentInsetStart == Integer.MIN_VALUE && contentInsetEnd == Integer.MIN_VALUE)) {
            this.u.g(contentInsetStart, contentInsetEnd);
        }
        this.v = a2.d(j.Toolbar_contentInsetStartWithNavigation, Integer.MIN_VALUE);
        this.w = a2.d(j.Toolbar_contentInsetEndWithActions, Integer.MIN_VALUE);
        this.g = a2.f(j.Toolbar_collapseIcon);
        this.h = a2.o(j.Toolbar_collapseContentDescription);
        CharSequence title = a2.o(j.Toolbar_title);
        if (!TextUtils.isEmpty(title)) {
            setTitle(title);
        }
        CharSequence subtitle = a2.o(j.Toolbar_subtitle);
        if (!TextUtils.isEmpty(subtitle)) {
            setSubtitle(subtitle);
        }
        this.k = getContext();
        int i3 = titleMargin;
        setPopupTheme(a2.m(j.Toolbar_popupTheme, 0));
        Drawable navIcon = a2.f(j.Toolbar_navigationIcon);
        if (navIcon != null) {
            setNavigationIcon(navIcon);
        }
        CharSequence navDesc = a2.o(j.Toolbar_navigationContentDescription);
        if (!TextUtils.isEmpty(navDesc)) {
            setNavigationContentDescription(navDesc);
        }
        Drawable drawable = navIcon;
        Drawable logo = a2.f(j.Toolbar_logo);
        if (logo != null) {
            setLogo(logo);
        }
        Drawable drawable2 = logo;
        CharSequence logoDesc = a2.o(j.Toolbar_logoDescription);
        if (!TextUtils.isEmpty(logoDesc)) {
            setLogoDescription(logoDesc);
        }
        CharSequence charSequence = logoDesc;
        if (a2.q(j.Toolbar_titleTextColor)) {
            CharSequence charSequence2 = navDesc;
            i2 = -1;
            setTitleTextColor(a2.b(j.Toolbar_titleTextColor, -1));
        } else {
            i2 = -1;
        }
        if (a2.q(j.Toolbar_subtitleTextColor)) {
            setSubtitleTextColor(a2.b(j.Toolbar_subtitleTextColor, i2));
        }
        a2.u();
    }

    public void setPopupTheme(int resId) {
        if (this.l != resId) {
            this.l = resId;
            if (resId == 0) {
                this.k = getContext();
            } else {
                this.k = new ContextThemeWrapper(getContext(), resId);
            }
        }
    }

    public int getPopupTheme() {
        return this.l;
    }

    public int getTitleMarginStart() {
        return this.q;
    }

    public void setTitleMarginStart(int margin) {
        this.q = margin;
        requestLayout();
    }

    public int getTitleMarginTop() {
        return this.s;
    }

    public void setTitleMarginTop(int margin) {
        this.s = margin;
        requestLayout();
    }

    public int getTitleMarginEnd() {
        return this.r;
    }

    public void setTitleMarginEnd(int margin) {
        this.r = margin;
        requestLayout();
    }

    public int getTitleMarginBottom() {
        return this.t;
    }

    public void setTitleMarginBottom(int margin) {
        this.t = margin;
        requestLayout();
    }

    public void onRtlPropertiesChanged(int layoutDirection) {
        super.onRtlPropertiesChanged(layoutDirection);
        h();
        l0 l0Var = this.u;
        boolean z2 = true;
        if (layoutDirection != 1) {
            z2 = false;
        }
        l0Var.f(z2);
    }

    public void setLogo(int resId) {
        setLogo(a.b.d.c.a.a.d(getContext(), resId));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r1.f646b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean d() {
        /*
            r1 = this;
            int r0 = r1.getVisibility()
            if (r0 != 0) goto L_0x0012
            android.support.v7.widget.ActionMenuView r0 = r1.f646b
            if (r0 == 0) goto L_0x0012
            boolean r0 = r0.I()
            if (r0 == 0) goto L_0x0012
            r0 = 1
            goto L_0x0013
        L_0x0012:
            r0 = 0
        L_0x0013:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.Toolbar.d():boolean");
    }

    public boolean z() {
        ActionMenuView actionMenuView = this.f646b;
        return actionMenuView != null && actionMenuView.H();
    }

    public boolean y() {
        ActionMenuView actionMenuView = this.f646b;
        return actionMenuView != null && actionMenuView.G();
    }

    public boolean M() {
        ActionMenuView actionMenuView = this.f646b;
        return actionMenuView != null && actionMenuView.N();
    }

    public boolean w() {
        ActionMenuView actionMenuView = this.f646b;
        return actionMenuView != null && actionMenuView.F();
    }

    public void H(h menu, a.b.d.f.c outerPresenter) {
        if (menu != null || this.f646b != null) {
            k();
            h oldMenu = this.f646b.L();
            if (oldMenu != menu) {
                if (oldMenu != null) {
                    oldMenu.O(this.K);
                    oldMenu.O(this.L);
                }
                if (this.L == null) {
                    this.L = new d();
                }
                outerPresenter.F(true);
                if (menu != null) {
                    menu.c(outerPresenter, this.k);
                    menu.c(this.L, this.k);
                } else {
                    outerPresenter.k(this.k, (h) null);
                    this.L.k(this.k, (h) null);
                    outerPresenter.i(true);
                    this.L.i(true);
                }
                this.f646b.setPopupTheme(this.l);
                this.f646b.setPresenter(outerPresenter);
                this.K = outerPresenter;
            }
        }
    }

    public void f() {
        ActionMenuView actionMenuView = this.f646b;
        if (actionMenuView != null) {
            actionMenuView.z();
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            i();
            if (!x(this.f)) {
                c(this.f, true);
            }
        } else {
            ImageView imageView = this.f;
            if (imageView != null && x(imageView)) {
                removeView(this.f);
                this.F.remove(this.f);
            }
        }
        ImageView imageView2 = this.f;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public Drawable getLogo() {
        ImageView imageView = this.f;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public void setLogoDescription(int resId) {
        setLogoDescription(getContext().getText(resId));
    }

    public void setLogoDescription(CharSequence description) {
        if (!TextUtils.isEmpty(description)) {
            i();
        }
        ImageView imageView = this.f;
        if (imageView != null) {
            imageView.setContentDescription(description);
        }
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.f;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public final void i() {
        if (this.f == null) {
            this.f = new o(getContext());
        }
    }

    public boolean v() {
        d dVar = this.L;
        return (dVar == null || dVar.f652c == null) ? false : true;
    }

    public void e() {
        d dVar = this.L;
        a.b.d.e.j.j item = dVar == null ? null : dVar.f652c;
        if (item != null) {
            item.collapseActionView();
        }
    }

    public CharSequence getTitle() {
        return this.y;
    }

    public void setTitle(int resId) {
        setTitle(getContext().getText(resId));
    }

    public void setTitle(CharSequence title) {
        if (!TextUtils.isEmpty(title)) {
            if (this.f647c == null) {
                Context context = getContext();
                y yVar = new y(context);
                this.f647c = yVar;
                yVar.setSingleLine();
                this.f647c.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.m;
                if (i2 != 0) {
                    this.f647c.setTextAppearance(context, i2);
                }
                int i3 = this.A;
                if (i3 != 0) {
                    this.f647c.setTextColor(i3);
                }
            }
            if (!x(this.f647c)) {
                c(this.f647c, true);
            }
        } else {
            TextView textView = this.f647c;
            if (textView != null && x(textView)) {
                removeView(this.f647c);
                this.F.remove(this.f647c);
            }
        }
        TextView textView2 = this.f647c;
        if (textView2 != null) {
            textView2.setText(title);
        }
        this.y = title;
    }

    public CharSequence getSubtitle() {
        return this.z;
    }

    public void setSubtitle(int resId) {
        setSubtitle(getContext().getText(resId));
    }

    public void setSubtitle(CharSequence subtitle) {
        if (!TextUtils.isEmpty(subtitle)) {
            if (this.d == null) {
                Context context = getContext();
                y yVar = new y(context);
                this.d = yVar;
                yVar.setSingleLine();
                this.d.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.n;
                if (i2 != 0) {
                    this.d.setTextAppearance(context, i2);
                }
                int i3 = this.B;
                if (i3 != 0) {
                    this.d.setTextColor(i3);
                }
            }
            if (!x(this.d)) {
                c(this.d, true);
            }
        } else {
            TextView textView = this.d;
            if (textView != null && x(textView)) {
                removeView(this.d);
                this.F.remove(this.d);
            }
        }
        TextView textView2 = this.d;
        if (textView2 != null) {
            textView2.setText(subtitle);
        }
        this.z = subtitle;
    }

    public void J(Context context, int resId) {
        this.m = resId;
        TextView textView = this.f647c;
        if (textView != null) {
            textView.setTextAppearance(context, resId);
        }
    }

    public void I(Context context, int resId) {
        this.n = resId;
        TextView textView = this.d;
        if (textView != null) {
            textView.setTextAppearance(context, resId);
        }
    }

    public void setTitleTextColor(int color) {
        this.A = color;
        TextView textView = this.f647c;
        if (textView != null) {
            textView.setTextColor(color);
        }
    }

    public void setSubtitleTextColor(int color) {
        this.B = color;
        TextView textView = this.d;
        if (textView != null) {
            textView.setTextColor(color);
        }
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.e;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public void setNavigationContentDescription(int resId) {
        setNavigationContentDescription(resId != 0 ? getContext().getText(resId) : null);
    }

    public void setNavigationContentDescription(CharSequence description) {
        if (!TextUtils.isEmpty(description)) {
            l();
        }
        ImageButton imageButton = this.e;
        if (imageButton != null) {
            imageButton.setContentDescription(description);
        }
    }

    public void setNavigationIcon(int resId) {
        setNavigationIcon(a.b.d.c.a.a.d(getContext(), resId));
    }

    public void setNavigationIcon(Drawable icon) {
        if (icon != null) {
            l();
            if (!x(this.e)) {
                c(this.e, true);
            }
        } else {
            ImageButton imageButton = this.e;
            if (imageButton != null && x(imageButton)) {
                removeView(this.e);
                this.F.remove(this.e);
            }
        }
        ImageButton imageButton2 = this.e;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(icon);
        }
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.e;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public void setNavigationOnClickListener(View.OnClickListener listener) {
        l();
        this.e.setOnClickListener(listener);
    }

    public Menu getMenu() {
        j();
        return this.f646b.getMenu();
    }

    public void setOverflowIcon(Drawable icon) {
        j();
        this.f646b.setOverflowIcon(icon);
    }

    public Drawable getOverflowIcon() {
        j();
        return this.f646b.getOverflowIcon();
    }

    public final void j() {
        k();
        if (this.f646b.L() == null) {
            h menu = (h) this.f646b.getMenu();
            if (this.L == null) {
                this.L = new d();
            }
            this.f646b.setExpandedActionViewsExclusive(true);
            menu.c(this.L, this.k);
        }
    }

    public final void k() {
        if (this.f646b == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext());
            this.f646b = actionMenuView;
            actionMenuView.setPopupTheme(this.l);
            this.f646b.setOnMenuItemClickListener(this.I);
            this.f646b.M((o.a) null, (h.a) null);
            e lp = generateDefaultLayoutParams();
            lp.f296a = 8388613 | (this.o & j.AppCompatTheme_windowActionBarOverlay);
            this.f646b.setLayoutParams(lp);
            c(this.f646b, false);
        }
    }

    private MenuInflater getMenuInflater() {
        return new a.b.d.e.g(getContext());
    }

    public void setOnMenuItemClickListener(f listener) {
        this.H = listener;
    }

    public void G(int contentInsetStart, int contentInsetEnd) {
        h();
        this.u.g(contentInsetStart, contentInsetEnd);
    }

    public int getContentInsetStart() {
        l0 l0Var = this.u;
        if (l0Var != null) {
            return l0Var.d();
        }
        return 0;
    }

    public int getContentInsetEnd() {
        l0 l0Var = this.u;
        if (l0Var != null) {
            return l0Var.a();
        }
        return 0;
    }

    public int getContentInsetLeft() {
        l0 l0Var = this.u;
        if (l0Var != null) {
            return l0Var.b();
        }
        return 0;
    }

    public int getContentInsetRight() {
        l0 l0Var = this.u;
        if (l0Var != null) {
            return l0Var.c();
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.v;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    public void setContentInsetStartWithNavigation(int insetStartWithNavigation) {
        if (insetStartWithNavigation < 0) {
            insetStartWithNavigation = Integer.MIN_VALUE;
        }
        if (insetStartWithNavigation != this.v) {
            this.v = insetStartWithNavigation;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.w;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public void setContentInsetEndWithActions(int insetEndWithActions) {
        if (insetEndWithActions < 0) {
            insetEndWithActions = Integer.MIN_VALUE;
        }
        if (insetEndWithActions != this.w) {
            this.w = insetEndWithActions;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public int getCurrentContentInsetStart() {
        if (getNavigationIcon() != null) {
            return Math.max(getContentInsetStart(), Math.max(this.v, 0));
        }
        return getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        boolean hasActions = false;
        ActionMenuView actionMenuView = this.f646b;
        if (actionMenuView != null) {
            h mb = actionMenuView.L();
            hasActions = mb != null && mb.hasVisibleItems();
        }
        if (hasActions) {
            return Math.max(getContentInsetEnd(), Math.max(this.w, 0));
        }
        return getContentInsetEnd();
    }

    public int getCurrentContentInsetLeft() {
        if (p.f(this) == 1) {
            return getCurrentContentInsetEnd();
        }
        return getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        if (p.f(this) == 1) {
            return getCurrentContentInsetStart();
        }
        return getCurrentContentInsetEnd();
    }

    public final void l() {
        if (this.e == null) {
            this.e = new m(getContext(), (AttributeSet) null, a.b.d.b.a.toolbarNavigationButtonStyle);
            e lp = generateDefaultLayoutParams();
            lp.f296a = 8388611 | (this.o & j.AppCompatTheme_windowActionBarOverlay);
            this.e.setLayoutParams(lp);
        }
    }

    public void g() {
        if (this.i == null) {
            m mVar = new m(getContext(), (AttributeSet) null, a.b.d.b.a.toolbarNavigationButtonStyle);
            this.i = mVar;
            mVar.setImageDrawable(this.g);
            this.i.setContentDescription(this.h);
            e lp = generateDefaultLayoutParams();
            lp.f296a = 8388611 | (this.o & j.AppCompatTheme_windowActionBarOverlay);
            lp.f653b = 2;
            this.i.setLayoutParams(lp);
            this.i.setOnClickListener(new c());
        }
    }

    public class c implements View.OnClickListener {
        public c() {
        }

        public void onClick(View v) {
            Toolbar.this.e();
        }
    }

    public final void c(View v2, boolean allowHide) {
        e lp;
        ViewGroup.LayoutParams vlp = v2.getLayoutParams();
        if (vlp == null) {
            lp = generateDefaultLayoutParams();
        } else if (!checkLayoutParams(vlp)) {
            lp = generateLayoutParams(vlp);
        } else {
            lp = (e) vlp;
        }
        lp.f653b = 1;
        if (!allowHide || this.j == null) {
            addView(v2, lp);
            return;
        }
        v2.setLayoutParams(lp);
        this.F.add(v2);
    }

    public Parcelable onSaveInstanceState() {
        a.b.d.e.j.j jVar;
        g state = new g(super.onSaveInstanceState());
        d dVar = this.L;
        if (!(dVar == null || (jVar = dVar.f652c) == null)) {
            state.d = jVar.getItemId();
        }
        state.e = z();
        return state;
    }

    public void onRestoreInstanceState(Parcelable state) {
        MenuItem item;
        if (!(state instanceof g)) {
            super.onRestoreInstanceState(state);
            return;
        }
        g ss = (g) state;
        super.onRestoreInstanceState(ss.a());
        ActionMenuView actionMenuView = this.f646b;
        Menu menu = actionMenuView != null ? actionMenuView.L() : null;
        int i2 = ss.d;
        if (!(i2 == 0 || this.L == null || menu == null || (item = menu.findItem(i2)) == null)) {
            item.expandActionView();
        }
        if (ss.e) {
            E();
        }
    }

    public final void E() {
        removeCallbacks(this.N);
        post(this.N);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.N);
    }

    public boolean onTouchEvent(MotionEvent ev) {
        int action = ev.getActionMasked();
        if (action == 0) {
            this.C = false;
        }
        if (!this.C) {
            boolean handled = super.onTouchEvent(ev);
            if (action == 0 && !handled) {
                this.C = true;
            }
        }
        if (action == 1 || action == 3) {
            this.C = false;
        }
        return true;
    }

    public boolean onHoverEvent(MotionEvent ev) {
        int action = ev.getActionMasked();
        if (action == 9) {
            this.D = false;
        }
        if (!this.D) {
            boolean handled = super.onHoverEvent(ev);
            if (action == 9 && !handled) {
                this.D = true;
            }
        }
        if (action == 10 || action == 3) {
            this.D = false;
        }
        return true;
    }

    public final void D(View child, int parentWidthSpec, int widthUsed, int parentHeightSpec, int heightUsed, int heightConstraint) {
        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) child.getLayoutParams();
        int childWidthSpec = ViewGroup.getChildMeasureSpec(parentWidthSpec, getPaddingLeft() + getPaddingRight() + lp.leftMargin + lp.rightMargin + widthUsed, lp.width);
        int childHeightSpec = ViewGroup.getChildMeasureSpec(parentHeightSpec, getPaddingTop() + getPaddingBottom() + lp.topMargin + lp.bottomMargin + heightUsed, lp.height);
        int childHeightMode = View.MeasureSpec.getMode(childHeightSpec);
        if (childHeightMode != 1073741824 && heightConstraint >= 0) {
            childHeightSpec = View.MeasureSpec.makeMeasureSpec(childHeightMode != 0 ? Math.min(View.MeasureSpec.getSize(childHeightSpec), heightConstraint) : heightConstraint, 1073741824);
        }
        child.measure(childWidthSpec, childHeightSpec);
    }

    public final int C(View child, int parentWidthMeasureSpec, int widthUsed, int parentHeightMeasureSpec, int heightUsed, int[] collapsingMargins) {
        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) child.getLayoutParams();
        int leftDiff = lp.leftMargin - collapsingMargins[0];
        int rightDiff = lp.rightMargin - collapsingMargins[1];
        int hMargins = Math.max(0, leftDiff) + Math.max(0, rightDiff);
        collapsingMargins[0] = Math.max(0, -leftDiff);
        collapsingMargins[1] = Math.max(0, -rightDiff);
        child.measure(ViewGroup.getChildMeasureSpec(parentWidthMeasureSpec, getPaddingLeft() + getPaddingRight() + hMargins + widthUsed, lp.width), ViewGroup.getChildMeasureSpec(parentHeightMeasureSpec, getPaddingTop() + getPaddingBottom() + lp.topMargin + lp.bottomMargin + heightUsed, lp.height));
        return child.getMeasuredWidth() + hMargins;
    }

    public final boolean K() {
        if (!this.M) {
            return false;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View child = getChildAt(i2);
            if (L(child) && child.getMeasuredWidth() > 0 && child.getMeasuredHeight() > 0) {
                return false;
            }
        }
        return true;
    }

    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int marginEndIndex;
        int marginStartIndex;
        int marginStartIndex2;
        int menuWidth;
        int titleHeight;
        int childCount;
        int childState;
        int height = 0;
        int childState2 = 0;
        int[] collapsingMargins = this.G;
        if (a1.b(this)) {
            marginStartIndex = 1;
            marginEndIndex = 0;
        } else {
            marginStartIndex = 0;
            marginEndIndex = 1;
        }
        int navWidth = 0;
        if (L(this.e)) {
            D(this.e, widthMeasureSpec, 0, heightMeasureSpec, 0, this.p);
            navWidth = this.e.getMeasuredWidth() + s(this.e);
            height = Math.max(0, this.e.getMeasuredHeight() + t(this.e));
            childState2 = View.combineMeasuredStates(0, this.e.getMeasuredState());
        }
        if (L(this.i)) {
            D(this.i, widthMeasureSpec, 0, heightMeasureSpec, 0, this.p);
            navWidth = this.i.getMeasuredWidth() + s(this.i);
            height = Math.max(height, this.i.getMeasuredHeight() + t(this.i));
            childState2 = View.combineMeasuredStates(childState2, this.i.getMeasuredState());
        }
        int contentInsetStart = getCurrentContentInsetStart();
        int width = 0 + Math.max(contentInsetStart, navWidth);
        collapsingMargins[marginStartIndex] = Math.max(0, contentInsetStart - navWidth);
        if (L(this.f646b)) {
            char c2 = marginStartIndex;
            marginStartIndex2 = 0;
            D(this.f646b, widthMeasureSpec, width, heightMeasureSpec, 0, this.p);
            int menuWidth2 = this.f646b.getMeasuredWidth() + s(this.f646b);
            height = Math.max(height, this.f646b.getMeasuredHeight() + t(this.f646b));
            childState2 = View.combineMeasuredStates(childState2, this.f646b.getMeasuredState());
            menuWidth = menuWidth2;
        } else {
            marginStartIndex2 = 0;
            menuWidth = 0;
        }
        int contentInsetEnd = getCurrentContentInsetEnd();
        int width2 = width + Math.max(contentInsetEnd, menuWidth);
        collapsingMargins[marginEndIndex] = Math.max(marginStartIndex2, contentInsetEnd - menuWidth);
        if (L(this.j)) {
            int i2 = contentInsetEnd;
            int i3 = menuWidth;
            width2 += C(this.j, widthMeasureSpec, width2, heightMeasureSpec, 0, collapsingMargins);
            height = Math.max(height, this.j.getMeasuredHeight() + t(this.j));
            childState2 = View.combineMeasuredStates(childState2, this.j.getMeasuredState());
        } else {
            int i4 = menuWidth;
        }
        if (L(this.f)) {
            width2 += C(this.f, widthMeasureSpec, width2, heightMeasureSpec, 0, collapsingMargins);
            height = Math.max(height, this.f.getMeasuredHeight() + t(this.f));
            childState2 = View.combineMeasuredStates(childState2, this.f.getMeasuredState());
        }
        int childCount2 = getChildCount();
        int childState3 = childState2;
        int height2 = height;
        int width3 = width2;
        int i5 = 0;
        while (i5 < childCount2) {
            View child = getChildAt(i5);
            e lp = (e) child.getLayoutParams();
            if (lp.f653b != 0) {
                View view = child;
                childState = childState3;
                childCount = childCount2;
            } else if (!L(child)) {
                childState = childState3;
                childCount = childCount2;
            } else {
                e eVar = lp;
                View child2 = child;
                childCount = childCount2;
                width3 += C(child, widthMeasureSpec, width3, heightMeasureSpec, 0, collapsingMargins);
                View child3 = child2;
                height2 = Math.max(height2, child2.getMeasuredHeight() + t(child3));
                childState3 = View.combineMeasuredStates(childState3, child3.getMeasuredState());
                i5++;
                childCount2 = childCount;
            }
            childState3 = childState;
            i5++;
            childCount2 = childCount;
        }
        int childState4 = childState3;
        int i6 = childCount2;
        int titleWidth = 0;
        int titleHeight2 = 0;
        int titleVertMargins = this.s + this.t;
        int titleHorizMargins = this.q + this.r;
        if (L(this.f647c)) {
            int C2 = C(this.f647c, widthMeasureSpec, width3 + titleHorizMargins, heightMeasureSpec, titleVertMargins, collapsingMargins);
            titleWidth = this.f647c.getMeasuredWidth() + s(this.f647c);
            titleHeight2 = this.f647c.getMeasuredHeight() + t(this.f647c);
            childState4 = View.combineMeasuredStates(childState4, this.f647c.getMeasuredState());
        }
        if (L(this.d)) {
            titleWidth = Math.max(titleWidth, C(this.d, widthMeasureSpec, width3 + titleHorizMargins, heightMeasureSpec, titleHeight2 + titleVertMargins, collapsingMargins));
            int titleHeight3 = titleHeight2 + this.d.getMeasuredHeight() + t(this.d);
            childState4 = View.combineMeasuredStates(childState4, this.d.getMeasuredState());
            titleHeight = titleHeight3;
        } else {
            titleHeight = titleHeight2;
        }
        setMeasuredDimension(View.resolveSizeAndState(Math.max(width3 + titleWidth + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), widthMeasureSpec, -16777216 & childState4), K() ? 0 : View.resolveSizeAndState(Math.max(Math.max(height2, titleHeight) + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), heightMeasureSpec, childState4 << 16));
    }

    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        int i20;
        boolean z3 = p.f(this) == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i21 = width - paddingRight;
        int[] iArr = this.G;
        iArr[1] = 0;
        iArr[0] = 0;
        int g2 = p.g(this);
        int min = g2 >= 0 ? Math.min(g2, i5 - i3) : 0;
        if (!L(this.e)) {
            i7 = paddingLeft;
            i6 = i21;
        } else if (z3) {
            i6 = B(this.e, i21, iArr, min);
            i7 = paddingLeft;
        } else {
            i7 = A(this.e, paddingLeft, iArr, min);
            i6 = i21;
        }
        if (L(this.i)) {
            if (z3) {
                i6 = B(this.i, i6, iArr, min);
            } else {
                i7 = A(this.i, i7, iArr, min);
            }
        }
        if (L(this.f646b)) {
            if (z3) {
                i7 = A(this.f646b, i7, iArr, min);
            } else {
                i6 = B(this.f646b, i6, iArr, min);
            }
        }
        int currentContentInsetLeft = getCurrentContentInsetLeft();
        int currentContentInsetRight = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft - i7);
        iArr[1] = Math.max(0, currentContentInsetRight - (i21 - i6));
        int max = Math.max(i7, currentContentInsetLeft);
        int min2 = Math.min(i6, i21 - currentContentInsetRight);
        if (L(this.j)) {
            if (z3) {
                min2 = B(this.j, min2, iArr, min);
            } else {
                max = A(this.j, max, iArr, min);
            }
        }
        if (L(this.f)) {
            if (z3) {
                min2 = B(this.f, min2, iArr, min);
            } else {
                max = A(this.f, max, iArr, min);
            }
        }
        boolean L2 = L(this.f647c);
        boolean L3 = L(this.d);
        if (L2) {
            e eVar = (e) this.f647c.getLayoutParams();
            i9 = paddingRight;
            i10 = eVar.topMargin + this.f647c.getMeasuredHeight() + eVar.bottomMargin + 0;
        } else {
            i9 = paddingRight;
            i10 = 0;
        }
        if (L3) {
            e eVar2 = (e) this.d.getLayoutParams();
            i11 = width;
            i10 += eVar2.topMargin + this.d.getMeasuredHeight() + eVar2.bottomMargin;
        } else {
            i11 = width;
        }
        if (L2 || L3) {
            TextView textView = L2 ? this.f647c : this.d;
            TextView textView2 = L3 ? this.d : this.f647c;
            e eVar3 = (e) textView.getLayoutParams();
            e eVar4 = (e) textView2.getLayoutParams();
            boolean z4 = (L2 && this.f647c.getMeasuredWidth() > 0) || (L3 && this.d.getMeasuredWidth() > 0);
            int i22 = this.x & j.AppCompatTheme_windowActionBarOverlay;
            i13 = paddingLeft;
            if (i22 == 48) {
                i15 = max;
                i12 = min;
                i16 = getPaddingTop() + eVar3.topMargin + this.s;
            } else if (i22 != 80) {
                int i23 = (((height - paddingTop) - paddingBottom) - i10) / 2;
                int i24 = eVar3.topMargin;
                i12 = min;
                int i25 = this.s;
                i15 = max;
                if (i23 < i24 + i25) {
                    i23 = i24 + i25;
                } else {
                    int i26 = (((height - paddingBottom) - i10) - i23) - paddingTop;
                    int i27 = eVar3.bottomMargin;
                    int i28 = this.t;
                    if (i26 < i27 + i28) {
                        i23 = Math.max(0, i23 - ((eVar4.bottomMargin + i28) - i26));
                    }
                }
                i16 = paddingTop + i23;
            } else {
                i15 = max;
                i12 = min;
                i16 = (((height - paddingBottom) - eVar4.bottomMargin) - this.t) - i10;
            }
            if (z3) {
                int i29 = (z4 ? this.q : 0) - iArr[1];
                i8 -= Math.max(0, i29);
                iArr[1] = Math.max(0, -i29);
                if (L2) {
                    int measuredWidth = i8 - this.f647c.getMeasuredWidth();
                    int measuredHeight = this.f647c.getMeasuredHeight() + i16;
                    this.f647c.layout(measuredWidth, i16, i8, measuredHeight);
                    i19 = measuredWidth - this.r;
                    i16 = measuredHeight + ((e) this.f647c.getLayoutParams()).bottomMargin;
                } else {
                    i19 = i8;
                }
                if (L3) {
                    int i30 = i16 + ((e) this.d.getLayoutParams()).topMargin;
                    this.d.layout(i8 - this.d.getMeasuredWidth(), i30, i8, this.d.getMeasuredHeight() + i30);
                    i20 = i8 - this.r;
                } else {
                    i20 = i8;
                }
                if (z4) {
                    i8 = Math.min(i19, i20);
                }
                max = i15;
                i14 = 0;
            } else {
                i14 = 0;
                int i31 = (z4 ? this.q : 0) - iArr[0];
                max = i15 + Math.max(0, i31);
                iArr[0] = Math.max(0, -i31);
                if (L2) {
                    int measuredWidth2 = this.f647c.getMeasuredWidth() + max;
                    int measuredHeight2 = this.f647c.getMeasuredHeight() + i16;
                    this.f647c.layout(max, i16, measuredWidth2, measuredHeight2);
                    i17 = measuredWidth2 + this.r;
                    i16 = measuredHeight2 + ((e) this.f647c.getLayoutParams()).bottomMargin;
                } else {
                    i17 = max;
                }
                if (L3) {
                    int i32 = i16 + ((e) this.d.getLayoutParams()).topMargin;
                    int measuredWidth3 = this.d.getMeasuredWidth() + max;
                    this.d.layout(max, i32, measuredWidth3, this.d.getMeasuredHeight() + i32);
                    i18 = measuredWidth3 + this.r;
                } else {
                    i18 = max;
                }
                if (z4) {
                    max = Math.max(i17, i18);
                }
            }
        } else {
            i13 = paddingLeft;
            i12 = min;
            i14 = 0;
        }
        b(this.E, 3);
        int size = this.E.size();
        for (int i33 = 0; i33 < size; i33++) {
            max = A(this.E.get(i33), max, iArr, i12);
        }
        int i34 = i12;
        b(this.E, 5);
        int size2 = this.E.size();
        for (int i35 = 0; i35 < size2; i35++) {
            i8 = B(this.E.get(i35), i8, iArr, i34);
        }
        b(this.E, 1);
        int u2 = u(this.E, iArr);
        int i36 = (i13 + (((i11 - i13) - i9) / 2)) - (u2 / 2);
        int i37 = u2 + i36;
        if (i36 >= max) {
            if (i37 > i8) {
                max = i36 - (i37 - i8);
            } else {
                max = i36;
            }
        }
        int size3 = this.E.size();
        while (i14 < size3) {
            max = A(this.E.get(i14), max, iArr, i34);
            i14++;
        }
        this.E.clear();
    }

    public final int u(List<View> views, int[] collapsingMargins) {
        int collapseLeft = collapsingMargins[0];
        int collapseRight = collapsingMargins[1];
        int width = 0;
        int count = views.size();
        for (int i2 = 0; i2 < count; i2++) {
            View v2 = views.get(i2);
            e lp = (e) v2.getLayoutParams();
            int l2 = lp.leftMargin - collapseLeft;
            int r2 = lp.rightMargin - collapseRight;
            int leftMargin = Math.max(0, l2);
            int rightMargin = Math.max(0, r2);
            collapseLeft = Math.max(0, -l2);
            collapseRight = Math.max(0, -r2);
            width += v2.getMeasuredWidth() + leftMargin + rightMargin;
        }
        return width;
    }

    public final int A(View child, int left, int[] collapsingMargins, int alignmentHeight) {
        e lp = (e) child.getLayoutParams();
        int l2 = lp.leftMargin - collapsingMargins[0];
        int left2 = left + Math.max(0, l2);
        collapsingMargins[0] = Math.max(0, -l2);
        int top = q(child, alignmentHeight);
        int childWidth = child.getMeasuredWidth();
        child.layout(left2, top, left2 + childWidth, child.getMeasuredHeight() + top);
        return left2 + lp.rightMargin + childWidth;
    }

    public final int B(View child, int right, int[] collapsingMargins, int alignmentHeight) {
        e lp = (e) child.getLayoutParams();
        int r2 = lp.rightMargin - collapsingMargins[1];
        int right2 = right - Math.max(0, r2);
        collapsingMargins[1] = Math.max(0, -r2);
        int top = q(child, alignmentHeight);
        int childWidth = child.getMeasuredWidth();
        child.layout(right2 - childWidth, top, right2, child.getMeasuredHeight() + top);
        return right2 - (lp.leftMargin + childWidth);
    }

    public final int q(View child, int alignmentHeight) {
        e lp = (e) child.getLayoutParams();
        int childHeight = child.getMeasuredHeight();
        int alignmentOffset = alignmentHeight > 0 ? (childHeight - alignmentHeight) / 2 : 0;
        int r2 = r(lp.f296a);
        if (r2 == 48) {
            return getPaddingTop() - alignmentOffset;
        }
        if (r2 == 80) {
            return (((getHeight() - getPaddingBottom()) - childHeight) - lp.bottomMargin) - alignmentOffset;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int spaceAbove = (((height - paddingTop) - paddingBottom) - childHeight) / 2;
        if (spaceAbove < lp.topMargin) {
            spaceAbove = lp.topMargin;
        } else {
            int spaceBelow = (((height - paddingBottom) - childHeight) - spaceAbove) - paddingTop;
            int i2 = lp.bottomMargin;
            if (spaceBelow < i2) {
                spaceAbove = Math.max(0, spaceAbove - (i2 - spaceBelow));
            }
        }
        return paddingTop + spaceAbove;
    }

    public final int r(int gravity) {
        int vgrav = gravity & j.AppCompatTheme_windowActionBarOverlay;
        if (vgrav == 16 || vgrav == 48 || vgrav == 80) {
            return vgrav;
        }
        return this.x & j.AppCompatTheme_windowActionBarOverlay;
    }

    public final void b(List<View> views, int gravity) {
        boolean z2 = true;
        if (p.f(this) != 1) {
            z2 = false;
        }
        boolean isRtl = z2;
        int childCount = getChildCount();
        int absGrav = a.b.c.h.d.a(gravity, p.f(this));
        views.clear();
        if (isRtl) {
            for (int i2 = childCount - 1; i2 >= 0; i2--) {
                View child = getChildAt(i2);
                e lp = (e) child.getLayoutParams();
                if (lp.f653b == 0 && L(child) && p(lp.f296a) == absGrav) {
                    views.add(child);
                }
            }
            return;
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            View child2 = getChildAt(i3);
            e lp2 = (e) child2.getLayoutParams();
            if (lp2.f653b == 0 && L(child2) && p(lp2.f296a) == absGrav) {
                views.add(child2);
            }
        }
    }

    public final int p(int gravity) {
        int ld = p.f(this);
        int hGrav = a.b.c.h.d.a(gravity, ld) & 7;
        if (hGrav == 1 || hGrav == 3 || hGrav == 5) {
            return hGrav;
        }
        if (ld == 1) {
            return 5;
        }
        return 3;
    }

    public final boolean L(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public final int s(View v2) {
        ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) v2.getLayoutParams();
        return a.b.c.h.g.b(mlp) + a.b.c.h.g.a(mlp);
    }

    public final int t(View v2) {
        ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) v2.getLayoutParams();
        return mlp.topMargin + mlp.bottomMargin;
    }

    /* renamed from: n */
    public e generateLayoutParams(AttributeSet attrs) {
        return new e(getContext(), attrs);
    }

    /* renamed from: o */
    public e generateLayoutParams(ViewGroup.LayoutParams p2) {
        if (p2 instanceof e) {
            return new e((e) p2);
        }
        if (p2 instanceof a.C0017a) {
            return new e((a.C0017a) p2);
        }
        if (p2 instanceof ViewGroup.MarginLayoutParams) {
            return new e((ViewGroup.MarginLayoutParams) p2);
        }
        return new e(p2);
    }

    /* renamed from: m */
    public e generateDefaultLayoutParams() {
        return new e(-2, -2);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams p2) {
        return super.checkLayoutParams(p2) && (p2 instanceof e);
    }

    public b0 getWrapper() {
        if (this.J == null) {
            this.J = new v0(this, true);
        }
        return this.J;
    }

    public void F() {
        for (int i2 = getChildCount() - 1; i2 >= 0; i2--) {
            View child = getChildAt(i2);
            if (!(((e) child.getLayoutParams()).f653b == 2 || child == this.f646b)) {
                removeViewAt(i2);
                this.F.add(child);
            }
        }
    }

    public void a() {
        for (int i2 = this.F.size() - 1; i2 >= 0; i2--) {
            addView(this.F.get(i2));
        }
        this.F.clear();
    }

    public final boolean x(View child) {
        return child.getParent() == this || this.F.contains(child);
    }

    public void setCollapsible(boolean collapsible) {
        this.M = collapsible;
        requestLayout();
    }

    public final void h() {
        if (this.u == null) {
            this.u = new l0();
        }
    }

    public a.b.d.f.c getOuterActionMenuPresenter() {
        return this.K;
    }

    public Context getPopupContext() {
        return this.k;
    }

    public static class e extends a.C0017a {

        /* renamed from: b  reason: collision with root package name */
        public int f653b = 0;

        public e(Context c2, AttributeSet attrs) {
            super(c2, attrs);
        }

        public e(int width, int height) {
            super(width, height);
            this.f296a = 8388627;
        }

        public e(e source) {
            super((a.C0017a) source);
            this.f653b = source.f653b;
        }

        public e(a.C0017a source) {
            super(source);
        }

        public e(ViewGroup.MarginLayoutParams source) {
            super((ViewGroup.LayoutParams) source);
            a(source);
        }

        public e(ViewGroup.LayoutParams source) {
            super(source);
        }

        public void a(ViewGroup.MarginLayoutParams source) {
            this.leftMargin = source.leftMargin;
            this.topMargin = source.topMargin;
            this.rightMargin = source.rightMargin;
            this.bottomMargin = source.bottomMargin;
        }
    }

    public static class g extends a.b.c.h.a {
        public static final Parcelable.Creator<g> CREATOR = new a();
        public int d;
        public boolean e;

        public g(Parcel source, ClassLoader loader) {
            super(source, loader);
            this.d = source.readInt();
            this.e = source.readInt() != 0;
        }

        public g(Parcelable superState) {
            super(superState);
        }

        public void writeToParcel(Parcel out, int flags) {
            super.writeToParcel(out, flags);
            out.writeInt(this.d);
            out.writeInt(this.e ? 1 : 0);
        }

        public static class a implements Parcelable.ClassLoaderCreator<g> {
            /* renamed from: b */
            public g createFromParcel(Parcel in, ClassLoader loader) {
                return new g(in, loader);
            }

            /* renamed from: a */
            public g createFromParcel(Parcel in) {
                return new g(in, (ClassLoader) null);
            }

            /* renamed from: c */
            public g[] newArray(int size) {
                return new g[size];
            }
        }
    }

    public class d implements a.b.d.e.j.o {

        /* renamed from: b  reason: collision with root package name */
        public h f651b;

        /* renamed from: c  reason: collision with root package name */
        public a.b.d.e.j.j f652c;

        public d() {
        }

        public void k(Context context, h menu) {
            a.b.d.e.j.j jVar;
            h hVar = this.f651b;
            if (!(hVar == null || (jVar = this.f652c) == null)) {
                hVar.f(jVar);
            }
            this.f651b = menu;
        }

        public void i(boolean cleared) {
            if (this.f652c != null) {
                boolean found = false;
                h hVar = this.f651b;
                if (hVar != null) {
                    int count = hVar.size();
                    int i = 0;
                    while (true) {
                        if (i >= count) {
                            break;
                        } else if (this.f651b.getItem(i) == this.f652c) {
                            found = true;
                            break;
                        } else {
                            i++;
                        }
                    }
                }
                if (!found) {
                    h(this.f651b, this.f652c);
                }
            }
        }

        public void j(o.a cb) {
        }

        public boolean b(u subMenu) {
            return false;
        }

        public void a(h menu, boolean allMenusAreClosing) {
        }

        public boolean g() {
            return false;
        }

        public boolean e(h menu, a.b.d.e.j.j item) {
            Toolbar.this.g();
            ViewParent collapseButtonParent = Toolbar.this.i.getParent();
            Toolbar toolbar = Toolbar.this;
            if (collapseButtonParent != toolbar) {
                if (collapseButtonParent instanceof ViewGroup) {
                    ((ViewGroup) collapseButtonParent).removeView(toolbar.i);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.i);
            }
            Toolbar.this.j = item.getActionView();
            this.f652c = item;
            ViewParent expandedActionParent = Toolbar.this.j.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (expandedActionParent != toolbar3) {
                if (expandedActionParent instanceof ViewGroup) {
                    ((ViewGroup) expandedActionParent).removeView(toolbar3.j);
                }
                e lp = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                lp.f296a = 8388611 | (toolbar4.o & j.AppCompatTheme_windowActionBarOverlay);
                lp.f653b = 2;
                toolbar4.j.setLayoutParams(lp);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.j);
            }
            Toolbar.this.F();
            Toolbar.this.requestLayout();
            item.r(true);
            View view = Toolbar.this.j;
            if (view instanceof a.b.d.e.c) {
                ((a.b.d.e.c) view).a();
            }
            return true;
        }

        public boolean h(h menu, a.b.d.e.j.j item) {
            View view = Toolbar.this.j;
            if (view instanceof a.b.d.e.c) {
                ((a.b.d.e.c) view).d();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.j);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.i);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.j = null;
            toolbar3.a();
            this.f652c = null;
            Toolbar.this.requestLayout();
            item.r(false);
            return true;
        }
    }
}
