package a.b.c.g;

import android.support.v4.util.SimpleArrayMap;
import java.util.ConcurrentModificationException;
import java.util.Map;

public class k<K, V> {
    public static Object[] e;
    public static int f;
    public static Object[] g;
    public static int h;

    /* renamed from: b  reason: collision with root package name */
    public int[] f236b;

    /* renamed from: c  reason: collision with root package name */
    public Object[] f237c;
    public int d;

    public static int b(int[] hashes, int N, int hash) {
        try {
            return c.a(hashes, N, hash);
        } catch (ArrayIndexOutOfBoundsException e2) {
            throw new ConcurrentModificationException();
        }
    }

    public int e(Object key, int hash) {
        int N = this.d;
        if (N == 0) {
            return -1;
        }
        int index = b(this.f236b, N, hash);
        if (index < 0 || key.equals(this.f237c[index << 1])) {
            return index;
        }
        int end = index + 1;
        while (end < N && this.f236b[end] == hash) {
            if (key.equals(this.f237c[end << 1])) {
                return end;
            }
            end++;
        }
        int i = index - 1;
        while (i >= 0 && this.f236b[i] == hash) {
            if (key.equals(this.f237c[i << 1])) {
                return i;
            }
            i--;
        }
        return end ^ -1;
    }

    public int g() {
        int N = this.d;
        if (N == 0) {
            return -1;
        }
        int index = b(this.f236b, N, 0);
        if (index < 0 || this.f237c[index << 1] == null) {
            return index;
        }
        int end = index + 1;
        while (end < N && this.f236b[end] == 0) {
            if (this.f237c[end << 1] == null) {
                return end;
            }
            end++;
        }
        int i = index - 1;
        while (i >= 0 && this.f236b[i] == 0) {
            if (this.f237c[i << 1] == null) {
                return i;
            }
            i--;
        }
        return end ^ -1;
    }

    public final void a(int size) {
        if (size == 8) {
            synchronized (a.class) {
                if (g != null) {
                    Object[] array = g;
                    this.f237c = array;
                    g = (Object[]) array[0];
                    this.f236b = (int[]) array[1];
                    array[1] = null;
                    array[0] = null;
                    h--;
                    return;
                }
            }
        } else if (size == 4) {
            synchronized (a.class) {
                if (e != null) {
                    Object[] array2 = e;
                    this.f237c = array2;
                    e = (Object[]) array2[0];
                    this.f236b = (int[]) array2[1];
                    array2[1] = null;
                    array2[0] = null;
                    f--;
                    return;
                }
            }
        }
        this.f236b = new int[size];
        this.f237c = new Object[(size << 1)];
    }

    public static void d(int[] hashes, Object[] array, int size) {
        if (hashes.length == 8) {
            synchronized (a.class) {
                if (h < 10) {
                    array[0] = g;
                    array[1] = hashes;
                    for (int i = (size << 1) - 1; i >= 2; i--) {
                        array[i] = null;
                    }
                    g = array;
                    h++;
                }
            }
        } else if (hashes.length == 4) {
            synchronized (a.class) {
                if (f < 10) {
                    array[0] = e;
                    array[1] = hashes;
                    for (int i2 = (size << 1) - 1; i2 >= 2; i2--) {
                        array[i2] = null;
                    }
                    e = array;
                    f++;
                }
            }
        }
    }

    public k() {
        this.f236b = c.f216a;
        this.f237c = c.f218c;
        this.d = 0;
    }

    public k(int capacity) {
        if (capacity == 0) {
            this.f236b = c.f216a;
            this.f237c = c.f218c;
        } else {
            a(capacity);
        }
        this.d = 0;
    }

    public void clear() {
        if (this.d > 0) {
            int[] ohashes = this.f236b;
            Object[] oarray = this.f237c;
            int osize = this.d;
            this.f236b = c.f216a;
            this.f237c = c.f218c;
            this.d = 0;
            d(ohashes, oarray, osize);
        }
        if (this.d > 0) {
            throw new ConcurrentModificationException();
        }
    }

    public void c(int minimumCapacity) {
        int osize = this.d;
        if (this.f236b.length < minimumCapacity) {
            int[] ohashes = this.f236b;
            Object[] oarray = this.f237c;
            a(minimumCapacity);
            if (this.d > 0) {
                System.arraycopy(ohashes, 0, this.f236b, 0, osize);
                System.arraycopy(oarray, 0, this.f237c, 0, osize << 1);
            }
            d(ohashes, oarray, osize);
        }
        if (this.d != osize) {
            throw new ConcurrentModificationException();
        }
    }

    public boolean containsKey(Object key) {
        return f(key) >= 0;
    }

    public int f(Object key) {
        return key == null ? g() : e(key, key.hashCode());
    }

    public int h(Object value) {
        int N = this.d * 2;
        Object[] array = this.f237c;
        if (value == null) {
            for (int i = 1; i < N; i += 2) {
                if (array[i] == null) {
                    return i >> 1;
                }
            }
            return -1;
        }
        for (int i2 = 1; i2 < N; i2 += 2) {
            if (value.equals(array[i2])) {
                return i2 >> 1;
            }
        }
        return -1;
    }

    public boolean containsValue(Object value) {
        return h(value) >= 0;
    }

    public V get(Object key) {
        int index = f(key);
        if (index >= 0) {
            return this.f237c[(index << 1) + 1];
        }
        return null;
    }

    public K i(int index) {
        return this.f237c[index << 1];
    }

    public V l(int index) {
        return this.f237c[(index << 1) + 1];
    }

    public V k(int index, V value) {
        int index2 = (index << 1) + 1;
        V[] vArr = this.f237c;
        V old = vArr[index2];
        vArr[index2] = value;
        return old;
    }

    public boolean isEmpty() {
        return this.d <= 0;
    }

    public V put(K key, V value) {
        int index;
        int hash;
        int osize = this.d;
        if (key == null) {
            hash = 0;
            index = g();
        } else {
            hash = key.hashCode();
            index = e(key, hash);
        }
        if (index >= 0) {
            int index2 = (index << 1) + 1;
            V[] vArr = this.f237c;
            V old = vArr[index2];
            vArr[index2] = value;
            return old;
        }
        int index3 = index ^ -1;
        if (osize >= this.f236b.length) {
            int n = 4;
            if (osize >= 8) {
                n = (osize >> 1) + osize;
            } else if (osize >= 4) {
                n = 8;
            }
            int[] ohashes = this.f236b;
            Object[] oarray = this.f237c;
            a(n);
            if (osize == this.d) {
                int[] iArr = this.f236b;
                if (iArr.length > 0) {
                    System.arraycopy(ohashes, 0, iArr, 0, ohashes.length);
                    System.arraycopy(oarray, 0, this.f237c, 0, oarray.length);
                }
                d(ohashes, oarray, osize);
            } else {
                throw new ConcurrentModificationException();
            }
        }
        if (index3 < osize) {
            int[] iArr2 = this.f236b;
            System.arraycopy(iArr2, index3, iArr2, index3 + 1, osize - index3);
            Object[] objArr = this.f237c;
            System.arraycopy(objArr, index3 << 1, objArr, (index3 + 1) << 1, (this.d - index3) << 1);
        }
        int i = this.d;
        if (osize == i) {
            int[] iArr3 = this.f236b;
            if (index3 < iArr3.length) {
                iArr3[index3] = hash;
                Object[] objArr2 = this.f237c;
                objArr2[index3 << 1] = key;
                objArr2[(index3 << 1) + 1] = value;
                this.d = i + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }

    public V remove(Object key) {
        int index = f(key);
        if (index >= 0) {
            return j(index);
        }
        return null;
    }

    public V j(int index) {
        int nsize;
        Object[] objArr = this.f237c;
        Object old = objArr[(index << 1) + 1];
        int osize = this.d;
        if (osize <= 1) {
            d(this.f236b, objArr, osize);
            this.f236b = c.f216a;
            this.f237c = c.f218c;
            nsize = 0;
        } else {
            nsize = osize - 1;
            int[] iArr = this.f236b;
            int i = 8;
            if (iArr.length <= 8 || this.d >= iArr.length / 3) {
                if (index < nsize) {
                    int[] iArr2 = this.f236b;
                    System.arraycopy(iArr2, index + 1, iArr2, index, nsize - index);
                    Object[] objArr2 = this.f237c;
                    System.arraycopy(objArr2, (index + 1) << 1, objArr2, index << 1, (nsize - index) << 1);
                }
                Object[] objArr3 = this.f237c;
                objArr3[nsize << 1] = null;
                objArr3[(nsize << 1) + 1] = null;
            } else {
                if (osize > 8) {
                    i = osize + (osize >> 1);
                }
                int n = i;
                int[] ohashes = this.f236b;
                Object[] oarray = this.f237c;
                a(n);
                if (osize == this.d) {
                    if (index > 0) {
                        System.arraycopy(ohashes, 0, this.f236b, 0, index);
                        System.arraycopy(oarray, 0, this.f237c, 0, index << 1);
                    }
                    if (index < nsize) {
                        System.arraycopy(ohashes, index + 1, this.f236b, index, nsize - index);
                        System.arraycopy(oarray, (index + 1) << 1, this.f237c, index << 1, (nsize - index) << 1);
                    }
                } else {
                    throw new ConcurrentModificationException();
                }
            }
        }
        if (osize == this.d) {
            this.d = nsize;
            return old;
        }
        throw new ConcurrentModificationException();
    }

    public int size() {
        return this.d;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof k) {
            SimpleArrayMap<?, ?> map = (k) object;
            if (size() != map.size()) {
                return false;
            }
            int i = 0;
            while (i < this.d) {
                try {
                    K key = i(i);
                    V mine = l(i);
                    Object theirs = map.get(key);
                    if (mine == null) {
                        if (theirs != null || !map.containsKey(key)) {
                            return false;
                        }
                    } else if (!mine.equals(theirs)) {
                        return false;
                    }
                    i++;
                } catch (NullPointerException e2) {
                    return false;
                } catch (ClassCastException e3) {
                    return false;
                }
            }
            return true;
        } else if (!(object instanceof Map)) {
            return false;
        } else {
            Map<?, ?> map2 = (Map) object;
            if (size() != map2.size()) {
                return false;
            }
            int i2 = 0;
            while (i2 < this.d) {
                try {
                    K key2 = i(i2);
                    V mine2 = l(i2);
                    Object theirs2 = map2.get(key2);
                    if (mine2 == null) {
                        if (theirs2 != null || !map2.containsKey(key2)) {
                            return false;
                        }
                    } else if (!mine2.equals(theirs2)) {
                        return false;
                    }
                    i2++;
                } catch (NullPointerException e4) {
                    return false;
                } catch (ClassCastException e5) {
                    return false;
                }
            }
            return true;
        }
    }

    public int hashCode() {
        int[] hashes = this.f236b;
        Object[] array = this.f237c;
        int result = 0;
        int i = 0;
        int v = 1;
        int s = this.d;
        while (i < s) {
            Object value = array[v];
            result += hashes[i] ^ (value == null ? 0 : value.hashCode());
            i++;
            v += 2;
        }
        return result;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder buffer = new StringBuilder(this.d * 28);
        buffer.append('{');
        for (int i = 0; i < this.d; i++) {
            if (i > 0) {
                buffer.append(", ");
            }
            Object key = i(i);
            if (key != this) {
                buffer.append(key);
            } else {
                buffer.append("(this Map)");
            }
            buffer.append('=');
            Object value = l(i);
            if (value != this) {
                buffer.append(value);
            } else {
                buffer.append("(this Map)");
            }
        }
        buffer.append('}');
        return buffer.toString();
    }
}
