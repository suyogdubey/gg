package android.support.v7.view.menu;

import a.b.d.e.j.h;
import a.b.d.e.j.j;
import a.b.d.e.j.p;
import a.b.d.e.j.s;
import a.b.d.f.f0;
import a.b.d.f.w0;
import a.b.d.f.y;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.support.v7.widget.ActionMenuView;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class ActionMenuItemView extends y implements p.a, View.OnClickListener, ActionMenuView.a {
    public j e;
    public CharSequence f;
    public Drawable g;
    public h.b h;
    public f0 i;
    public b j;
    public boolean k;
    public boolean l;
    public int m;
    public int n;
    public int o;

    public static abstract class b {
        public abstract s a();
    }

    public ActionMenuItemView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ActionMenuItemView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        Resources res = context.getResources();
        this.k = g();
        TypedArray a2 = context.obtainStyledAttributes(attrs, a.b.d.b.j.ActionMenuItemView, defStyle, 0);
        this.m = a2.getDimensionPixelSize(a.b.d.b.j.ActionMenuItemView_android_minWidth, 0);
        a2.recycle();
        this.o = (int) ((32.0f * res.getDisplayMetrics().density) + 0.5f);
        setOnClickListener(this);
        this.n = -1;
        setSaveEnabled(false);
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        this.k = g();
        h();
    }

    public final boolean g() {
        Configuration config = getContext().getResources().getConfiguration();
        int widthDp = config.screenWidthDp;
        return widthDp >= 480 || (widthDp >= 640 && config.screenHeightDp >= 480) || config.orientation == 2;
    }

    public void setPadding(int l2, int t, int r, int b2) {
        this.n = l2;
        super.setPadding(l2, t, r, b2);
    }

    public j getItemData() {
        return this.e;
    }

    public void d(j itemData, int menuType) {
        this.e = itemData;
        setIcon(itemData.getIcon());
        setTitle(itemData.i(this));
        setId(itemData.getItemId());
        setVisibility(itemData.isVisible() ? 0 : 8);
        setEnabled(itemData.isEnabled());
        if (itemData.hasSubMenu() && this.i == null) {
            this.i = new a();
        }
    }

    public boolean onTouchEvent(MotionEvent e2) {
        f0 f0Var;
        if (!this.e.hasSubMenu() || (f0Var = this.i) == null || !f0Var.onTouch(this, e2)) {
            return super.onTouchEvent(e2);
        }
        return true;
    }

    public void onClick(View v) {
        h.b bVar = this.h;
        if (bVar != null) {
            bVar.c(this.e);
        }
    }

    public void setItemInvoker(h.b invoker) {
        this.h = invoker;
    }

    public void setPopupCallback(b popupCallback) {
        this.j = popupCallback;
    }

    public boolean c() {
        return true;
    }

    public void setCheckable(boolean checkable) {
    }

    public void setChecked(boolean checked) {
    }

    public void setExpandedFormat(boolean expandedFormat) {
        if (this.l != expandedFormat) {
            this.l = expandedFormat;
            j jVar = this.e;
            if (jVar != null) {
                jVar.c();
            }
        }
    }

    public final void h() {
        boolean z = true;
        boolean visible = !TextUtils.isEmpty(this.f);
        if (this.g != null && (!this.e.A() || (!this.k && !this.l))) {
            z = false;
        }
        boolean visible2 = visible & z;
        CharSequence charSequence = null;
        setText(visible2 ? this.f : null);
        CharSequence contentDescription = this.e.getContentDescription();
        if (TextUtils.isEmpty(contentDescription)) {
            setContentDescription(visible2 ? null : this.e.getTitle());
        } else {
            setContentDescription(contentDescription);
        }
        CharSequence tooltipText = this.e.getTooltipText();
        if (TextUtils.isEmpty(tooltipText)) {
            if (!visible2) {
                charSequence = this.e.getTitle();
            }
            w0.a(this, charSequence);
            return;
        }
        w0.a(this, tooltipText);
    }

    public void setIcon(Drawable icon) {
        this.g = icon;
        if (icon != null) {
            int width = icon.getIntrinsicWidth();
            int height = icon.getIntrinsicHeight();
            int i2 = this.o;
            if (width > i2) {
                float scale = ((float) i2) / ((float) width);
                width = this.o;
                height = (int) (((float) height) * scale);
            }
            int i3 = this.o;
            if (height > i3) {
                float scale2 = ((float) i3) / ((float) height);
                height = this.o;
                width = (int) (((float) width) * scale2);
            }
            icon.setBounds(0, 0, width, height);
        }
        setCompoundDrawables(icon, (Drawable) null, (Drawable) null, (Drawable) null);
        h();
    }

    public boolean f() {
        return !TextUtils.isEmpty(getText());
    }

    public void setTitle(CharSequence title) {
        this.f = title;
        h();
    }

    public boolean a() {
        return f() && this.e.getIcon() == null;
    }

    public boolean b() {
        return f();
    }

    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int i2;
        boolean textVisible = f();
        if (textVisible && (i2 = this.n) >= 0) {
            super.setPadding(i2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int widthMode = View.MeasureSpec.getMode(widthMeasureSpec);
        int widthSize = View.MeasureSpec.getSize(widthMeasureSpec);
        int oldMeasuredWidth = getMeasuredWidth();
        int targetWidth = widthMode == Integer.MIN_VALUE ? Math.min(widthSize, this.m) : this.m;
        if (widthMode != 1073741824 && this.m > 0 && oldMeasuredWidth < targetWidth) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(targetWidth, 1073741824), heightMeasureSpec);
        }
        if (!textVisible && this.g != null) {
            super.setPadding((getMeasuredWidth() - this.g.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
    }

    public class a extends f0 {
        public a() {
            super(ActionMenuItemView.this);
        }

        public s b() {
            b bVar = ActionMenuItemView.this.j;
            if (bVar != null) {
                return bVar.a();
            }
            return null;
        }

        public boolean c() {
            s popup;
            ActionMenuItemView actionMenuItemView = ActionMenuItemView.this;
            h.b bVar = actionMenuItemView.h;
            if (bVar == null || !bVar.c(actionMenuItemView.e) || (popup = b()) == null || !popup.c()) {
                return false;
            }
            return true;
        }
    }

    public void onRestoreInstanceState(Parcelable state) {
        super.onRestoreInstanceState((Parcelable) null);
    }
}
