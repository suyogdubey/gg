package android.arch.lifecycle;

import a.a.b.a;
import a.a.b.c;
import a.a.b.e;

public class ReflectiveGenericLifecycleObserver implements GenericLifecycleObserver {

    /* renamed from: a  reason: collision with root package name */
    public final Object f569a;

    /* renamed from: b  reason: collision with root package name */
    public final a f570b;

    public void g(e source, c.a event) {
        this.f570b.a(source, event, this.f569a);
    }
}
