package b.a.f;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;
import androidx.cardview.widget.CardView;

public class b implements e {
    public void m(d cardView, Context context, ColorStateList backgroundColor, float radius, float elevation, float maxElevation) {
        ((CardView.a) cardView).e(new f(backgroundColor, radius));
        View view = ((CardView.a) cardView).b();
        view.setClipToOutline(true);
        view.setElevation(elevation);
        k(cardView, maxElevation);
    }

    public void n(d cardView, float radius) {
        o(cardView).h(radius);
    }

    public void l() {
    }

    public void k(d cardView, float maxElevation) {
        o(cardView).g(maxElevation, ((CardView.a) cardView).d(), ((CardView.a) cardView).c());
        p(cardView);
    }

    public float a(d cardView) {
        return o(cardView).c();
    }

    public float g(d cardView) {
        return b(cardView) * 2.0f;
    }

    public float e(d cardView) {
        return b(cardView) * 2.0f;
    }

    public float b(d cardView) {
        return o(cardView).d();
    }

    public void j(d cardView, float elevation) {
        ((CardView.a) cardView).b().setElevation(elevation);
    }

    public float f(d cardView) {
        return ((CardView.a) cardView).b().getElevation();
    }

    public void p(d cardView) {
        if (!((CardView.a) cardView).d()) {
            ((CardView.a) cardView).g(0, 0, 0, 0);
            return;
        }
        float elevation = a(cardView);
        float radius = b(cardView);
        int hPadding = (int) Math.ceil((double) g.c(elevation, radius, ((CardView.a) cardView).c()));
        int vPadding = (int) Math.ceil((double) g.d(elevation, radius, ((CardView.a) cardView).c()));
        ((CardView.a) cardView).g(hPadding, vPadding, hPadding, vPadding);
    }

    public void h(d cardView) {
        k(cardView, a(cardView));
    }

    public void c(d cardView) {
        k(cardView, a(cardView));
    }

    public void d(d cardView, ColorStateList color) {
        o(cardView).f(color);
    }

    public ColorStateList i(d cardView) {
        return o(cardView).b();
    }

    public final f o(d cardView) {
        return (f) ((CardView.a) cardView).a();
    }
}
