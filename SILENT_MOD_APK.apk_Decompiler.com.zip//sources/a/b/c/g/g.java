package a.b.c.g;

import java.util.LinkedHashMap;
import java.util.Locale;

public class g<K, V> {

    /* renamed from: a  reason: collision with root package name */
    public final LinkedHashMap<K, V> f223a;

    /* renamed from: b  reason: collision with root package name */
    public int f224b;

    /* renamed from: c  reason: collision with root package name */
    public int f225c;
    public int d;
    public int e;
    public int f;
    public int g;
    public int h;

    public g(int maxSize) {
        if (maxSize > 0) {
            this.f225c = maxSize;
            this.f223a = new LinkedHashMap<>(0, 0.75f, true);
            return;
        }
        throw new IllegalArgumentException("maxSize <= 0");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x001b, code lost:
        a();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x001f, code lost:
        if (0 != 0) goto L_0x0022;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0021, code lost:
        return null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0022, code lost:
        monitor-enter(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:?, code lost:
        r4.e++;
        r1 = r4.f223a.put(r5, (java.lang.Object) null);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0030, code lost:
        if (r1 == null) goto L_0x0038;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0032, code lost:
        r4.f223a.put(r5, r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0038, code lost:
        r0 = r4.f224b;
        e(r5, (java.lang.Object) null);
        r4.f224b = r0 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0041, code lost:
        monitor-exit(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0042, code lost:
        if (r1 == null) goto L_0x0048;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0044, code lost:
        b();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0047, code lost:
        return r1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0048, code lost:
        g(r4.f225c);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x004d, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final V c(K r5) {
        /*
            r4 = this;
            if (r5 == 0) goto L_0x0059
            monitor-enter(r4)
            r0 = 0
            java.util.LinkedHashMap<K, V> r1 = r4.f223a     // Catch:{ all -> 0x0051 }
            java.lang.Object r1 = r1.get(r5)     // Catch:{ all -> 0x0051 }
            if (r1 == 0) goto L_0x0014
            int r0 = r4.g     // Catch:{ all -> 0x0057 }
            int r0 = r0 + 1
            r4.g = r0     // Catch:{ all -> 0x0057 }
            monitor-exit(r4)     // Catch:{ all -> 0x0057 }
            return r1
        L_0x0014:
            int r2 = r4.h     // Catch:{ all -> 0x0057 }
            int r2 = r2 + 1
            r4.h = r2     // Catch:{ all -> 0x0057 }
            monitor-exit(r4)     // Catch:{ all -> 0x0057 }
            r4.a()
            r2 = 0
            if (r2 != 0) goto L_0x0022
            return r0
        L_0x0022:
            monitor-enter(r4)
            int r0 = r4.e     // Catch:{ all -> 0x004e }
            int r0 = r0 + 1
            r4.e = r0     // Catch:{ all -> 0x004e }
            java.util.LinkedHashMap<K, V> r0 = r4.f223a     // Catch:{ all -> 0x004e }
            java.lang.Object r0 = r0.put(r5, r2)     // Catch:{ all -> 0x004e }
            r1 = r0
            if (r1 == 0) goto L_0x0038
            java.util.LinkedHashMap<K, V> r0 = r4.f223a     // Catch:{ all -> 0x004e }
            r0.put(r5, r1)     // Catch:{ all -> 0x004e }
            goto L_0x0041
        L_0x0038:
            int r0 = r4.f224b     // Catch:{ all -> 0x004e }
            r4.e(r5, r2)     // Catch:{ all -> 0x004e }
            int r0 = r0 + 1
            r4.f224b = r0     // Catch:{ all -> 0x004e }
        L_0x0041:
            monitor-exit(r4)     // Catch:{ all -> 0x004e }
            if (r1 == 0) goto L_0x0048
            r4.b()
            return r1
        L_0x0048:
            int r0 = r4.f225c
            r4.g(r0)
            return r2
        L_0x004e:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x004e }
            throw r0
        L_0x0051:
            r1 = move-exception
            r3 = r1
            r1 = r0
            r0 = r3
        L_0x0055:
            monitor-exit(r4)     // Catch:{ all -> 0x0057 }
            throw r0
        L_0x0057:
            r0 = move-exception
            goto L_0x0055
        L_0x0059:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "key == null"
            r0.<init>(r1)
            goto L_0x0062
        L_0x0061:
            throw r0
        L_0x0062:
            goto L_0x0061
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.g.g.c(java.lang.Object):java.lang.Object");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0027, code lost:
        if (r0 == null) goto L_0x002c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0029, code lost:
        b();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x002c, code lost:
        g(r2.f225c);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0031, code lost:
        return r0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final V d(K r3, V r4) {
        /*
            r2 = this;
            if (r3 == 0) goto L_0x0037
            if (r4 == 0) goto L_0x0037
            monitor-enter(r2)
            r0 = 0
            int r1 = r2.d     // Catch:{ all -> 0x0032 }
            int r1 = r1 + 1
            r2.d = r1     // Catch:{ all -> 0x0032 }
            int r1 = r2.f224b     // Catch:{ all -> 0x0032 }
            r2.e(r3, r4)     // Catch:{ all -> 0x0032 }
            int r1 = r1 + 1
            r2.f224b = r1     // Catch:{ all -> 0x0032 }
            java.util.LinkedHashMap<K, V> r1 = r2.f223a     // Catch:{ all -> 0x0032 }
            java.lang.Object r0 = r1.put(r3, r4)     // Catch:{ all -> 0x0032 }
            if (r0 == 0) goto L_0x0026
            int r1 = r2.f224b     // Catch:{ all -> 0x0035 }
            r2.e(r3, r0)     // Catch:{ all -> 0x0035 }
            int r1 = r1 + -1
            r2.f224b = r1     // Catch:{ all -> 0x0035 }
        L_0x0026:
            monitor-exit(r2)     // Catch:{ all -> 0x0035 }
            if (r0 == 0) goto L_0x002c
            r2.b()
        L_0x002c:
            int r1 = r2.f225c
            r2.g(r1)
            return r0
        L_0x0032:
            r1 = move-exception
        L_0x0033:
            monitor-exit(r2)     // Catch:{ all -> 0x0035 }
            throw r1
        L_0x0035:
            r1 = move-exception
            goto L_0x0033
        L_0x0037:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "key == null || value == null"
            r0.<init>(r1)
            goto L_0x0040
        L_0x003f:
            throw r0
        L_0x0040:
            goto L_0x003f
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.g.g.d(java.lang.Object, java.lang.Object):java.lang.Object");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0073, code lost:
        throw new java.lang.IllegalStateException(getClass().getName() + ".sizeOf() is reporting inconsistent results!");
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void g(int r6) {
        /*
            r5 = this;
            r0 = 0
            r1 = r0
        L_0x0002:
            monitor-enter(r5)
            int r2 = r5.f224b     // Catch:{ all -> 0x0074 }
            if (r2 < 0) goto L_0x0055
            java.util.LinkedHashMap<K, V> r2 = r5.f223a     // Catch:{ all -> 0x0074 }
            boolean r2 = r2.isEmpty()     // Catch:{ all -> 0x0074 }
            if (r2 == 0) goto L_0x0013
            int r2 = r5.f224b     // Catch:{ all -> 0x0074 }
            if (r2 != 0) goto L_0x0055
        L_0x0013:
            int r2 = r5.f224b     // Catch:{ all -> 0x0074 }
            if (r2 <= r6) goto L_0x0053
            java.util.LinkedHashMap<K, V> r2 = r5.f223a     // Catch:{ all -> 0x0074 }
            boolean r2 = r2.isEmpty()     // Catch:{ all -> 0x0074 }
            if (r2 == 0) goto L_0x0020
            goto L_0x0053
        L_0x0020:
            java.util.LinkedHashMap<K, V> r2 = r5.f223a     // Catch:{ all -> 0x0074 }
            java.util.Set r2 = r2.entrySet()     // Catch:{ all -> 0x0074 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ all -> 0x0074 }
            java.lang.Object r2 = r2.next()     // Catch:{ all -> 0x0074 }
            java.util.Map$Entry r2 = (java.util.Map.Entry) r2     // Catch:{ all -> 0x0074 }
            java.lang.Object r0 = r2.getKey()     // Catch:{ all -> 0x0074 }
            java.lang.Object r1 = r2.getValue()     // Catch:{ all -> 0x0051 }
            java.util.LinkedHashMap<K, V> r3 = r5.f223a     // Catch:{ all -> 0x0077 }
            r3.remove(r0)     // Catch:{ all -> 0x0077 }
            int r3 = r5.f224b     // Catch:{ all -> 0x0077 }
            r5.e(r0, r1)     // Catch:{ all -> 0x0077 }
            int r3 = r3 + -1
            r5.f224b = r3     // Catch:{ all -> 0x0077 }
            int r3 = r5.f     // Catch:{ all -> 0x0077 }
            int r3 = r3 + 1
            r5.f = r3     // Catch:{ all -> 0x0077 }
            monitor-exit(r5)     // Catch:{ all -> 0x0077 }
            r5.b()
            goto L_0x0002
        L_0x0051:
            r2 = move-exception
            goto L_0x0075
        L_0x0053:
            monitor-exit(r5)     // Catch:{ all -> 0x0074 }
            return
        L_0x0055:
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException     // Catch:{ all -> 0x0074 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x0074 }
            r3.<init>()     // Catch:{ all -> 0x0074 }
            java.lang.Class r4 = r5.getClass()     // Catch:{ all -> 0x0074 }
            java.lang.String r4 = r4.getName()     // Catch:{ all -> 0x0074 }
            r3.append(r4)     // Catch:{ all -> 0x0074 }
            java.lang.String r4 = ".sizeOf() is reporting inconsistent results!"
            r3.append(r4)     // Catch:{ all -> 0x0074 }
            java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x0074 }
            r2.<init>(r3)     // Catch:{ all -> 0x0074 }
            throw r2     // Catch:{ all -> 0x0074 }
        L_0x0074:
            r2 = move-exception
        L_0x0075:
            monitor-exit(r5)     // Catch:{ all -> 0x0077 }
            throw r2
        L_0x0077:
            r2 = move-exception
            goto L_0x0075
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.g.g.g(int):void");
    }

    public void b() {
    }

    public Object a() {
        return null;
    }

    public final int e(K key, V value) {
        f();
        if (1 >= 0) {
            return 1;
        }
        throw new IllegalStateException("Negative size: " + key + "=" + value);
    }

    public int f() {
        return 1;
    }

    public final synchronized String toString() {
        int accesses;
        accesses = this.g + this.h;
        return String.format(Locale.US, "LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]", new Object[]{Integer.valueOf(this.f225c), Integer.valueOf(this.g), Integer.valueOf(this.h), Integer.valueOf(accesses != 0 ? (this.g * 100) / accesses : 0)});
    }
}
