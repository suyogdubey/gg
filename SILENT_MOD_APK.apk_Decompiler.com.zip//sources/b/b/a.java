package b.b;

import android.os.Parcelable;
import java.lang.reflect.InvocationTargetException;

public abstract class a {
    public abstract void a();

    public abstract a b();

    public abstract byte[] f();

    public abstract boolean h(int i);

    public abstract int j();

    public abstract <T extends Parcelable> T l();

    public abstract String n();

    public abstract void q(int i);

    public abstract void s(byte[] bArr);

    public abstract void u(int i);

    public abstract void w(Parcelable parcelable);

    public abstract void y(String str);

    public boolean e() {
        return false;
    }

    public void r() {
    }

    public void t(byte[] b2, int fieldId) {
        q(fieldId);
        s(b2);
    }

    public void v(int val, int fieldId) {
        q(fieldId);
        u(val);
    }

    public void z(String val, int fieldId) {
        q(fieldId);
        y(val);
    }

    public void x(Parcelable p, int fieldId) {
        q(fieldId);
        w(p);
    }

    public int k(int def, int fieldId) {
        if (!h(fieldId)) {
            return def;
        }
        return j();
    }

    public String o(String def, int fieldId) {
        if (!h(fieldId)) {
            return def;
        }
        return n();
    }

    public byte[] g(byte[] def, int fieldId) {
        if (!h(fieldId)) {
            return def;
        }
        return f();
    }

    public <T extends Parcelable> T m(T def, int fieldId) {
        if (!h(fieldId)) {
            return def;
        }
        return l();
    }

    public void B(c p) {
        if (p == null) {
            y((String) null);
            return;
        }
        C(p);
        a subParcel = b();
        A(p, subParcel);
        subParcel.a();
    }

    public final void C(c p) {
        try {
            y(d(p.getClass()).getName());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(p.getClass().getSimpleName() + " does not have a Parcelizer", e);
        }
    }

    public <T extends c> T p() {
        String name = n();
        if (name == null) {
            return null;
        }
        return i(name, b());
    }

    public static <T extends c> T i(String parcelCls, a versionedParcel) {
        Class<a> cls = a.class;
        try {
            return (c) Class.forName(parcelCls, true, cls.getClassLoader()).getDeclaredMethod("read", new Class[]{cls}).invoke((Object) null, new Object[]{versionedParcel});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    public static <T extends c> void A(T val, a versionedParcel) {
        try {
            c(val).getDeclaredMethod("write", new Class[]{val.getClass(), a.class}).invoke((Object) null, new Object[]{val, versionedParcel});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    public static <T extends c> Class c(T val) {
        return d(val.getClass());
    }

    public static Class d(Class<? extends c> cls) {
        return Class.forName(String.format("%s.%sParcelizer", new Object[]{cls.getPackage().getName(), cls.getSimpleName()}), false, cls.getClassLoader());
    }
}
