package b.a.f;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import b.a.f.g;

public class a extends c {

    /* renamed from: b.a.f.a$a  reason: collision with other inner class name */
    public class C0025a implements g.a {
        public C0025a(a this$0) {
        }

        public void a(Canvas canvas, RectF bounds, float cornerRadius, Paint paint) {
            canvas.drawRoundRect(bounds, cornerRadius, cornerRadius, paint);
        }
    }

    public void l() {
        g.r = new C0025a(this);
    }
}
