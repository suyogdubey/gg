package a.b.c.h;

import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.ViewParent;

public final class s {
    public static boolean f(ViewParent parent, View child, View target, int nestedScrollAxes, int type) {
        if (parent instanceof k) {
            return ((k) parent).n(child, target, nestedScrollAxes, type);
        }
        if (type != 0) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                return parent.onStartNestedScroll(child, target, nestedScrollAxes);
            } catch (AbstractMethodError e) {
                Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface " + "method onStartNestedScroll", e);
                return false;
            }
        } else if (parent instanceof l) {
            return ((l) parent).onStartNestedScroll(child, target, nestedScrollAxes);
        } else {
            return false;
        }
    }

    public static void e(ViewParent parent, View child, View target, int nestedScrollAxes, int type) {
        if (parent instanceof k) {
            ((k) parent).i(child, target, nestedScrollAxes, type);
        } else if (type != 0) {
        } else {
            if (Build.VERSION.SDK_INT >= 21) {
                try {
                    parent.onNestedScrollAccepted(child, target, nestedScrollAxes);
                } catch (AbstractMethodError e) {
                    Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface " + "method onNestedScrollAccepted", e);
                }
            } else if (parent instanceof l) {
                ((l) parent).onNestedScrollAccepted(child, target, nestedScrollAxes);
            }
        }
    }

    public static void g(ViewParent parent, View target, int type) {
        if (parent instanceof k) {
            ((k) parent).l(target, type);
        } else if (type != 0) {
        } else {
            if (Build.VERSION.SDK_INT >= 21) {
                try {
                    parent.onStopNestedScroll(target);
                } catch (AbstractMethodError e) {
                    Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface " + "method onStopNestedScroll", e);
                }
            } else if (parent instanceof l) {
                ((l) parent).onStopNestedScroll(target);
            }
        }
    }

    public static void d(ViewParent parent, View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed, int type) {
        if (parent instanceof k) {
            ((k) parent).k(target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed, type);
        } else if (type != 0) {
        } else {
            if (Build.VERSION.SDK_INT >= 21) {
                try {
                    parent.onNestedScroll(target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
                } catch (AbstractMethodError e) {
                    Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface " + "method onNestedScroll", e);
                }
            } else if (parent instanceof l) {
                ((l) parent).onNestedScroll(target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
            }
        }
    }

    public static void c(ViewParent parent, View target, int dx, int dy, int[] consumed, int type) {
        if (parent instanceof k) {
            ((k) parent).m(target, dx, dy, consumed, type);
        } else if (type != 0) {
        } else {
            if (Build.VERSION.SDK_INT >= 21) {
                try {
                    parent.onNestedPreScroll(target, dx, dy, consumed);
                } catch (AbstractMethodError e) {
                    Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface " + "method onNestedPreScroll", e);
                }
            } else if (parent instanceof l) {
                ((l) parent).onNestedPreScroll(target, dx, dy, consumed);
            }
        }
    }

    public static boolean a(ViewParent parent, View target, float velocityX, float velocityY, boolean consumed) {
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                return parent.onNestedFling(target, velocityX, velocityY, consumed);
            } catch (AbstractMethodError e) {
                Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface " + "method onNestedFling", e);
                return false;
            }
        } else if (parent instanceof l) {
            return ((l) parent).onNestedFling(target, velocityX, velocityY, consumed);
        } else {
            return false;
        }
    }

    public static boolean b(ViewParent parent, View target, float velocityX, float velocityY) {
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                return parent.onNestedPreFling(target, velocityX, velocityY);
            } catch (AbstractMethodError e) {
                Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface " + "method onNestedPreFling", e);
                return false;
            }
        } else if (parent instanceof l) {
            return ((l) parent).onNestedPreFling(target, velocityX, velocityY);
        } else {
            return false;
        }
    }
}
