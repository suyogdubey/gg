package a.b.d.f;

import a.b.c.h.o;
import a.b.c.i.l;
import a.b.d.b.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;

public class d extends AutoCompleteTextView implements o {
    public static final int[] d = {16843126};

    /* renamed from: b  reason: collision with root package name */
    public final e f445b;

    /* renamed from: c  reason: collision with root package name */
    public final x f446c;

    public d(Context context, AttributeSet attrs) {
        this(context, attrs, a.autoCompleteTextViewStyle);
    }

    public d(Context context, AttributeSet attrs, int defStyleAttr) {
        super(q0.b(context), attrs, defStyleAttr);
        t0 a2 = t0.t(getContext(), attrs, d, defStyleAttr, 0);
        if (a2.q(0)) {
            setDropDownBackgroundDrawable(a2.f(0));
        }
        a2.u();
        e eVar = new e(this);
        this.f445b = eVar;
        eVar.e(attrs, defStyleAttr);
        x xVar = new x(this);
        this.f446c = xVar;
        xVar.k(attrs, defStyleAttr);
        this.f446c.b();
    }

    public void setDropDownBackgroundResource(int resId) {
        setDropDownBackgroundDrawable(a.b.d.c.a.a.d(getContext(), resId));
    }

    public void setBackgroundResource(int resId) {
        super.setBackgroundResource(resId);
        e eVar = this.f445b;
        if (eVar != null) {
            eVar.g(resId);
        }
    }

    public void setBackgroundDrawable(Drawable background) {
        super.setBackgroundDrawable(background);
        e eVar = this.f445b;
        if (eVar != null) {
            eVar.f();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList tint) {
        e eVar = this.f445b;
        if (eVar != null) {
            eVar.i(tint);
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        e eVar = this.f445b;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode tintMode) {
        e eVar = this.f445b;
        if (eVar != null) {
            eVar.j(tintMode);
        }
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        e eVar = this.f445b;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        e eVar = this.f445b;
        if (eVar != null) {
            eVar.b();
        }
        x xVar = this.f446c;
        if (xVar != null) {
            xVar.b();
        }
    }

    public void setTextAppearance(Context context, int resId) {
        super.setTextAppearance(context, resId);
        x xVar = this.f446c;
        if (xVar != null) {
            xVar.n(context, resId);
        }
    }

    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(outAttrs);
        l.a(onCreateInputConnection, outAttrs, this);
        return onCreateInputConnection;
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback actionModeCallback) {
        super.setCustomSelectionActionModeCallback(l.k(this, actionModeCallback));
    }
}
