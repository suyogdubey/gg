package c.a;

import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

public class c {
    public static String b(byte[] bytes) {
        char[] hexArray = "0123456789abcdef".toCharArray();
        char[] hexChars = new char[(bytes.length * 2)];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 255;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[(j * 2) + 1] = hexArray[v & 15];
        }
        return new String(hexChars);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0022, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:?, code lost:
        r1.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
        throw r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:?, code lost:
        r1.close();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String g(java.io.InputStream r4) {
        /*
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.io.BufferedReader r1 = new java.io.BufferedReader     // Catch:{ IOException -> 0x0029 }
            java.io.InputStreamReader r2 = new java.io.InputStreamReader     // Catch:{ IOException -> 0x0029 }
            r2.<init>(r4)     // Catch:{ IOException -> 0x0029 }
            r1.<init>(r2)     // Catch:{ IOException -> 0x0029 }
            java.lang.String r2 = ""
        L_0x0011:
            java.lang.String r3 = r1.readLine()     // Catch:{ all -> 0x0020 }
            r2 = r3
            if (r3 == 0) goto L_0x001c
            r0.append(r2)     // Catch:{ all -> 0x0020 }
            goto L_0x0011
        L_0x001c:
            r1.close()     // Catch:{ IOException -> 0x0029 }
            goto L_0x002a
        L_0x0020:
            r2 = move-exception
            throw r2     // Catch:{ all -> 0x0022 }
        L_0x0022:
            r2 = move-exception
            r1.close()     // Catch:{ all -> 0x0027 }
            goto L_0x0028
        L_0x0027:
            r3 = move-exception
        L_0x0028:
            throw r2     // Catch:{ IOException -> 0x0029 }
        L_0x0029:
            r1 = move-exception
        L_0x002a:
            java.lang.String r1 = r0.toString()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: c.a.c.g(java.io.InputStream):java.lang.String");
    }

    public static String a(String data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.reset();
            md.update(data.getBytes(StandardCharsets.UTF_8));
            return b(md.digest()).toUpperCase();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    public static byte[] e(byte[] srcdata) {
        try {
            SecretKeySpec skey = new SecretKeySpec("22P9ULFDKPJ70G46".getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(2, skey);
            return cipher.doFinal(srcdata);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        } catch (InvalidKeyException e2) {
            e2.printStackTrace();
            return null;
        } catch (NoSuchPaddingException e3) {
            e3.printStackTrace();
            return null;
        } catch (BadPaddingException e4) {
            e4.printStackTrace();
            return null;
        } catch (IllegalBlockSizeException e5) {
            e5.printStackTrace();
            return null;
        }
    }

    public static String f(String data, String sign) {
        char[] key = sign.toCharArray();
        char[] out = d(data).toCharArray();
        for (int i = 0; i < out.length; i++) {
            out[i] = (char) (key[i % key.length] ^ out[i]);
        }
        return new String(out);
    }

    public static String h(String s) {
        return Base64.encodeToString(s.getBytes(StandardCharsets.UTF_8), 2);
    }

    public static String i(byte[] s) {
        return Base64.encodeToString(s, 2);
    }

    public static byte[] c(String s) {
        return Base64.decode(s, 2);
    }

    public static String d(String s) {
        return new String(Base64.decode(s, 2), StandardCharsets.UTF_8);
    }
}
