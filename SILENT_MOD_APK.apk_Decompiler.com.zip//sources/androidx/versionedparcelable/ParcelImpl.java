package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import b.b.b;
import b.b.c;

public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new a();

    /* renamed from: b  reason: collision with root package name */
    public final c f660b;

    public ParcelImpl(Parcel in) {
        this.f660b = new b(in).p();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        new b(dest).B(this.f660b);
    }

    public static class a implements Parcelable.Creator<ParcelImpl> {
        /* renamed from: a */
        public ParcelImpl createFromParcel(Parcel in) {
            return new ParcelImpl(in);
        }

        /* renamed from: b */
        public ParcelImpl[] newArray(int size) {
            return new ParcelImpl[size];
        }
    }
}
