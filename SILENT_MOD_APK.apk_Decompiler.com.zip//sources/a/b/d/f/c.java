package a.b.d.f;

import a.b.c.h.c;
import a.b.d.b.g;
import a.b.d.e.j.h;
import a.b.d.e.j.j;
import a.b.d.e.j.n;
import a.b.d.e.j.o;
import a.b.d.e.j.p;
import a.b.d.e.j.s;
import a.b.d.e.j.u;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.widget.ActionMenuView;
import android.util.AttributeSet;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public class c extends a.b.d.e.j.b implements c.a {
    public int A;
    public d j;
    public Drawable k;
    public boolean l;
    public boolean m;
    public boolean n;
    public int o;
    public int p;
    public int q;
    public boolean r;
    public int s;
    public final SparseBooleanArray t = new SparseBooleanArray();
    public View u;
    public e v;
    public a w;
    public C0023c x;
    public b y;
    public final f z = new f();

    public c(Context context) {
        super(context, g.abc_action_menu_layout, g.abc_action_menu_item_layout);
    }

    public void k(Context context, h menu) {
        super.k(context, menu);
        Resources res = context.getResources();
        a.b.d.e.a abp = a.b.d.e.a.b(context);
        if (!this.n) {
            this.m = abp.h();
        }
        this.o = abp.c();
        this.q = abp.d();
        int width = this.o;
        if (this.m) {
            if (this.j == null) {
                d dVar = new d(this.f392b);
                this.j = dVar;
                if (this.l) {
                    dVar.setImageDrawable(this.k);
                    this.k = null;
                    this.l = false;
                }
                int spec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.j.measure(spec, spec);
            }
            width -= this.j.getMeasuredWidth();
        } else {
            this.j = null;
        }
        this.p = width;
        this.s = (int) (res.getDisplayMetrics().density * 56.0f);
        this.u = null;
    }

    public void E() {
        this.q = a.b.d.e.a.b(this.f393c).d();
        h hVar = this.d;
        if (hVar != null) {
            hVar.K(true);
        }
    }

    public void I(boolean reserveOverflow) {
        this.m = reserveOverflow;
        this.n = true;
    }

    public void F(boolean isExclusive) {
        this.r = isExclusive;
    }

    public void H(Drawable icon) {
        d dVar = this.j;
        if (dVar != null) {
            dVar.setImageDrawable(icon);
            return;
        }
        this.l = true;
        this.k = icon;
    }

    public Drawable z() {
        d dVar = this.j;
        if (dVar != null) {
            return dVar.getDrawable();
        }
        if (this.l) {
            return this.k;
        }
        return null;
    }

    public p o(ViewGroup root) {
        p oldMenuView = this.i;
        p result = super.o(root);
        if (oldMenuView != result) {
            ((ActionMenuView) result).setPresenter(this);
        }
        return result;
    }

    public View n(j item, View convertView, ViewGroup parent) {
        View actionView = item.getActionView();
        if (actionView == null || item.j()) {
            actionView = super.n(item, convertView, parent);
        }
        actionView.setVisibility(item.isActionViewExpanded() ? 8 : 0);
        ActionMenuView menuParent = (ActionMenuView) parent;
        ViewGroup.LayoutParams lp = actionView.getLayoutParams();
        if (!menuParent.checkLayoutParams(lp)) {
            actionView.setLayoutParams(menuParent.m(lp));
        }
        return actionView;
    }

    public void d(j item, p.a itemView) {
        itemView.d(item, 0);
        ActionMenuItemView actionItemView = (ActionMenuItemView) itemView;
        actionItemView.setItemInvoker((ActionMenuView) this.i);
        if (this.y == null) {
            this.y = new b();
        }
        actionItemView.setPopupCallback(this.y);
    }

    public boolean q(int childIndex, j item) {
        return item.l();
    }

    public void i(boolean cleared) {
        p pVar;
        super.i(cleared);
        ((View) this.i).requestLayout();
        h hVar = this.d;
        if (hVar != null) {
            ArrayList<j> s2 = hVar.s();
            int count = s2.size();
            for (int i = 0; i < count; i++) {
                a.b.c.h.c provider = s2.get(i).a();
                if (provider != null) {
                    provider.i(this);
                }
            }
        }
        h hVar2 = this.d;
        ArrayList<j> z2 = hVar2 != null ? hVar2.z() : null;
        boolean hasOverflow = false;
        if (this.m && z2 != null) {
            int count2 = z2.size();
            boolean z3 = false;
            if (count2 == 1) {
                hasOverflow = !z2.get(0).isActionViewExpanded();
            } else {
                if (count2 > 0) {
                    z3 = true;
                }
                hasOverflow = z3;
            }
        }
        if (hasOverflow) {
            if (this.j == null) {
                this.j = new d(this.f392b);
            }
            ViewGroup parent = (ViewGroup) this.j.getParent();
            if (parent != this.i) {
                if (parent != null) {
                    parent.removeView(this.j);
                }
                ActionMenuView menuView = (ActionMenuView) this.i;
                menuView.addView(this.j, menuView.D());
            }
        } else {
            d dVar = this.j;
            if (dVar != null && dVar.getParent() == (pVar = this.i)) {
                ((ViewGroup) pVar).removeView(this.j);
            }
        }
        ((ActionMenuView) this.i).setOverflowReserved(this.m);
    }

    public boolean l(ViewGroup parent, int childIndex) {
        if (parent.getChildAt(childIndex) == this.j) {
            return false;
        }
        super.l(parent, childIndex);
        return true;
    }

    /* JADX WARNING: type inference failed for: r2v3, types: [android.view.Menu] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean b(a.b.d.e.j.u r8) {
        /*
            r7 = this;
            boolean r0 = r8.hasVisibleItems()
            r1 = 0
            if (r0 != 0) goto L_0x0008
            return r1
        L_0x0008:
            r0 = r8
        L_0x0009:
            android.view.Menu r2 = r0.e0()
            a.b.d.e.j.h r3 = r7.d
            if (r2 == r3) goto L_0x0019
            android.view.Menu r2 = r0.e0()
            r0 = r2
            a.b.d.e.j.u r0 = (a.b.d.e.j.u) r0
            goto L_0x0009
        L_0x0019:
            android.view.MenuItem r2 = r0.getItem()
            android.view.View r2 = r7.y(r2)
            if (r2 != 0) goto L_0x0024
            return r1
        L_0x0024:
            android.view.MenuItem r1 = r8.getItem()
            a.b.d.e.j.j r1 = (a.b.d.e.j.j) r1
            r1.getItemId()
            r1 = 0
            int r3 = r8.size()
            r4 = 0
        L_0x0033:
            if (r4 >= r3) goto L_0x004a
            android.view.MenuItem r5 = r8.getItem(r4)
            boolean r6 = r5.isVisible()
            if (r6 == 0) goto L_0x0047
            android.graphics.drawable.Drawable r6 = r5.getIcon()
            if (r6 == 0) goto L_0x0047
            r1 = 1
            goto L_0x004a
        L_0x0047:
            int r4 = r4 + 1
            goto L_0x0033
        L_0x004a:
            a.b.d.f.c$a r4 = new a.b.d.f.c$a
            android.content.Context r5 = r7.f393c
            r4.<init>(r5, r8, r2)
            r7.w = r4
            r4.g(r1)
            a.b.d.f.c$a r4 = r7.w
            r4.k()
            super.b(r8)
            r4 = 1
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.d.f.c.b(a.b.d.e.j.u):boolean");
    }

    public final View y(MenuItem item) {
        ViewGroup parent = (ViewGroup) this.i;
        if (parent == null) {
            return null;
        }
        int count = parent.getChildCount();
        for (int i = 0; i < count; i++) {
            View child = parent.getChildAt(i);
            if ((child instanceof p.a) && ((p.a) child).getItemData() == item) {
                return child;
            }
        }
        return null;
    }

    public boolean J() {
        h hVar;
        if (!this.m || D() || (hVar = this.d) == null || this.i == null || this.x != null || hVar.z().isEmpty()) {
            return false;
        }
        C0023c cVar = new C0023c(new e(this.f393c, this.d, this.j, true));
        this.x = cVar;
        ((View) this.i).post(cVar);
        super.b((u) null);
        return true;
    }

    public boolean A() {
        p pVar;
        C0023c cVar = this.x;
        if (cVar == null || (pVar = this.i) == null) {
            n popup = this.v;
            if (popup == null) {
                return false;
            }
            popup.b();
            return true;
        }
        ((View) pVar).removeCallbacks(cVar);
        this.x = null;
        return true;
    }

    public boolean x() {
        return A() | B();
    }

    public boolean B() {
        a aVar = this.w;
        if (aVar == null) {
            return false;
        }
        aVar.b();
        return true;
    }

    public boolean D() {
        e eVar = this.v;
        return eVar != null && eVar.d();
    }

    public boolean C() {
        return this.x != null || D();
    }

    public boolean g() {
        int itemsSize;
        ArrayList<j> arrayList;
        ViewGroup parent;
        ArrayList<j> arrayList2;
        int requiredItems;
        int itemsSize2;
        int maxActions;
        boolean isAction;
        int widthLimit;
        boolean z2;
        c cVar = this;
        h hVar = cVar.d;
        if (hVar != null) {
            arrayList = hVar.E();
            itemsSize = arrayList.size();
        } else {
            arrayList = null;
            itemsSize = 0;
        }
        int maxActions2 = cVar.q;
        int widthLimit2 = cVar.p;
        int querySpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup parent2 = (ViewGroup) cVar.i;
        int requiredItems2 = 0;
        int requestedItems = 0;
        int firstActionWidth = 0;
        boolean hasOverflow = false;
        for (int i = 0; i < itemsSize; i++) {
            j item = arrayList.get(i);
            if (item.o()) {
                requiredItems2++;
            } else if (item.n()) {
                requestedItems++;
            } else {
                hasOverflow = true;
            }
            if (cVar.r && item.isActionViewExpanded()) {
                maxActions2 = 0;
            }
        }
        if (cVar.m != 0 && (hasOverflow || requiredItems2 + requestedItems > maxActions2)) {
            maxActions2--;
        }
        int maxActions3 = maxActions2 - requiredItems2;
        SparseBooleanArray seenGroups = cVar.t;
        seenGroups.clear();
        int i2 = 0;
        while (i2 < itemsSize) {
            j item2 = arrayList.get(i2);
            if (item2.o()) {
                itemsSize2 = itemsSize;
                View v2 = cVar.n(item2, cVar.u, parent2);
                requiredItems = requiredItems2;
                if (cVar.u == null) {
                    cVar.u = v2;
                }
                v2.measure(querySpec, querySpec);
                int measuredWidth = v2.getMeasuredWidth();
                int widthLimit3 = widthLimit2 - measuredWidth;
                if (firstActionWidth == 0) {
                    firstActionWidth = measuredWidth;
                }
                View view = v2;
                int groupId = item2.getGroupId();
                if (groupId != 0) {
                    widthLimit = widthLimit3;
                    z2 = true;
                    seenGroups.put(groupId, true);
                } else {
                    widthLimit = widthLimit3;
                    z2 = true;
                }
                item2.u(z2);
                arrayList2 = arrayList;
                parent = parent2;
                widthLimit2 = widthLimit;
            } else {
                itemsSize2 = itemsSize;
                requiredItems = requiredItems2;
                if (item2.n() != 0) {
                    int groupId2 = item2.getGroupId();
                    boolean inGroup = seenGroups.get(groupId2);
                    boolean isAction2 = (maxActions3 > 0 || inGroup) && widthLimit2 > 0;
                    if (isAction2) {
                        maxActions = maxActions3;
                        View v3 = cVar.n(item2, cVar.u, parent2);
                        parent = parent2;
                        if (cVar.u == null) {
                            cVar.u = v3;
                        }
                        v3.measure(querySpec, querySpec);
                        int measuredWidth2 = v3.getMeasuredWidth();
                        widthLimit2 -= measuredWidth2;
                        if (firstActionWidth == 0) {
                            firstActionWidth = measuredWidth2;
                        }
                        isAction = isAction2 & (widthLimit2 + firstActionWidth > 0);
                    } else {
                        maxActions = maxActions3;
                        parent = parent2;
                        isAction = isAction2;
                    }
                    if (isAction && groupId2 != 0) {
                        seenGroups.put(groupId2, true);
                        arrayList2 = arrayList;
                    } else if (inGroup) {
                        seenGroups.put(groupId2, false);
                        int j2 = 0;
                        while (j2 < i2) {
                            j areYouMyGroupie = arrayList.get(j2);
                            ArrayList<j> arrayList3 = arrayList;
                            if (areYouMyGroupie.getGroupId() == groupId2) {
                                if (areYouMyGroupie.l()) {
                                    maxActions++;
                                }
                                areYouMyGroupie.u(false);
                            }
                            j2++;
                            arrayList = arrayList3;
                        }
                        arrayList2 = arrayList;
                    } else {
                        arrayList2 = arrayList;
                    }
                    if (isAction) {
                        maxActions--;
                    }
                    item2.u(isAction);
                    maxActions3 = maxActions;
                } else {
                    arrayList2 = arrayList;
                    int i3 = maxActions3;
                    parent = parent2;
                    item2.u(false);
                }
            }
            i2++;
            cVar = this;
            itemsSize = itemsSize2;
            requiredItems2 = requiredItems;
            arrayList = arrayList2;
            parent2 = parent;
        }
        return true;
    }

    public void a(h menu, boolean allMenusAreClosing) {
        x();
        super.a(menu, allMenusAreClosing);
    }

    public void G(ActionMenuView menuView) {
        this.i = menuView;
        menuView.b(this.d);
    }

    public class d extends o implements ActionMenuView.a {
        public d(Context context) {
            super(context, (AttributeSet) null, a.b.d.b.a.actionOverflowButtonStyle);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            w0.a(this, getContentDescription());
            setOnTouchListener(new a(this, c.this));
        }

        public class a extends f0 {
            public a(View src, c cVar) {
                super(src);
            }

            public s b() {
                e eVar = c.this.v;
                if (eVar == null) {
                    return null;
                }
                return eVar.c();
            }

            public boolean c() {
                c.this.J();
                return true;
            }

            public boolean d() {
                c cVar = c.this;
                if (cVar.x != null) {
                    return false;
                }
                cVar.A();
                return true;
            }
        }

        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            c.this.J();
            return true;
        }

        public boolean a() {
            return false;
        }

        public boolean b() {
            return false;
        }

        public boolean setFrame(int l, int t, int r, int b2) {
            boolean changed = super.setFrame(l, t, r, b2);
            Drawable d2 = getDrawable();
            Drawable bg = getBackground();
            if (!(d2 == null || bg == null)) {
                int width = getWidth();
                int height = getHeight();
                int halfEdge = Math.max(width, height) / 2;
                int offsetX = getPaddingLeft() - getPaddingRight();
                int centerX = (width + offsetX) / 2;
                int centerY = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                a.b.c.c.j.a.k(bg, centerX - halfEdge, centerY - halfEdge, centerX + halfEdge, centerY + halfEdge);
            }
            return changed;
        }
    }

    public class e extends n {
        public e(Context context, h menu, View anchorView, boolean overflowOnly) {
            super(context, menu, anchorView, overflowOnly, a.b.d.b.a.actionOverflowMenuStyle);
            h(8388613);
            j(c.this.z);
        }

        public void e() {
            if (c.this.d != null) {
                c.this.d.close();
            }
            c.this.v = null;
            super.e();
        }
    }

    public class a extends n {
        public a(Context context, u subMenu, View anchorView) {
            super(context, subMenu, anchorView, false, a.b.d.b.a.actionOverflowMenuStyle);
            if (!((j) subMenu.getItem()).l()) {
                View view = c.this.j;
                f(view == null ? (View) c.this.i : view);
            }
            j(c.this.z);
        }

        public void e() {
            c cVar = c.this;
            cVar.w = null;
            cVar.A = 0;
            super.e();
        }
    }

    public class f implements o.a {
        public f() {
        }

        public boolean b(h subMenu) {
            if (subMenu == null) {
                return false;
            }
            c.this.A = ((j) ((u) subMenu).getItem()).getItemId();
            o.a cb = c.this.m();
            if (cb != null) {
                return cb.b(subMenu);
            }
            return false;
        }

        public void a(h menu, boolean allMenusAreClosing) {
            if (menu instanceof u) {
                menu.D().e(false);
            }
            o.a cb = c.this.m();
            if (cb != null) {
                cb.a(menu, allMenusAreClosing);
            }
        }
    }

    /* renamed from: a.b.d.f.c$c  reason: collision with other inner class name */
    public class C0023c implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        public e f442b;

        public C0023c(e popup) {
            this.f442b = popup;
        }

        public void run() {
            if (c.this.d != null) {
                c.this.d.d();
            }
            View menuView = (View) c.this.i;
            if (!(menuView == null || menuView.getWindowToken() == null || !this.f442b.m())) {
                c.this.v = this.f442b;
            }
            c.this.x = null;
        }
    }

    public class b extends ActionMenuItemView.b {
        public b() {
        }

        public s a() {
            a aVar = c.this.w;
            if (aVar != null) {
                return aVar.c();
            }
            return null;
        }
    }
}
