package android.support.v7.view.menu;

import a.b.d.e.j.h;
import a.b.d.e.j.j;
import a.b.d.e.j.p;
import a.b.d.f.t0;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public final class ExpandedMenuView extends ListView implements h.b, p, AdapterView.OnItemClickListener {

    /* renamed from: c  reason: collision with root package name */
    public static final int[] f608c = {16842964, 16843049};

    /* renamed from: b  reason: collision with root package name */
    public h f609b;

    public ExpandedMenuView(Context context, AttributeSet attrs) {
        this(context, attrs, 16842868);
    }

    public ExpandedMenuView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs);
        setOnItemClickListener(this);
        t0 a2 = t0.t(context, attrs, f608c, defStyleAttr, 0);
        if (a2.q(0)) {
            setBackgroundDrawable(a2.f(0));
        }
        if (a2.q(1)) {
            setDivider(a2.f(1));
        }
        a2.u();
    }

    public void b(h menu) {
        this.f609b = menu;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    public boolean c(j item) {
        return this.f609b.L(item, 0);
    }

    public void onItemClick(AdapterView parent, View v, int position, long id) {
        c((j) getAdapter().getItem(position));
    }

    public int getWindowAnimations() {
        return 0;
    }
}
