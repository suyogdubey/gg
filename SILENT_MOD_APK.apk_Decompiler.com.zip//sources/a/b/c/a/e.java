package a.b.c.a;

import a.a.b.c;
import a.a.b.i;
import a.a.b.n;
import a.a.b.o;
import a.b.c.a.k;
import a.b.c.g.k;
import android.animation.Animator;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

public class e implements ComponentCallbacks, View.OnCreateContextMenuListener, a.a.b.e, o {
    public static final k<String, Class<?>> X = new k<>();
    public static final Object Y = new Object();
    public String A;
    public boolean B;
    public boolean C;
    public boolean D;
    public boolean E;
    public boolean F;
    public boolean G = true;
    public boolean H;
    public ViewGroup I;
    public View J;
    public View K;
    public boolean L;
    public boolean M = true;
    public d N;
    public boolean O;
    public boolean P;
    public float Q;
    public LayoutInflater R;
    public boolean S;
    public a.a.b.f T = new a.a.b.f(this);
    public a.a.b.f U;
    public a.a.b.e V;
    public i<a.a.b.e> W = new i<>();

    /* renamed from: b  reason: collision with root package name */
    public int f63b = 0;

    /* renamed from: c  reason: collision with root package name */
    public Bundle f64c;
    public SparseArray<Parcelable> d;
    public Boolean e;
    public int f = -1;
    public String g;
    public Bundle h;
    public e i;
    public int j = -1;
    public int k;
    public boolean l;
    public boolean m;
    public boolean n;
    public boolean o;
    public boolean p;
    public boolean q;
    public int r;
    public k s;
    public i t;
    public k u;
    public l v;
    public n w;
    public e x;
    public int y;
    public int z;

    public interface f {
    }

    public a.a.b.c a() {
        return this.T;
    }

    public n d() {
        if (m() != null) {
            if (this.w == null) {
                this.w = new n();
            }
            return this.w;
        }
        throw new IllegalStateException("Can't access ViewModels from detached fragment");
    }

    /* renamed from: a.b.c.a.e$e  reason: collision with other inner class name */
    public static class C0005e extends RuntimeException {
        public C0005e(String msg, Exception cause) {
            super(msg, cause);
        }
    }

    public static e E(Context context, String fname, Bundle args) {
        try {
            Class<?> clazz = X.get(fname);
            if (clazz == null) {
                clazz = context.getClassLoader().loadClass(fname);
                X.put(fname, clazz);
            }
            e f2 = (e) clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
            if (args != null) {
                args.setClassLoader(f2.getClass().getClassLoader());
                f2.P0(args);
            }
            return f2;
        } catch (ClassNotFoundException e2) {
            throw new C0005e("Unable to instantiate fragment " + fname + ": make sure class name exists, is public, and has an" + " empty constructor that is public", e2);
        } catch (InstantiationException e3) {
            throw new C0005e("Unable to instantiate fragment " + fname + ": make sure class name exists, is public, and has an" + " empty constructor that is public", e3);
        } catch (IllegalAccessException e4) {
            throw new C0005e("Unable to instantiate fragment " + fname + ": make sure class name exists, is public, and has an" + " empty constructor that is public", e4);
        } catch (NoSuchMethodException e5) {
            throw new C0005e("Unable to instantiate fragment " + fname + ": could not find Fragment constructor", e5);
        } catch (InvocationTargetException e6) {
            throw new C0005e("Unable to instantiate fragment " + fname + ": calling Fragment constructor caused an exception", e6);
        }
    }

    public static boolean K(Context context, String fname) {
        try {
            Class<?> clazz = X.get(fname);
            if (clazz == null) {
                clazz = context.getClassLoader().loadClass(fname);
                X.put(fname, clazz);
            }
            return e.class.isAssignableFrom(clazz);
        } catch (ClassNotFoundException e2) {
            return false;
        }
    }

    public final void M0(Bundle savedInstanceState) {
        SparseArray<Parcelable> sparseArray = this.d;
        if (sparseArray != null) {
            this.K.restoreHierarchyState(sparseArray);
            this.d = null;
        }
        this.H = false;
        n0();
        if (!this.H) {
            throw new w("Fragment " + this + " did not call through to super.onViewStateRestored()");
        } else if (this.J != null) {
            this.U.g(c.a.ON_CREATE);
        }
    }

    public final void R0(int index, e parent) {
        this.f = index;
        if (parent != null) {
            this.g = parent.g + ":" + this.f;
            return;
        }
        this.g = "android:fragment:" + this.f;
    }

    public final boolean H() {
        return this.r > 0;
    }

    public final boolean equals(Object o2) {
        return super.equals(o2);
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        a.b.c.g.d.a(this, sb);
        if (this.f >= 0) {
            sb.append(" #");
            sb.append(this.f);
        }
        if (this.y != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.y));
        }
        if (this.A != null) {
            sb.append(" ");
            sb.append(this.A);
        }
        sb.append('}');
        return sb.toString();
    }

    public void P0(Bundle args) {
        if (this.f < 0 || !J()) {
            this.h = args;
            return;
        }
        throw new IllegalStateException("Fragment already active and state has been saved");
    }

    public final boolean J() {
        k kVar = this.s;
        if (kVar == null) {
            return false;
        }
        return kVar.c();
    }

    public Context m() {
        i iVar = this.t;
        if (iVar == null) {
            return null;
        }
        return iVar.e();
    }

    public final Context K0() {
        Context context = m();
        if (context != null) {
            return context;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to a context.");
    }

    public final f g() {
        i iVar = this.t;
        if (iVar == null) {
            return null;
        }
        return (f) iVar.d();
    }

    public final Resources x() {
        return K0().getResources();
    }

    public final j r() {
        return this.s;
    }

    public final j l() {
        if (this.u == null) {
            F();
            int i2 = this.f63b;
            if (i2 >= 4) {
                this.u.R();
            } else if (i2 >= 3) {
                this.u.S();
            } else if (i2 >= 2) {
                this.u.p();
            } else if (i2 >= 1) {
                this.u.s();
            }
        }
        return this.u;
    }

    public j o0() {
        return this.u;
    }

    public void b0() {
    }

    public void N() {
    }

    public void h0() {
    }

    public LayoutInflater a0(Bundle savedInstanceState) {
        return s();
    }

    public LayoutInflater y0(Bundle savedInstanceState) {
        LayoutInflater layoutInflater = a0(savedInstanceState);
        this.R = layoutInflater;
        return layoutInflater;
    }

    @Deprecated
    public LayoutInflater s() {
        i iVar = this.t;
        if (iVar != null) {
            LayoutInflater result = iVar.j();
            l();
            k kVar = this.u;
            kVar.m0();
            a.b.c.h.f.b(result, kVar);
            return result;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    public void d0(AttributeSet attrs, Bundle savedInstanceState) {
        this.H = true;
        i iVar = this.t;
        if ((iVar == null ? null : iVar.d()) != null) {
            this.H = false;
            c0();
        }
    }

    @Deprecated
    public void c0() {
        this.H = true;
    }

    public void Q() {
    }

    public void O() {
        this.H = true;
        i iVar = this.t;
        if ((iVar == null ? null : iVar.d()) != null) {
            this.H = false;
            P();
        }
    }

    @Deprecated
    public void P() {
        this.H = true;
    }

    public Animation T() {
        return null;
    }

    public Animator U() {
        return null;
    }

    public void S(Bundle savedInstanceState) {
        this.H = true;
        L0(savedInstanceState);
        k kVar = this.u;
        if (kVar != null && !kVar.p0(1)) {
            this.u.s();
        }
    }

    public void L0(Bundle savedInstanceState) {
        Parcelable p2;
        if (savedInstanceState != null && (p2 = savedInstanceState.getParcelable("android:support:fragments")) != null) {
            if (this.u == null) {
                F();
            }
            this.u.L0(p2, this.v);
            this.v = null;
            this.u.s();
        }
    }

    public View V() {
        return null;
    }

    public void m0() {
    }

    public View C() {
        return this.J;
    }

    public void M() {
        this.H = true;
    }

    public void n0() {
        this.H = true;
    }

    public void k0() {
        this.H = true;
    }

    public void i0() {
        this.H = true;
    }

    public void j0() {
    }

    public void e0() {
    }

    public void g0() {
    }

    public void onConfigurationChanged(Configuration newConfig) {
        this.H = true;
    }

    public void f0() {
        this.H = true;
    }

    public void l0() {
        this.H = true;
    }

    public void onLowMemory() {
        this.H = true;
    }

    public void Y() {
        this.H = true;
    }

    public void W() {
        boolean isChangingConfigurations = true;
        this.H = true;
        f activity = g();
        if (activity == null || !activity.isChangingConfigurations()) {
            isChangingConfigurations = false;
        }
        n nVar = this.w;
        if (nVar != null && !isChangingConfigurations) {
            nVar.a();
        }
    }

    public void D() {
        this.f = -1;
        this.g = null;
        this.l = false;
        this.m = false;
        this.n = false;
        this.o = false;
        this.p = false;
        this.r = 0;
        this.s = null;
        this.u = null;
        this.t = null;
        this.y = 0;
        this.z = 0;
        this.A = null;
        this.B = false;
        this.C = false;
        this.E = false;
    }

    public void Z() {
        this.H = true;
    }

    public void X() {
    }

    public void onCreateContextMenu(ContextMenu menu, View v2, ContextMenu.ContextMenuInfo menuInfo) {
        g().onCreateContextMenu(menu, v2, menuInfo);
    }

    public boolean R() {
        return false;
    }

    public Object n() {
        d dVar = this.N;
        if (dVar == null) {
            return null;
        }
        return dVar.g;
    }

    public Object y() {
        d dVar = this.N;
        if (dVar == null) {
            return null;
        }
        Object obj = dVar.h;
        return obj == Y ? n() : obj;
    }

    public Object p() {
        d dVar = this.N;
        if (dVar == null) {
            return null;
        }
        return dVar.i;
    }

    public Object w() {
        d dVar = this.N;
        if (dVar == null) {
            return null;
        }
        Object obj = dVar.j;
        return obj == Y ? p() : obj;
    }

    public Object z() {
        d dVar = this.N;
        if (dVar == null) {
            return null;
        }
        return dVar.k;
    }

    public Object A() {
        d dVar = this.N;
        if (dVar == null) {
            return null;
        }
        Object obj = dVar.l;
        return obj == Y ? z() : obj;
    }

    public boolean h() {
        Boolean bool;
        d dVar = this.N;
        if (dVar == null || (bool = dVar.n) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public boolean i() {
        Boolean bool;
        d dVar = this.N;
        if (dVar == null || (bool = dVar.m) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public void W0() {
        k kVar = this.s;
        if (kVar == null || kVar.l == null) {
            e().q = false;
        } else if (Looper.myLooper() != this.s.l.g().getLooper()) {
            this.s.l.g().postAtFrontOfQueue(new a());
        } else {
            b();
        }
    }

    public class a implements Runnable {
        public a() {
        }

        public void run() {
            e.this.b();
        }
    }

    public void b() {
        f listener;
        d dVar = this.N;
        if (dVar == null) {
            listener = null;
        } else {
            dVar.q = false;
            f listener2 = dVar.r;
            dVar.r = null;
            listener = listener2;
        }
        if (listener != null) {
            ((k.l) listener).d();
        }
    }

    public void c(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
        writer.print(prefix);
        writer.print("mFragmentId=#");
        writer.print(Integer.toHexString(this.y));
        writer.print(" mContainerId=#");
        writer.print(Integer.toHexString(this.z));
        writer.print(" mTag=");
        writer.println(this.A);
        writer.print(prefix);
        writer.print("mState=");
        writer.print(this.f63b);
        writer.print(" mIndex=");
        writer.print(this.f);
        writer.print(" mWho=");
        writer.print(this.g);
        writer.print(" mBackStackNesting=");
        writer.println(this.r);
        writer.print(prefix);
        writer.print("mAdded=");
        writer.print(this.l);
        writer.print(" mRemoving=");
        writer.print(this.m);
        writer.print(" mFromLayout=");
        writer.print(this.n);
        writer.print(" mInLayout=");
        writer.println(this.o);
        writer.print(prefix);
        writer.print("mHidden=");
        writer.print(this.B);
        writer.print(" mDetached=");
        writer.print(this.C);
        writer.print(" mMenuVisible=");
        writer.print(this.G);
        writer.print(" mHasMenu=");
        writer.println(false);
        writer.print(prefix);
        writer.print("mRetainInstance=");
        writer.print(this.D);
        writer.print(" mRetaining=");
        writer.print(this.E);
        writer.print(" mUserVisibleHint=");
        writer.println(this.M);
        if (this.s != null) {
            writer.print(prefix);
            writer.print("mFragmentManager=");
            writer.println(this.s);
        }
        if (this.t != null) {
            writer.print(prefix);
            writer.print("mHost=");
            writer.println(this.t);
        }
        if (this.x != null) {
            writer.print(prefix);
            writer.print("mParentFragment=");
            writer.println(this.x);
        }
        if (this.h != null) {
            writer.print(prefix);
            writer.print("mArguments=");
            writer.println(this.h);
        }
        if (this.f64c != null) {
            writer.print(prefix);
            writer.print("mSavedFragmentState=");
            writer.println(this.f64c);
        }
        if (this.d != null) {
            writer.print(prefix);
            writer.print("mSavedViewState=");
            writer.println(this.d);
        }
        if (this.i != null) {
            writer.print(prefix);
            writer.print("mTarget=");
            writer.print(this.i);
            writer.print(" mTargetRequestCode=");
            writer.println(this.k);
        }
        if (t() != 0) {
            writer.print(prefix);
            writer.print("mNextAnim=");
            writer.println(t());
        }
        if (this.I != null) {
            writer.print(prefix);
            writer.print("mContainer=");
            writer.println(this.I);
        }
        if (this.J != null) {
            writer.print(prefix);
            writer.print("mView=");
            writer.println(this.J);
        }
        if (this.K != null) {
            writer.print(prefix);
            writer.print("mInnerView=");
            writer.println(this.J);
        }
        if (j() != null) {
            writer.print(prefix);
            writer.print("mAnimatingAway=");
            writer.println(j());
            writer.print(prefix);
            writer.print("mStateAfterAnimating=");
            writer.println(B());
        }
        if (m() != null) {
            s.b(this).a(prefix, fd, writer, args);
        }
        if (this.u != null) {
            writer.print(prefix);
            writer.println("Child " + this.u + ":");
            k kVar = this.u;
            kVar.a(prefix + "  ", fd, writer, args);
        }
    }

    public e f(String who) {
        if (who.equals(this.g)) {
            return this;
        }
        k kVar = this.u;
        if (kVar != null) {
            return kVar.f0(who);
        }
        return null;
    }

    public void F() {
        if (this.t != null) {
            k kVar = new k();
            this.u = kVar;
            kVar.h(this.t, new b(), this);
            return;
        }
        throw new IllegalStateException("Fragment has not been attached yet.");
    }

    public class b extends g {
        public b() {
        }

        public View b(int id) {
            View view = e.this.J;
            if (view != null) {
                return view.findViewById(id);
            }
            throw new IllegalStateException("Fragment does not have a view");
        }

        public boolean c() {
            return e.this.J != null;
        }

        public e a(Context context, String className, Bundle arguments) {
            return e.this.t.a(context, className, arguments);
        }
    }

    public void s0(Bundle savedInstanceState) {
        k kVar = this.u;
        if (kVar != null) {
            kVar.C0();
        }
        this.f63b = 1;
        this.H = false;
        S(savedInstanceState);
        this.S = true;
        if (this.H) {
            this.T.g(c.a.ON_CREATE);
            return;
        }
        throw new w("Fragment " + this + " did not call through to super.onCreate()");
    }

    public void u0(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        k kVar = this.u;
        if (kVar != null) {
            kVar.C0();
        }
        this.q = true;
        this.V = new c();
        this.U = null;
        V();
        this.J = null;
        if (0 != 0) {
            this.V.a();
            this.W.n(this.V);
        } else if (this.U == null) {
            this.V = null;
        } else {
            throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
        }
    }

    public class c implements a.a.b.e {
        public c() {
        }

        public a.a.b.c a() {
            e eVar = e.this;
            if (eVar.U == null) {
                eVar.U = new a.a.b.f(eVar.V);
            }
            return e.this.U;
        }
    }

    public void p0(Bundle savedInstanceState) {
        k kVar = this.u;
        if (kVar != null) {
            kVar.C0();
        }
        this.f63b = 2;
        this.H = false;
        M();
        if (this.H) {
            k kVar2 = this.u;
            if (kVar2 != null) {
                kVar2.p();
                return;
            }
            return;
        }
        throw new w("Fragment " + this + " did not call through to super.onActivityCreated()");
    }

    public void I0() {
        k kVar = this.u;
        if (kVar != null) {
            kVar.C0();
            this.u.Z();
        }
        this.f63b = 3;
        this.H = false;
        k0();
        if (this.H) {
            k kVar2 = this.u;
            if (kVar2 != null) {
                kVar2.S();
            }
            this.T.g(c.a.ON_START);
            if (this.J != null) {
                this.U.g(c.a.ON_START);
                return;
            }
            return;
        }
        throw new w("Fragment " + this + " did not call through to super.onStart()");
    }

    public void G0() {
        k kVar = this.u;
        if (kVar != null) {
            kVar.C0();
            this.u.Z();
        }
        this.f63b = 4;
        this.H = false;
        i0();
        if (this.H) {
            k kVar2 = this.u;
            if (kVar2 != null) {
                kVar2.R();
                this.u.Z();
            }
            this.T.g(c.a.ON_RESUME);
            if (this.J != null) {
                this.U.g(c.a.ON_RESUME);
                return;
            }
            return;
        }
        throw new w("Fragment " + this + " did not call through to super.onResume()");
    }

    public void L() {
        k kVar = this.u;
        if (kVar != null) {
            kVar.C0();
        }
    }

    public void A0(boolean isInMultiWindowMode) {
        e0();
        k kVar = this.u;
        if (kVar != null) {
            kVar.x(isInMultiWindowMode);
        }
    }

    public void E0(boolean isInPictureInPictureMode) {
        g0();
        k kVar = this.u;
        if (kVar != null) {
            kVar.P(isInPictureInPictureMode);
        }
    }

    public void q0(Configuration newConfig) {
        onConfigurationChanged(newConfig);
        k kVar = this.u;
        if (kVar != null) {
            kVar.q(newConfig);
        }
    }

    public void z0() {
        onLowMemory();
        k kVar = this.u;
        if (kVar != null) {
            kVar.w();
        }
    }

    public boolean t0(Menu menu, MenuInflater inflater) {
        k kVar;
        if (this.B || (kVar = this.u) == null) {
            return false;
        }
        return false | kVar.t(menu, inflater);
    }

    public boolean F0(Menu menu) {
        k kVar;
        if (this.B || (kVar = this.u) == null) {
            return false;
        }
        return false | kVar.Q(menu);
    }

    public boolean B0(MenuItem item) {
        k kVar;
        if (this.B || (kVar = this.u) == null || !kVar.M(item)) {
            return false;
        }
        return true;
    }

    public boolean r0(MenuItem item) {
        if (this.B) {
            return false;
        }
        R();
        k kVar = this.u;
        if (kVar == null || !kVar.r(item)) {
            return false;
        }
        return true;
    }

    public void C0(Menu menu) {
        k kVar;
        if (!this.B && (kVar = this.u) != null) {
            kVar.N(menu);
        }
    }

    public void H0(Bundle outState) {
        Parcelable p2;
        j0();
        k kVar = this.u;
        if (kVar != null && (p2 = kVar.O0()) != null) {
            outState.putParcelable("android:support:fragments", p2);
        }
    }

    public void D0() {
        if (this.J != null) {
            this.U.g(c.a.ON_PAUSE);
        }
        this.T.g(c.a.ON_PAUSE);
        k kVar = this.u;
        if (kVar != null) {
            kVar.O();
        }
        this.f63b = 3;
        this.H = false;
        f0();
        if (!this.H) {
            throw new w("Fragment " + this + " did not call through to super.onPause()");
        }
    }

    public void J0() {
        if (this.J != null) {
            this.U.g(c.a.ON_STOP);
        }
        this.T.g(c.a.ON_STOP);
        k kVar = this.u;
        if (kVar != null) {
            kVar.U();
        }
        this.f63b = 2;
        this.H = false;
        l0();
        if (!this.H) {
            throw new w("Fragment " + this + " did not call through to super.onStop()");
        }
    }

    public void w0() {
        if (this.J != null) {
            this.U.g(c.a.ON_DESTROY);
        }
        k kVar = this.u;
        if (kVar != null) {
            kVar.v();
        }
        this.f63b = 1;
        this.H = false;
        Y();
        if (this.H) {
            s.b(this).c();
            this.q = false;
            return;
        }
        throw new w("Fragment " + this + " did not call through to super.onDestroyView()");
    }

    public void v0() {
        this.T.g(c.a.ON_DESTROY);
        k kVar = this.u;
        if (kVar != null) {
            kVar.u();
        }
        this.f63b = 0;
        this.H = false;
        this.S = false;
        W();
        if (this.H) {
            this.u = null;
            return;
        }
        throw new w("Fragment " + this + " did not call through to super.onDestroy()");
    }

    public void x0() {
        this.H = false;
        Z();
        this.R = null;
        if (this.H) {
            k kVar = this.u;
            if (kVar == null) {
                return;
            }
            if (this.E) {
                kVar.u();
                this.u = null;
                return;
            }
            throw new IllegalStateException("Child FragmentManager of " + this + " was not " + " destroyed and this fragment is not retaining instance");
        }
        throw new w("Fragment " + this + " did not call through to super.onDetach()");
    }

    public void U0(f listener) {
        e();
        f fVar = this.N.r;
        if (listener != fVar) {
            if (listener == null || fVar == null) {
                d dVar = this.N;
                if (dVar.q) {
                    dVar.r = listener;
                }
                if (listener != null) {
                    ((k.l) listener).e();
                    return;
                }
                return;
            }
            throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
        }
    }

    public final d e() {
        if (this.N == null) {
            this.N = new d();
        }
        return this.N;
    }

    public int t() {
        d dVar = this.N;
        if (dVar == null) {
            return 0;
        }
        return dVar.d;
    }

    public void S0(int animResourceId) {
        if (this.N != null || animResourceId != 0) {
            e().d = animResourceId;
        }
    }

    public int u() {
        d dVar = this.N;
        if (dVar == null) {
            return 0;
        }
        return dVar.e;
    }

    public void T0(int nextTransition, int nextTransitionStyle) {
        if (this.N != null || nextTransition != 0 || nextTransitionStyle != 0) {
            e();
            d dVar = this.N;
            dVar.e = nextTransition;
            dVar.f = nextTransitionStyle;
        }
    }

    public int v() {
        d dVar = this.N;
        if (dVar == null) {
            return 0;
        }
        return dVar.f;
    }

    public void o() {
        if (this.N != null) {
        }
    }

    public void q() {
        if (this.N != null) {
        }
    }

    public View j() {
        d dVar = this.N;
        if (dVar == null) {
            return null;
        }
        return dVar.f68a;
    }

    public void N0(View view) {
        e().f68a = view;
    }

    public void O0(Animator animator) {
        e().f69b = animator;
    }

    public Animator k() {
        d dVar = this.N;
        if (dVar == null) {
            return null;
        }
        return dVar.f69b;
    }

    public int B() {
        d dVar = this.N;
        if (dVar == null) {
            return 0;
        }
        return dVar.f70c;
    }

    public void V0(int state) {
        e().f70c = state;
    }

    public boolean I() {
        d dVar = this.N;
        if (dVar == null) {
            return false;
        }
        return dVar.q;
    }

    public boolean G() {
        d dVar = this.N;
        if (dVar == null) {
            return false;
        }
        return dVar.s;
    }

    public void Q0(boolean replaced) {
        e().s = replaced;
    }

    public static class d {

        /* renamed from: a  reason: collision with root package name */
        public View f68a;

        /* renamed from: b  reason: collision with root package name */
        public Animator f69b;

        /* renamed from: c  reason: collision with root package name */
        public int f70c;
        public int d;
        public int e;
        public int f;
        public Object g = null;
        public Object h;
        public Object i;
        public Object j;
        public Object k;
        public Object l;
        public Boolean m;
        public Boolean n;
        public v o;
        public v p;
        public boolean q;
        public f r;
        public boolean s;

        public d() {
            Object obj = e.Y;
            this.h = obj;
            this.i = null;
            this.j = obj;
            this.k = null;
            this.l = obj;
            this.o = null;
            this.p = null;
        }
    }
}
