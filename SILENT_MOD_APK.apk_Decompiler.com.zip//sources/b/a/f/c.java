package b.a.f;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;
import androidx.cardview.widget.CardView;

public class c implements e {

    /* renamed from: a  reason: collision with root package name */
    public final RectF f661a = new RectF();

    public void m(d cardView, Context context, ColorStateList backgroundColor, float radius, float elevation, float maxElevation) {
        g background = o(context, backgroundColor, radius, elevation, maxElevation);
        background.m(((CardView.a) cardView).c());
        ((CardView.a) cardView).e(background);
        q(cardView);
    }

    public final g o(Context context, ColorStateList backgroundColor, float radius, float elevation, float maxElevation) {
        return new g(context.getResources(), backgroundColor, radius, elevation, maxElevation);
    }

    public void q(d cardView) {
        Rect shadowPadding = new Rect();
        p(cardView).h(shadowPadding);
        ((CardView.a) cardView).f((int) Math.ceil((double) g(cardView)), (int) Math.ceil((double) e(cardView)));
        ((CardView.a) cardView).g(shadowPadding.left, shadowPadding.top, shadowPadding.right, shadowPadding.bottom);
    }

    public void h(d cardView) {
    }

    public void c(d cardView) {
        p(cardView).m(((CardView.a) cardView).c());
        q(cardView);
    }

    public void d(d cardView, ColorStateList color) {
        p(cardView).o(color);
    }

    public ColorStateList i(d cardView) {
        return p(cardView).f();
    }

    public void n(d cardView, float radius) {
        p(cardView).p(radius);
        q(cardView);
    }

    public float b(d cardView) {
        return p(cardView).g();
    }

    public void j(d cardView, float elevation) {
        p(cardView).r(elevation);
    }

    public float f(d cardView) {
        return p(cardView).l();
    }

    public void k(d cardView, float maxElevation) {
        p(cardView).q(maxElevation);
        q(cardView);
    }

    public float a(d cardView) {
        return p(cardView).i();
    }

    public float g(d cardView) {
        return p(cardView).k();
    }

    public float e(d cardView) {
        return p(cardView).j();
    }

    public final g p(d cardView) {
        return (g) ((CardView.a) cardView).a();
    }
}
