package b.a;

public final class c {
    public static final int cardview_compat_inset_shadow = 2131034187;
    public static final int cardview_default_elevation = 2131034188;
    public static final int cardview_default_radius = 2131034189;
}
