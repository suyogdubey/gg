package a.b.c.h;

import android.view.View;

public interface k extends l {
    void i(View view, View view2, int i, int i2);

    void k(View view, int i, int i2, int i3, int i4, int i5);

    void l(View view, int i);

    void m(View view, int i, int i2, int[] iArr, int i3);

    boolean n(View view, View view2, int i, int i2);
}
