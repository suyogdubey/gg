package a.b.c.d.a;

import android.view.SubMenu;

public interface c extends a, SubMenu {
}
