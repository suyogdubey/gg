package com.gjjiitld;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.cardview.widget.CardView;
import java.util.Locale;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends Activity {

    /* renamed from: b  reason: collision with root package name */
    public c.a.b f679b;

    static {
        System.loadLibrary("biruleibe");
    }

    public final void h(Activity activity) {
        if (Build.VERSION.SDK_INT >= 23) {
            activity.getWindow().setStatusBarColor(Color.parseColor("#FF121212"));
            activity.getWindow().setNavigationBarColor(Color.parseColor("#FF121212"));
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        h(this);
        setContentView(R.layout.activity_login2);
        d();
        if (!f()) {
            g();
        }
        this.f679b = c.a.b.d(this);
        a();
        ((TextView) findViewById(R.id.textUsername)).setText(this.f679b.c("USER", ""));
        ((TextView) findViewById(R.id.txtTitleLie)).setText("Quick");
        ((TextView) findViewById(R.id.txtTitleShooter)).setText("Axis");
        ((CardView) findViewById(R.id.btnSignIn)).setOnClickListener(new a());
    }

    public class a implements View.OnClickListener {
        public a() {
        }

        public void onClick(View v) {
            TextView textUsername = (TextView) LoginActivity.this.findViewById(R.id.textUsername);
            if (!textUsername.getText().toString().isEmpty()) {
                LoginActivity.this.f679b.e("USER", textUsername.getText().toString());
                if (LoginActivity.e().equals("BR")) {
                    LoginActivity.this.c("The Brazilian server is not online.", "OFFLINE", "#ff0000", "#00ff4e");
                    new AuthGringa(LoginActivity.this).execute(new String[]{textUsername.getText().toString(), UUID.randomUUID().toString()});
                } else {
                    LoginActivity.this.c("Logged in as Emulator on Another Server!", "ONLINE", "#ff0000", "#00ff4e");
                    new AuthGringa(LoginActivity.this).execute(new String[]{textUsername.getText().toString(), UUID.randomUUID().toString()});
                }
            }
            if (textUsername.getText().toString().isEmpty()) {
                textUsername.setError("Please enter username");
            }
            if (textUsername.getText().toString().isEmpty()) {
                textUsername.setError("Please enter username");
            }
        }
    }

    public static String e() {
        return Locale.getDefault().getCountry();
    }

    public void c(String resposta, String resposta2, String color, String color2) {
        View toastLayout = getLayoutInflater().inflate(R.layout.toastlk, (ViewGroup) findViewById(R.id.toast_root_view));
        TextView header = (TextView) toastLayout.findViewById(R.id.toast_header);
        TextView body = (TextView) toastLayout.findViewById(R.id.toast_body);
        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(17, 0, 0);
        toast.setDuration(1);
        toast.setView(toastLayout);
        body.setText(resposta);
        body.setTextColor(Color.parseColor(color));
        header.setTextColor(Color.parseColor(color2));
        header.setText(resposta2);
        new Handler().postDelayed(new b(this, toast), 0);
    }

    public class b implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ Toast f681b;

        public b(LoginActivity this$0, Toast toast) {
            this.f681b = toast;
        }

        public void run() {
            this.f681b.show();
        }
    }

    public final void d() {
        if (a.b.c.b.a.a(this, "android.permission.ACCESS_FINE_LOCATION") != 0) {
            a.b.c.a.a.g(this, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 1003);
        }
        if (a.b.c.b.a.a(this, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
            a.b.c.a.a.g(this, new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 1002);
        }
        if (a.b.c.b.a.a(this, "android.permission.ACCESS_WIFI_STATE") != 0) {
            a.b.c.a.a.g(this, new String[]{"android.permission.ACCESS_WIFI_STATE"}, 1001);
        }
    }

    public final boolean f() {
        return Settings.canDrawOverlays(this);
    }

    public final void g() {
        startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 1234);
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1001:
                if (grantResults.length <= 0 || grantResults[0] != 0) {
                    c("Permissão de Wi-Fi negada!", "ONLINE", "#ff0000", "#00ff4e");
                    return;
                } else {
                    c("Permissão de Wi-Fi concedida!", "ONLINE", "#ff0000", "#00ff4e");
                    return;
                }
            case 1002:
                if (grantResults.length > 0) {
                    int i = grantResults[0];
                    return;
                }
                return;
            case 1003:
                if (grantResults.length > 0) {
                    int i2 = grantResults[0];
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 1234) {
            return;
        }
        if (f()) {
            c("Permissão de sobreposição concedida!", "ONLINE", "#ff0000", "#00ff4e");
        } else {
            c("Permissão de sobreposição negada!", "ONLINE", "#ff0000", "#00ff4e");
        }
    }

    public void a() {
        String title12;
        String title122;
        String title13;
        String title132;
        String title14;
        String title15;
        String title142;
        String title133;
        c.a.a getJson = new c.a.a();
        String json = getJson.a("https://brutalkill.xyz/sahilX/mod/dialog_vendedores.php");
        String Compra = null;
        try {
            Compra = new JSONObject(json).get("LKTEAM").toString();
        } catch (JSONException e) {
            System.out.println(e.toString());
        }
        String title2 = null;
        try {
            title2 = new JSONObject(json).get("vendedores2").toString();
        } catch (JSONException e2) {
            System.out.println(e2.toString());
        }
        String title3 = null;
        try {
            title3 = new JSONObject(json).get("vendedores3").toString();
        } catch (JSONException e3) {
            System.out.println(e3.toString());
        }
        String title4 = null;
        try {
            title4 = new JSONObject(json).get("vendedores4").toString();
        } catch (JSONException e4) {
            System.out.println(e4.toString());
        }
        String title5 = null;
        try {
            title5 = new JSONObject(json).get("vendedores5").toString();
        } catch (JSONException e5) {
            System.out.println(e5.toString());
        }
        String title6 = null;
        try {
            title6 = new JSONObject(json).get("vendedores6").toString();
        } catch (JSONException e6) {
            System.out.println(e6.toString());
        }
        String title7 = null;
        try {
            title7 = new JSONObject(json).get("vendedores7").toString();
        } catch (JSONException e7) {
            System.out.println(e7.toString());
        }
        String title8 = null;
        try {
            title8 = new JSONObject(json).get("vendedores8").toString();
        } catch (JSONException e8) {
            System.out.println(e8.toString());
        }
        String title9 = null;
        try {
            title9 = new JSONObject(json).get("vendedores9").toString();
        } catch (JSONException e9) {
            System.out.println(e9.toString());
        }
        String title10 = null;
        try {
            title10 = new JSONObject(json).get("vendedores10").toString();
        } catch (JSONException e10) {
            System.out.println(e10.toString());
        }
        String title11 = null;
        try {
            title11 = new JSONObject(json).get("vendedores11").toString();
            c.a.a aVar = getJson;
        } catch (JSONException e11) {
            c.a.a aVar2 = getJson;
            System.out.println(e11.toString());
        }
        try {
            title12 = new JSONObject(json).get("vendedores12").toString();
        } catch (JSONException e12) {
            System.out.println(e12.toString());
            title12 = null;
        }
        try {
            title133 = null;
            try {
                title13 = new JSONObject(json).get("vendedores13").toString();
                title122 = title12;
            } catch (JSONException e13) {
                e = e13;
                title122 = title12;
                System.out.println(e.toString());
                title13 = title133;
                title142 = null;
                try {
                    title14 = new JSONObject(json).get("vendedores14").toString();
                    title132 = title13;
                } catch (JSONException e14) {
                    e = e14;
                    title132 = title13;
                    System.out.println(e.toString());
                    title14 = title142;
                    String str = json;
                    title15 = new JSONObject(json).get("vendedores15").toString();
                    AlertDialog.Builder cancelable = new AlertDialog.Builder(this).setTitle(Compra).setCancelable(false);
                    StringBuilder sb = new StringBuilder();
                    String str2 = Compra;
                    sb.append("");
                    sb.append(title2);
                    sb.append(title3);
                    sb.append(title4);
                    sb.append(title5);
                    sb.append(title6);
                    sb.append(title7);
                    sb.append(title8);
                    sb.append(title9);
                    sb.append(title10);
                    sb.append(title11);
                    sb.append(title122);
                    sb.append(title132);
                    sb.append(title14);
                    sb.append(title15);
                    ((TextView) cancelable.setMessage(Html.fromHtml(sb.toString())).setPositiveButton("OK", new c(this)).show().findViewById(16908299)).setMovementMethod(LinkMovementMethod.getInstance());
                }
                String str3 = json;
                try {
                    title15 = new JSONObject(json).get("vendedores15").toString();
                } catch (JSONException e15) {
                    e = e15;
                    System.out.println(e.toString());
                    title15 = null;
                    AlertDialog.Builder cancelable2 = new AlertDialog.Builder(this).setTitle(Compra).setCancelable(false);
                    StringBuilder sb2 = new StringBuilder();
                    String str22 = Compra;
                    sb2.append("");
                    sb2.append(title2);
                    sb2.append(title3);
                    sb2.append(title4);
                    sb2.append(title5);
                    sb2.append(title6);
                    sb2.append(title7);
                    sb2.append(title8);
                    sb2.append(title9);
                    sb2.append(title10);
                    sb2.append(title11);
                    sb2.append(title122);
                    sb2.append(title132);
                    sb2.append(title14);
                    sb2.append(title15);
                    ((TextView) cancelable2.setMessage(Html.fromHtml(sb2.toString())).setPositiveButton("OK", new c(this)).show().findViewById(16908299)).setMovementMethod(LinkMovementMethod.getInstance());
                }
                AlertDialog.Builder cancelable22 = new AlertDialog.Builder(this).setTitle(Compra).setCancelable(false);
                StringBuilder sb22 = new StringBuilder();
                String str222 = Compra;
                sb22.append("");
                sb22.append(title2);
                sb22.append(title3);
                sb22.append(title4);
                sb22.append(title5);
                sb22.append(title6);
                sb22.append(title7);
                sb22.append(title8);
                sb22.append(title9);
                sb22.append(title10);
                sb22.append(title11);
                sb22.append(title122);
                sb22.append(title132);
                sb22.append(title14);
                sb22.append(title15);
                ((TextView) cancelable22.setMessage(Html.fromHtml(sb22.toString())).setPositiveButton("OK", new c(this)).show().findViewById(16908299)).setMovementMethod(LinkMovementMethod.getInstance());
            }
        } catch (JSONException e16) {
            e = e16;
            title133 = null;
            title122 = title12;
            System.out.println(e.toString());
            title13 = title133;
            title142 = null;
            title14 = new JSONObject(json).get("vendedores14").toString();
            title132 = title13;
            String str32 = json;
            title15 = new JSONObject(json).get("vendedores15").toString();
            AlertDialog.Builder cancelable222 = new AlertDialog.Builder(this).setTitle(Compra).setCancelable(false);
            StringBuilder sb222 = new StringBuilder();
            String str2222 = Compra;
            sb222.append("");
            sb222.append(title2);
            sb222.append(title3);
            sb222.append(title4);
            sb222.append(title5);
            sb222.append(title6);
            sb222.append(title7);
            sb222.append(title8);
            sb222.append(title9);
            sb222.append(title10);
            sb222.append(title11);
            sb222.append(title122);
            sb222.append(title132);
            sb222.append(title14);
            sb222.append(title15);
            ((TextView) cancelable222.setMessage(Html.fromHtml(sb222.toString())).setPositiveButton("OK", new c(this)).show().findViewById(16908299)).setMovementMethod(LinkMovementMethod.getInstance());
        }
        try {
            title142 = null;
            title14 = new JSONObject(json).get("vendedores14").toString();
            title132 = title13;
        } catch (JSONException e17) {
            e = e17;
            title142 = null;
            title132 = title13;
            System.out.println(e.toString());
            title14 = title142;
            String str322 = json;
            title15 = new JSONObject(json).get("vendedores15").toString();
            AlertDialog.Builder cancelable2222 = new AlertDialog.Builder(this).setTitle(Compra).setCancelable(false);
            StringBuilder sb2222 = new StringBuilder();
            String str22222 = Compra;
            sb2222.append("");
            sb2222.append(title2);
            sb2222.append(title3);
            sb2222.append(title4);
            sb2222.append(title5);
            sb2222.append(title6);
            sb2222.append(title7);
            sb2222.append(title8);
            sb2222.append(title9);
            sb2222.append(title10);
            sb2222.append(title11);
            sb2222.append(title122);
            sb2222.append(title132);
            sb2222.append(title14);
            sb2222.append(title15);
            ((TextView) cancelable2222.setMessage(Html.fromHtml(sb2222.toString())).setPositiveButton("OK", new c(this)).show().findViewById(16908299)).setMovementMethod(LinkMovementMethod.getInstance());
        }
        try {
            String str3222 = json;
            title15 = new JSONObject(json).get("vendedores15").toString();
        } catch (JSONException e18) {
            e = e18;
            String str4 = json;
            System.out.println(e.toString());
            title15 = null;
            AlertDialog.Builder cancelable22222 = new AlertDialog.Builder(this).setTitle(Compra).setCancelable(false);
            StringBuilder sb22222 = new StringBuilder();
            String str222222 = Compra;
            sb22222.append("");
            sb22222.append(title2);
            sb22222.append(title3);
            sb22222.append(title4);
            sb22222.append(title5);
            sb22222.append(title6);
            sb22222.append(title7);
            sb22222.append(title8);
            sb22222.append(title9);
            sb22222.append(title10);
            sb22222.append(title11);
            sb22222.append(title122);
            sb22222.append(title132);
            sb22222.append(title14);
            sb22222.append(title15);
            ((TextView) cancelable22222.setMessage(Html.fromHtml(sb22222.toString())).setPositiveButton("OK", new c(this)).show().findViewById(16908299)).setMovementMethod(LinkMovementMethod.getInstance());
        }
        AlertDialog.Builder cancelable222222 = new AlertDialog.Builder(this).setTitle(Compra).setCancelable(false);
        StringBuilder sb222222 = new StringBuilder();
        String str2222222 = Compra;
        sb222222.append("");
        sb222222.append(title2);
        sb222222.append(title3);
        sb222222.append(title4);
        sb222222.append(title5);
        sb222222.append(title6);
        sb222222.append(title7);
        sb222222.append(title8);
        sb222222.append(title9);
        sb222222.append(title10);
        sb222222.append(title11);
        sb222222.append(title122);
        sb222222.append(title132);
        sb222222.append(title14);
        sb222222.append(title15);
        ((TextView) cancelable222222.setMessage(Html.fromHtml(sb222222.toString())).setPositiveButton("OK", new c(this)).show().findViewById(16908299)).setMovementMethod(LinkMovementMethod.getInstance());
    }

    public class c implements DialogInterface.OnClickListener {
        public c(LoginActivity this$0) {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            dialogInterface.cancel();
        }
    }
}
