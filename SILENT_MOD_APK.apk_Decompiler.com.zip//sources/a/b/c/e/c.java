package a.b.c.e;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class c {

    /* renamed from: a  reason: collision with root package name */
    public final Object f198a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public HandlerThread f199b;

    /* renamed from: c  reason: collision with root package name */
    public Handler f200c;
    public int d;
    public Handler.Callback e = new a();
    public final int f;
    public final int g;
    public final String h;

    public interface d<T> {
        void a(T t);
    }

    public class a implements Handler.Callback {
        public a() {
        }

        public boolean handleMessage(Message msg) {
            int i = msg.what;
            if (i == 0) {
                c.this.a();
                return true;
            } else if (i != 1) {
                return true;
            } else {
                c.this.b((Runnable) msg.obj);
                return true;
            }
        }
    }

    public c(String threadName, int priority, int destructAfterMillisec) {
        this.h = threadName;
        this.g = priority;
        this.f = destructAfterMillisec;
        this.d = 0;
    }

    public final void c(Runnable runnable) {
        synchronized (this.f198a) {
            if (this.f199b == null) {
                HandlerThread handlerThread = new HandlerThread(this.h, this.g);
                this.f199b = handlerThread;
                handlerThread.start();
                this.f200c = new Handler(this.f199b.getLooper(), this.e);
                this.d++;
            }
            this.f200c.removeMessages(0);
            this.f200c.sendMessage(this.f200c.obtainMessage(1, runnable));
        }
    }

    public class b implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ Callable f202b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ Handler f203c;
        public final /* synthetic */ d d;

        public b(c this$0, Callable callable, Handler handler, d dVar) {
            this.f202b = callable;
            this.f203c = handler;
            this.d = dVar;
        }

        public void run() {
            T t;
            try {
                t = this.f202b.call();
            } catch (Exception e) {
                t = null;
            }
            this.f203c.post(new a(t));
        }

        public class a implements Runnable {

            /* renamed from: b  reason: collision with root package name */
            public final /* synthetic */ Object f204b;

            public a(Object obj) {
                this.f204b = obj;
            }

            public void run() {
                b.this.d.a(this.f204b);
            }
        }
    }

    public <T> void d(Callable<T> callable, d<T> reply) {
        c(new b(this, callable, new Handler(), reply));
    }

    public <T> T e(Callable<T> callable, int timeoutMillis) {
        ReentrantLock lock = new ReentrantLock();
        Condition cond = lock.newCondition();
        AtomicReference<T> holder = new AtomicReference<>();
        AtomicBoolean running = new AtomicBoolean(true);
        c(new C0011c(this, holder, callable, lock, running, cond));
        lock.lock();
        try {
            if (!running.get()) {
                return holder.get();
            }
            long remaining = TimeUnit.MILLISECONDS.toNanos((long) timeoutMillis);
            do {
                try {
                    remaining = cond.awaitNanos(remaining);
                } catch (InterruptedException e2) {
                }
                if (!running.get()) {
                    T t = holder.get();
                    lock.unlock();
                    return t;
                }
            } while (remaining > 0);
            throw new InterruptedException("timeout");
        } finally {
            lock.unlock();
        }
    }

    /* renamed from: a.b.c.e.c$c  reason: collision with other inner class name */
    public class C0011c implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ AtomicReference f206b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ Callable f207c;
        public final /* synthetic */ ReentrantLock d;
        public final /* synthetic */ AtomicBoolean e;
        public final /* synthetic */ Condition f;

        public C0011c(c this$0, AtomicReference atomicReference, Callable callable, ReentrantLock reentrantLock, AtomicBoolean atomicBoolean, Condition condition) {
            this.f206b = atomicReference;
            this.f207c = callable;
            this.d = reentrantLock;
            this.e = atomicBoolean;
            this.f = condition;
        }

        public void run() {
            try {
                this.f206b.set(this.f207c.call());
            } catch (Exception e2) {
            }
            this.d.lock();
            try {
                this.e.set(false);
                this.f.signal();
            } finally {
                this.d.unlock();
            }
        }
    }

    public void b(Runnable runnable) {
        runnable.run();
        synchronized (this.f198a) {
            this.f200c.removeMessages(0);
            this.f200c.sendMessageDelayed(this.f200c.obtainMessage(0), (long) this.f);
        }
    }

    public void a() {
        synchronized (this.f198a) {
            if (!this.f200c.hasMessages(1)) {
                this.f199b.quit();
                this.f199b = null;
                this.f200c = null;
            }
        }
    }
}
