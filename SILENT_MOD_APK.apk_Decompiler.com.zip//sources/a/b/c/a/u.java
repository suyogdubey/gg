package a.b.c.a;

import android.view.View;
import android.view.ViewTreeObserver;

public class u implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

    /* renamed from: b  reason: collision with root package name */
    public final View f137b;

    /* renamed from: c  reason: collision with root package name */
    public ViewTreeObserver f138c;
    public final Runnable d;

    public u(View view, Runnable runnable) {
        this.f137b = view;
        this.f138c = view.getViewTreeObserver();
        this.d = runnable;
    }

    public static u a(View view, Runnable runnable) {
        u listener = new u(view, runnable);
        view.getViewTreeObserver().addOnPreDrawListener(listener);
        view.addOnAttachStateChangeListener(listener);
        return listener;
    }

    public boolean onPreDraw() {
        b();
        this.d.run();
        return true;
    }

    public void b() {
        if (this.f138c.isAlive()) {
            this.f138c.removeOnPreDrawListener(this);
        } else {
            this.f137b.getViewTreeObserver().removeOnPreDrawListener(this);
        }
        this.f137b.removeOnAttachStateChangeListener(this);
    }

    public void onViewAttachedToWindow(View v) {
        this.f138c = v.getViewTreeObserver();
    }

    public void onViewDetachedFromWindow(View v) {
        b();
    }
}
