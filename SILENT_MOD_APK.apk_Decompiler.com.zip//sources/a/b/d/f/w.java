package a.b.d.f;

import a.b.c.h.o;
import a.b.c.h.p;
import a.b.d.e.j.s;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;

public class w extends Spinner implements o {
    public static final int[] j = {16843505};

    /* renamed from: b  reason: collision with root package name */
    public final e f534b;

    /* renamed from: c  reason: collision with root package name */
    public final Context f535c;
    public f0 d;
    public SpinnerAdapter e;
    public final boolean f;
    public c g;
    public int h;
    public final Rect i;

    public w(Context context, AttributeSet attrs) {
        this(context, attrs, a.b.d.b.a.spinnerStyle);
    }

    public w(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, -1);
    }

    public w(Context context, AttributeSet attrs, int defStyleAttr, int mode) {
        this(context, attrs, defStyleAttr, mode, (Resources.Theme) null);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0069, code lost:
        if (r3 == null) goto L_0x0072;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public w(android.content.Context r9, android.util.AttributeSet r10, int r11, int r12, android.content.res.Resources.Theme r13) {
        /*
            r8 = this;
            r8.<init>(r9, r10, r11)
            android.graphics.Rect r0 = new android.graphics.Rect
            r0.<init>()
            r8.i = r0
            int[] r0 = a.b.d.b.j.Spinner
            r1 = 0
            a.b.d.f.t0 r0 = a.b.d.f.t0.t(r9, r10, r0, r11, r1)
            a.b.d.f.e r2 = new a.b.d.f.e
            r2.<init>(r8)
            r8.f534b = r2
            r2 = 0
            if (r13 == 0) goto L_0x0023
            a.b.d.e.d r3 = new a.b.d.e.d
            r3.<init>((android.content.Context) r9, (android.content.res.Resources.Theme) r13)
            r8.f535c = r3
            goto L_0x003e
        L_0x0023:
            int r3 = a.b.d.b.j.Spinner_popupTheme
            int r3 = r0.m(r3, r1)
            if (r3 == 0) goto L_0x0033
            a.b.d.e.d r4 = new a.b.d.e.d
            r4.<init>((android.content.Context) r9, (int) r3)
            r8.f535c = r4
            goto L_0x003e
        L_0x0033:
            int r4 = android.os.Build.VERSION.SDK_INT
            r5 = 23
            if (r4 >= r5) goto L_0x003b
            r4 = r9
            goto L_0x003c
        L_0x003b:
            r4 = r2
        L_0x003c:
            r8.f535c = r4
        L_0x003e:
            android.content.Context r3 = r8.f535c
            r4 = 1
            if (r3 == 0) goto L_0x00aa
            r3 = -1
            if (r12 != r3) goto L_0x0072
            r3 = 0
            int[] r5 = j     // Catch:{ Exception -> 0x0060 }
            android.content.res.TypedArray r5 = r9.obtainStyledAttributes(r10, r5, r11, r1)     // Catch:{ Exception -> 0x0060 }
            r3 = r5
            boolean r5 = r3.hasValue(r1)     // Catch:{ Exception -> 0x0060 }
            if (r5 == 0) goto L_0x0059
            int r5 = r3.getInt(r1, r1)     // Catch:{ Exception -> 0x0060 }
            r12 = r5
        L_0x0059:
        L_0x005a:
            r3.recycle()
            goto L_0x0072
        L_0x005e:
            r1 = move-exception
            goto L_0x006c
        L_0x0060:
            r5 = move-exception
            java.lang.String r6 = "AppCompatSpinner"
            java.lang.String r7 = "Could not read android:spinnerMode"
            android.util.Log.i(r6, r7, r5)     // Catch:{ all -> 0x005e }
            if (r3 == 0) goto L_0x0072
            goto L_0x005a
        L_0x006c:
            if (r3 == 0) goto L_0x0071
            r3.recycle()
        L_0x0071:
            throw r1
        L_0x0072:
            if (r12 != r4) goto L_0x00aa
            a.b.d.f.w$c r3 = new a.b.d.f.w$c
            android.content.Context r5 = r8.f535c
            r3.<init>(r5, r10, r11)
            android.content.Context r5 = r8.f535c
            int[] r6 = a.b.d.b.j.Spinner
            a.b.d.f.t0 r1 = a.b.d.f.t0.t(r5, r10, r6, r11, r1)
            int r5 = a.b.d.b.j.Spinner_android_dropDownWidth
            r6 = -2
            int r5 = r1.l(r5, r6)
            r8.h = r5
            int r5 = a.b.d.b.j.Spinner_android_popupBackground
            android.graphics.drawable.Drawable r5 = r1.f(r5)
            r3.u(r5)
            int r5 = a.b.d.b.j.Spinner_android_prompt
            java.lang.String r5 = r0.n(r5)
            r3.N(r5)
            r1.u()
            r8.g = r3
            a.b.d.f.w$a r5 = new a.b.d.f.w$a
            r5.<init>(r8, r3)
            r8.d = r5
        L_0x00aa:
            int r1 = a.b.d.b.j.Spinner_android_entries
            java.lang.CharSequence[] r1 = r0.p(r1)
            if (r1 == 0) goto L_0x00c2
            android.widget.ArrayAdapter r3 = new android.widget.ArrayAdapter
            r5 = 17367048(0x1090008, float:2.5162948E-38)
            r3.<init>(r9, r5, r1)
            int r5 = a.b.d.b.g.support_simple_spinner_dropdown_item
            r3.setDropDownViewResource(r5)
            r8.setAdapter((android.widget.SpinnerAdapter) r3)
        L_0x00c2:
            r0.u()
            r8.f = r4
            android.widget.SpinnerAdapter r3 = r8.e
            if (r3 == 0) goto L_0x00d0
            r8.setAdapter((android.widget.SpinnerAdapter) r3)
            r8.e = r2
        L_0x00d0:
            a.b.d.f.e r2 = r8.f534b
            r2.e(r10, r11)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.d.f.w.<init>(android.content.Context, android.util.AttributeSet, int, int, android.content.res.Resources$Theme):void");
    }

    public class a extends f0 {
        public final /* synthetic */ c k;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(View src, c cVar) {
            super(src);
            this.k = cVar;
        }

        public s b() {
            return this.k;
        }

        public boolean c() {
            if (w.this.g.c()) {
                return true;
            }
            w.this.g.f();
            return true;
        }
    }

    public Context getPopupContext() {
        if (this.g != null) {
            return this.f535c;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return super.getPopupContext();
        }
        return null;
    }

    public void setPopupBackgroundDrawable(Drawable background) {
        c cVar = this.g;
        if (cVar != null) {
            cVar.u(background);
        } else {
            super.setPopupBackgroundDrawable(background);
        }
    }

    public void setPopupBackgroundResource(int resId) {
        setPopupBackgroundDrawable(a.b.d.c.a.a.d(getPopupContext(), resId));
    }

    public Drawable getPopupBackground() {
        c cVar = this.g;
        if (cVar != null) {
            return cVar.j();
        }
        return super.getPopupBackground();
    }

    public void setDropDownVerticalOffset(int pixels) {
        c cVar = this.g;
        if (cVar != null) {
            cVar.H(pixels);
        } else {
            super.setDropDownVerticalOffset(pixels);
        }
    }

    public int getDropDownVerticalOffset() {
        c cVar = this.g;
        if (cVar != null) {
            return cVar.m();
        }
        return super.getDropDownVerticalOffset();
    }

    public void setDropDownHorizontalOffset(int pixels) {
        c cVar = this.g;
        if (cVar != null) {
            cVar.y(pixels);
        } else {
            super.setDropDownHorizontalOffset(pixels);
        }
    }

    public int getDropDownHorizontalOffset() {
        c cVar = this.g;
        if (cVar != null) {
            return cVar.k();
        }
        return super.getDropDownHorizontalOffset();
    }

    public void setDropDownWidth(int pixels) {
        if (this.g != null) {
            this.h = pixels;
        } else {
            super.setDropDownWidth(pixels);
        }
    }

    public int getDropDownWidth() {
        if (this.g != null) {
            return this.h;
        }
        return super.getDropDownWidth();
    }

    public void setAdapter(SpinnerAdapter adapter) {
        if (!this.f) {
            this.e = adapter;
            return;
        }
        super.setAdapter(adapter);
        if (this.g != null) {
            Context popupContext = this.f535c;
            if (popupContext == null) {
                popupContext = getContext();
            }
            this.g.r(new b(adapter, popupContext.getTheme()));
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        c cVar = this.g;
        if (cVar != null && cVar.c()) {
            this.g.dismiss();
        }
    }

    public boolean onTouchEvent(MotionEvent event) {
        f0 f0Var = this.d;
        if (f0Var == null || !f0Var.onTouch(this, event)) {
            return super.onTouchEvent(event);
        }
        return true;
    }

    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        if (this.g != null && View.MeasureSpec.getMode(widthMeasureSpec) == Integer.MIN_VALUE) {
            setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(widthMeasureSpec)), getMeasuredHeight());
        }
    }

    public boolean performClick() {
        c cVar = this.g;
        if (cVar == null) {
            return super.performClick();
        }
        if (cVar.c()) {
            return true;
        }
        this.g.f();
        return true;
    }

    public void setPrompt(CharSequence prompt) {
        c cVar = this.g;
        if (cVar != null) {
            cVar.N(prompt);
        } else {
            super.setPrompt(prompt);
        }
    }

    public CharSequence getPrompt() {
        c cVar = this.g;
        return cVar != null ? cVar.L() : super.getPrompt();
    }

    public void setBackgroundResource(int resId) {
        super.setBackgroundResource(resId);
        e eVar = this.f534b;
        if (eVar != null) {
            eVar.g(resId);
        }
    }

    public void setBackgroundDrawable(Drawable background) {
        super.setBackgroundDrawable(background);
        e eVar = this.f534b;
        if (eVar != null) {
            eVar.f();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList tint) {
        e eVar = this.f534b;
        if (eVar != null) {
            eVar.i(tint);
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        e eVar = this.f534b;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode tintMode) {
        e eVar = this.f534b;
        if (eVar != null) {
            eVar.j(tintMode);
        }
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        e eVar = this.f534b;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        e eVar = this.f534b;
        if (eVar != null) {
            eVar.b();
        }
    }

    public int a(SpinnerAdapter adapter, Drawable background) {
        if (adapter == null) {
            return 0;
        }
        int width = 0;
        View itemView = null;
        int itemType = 0;
        int widthMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int start = Math.max(0, getSelectedItemPosition());
        int end = Math.min(adapter.getCount(), start + 15);
        for (int i2 = Math.max(0, start - (15 - (end - start))); i2 < end; i2++) {
            int positionType = adapter.getItemViewType(i2);
            if (positionType != itemType) {
                itemType = positionType;
                itemView = null;
            }
            itemView = adapter.getView(i2, itemView, this);
            if (itemView.getLayoutParams() == null) {
                itemView.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            itemView.measure(widthMeasureSpec, heightMeasureSpec);
            width = Math.max(width, itemView.getMeasuredWidth());
        }
        if (background == null) {
            return width;
        }
        background.getPadding(this.i);
        Rect rect = this.i;
        return width + rect.left + rect.right;
    }

    public static class b implements ListAdapter, SpinnerAdapter {

        /* renamed from: b  reason: collision with root package name */
        public SpinnerAdapter f536b;

        /* renamed from: c  reason: collision with root package name */
        public ListAdapter f537c;

        public b(SpinnerAdapter adapter, Resources.Theme dropDownTheme) {
            this.f536b = adapter;
            if (adapter instanceof ListAdapter) {
                this.f537c = (ListAdapter) adapter;
            }
            if (dropDownTheme == null) {
                return;
            }
            if (Build.VERSION.SDK_INT >= 23 && (adapter instanceof ThemedSpinnerAdapter)) {
                ThemedSpinnerAdapter themedAdapter = (ThemedSpinnerAdapter) adapter;
                if (themedAdapter.getDropDownViewTheme() != dropDownTheme) {
                    themedAdapter.setDropDownViewTheme(dropDownTheme);
                }
            } else if (adapter instanceof p0) {
                p0 themedAdapter2 = (p0) adapter;
                if (themedAdapter2.getDropDownViewTheme() == null) {
                    themedAdapter2.setDropDownViewTheme(dropDownTheme);
                }
            }
        }

        public int getCount() {
            SpinnerAdapter spinnerAdapter = this.f536b;
            if (spinnerAdapter == null) {
                return 0;
            }
            return spinnerAdapter.getCount();
        }

        public Object getItem(int position) {
            SpinnerAdapter spinnerAdapter = this.f536b;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getItem(position);
        }

        public long getItemId(int position) {
            SpinnerAdapter spinnerAdapter = this.f536b;
            if (spinnerAdapter == null) {
                return -1;
            }
            return spinnerAdapter.getItemId(position);
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            return getDropDownView(position, convertView, parent);
        }

        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            SpinnerAdapter spinnerAdapter = this.f536b;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(position, convertView, parent);
        }

        public boolean hasStableIds() {
            SpinnerAdapter spinnerAdapter = this.f536b;
            return spinnerAdapter != null && spinnerAdapter.hasStableIds();
        }

        public void registerDataSetObserver(DataSetObserver observer) {
            SpinnerAdapter spinnerAdapter = this.f536b;
            if (spinnerAdapter != null) {
                spinnerAdapter.registerDataSetObserver(observer);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver observer) {
            SpinnerAdapter spinnerAdapter = this.f536b;
            if (spinnerAdapter != null) {
                spinnerAdapter.unregisterDataSetObserver(observer);
            }
        }

        public boolean areAllItemsEnabled() {
            ListAdapter adapter = this.f537c;
            if (adapter != null) {
                return adapter.areAllItemsEnabled();
            }
            return true;
        }

        public boolean isEnabled(int position) {
            ListAdapter adapter = this.f537c;
            if (adapter != null) {
                return adapter.isEnabled(position);
            }
            return true;
        }

        public int getItemViewType(int position) {
            return 0;
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean isEmpty() {
            return getCount() == 0;
        }
    }

    public class c extends h0 {
        public CharSequence G;
        public ListAdapter H;
        public final Rect I = new Rect();

        public c(Context context, AttributeSet attrs, int defStyleAttr) {
            super(context, attrs, defStyleAttr);
            s(w.this);
            A(true);
            F(0);
            C(new a(w.this));
        }

        public class a implements AdapterView.OnItemClickListener {
            public a(w wVar) {
            }

            public void onItemClick(AdapterView<?> adapterView, View v, int position, long id) {
                w.this.setSelection(position);
                if (w.this.getOnItemClickListener() != null) {
                    c cVar = c.this;
                    w.this.performItemClick(v, position, cVar.H.getItemId(position));
                }
                c.this.dismiss();
            }
        }

        public void r(ListAdapter adapter) {
            super.r(adapter);
            this.H = adapter;
        }

        public CharSequence L() {
            return this.G;
        }

        public void N(CharSequence hintText) {
            this.G = hintText;
        }

        public void K() {
            int hOffset;
            Drawable background = j();
            int hOffset2 = 0;
            if (background != null) {
                background.getPadding(w.this.i);
                hOffset2 = a1.b(w.this) ? w.this.i.right : -w.this.i.left;
            } else {
                Rect rect = w.this.i;
                rect.right = 0;
                rect.left = 0;
            }
            int spinnerPaddingLeft = w.this.getPaddingLeft();
            int spinnerPaddingRight = w.this.getPaddingRight();
            int spinnerWidth = w.this.getWidth();
            w wVar = w.this;
            int i = wVar.h;
            if (i == -2) {
                int contentWidth = wVar.a((SpinnerAdapter) this.H, j());
                int i2 = w.this.getContext().getResources().getDisplayMetrics().widthPixels;
                Rect rect2 = w.this.i;
                int contentWidthLimit = (i2 - rect2.left) - rect2.right;
                if (contentWidth > contentWidthLimit) {
                    contentWidth = contentWidthLimit;
                }
                v(Math.max(contentWidth, (spinnerWidth - spinnerPaddingLeft) - spinnerPaddingRight));
            } else if (i == -1) {
                v((spinnerWidth - spinnerPaddingLeft) - spinnerPaddingRight);
            } else {
                v(i);
            }
            if (a1.b(w.this)) {
                hOffset = hOffset2 + ((spinnerWidth - spinnerPaddingRight) - n());
            } else {
                hOffset = hOffset2 + spinnerPaddingLeft;
            }
            y(hOffset);
        }

        public void f() {
            ViewTreeObserver vto;
            boolean wasShowing = c();
            K();
            z(2);
            super.f();
            d().setChoiceMode(1);
            G(w.this.getSelectedItemPosition());
            if (!wasShowing && (vto = w.this.getViewTreeObserver()) != null) {
                ViewTreeObserver.OnGlobalLayoutListener layoutListener = new b();
                vto.addOnGlobalLayoutListener(layoutListener);
                B(new C0024c(layoutListener));
            }
        }

        public class b implements ViewTreeObserver.OnGlobalLayoutListener {
            public b() {
            }

            public void onGlobalLayout() {
                c cVar = c.this;
                if (!cVar.M(w.this)) {
                    c.this.dismiss();
                    return;
                }
                c.this.K();
                c.super.f();
            }
        }

        /* renamed from: a.b.d.f.w$c$c  reason: collision with other inner class name */
        public class C0024c implements PopupWindow.OnDismissListener {

            /* renamed from: b  reason: collision with root package name */
            public final /* synthetic */ ViewTreeObserver.OnGlobalLayoutListener f540b;

            public C0024c(ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
                this.f540b = onGlobalLayoutListener;
            }

            public void onDismiss() {
                ViewTreeObserver vto = w.this.getViewTreeObserver();
                if (vto != null) {
                    vto.removeGlobalOnLayoutListener(this.f540b);
                }
            }
        }

        public boolean M(View view) {
            return p.l(view) && view.getGlobalVisibleRect(this.I);
        }
    }
}
