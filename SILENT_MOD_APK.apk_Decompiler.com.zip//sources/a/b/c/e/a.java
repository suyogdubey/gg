package a.b.c.e;

import a.b.c.g.j;
import android.util.Base64;
import java.util.List;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public final String f179a;

    /* renamed from: b  reason: collision with root package name */
    public final String f180b;

    /* renamed from: c  reason: collision with root package name */
    public final String f181c;
    public final List<List<byte[]>> d;
    public final int e = 0;
    public final String f = (this.f179a + "-" + this.f180b + "-" + this.f181c);

    public a(String providerAuthority, String providerPackage, String query, List<List<byte[]>> certificates) {
        j.b(providerAuthority);
        this.f179a = providerAuthority;
        j.b(providerPackage);
        this.f180b = providerPackage;
        j.b(query);
        this.f181c = query;
        j.b(certificates);
        this.d = certificates;
    }

    public String d() {
        return this.f179a;
    }

    public String e() {
        return this.f180b;
    }

    public String f() {
        return this.f181c;
    }

    public List<List<byte[]>> a() {
        return this.d;
    }

    public int b() {
        return this.e;
    }

    public String c() {
        return this.f;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("FontRequest {mProviderAuthority: " + this.f179a + ", mProviderPackage: " + this.f180b + ", mQuery: " + this.f181c + ", mCertificates:");
        for (int i = 0; i < this.d.size(); i++) {
            builder.append(" [");
            List<byte[]> set = this.d.get(i);
            for (int j = 0; j < set.size(); j++) {
                builder.append(" \"");
                builder.append(Base64.encodeToString(set.get(j), 0));
                builder.append("\"");
            }
            builder.append(" ]");
        }
        builder.append("}");
        builder.append("mCertificatesArray: " + this.e);
        return builder.toString();
    }
}
