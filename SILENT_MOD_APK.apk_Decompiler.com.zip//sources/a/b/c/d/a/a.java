package a.b.c.d.a;

import android.view.Menu;

public interface a extends Menu {
}
