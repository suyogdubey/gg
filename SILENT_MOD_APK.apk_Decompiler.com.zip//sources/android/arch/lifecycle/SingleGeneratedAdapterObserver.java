package android.arch.lifecycle;

import a.a.b.b;
import a.a.b.c;
import a.a.b.e;
import a.a.b.h;

public class SingleGeneratedAdapterObserver implements GenericLifecycleObserver {

    /* renamed from: a  reason: collision with root package name */
    public final b f571a;

    public void g(e source, c.a event) {
        this.f571a.a(source, event, false, (h) null);
        this.f571a.a(source, event, true, (h) null);
    }
}
