package com.gjjiitld;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import c.a.d;

public class Floater extends Service {
    public void onCreate() {
        super.onCreate();
        d.b(this, this);
    }

    public void onDestroy() {
        d.a();
        super.onDestroy();
    }

    public IBinder onBind(Intent intent) {
        return null;
    }
}
