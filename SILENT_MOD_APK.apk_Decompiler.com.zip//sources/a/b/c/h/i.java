package a.b.c.h;

public interface i {
    void stopNestedScroll();
}
