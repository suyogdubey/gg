package a.b.c.a;

import a.a.b.c;
import a.a.b.e;
import a.a.b.f;
import a.b.c.g.k;
import a.b.c.h.e;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;

public class x extends Activity implements e, e.a {

    /* renamed from: b  reason: collision with root package name */
    public f f139b = new f(this);

    public x() {
        new k();
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        a.a.b.k.e(this);
    }

    public void onSaveInstanceState(Bundle outState) {
        this.f139b.i(c.b.CREATED);
        super.onSaveInstanceState(outState);
    }

    public c a() {
        return this.f139b;
    }

    public boolean f(KeyEvent event) {
        return super.dispatchKeyEvent(event);
    }

    public boolean dispatchKeyShortcutEvent(KeyEvent event) {
        View decor = getWindow().getDecorView();
        if (decor == null || !a.b.c.h.e.d(decor, event)) {
            return super.dispatchKeyShortcutEvent(event);
        }
        return true;
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        View decor = getWindow().getDecorView();
        if (decor == null || !a.b.c.h.e.d(decor, event)) {
            return a.b.c.h.e.e(this, decor, this, event);
        }
        return true;
    }
}
