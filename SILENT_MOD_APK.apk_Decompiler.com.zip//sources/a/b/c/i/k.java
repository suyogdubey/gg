package a.b.c.i;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public abstract class k extends d {
    public int j;
    public int k;
    public LayoutInflater l;

    @Deprecated
    public k(Context context, int layout, Cursor c2, boolean autoRequery) {
        super(context, c2, autoRequery);
        this.k = layout;
        this.j = layout;
        this.l = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    public View g(Context context, Cursor cursor, ViewGroup parent) {
        return this.l.inflate(this.j, parent, false);
    }

    public View f(Context context, Cursor cursor, ViewGroup parent) {
        return this.l.inflate(this.k, parent, false);
    }
}
