package a.b.c.g;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public class a<K, V> extends k<K, V> implements Map<K, V> {
    public h<K, V> i;

    public a() {
    }

    public a(int capacity) {
        super(capacity);
    }

    /* renamed from: a.b.c.g.a$a  reason: collision with other inner class name */
    public class C0014a extends h<K, V> {
        public C0014a() {
        }

        public int d() {
            return a.this.d;
        }

        public Object b(int index, int offset) {
            return a.this.f237c[(index << 1) + offset];
        }

        public int e(Object key) {
            return a.this.f(key);
        }

        public int f(Object value) {
            return a.this.h(value);
        }

        public Map<K, V> c() {
            return a.this;
        }

        public void g(K key, V value) {
            a.this.put(key, value);
        }

        public V i(int index, V value) {
            return a.this.k(index, value);
        }

        public void h(int index) {
            a.this.j(index);
        }

        public void a() {
            a.this.clear();
        }
    }

    public final h<K, V> m() {
        if (this.i == null) {
            this.i = new C0014a();
        }
        return this.i;
    }

    public void putAll(Map<? extends K, ? extends V> map) {
        c(this.d + map.size());
        for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    public boolean n(Collection<?> collection) {
        return h.p(this, collection);
    }

    public Set<Map.Entry<K, V>> entrySet() {
        return m().l();
    }

    public Set<K> keySet() {
        return m().m();
    }

    public Collection<V> values() {
        return m().n();
    }
}
