package a.b.c.a;

import a.a.b.n;
import java.util.List;

public class l {

    /* renamed from: a  reason: collision with root package name */
    public final List<e> f104a;

    /* renamed from: b  reason: collision with root package name */
    public final List<l> f105b;

    /* renamed from: c  reason: collision with root package name */
    public final List<n> f106c;

    public l(List<e> fragments, List<l> childNonConfigs, List<n> viewModelStores) {
        this.f104a = fragments;
        this.f105b = childNonConfigs;
        this.f106c = viewModelStores;
    }

    public List<e> b() {
        return this.f104a;
    }

    public List<l> a() {
        return this.f105b;
    }

    public List<n> c() {
        return this.f106c;
    }
}
