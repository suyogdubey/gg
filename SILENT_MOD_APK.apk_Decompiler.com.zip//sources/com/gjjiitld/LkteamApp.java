package com.gjjiitld;

import android.app.Application;
import java.io.IOException;

public class LkteamApp extends Application {
    public void onCreate() {
        super.onCreate();
        try {
            Runtime.getRuntime().exec("su");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
