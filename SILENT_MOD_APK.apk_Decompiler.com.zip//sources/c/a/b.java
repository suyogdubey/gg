package c.a;

import android.content.Context;
import android.content.SharedPreferences;

public class b {

    /* renamed from: b  reason: collision with root package name */
    public static b f671b;

    /* renamed from: a  reason: collision with root package name */
    public SharedPreferences f672a;

    public b(Context context) {
        Context applicationContext = context.getApplicationContext();
        this.f672a = applicationContext.getSharedPreferences(context.getPackageName() + "_preferences", 0);
    }

    public static b d(Context context) {
        if (f671b == null) {
            f671b = new b(context);
        }
        return f671b;
    }

    public String b(String what) {
        return this.f672a.getString(what, "");
    }

    public String c(String what, String defaultString) {
        return this.f672a.getString(what, defaultString);
    }

    public void e(String where, String what) {
        this.f672a.edit().putString(where, what).apply();
    }

    public boolean a(String key) {
        return this.f672a.contains(key);
    }
}
