package b.b;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseIntArray;

public class b extends a {

    /* renamed from: a  reason: collision with root package name */
    public final SparseIntArray f668a;

    /* renamed from: b  reason: collision with root package name */
    public final Parcel f669b;

    /* renamed from: c  reason: collision with root package name */
    public final int f670c;
    public final int d;
    public final String e;
    public int f;
    public int g;

    public b(Parcel p) {
        this(p, p.dataPosition(), p.dataSize(), "");
    }

    public b(Parcel p, int offset, int end, String prefix) {
        this.f668a = new SparseIntArray();
        this.f = -1;
        this.g = 0;
        this.f669b = p;
        this.f670c = offset;
        this.d = end;
        this.g = offset;
        this.e = prefix;
    }

    public final int D(int fieldId) {
        int fid;
        do {
            int i = this.g;
            if (i >= this.d) {
                return -1;
            }
            this.f669b.setDataPosition(i);
            int size = this.f669b.readInt();
            fid = this.f669b.readInt();
            this.g += size;
        } while (fid != fieldId);
        return this.f669b.dataPosition();
    }

    public boolean h(int fieldId) {
        int position = D(fieldId);
        if (position == -1) {
            return false;
        }
        this.f669b.setDataPosition(position);
        return true;
    }

    public void q(int fieldId) {
        a();
        this.f = fieldId;
        this.f668a.put(fieldId, this.f669b.dataPosition());
        u(0);
        u(fieldId);
    }

    public void a() {
        int i = this.f;
        if (i >= 0) {
            int currentFieldPosition = this.f668a.get(i);
            int position = this.f669b.dataPosition();
            this.f669b.setDataPosition(currentFieldPosition);
            this.f669b.writeInt(position - currentFieldPosition);
            this.f669b.setDataPosition(position);
        }
    }

    public a b() {
        Parcel parcel = this.f669b;
        int dataPosition = parcel.dataPosition();
        int i = this.g;
        if (i == this.f670c) {
            i = this.d;
        }
        return new b(parcel, dataPosition, i, this.e + "  ");
    }

    public void s(byte[] b2) {
        if (b2 != null) {
            this.f669b.writeInt(b2.length);
            this.f669b.writeByteArray(b2);
            return;
        }
        this.f669b.writeInt(-1);
    }

    public void u(int val) {
        this.f669b.writeInt(val);
    }

    public void y(String val) {
        this.f669b.writeString(val);
    }

    public void w(Parcelable p) {
        this.f669b.writeParcelable(p, 0);
    }

    public int j() {
        return this.f669b.readInt();
    }

    public String n() {
        return this.f669b.readString();
    }

    public byte[] f() {
        int len = this.f669b.readInt();
        if (len < 0) {
            return null;
        }
        byte[] bytes = new byte[len];
        this.f669b.readByteArray(bytes);
        return bytes;
    }

    public <T extends Parcelable> T l() {
        return this.f669b.readParcelable(getClass().getClassLoader());
    }
}
