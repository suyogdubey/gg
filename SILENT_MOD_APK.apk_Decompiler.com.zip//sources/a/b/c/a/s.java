package a.b.c.a;

import a.a.b.e;
import a.a.b.o;
import android.support.v4.app.LoaderManagerImpl;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class s {
    @Deprecated
    public abstract void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract void c();

    public static <T extends e & o> s b(T owner) {
        return new LoaderManagerImpl(owner, ((o) owner).d());
    }
}
