package a.b.d.f;

import a.b.d.a.a;
import android.content.res.Configuration;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.widget.AdapterView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

public class m0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {

    /* renamed from: b  reason: collision with root package name */
    public Runnable f490b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f491c;
    public int d;
    public int e;
    public int f;
    public int g;

    static {
        new DecelerateInterpolator();
    }

    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setFillViewport(View.MeasureSpec.getMode(widthMeasureSpec) == 1073741824);
        throw null;
    }

    public void setAllowCollapse(boolean allowCollapse) {
        this.f491c = allowCollapse;
    }

    public void setTabSelected(int position) {
        this.g = position;
        throw null;
    }

    public void setContentHeight(int contentHeight) {
        this.f = contentHeight;
        requestLayout();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        a.b.d.e.a abp = a.b.d.e.a.b(getContext());
        setContentHeight(abp.f());
        this.e = abp.e();
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Runnable runnable = this.f490b;
        if (runnable != null) {
            post(runnable);
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Runnable runnable = this.f490b;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
    }

    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        ((a) view).a().a();
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    public class a extends LinearLayout {

        /* renamed from: b  reason: collision with root package name */
        public a.c f492b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ m0 f493c;

        public void setSelected(boolean selected) {
            boolean changed = isSelected() != selected;
            super.setSelected(selected);
            if (changed && selected) {
                sendAccessibilityEvent(4);
            }
        }

        public void onInitializeAccessibilityEvent(AccessibilityEvent event) {
            super.onInitializeAccessibilityEvent(event);
            event.setClassName(a.c.class.getName());
        }

        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
            super.onInitializeAccessibilityNodeInfo(info);
            info.setClassName(a.c.class.getName());
        }

        public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int i;
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            if (this.f493c.d > 0 && getMeasuredWidth() > (i = this.f493c.d)) {
                super.onMeasure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), heightMeasureSpec);
            }
        }

        public a.c a() {
            return this.f492b;
        }
    }
}
