package a.b.c.a;

import a.b.c.a.c;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

public final class d implements Parcelable {
    public static final Parcelable.Creator<d> CREATOR = new a();

    /* renamed from: b  reason: collision with root package name */
    public final int[] f61b;

    /* renamed from: c  reason: collision with root package name */
    public final int f62c;
    public final int d;
    public final String e;
    public final int f;
    public final int g;
    public final CharSequence h;
    public final int i;
    public final CharSequence j;
    public final ArrayList<String> k;
    public final ArrayList<String> l;
    public final boolean m;

    public d(c bse) {
        int numOps = bse.f56b.size();
        this.f61b = new int[(numOps * 6)];
        if (bse.i) {
            int pos = 0;
            for (int opNum = 0; opNum < numOps; opNum++) {
                c.a op = bse.f56b.get(opNum);
                int[] iArr = this.f61b;
                int pos2 = pos + 1;
                iArr[pos] = op.f58a;
                int pos3 = pos2 + 1;
                e eVar = op.f59b;
                iArr[pos2] = eVar != null ? eVar.f : -1;
                int[] iArr2 = this.f61b;
                int pos4 = pos3 + 1;
                iArr2[pos3] = op.f60c;
                int pos5 = pos4 + 1;
                iArr2[pos4] = op.d;
                int pos6 = pos5 + 1;
                iArr2[pos5] = op.e;
                pos = pos6 + 1;
                iArr2[pos6] = op.f;
            }
            this.f62c = bse.g;
            this.d = bse.h;
            this.e = bse.j;
            this.f = bse.k;
            this.g = bse.l;
            this.h = bse.m;
            this.i = bse.n;
            this.j = bse.o;
            this.k = bse.p;
            this.l = bse.q;
            this.m = bse.r;
            return;
        }
        throw new IllegalStateException("Not on back stack");
    }

    public d(Parcel in) {
        this.f61b = in.createIntArray();
        this.f62c = in.readInt();
        this.d = in.readInt();
        this.e = in.readString();
        this.f = in.readInt();
        this.g = in.readInt();
        this.h = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(in);
        this.i = in.readInt();
        this.j = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(in);
        this.k = in.createStringArrayList();
        this.l = in.createStringArrayList();
        this.m = in.readInt() != 0;
    }

    public c a(k fm) {
        c bse = new c(fm);
        int pos = 0;
        int num = 0;
        while (pos < this.f61b.length) {
            c.a op = new c.a();
            int[] iArr = this.f61b;
            int pos2 = pos + 1;
            op.f58a = iArr[pos];
            boolean z = k.C;
            int pos3 = pos2 + 1;
            int findex = iArr[pos2];
            if (findex >= 0) {
                op.f59b = fm.e.get(findex);
            } else {
                op.f59b = null;
            }
            int[] iArr2 = this.f61b;
            int pos4 = pos3 + 1;
            int pos5 = iArr2[pos3];
            op.f60c = pos5;
            int pos6 = pos4 + 1;
            int pos7 = iArr2[pos4];
            op.d = pos7;
            int pos8 = pos6 + 1;
            int pos9 = iArr2[pos6];
            op.e = pos9;
            int i2 = iArr2[pos8];
            op.f = i2;
            bse.f57c = pos5;
            bse.d = pos7;
            bse.e = pos9;
            bse.f = i2;
            bse.a(op);
            num++;
            pos = pos8 + 1;
        }
        bse.g = this.f62c;
        bse.h = this.d;
        bse.j = this.e;
        bse.k = this.f;
        bse.i = true;
        bse.l = this.g;
        bse.m = this.h;
        bse.n = this.i;
        bse.o = this.j;
        bse.p = this.k;
        bse.q = this.l;
        bse.r = this.m;
        bse.b(1);
        return bse;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeIntArray(this.f61b);
        dest.writeInt(this.f62c);
        dest.writeInt(this.d);
        dest.writeString(this.e);
        dest.writeInt(this.f);
        dest.writeInt(this.g);
        TextUtils.writeToParcel(this.h, dest, 0);
        dest.writeInt(this.i);
        TextUtils.writeToParcel(this.j, dest, 0);
        dest.writeStringList(this.k);
        dest.writeStringList(this.l);
        dest.writeInt(this.m ? 1 : 0);
    }

    public static class a implements Parcelable.Creator<d> {
        /* renamed from: a */
        public d createFromParcel(Parcel in) {
            return new d(in);
        }

        /* renamed from: b */
        public d[] newArray(int size) {
            return new d[size];
        }
    }
}
