package c.a;

import android.os.StrictMode;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class a {
    public String a(String _url) {
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new BufferedInputStream(((HttpURLConnection) new URL(_url).openConnection()).getInputStream()), "UTF-8"), 8);
            StringBuilder sb = new StringBuilder();
            while (true) {
                String readLine = reader.readLine();
                String line = readLine;
                if (readLine == null) {
                    return sb.toString();
                }
                sb.append(line + "\n");
            }
        } catch (Exception e) {
            return e.toString();
        }
    }
}
