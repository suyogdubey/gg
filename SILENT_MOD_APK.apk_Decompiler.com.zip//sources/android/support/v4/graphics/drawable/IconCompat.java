package android.support.v4.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {
    public static final PorterDuff.Mode j = PorterDuff.Mode.SRC_IN;

    /* renamed from: a  reason: collision with root package name */
    public int f577a;

    /* renamed from: b  reason: collision with root package name */
    public Object f578b;

    /* renamed from: c  reason: collision with root package name */
    public byte[] f579c;
    public Parcelable d;
    public int e;
    public int f;
    public ColorStateList g = null;
    public PorterDuff.Mode h = j;
    public String i;

    public String c() {
        if (this.f577a == -1 && Build.VERSION.SDK_INT >= 23) {
            return d((Icon) this.f578b);
        }
        if (this.f577a == 2) {
            return ((String) this.f578b).split(":", -1)[0];
        }
        throw new IllegalStateException("called getResPackage() on " + this);
    }

    public int a() {
        if (this.f577a == -1 && Build.VERSION.SDK_INT >= 23) {
            return b((Icon) this.f578b);
        }
        if (this.f577a == 2) {
            return this.e;
        }
        throw new IllegalStateException("called getResId() on " + this);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x002c, code lost:
        if (r1 != 5) goto L_0x009c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x00a0  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x00b0  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String toString() {
        /*
            r4 = this;
            int r0 = r4.f577a
            r1 = -1
            if (r0 != r1) goto L_0x000c
            java.lang.Object r0 = r4.f578b
            java.lang.String r0 = java.lang.String.valueOf(r0)
            return r0
        L_0x000c:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Icon(typ="
            r0.<init>(r1)
            int r1 = r4.f577a
            java.lang.String r1 = g(r1)
            java.lang.StringBuilder r0 = r0.append(r1)
            int r1 = r4.f577a
            r2 = 1
            if (r1 == r2) goto L_0x007b
            r3 = 2
            if (r1 == r3) goto L_0x0053
            r2 = 3
            if (r1 == r2) goto L_0x003a
            r2 = 4
            if (r1 == r2) goto L_0x002f
            r2 = 5
            if (r1 == r2) goto L_0x007b
            goto L_0x009c
        L_0x002f:
            java.lang.String r1 = " uri="
            r0.append(r1)
            java.lang.Object r1 = r4.f578b
            r0.append(r1)
            goto L_0x009c
        L_0x003a:
            java.lang.String r1 = " len="
            r0.append(r1)
            int r1 = r4.e
            r0.append(r1)
            int r1 = r4.f
            if (r1 == 0) goto L_0x009c
            java.lang.String r1 = " off="
            r0.append(r1)
            int r1 = r4.f
            r0.append(r1)
            goto L_0x009c
        L_0x0053:
            java.lang.String r1 = " pkg="
            r0.append(r1)
            java.lang.String r1 = r4.c()
            r0.append(r1)
            java.lang.String r1 = " id="
            r0.append(r1)
            java.lang.Object[] r1 = new java.lang.Object[r2]
            r2 = 0
            int r3 = r4.a()
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r1[r2] = r3
            java.lang.String r2 = "0x%08x"
            java.lang.String r1 = java.lang.String.format(r2, r1)
            r0.append(r1)
            goto L_0x009c
        L_0x007b:
            java.lang.String r1 = " size="
            r0.append(r1)
            java.lang.Object r1 = r4.f578b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getWidth()
            r0.append(r1)
            java.lang.String r1 = "x"
            r0.append(r1)
            java.lang.Object r1 = r4.f578b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getHeight()
            r0.append(r1)
        L_0x009c:
            android.content.res.ColorStateList r1 = r4.g
            if (r1 == 0) goto L_0x00aa
            java.lang.String r1 = " tint="
            r0.append(r1)
            android.content.res.ColorStateList r1 = r4.g
            r0.append(r1)
        L_0x00aa:
            android.graphics.PorterDuff$Mode r1 = r4.h
            android.graphics.PorterDuff$Mode r2 = j
            if (r1 == r2) goto L_0x00ba
            java.lang.String r1 = " mode="
            r0.append(r1)
            android.graphics.PorterDuff$Mode r1 = r4.h
            r0.append(r1)
        L_0x00ba:
            java.lang.String r1 = ")"
            r0.append(r1)
            java.lang.String r1 = r0.toString()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.graphics.drawable.IconCompat.toString():java.lang.String");
    }

    public void f(boolean isStream) {
        this.i = this.h.name();
        int i2 = this.f577a;
        if (i2 != -1) {
            if (i2 != 1) {
                if (i2 == 2) {
                    this.f579c = ((String) this.f578b).getBytes(Charset.forName("UTF-16"));
                    return;
                } else if (i2 == 3) {
                    this.f579c = (byte[]) this.f578b;
                    return;
                } else if (i2 == 4) {
                    this.f579c = this.f578b.toString().getBytes(Charset.forName("UTF-16"));
                    return;
                } else if (i2 != 5) {
                    return;
                }
            }
            if (isStream) {
                ByteArrayOutputStream data = new ByteArrayOutputStream();
                ((Bitmap) this.f578b).compress(Bitmap.CompressFormat.PNG, 90, data);
                this.f579c = data.toByteArray();
                return;
            }
            this.d = (Parcelable) this.f578b;
        } else if (!isStream) {
            this.d = (Parcelable) this.f578b;
        } else {
            throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
        }
    }

    public void e() {
        this.h = PorterDuff.Mode.valueOf(this.i);
        int i2 = this.f577a;
        if (i2 != -1) {
            if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 == 3) {
                        this.f578b = this.f579c;
                        return;
                    } else if (i2 != 4) {
                        if (i2 != 5) {
                            return;
                        }
                    }
                }
                this.f578b = new String(this.f579c, Charset.forName("UTF-16"));
                return;
            }
            Parcelable parcelable = this.d;
            if (parcelable != null) {
                this.f578b = parcelable;
                return;
            }
            byte[] bArr = this.f579c;
            this.f578b = bArr;
            this.f577a = 3;
            this.e = 0;
            this.f = bArr.length;
            return;
        }
        Parcelable parcelable2 = this.d;
        if (parcelable2 != null) {
            this.f578b = parcelable2;
            return;
        }
        throw new IllegalArgumentException("Invalid icon");
    }

    public static String g(int x) {
        if (x == 1) {
            return "BITMAP";
        }
        if (x == 2) {
            return "RESOURCE";
        }
        if (x == 3) {
            return "DATA";
        }
        if (x == 4) {
            return "URI";
        }
        if (x != 5) {
            return "UNKNOWN";
        }
        return "BITMAP_MASKABLE";
    }

    public static String d(Icon icon) {
        if (Build.VERSION.SDK_INT >= 28) {
            return icon.getResPackage();
        }
        try {
            return (String) icon.getClass().getMethod("getResPackage", new Class[0]).invoke(icon, new Object[0]);
        } catch (IllegalAccessException e2) {
            Log.e("IconCompat", "Unable to get icon package", e2);
            return null;
        } catch (InvocationTargetException e3) {
            Log.e("IconCompat", "Unable to get icon package", e3);
            return null;
        } catch (NoSuchMethodException e4) {
            Log.e("IconCompat", "Unable to get icon package", e4);
            return null;
        }
    }

    public static int b(Icon icon) {
        if (Build.VERSION.SDK_INT >= 28) {
            return icon.getResId();
        }
        try {
            return ((Integer) icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException e2) {
            Log.e("IconCompat", "Unable to get icon resource", e2);
            return 0;
        } catch (InvocationTargetException e3) {
            Log.e("IconCompat", "Unable to get icon resource", e3);
            return 0;
        } catch (NoSuchMethodException e4) {
            Log.e("IconCompat", "Unable to get icon resource", e4);
            return 0;
        }
    }
}
