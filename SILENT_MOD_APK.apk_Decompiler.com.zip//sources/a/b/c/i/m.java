package a.b.c.i;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public interface m {
    void setSupportButtonTintList(ColorStateList colorStateList);

    void setSupportButtonTintMode(PorterDuff.Mode mode);
}
