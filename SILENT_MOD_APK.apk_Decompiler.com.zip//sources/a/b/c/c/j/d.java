package a.b.c.c.j;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

public class d extends Drawable implements Drawable.Callback, c, b {
    public static final PorterDuff.Mode h = PorterDuff.Mode.SRC_IN;

    /* renamed from: b  reason: collision with root package name */
    public int f174b;

    /* renamed from: c  reason: collision with root package name */
    public PorterDuff.Mode f175c;
    public boolean d;
    public a e;
    public boolean f;
    public Drawable g;

    public d(a state, Resources res) {
        this.e = state;
        e(res);
    }

    public d(Drawable dr) {
        this.e = d();
        b(dr);
    }

    public final void e(Resources res) {
        Drawable.ConstantState constantState;
        a aVar = this.e;
        if (aVar != null && (constantState = aVar.f177b) != null) {
            b(constantState.newDrawable(res));
        }
    }

    public void jumpToCurrentState() {
        this.g.jumpToCurrentState();
    }

    public void draw(Canvas canvas) {
        this.g.draw(canvas);
    }

    public void onBoundsChange(Rect bounds) {
        Drawable drawable = this.g;
        if (drawable != null) {
            drawable.setBounds(bounds);
        }
    }

    public void setChangingConfigurations(int configs) {
        this.g.setChangingConfigurations(configs);
    }

    public int getChangingConfigurations() {
        int changingConfigurations = super.getChangingConfigurations();
        a aVar = this.e;
        return changingConfigurations | (aVar != null ? aVar.getChangingConfigurations() : 0) | this.g.getChangingConfigurations();
    }

    public void setDither(boolean dither) {
        this.g.setDither(dither);
    }

    public void setFilterBitmap(boolean filter) {
        this.g.setFilterBitmap(filter);
    }

    public void setAlpha(int alpha) {
        this.g.setAlpha(alpha);
    }

    public void setColorFilter(ColorFilter cf) {
        this.g.setColorFilter(cf);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r2.e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isStateful() {
        /*
            r2 = this;
            boolean r0 = r2.c()
            if (r0 == 0) goto L_0x000d
            a.b.c.c.j.d$a r0 = r2.e
            if (r0 == 0) goto L_0x000d
            android.content.res.ColorStateList r0 = r0.f178c
            goto L_0x000e
        L_0x000d:
            r0 = 0
        L_0x000e:
            if (r0 == 0) goto L_0x0016
            boolean r1 = r0.isStateful()
            if (r1 != 0) goto L_0x001e
        L_0x0016:
            android.graphics.drawable.Drawable r1 = r2.g
            boolean r1 = r1.isStateful()
            if (r1 == 0) goto L_0x0020
        L_0x001e:
            r1 = 1
            goto L_0x0021
        L_0x0020:
            r1 = 0
        L_0x0021:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.c.j.d.isStateful():boolean");
    }

    public boolean setState(int[] stateSet) {
        return f(stateSet) || this.g.setState(stateSet);
    }

    public int[] getState() {
        return this.g.getState();
    }

    public Drawable getCurrent() {
        return this.g.getCurrent();
    }

    public boolean setVisible(boolean visible, boolean restart) {
        return super.setVisible(visible, restart) || this.g.setVisible(visible, restart);
    }

    public int getOpacity() {
        return this.g.getOpacity();
    }

    public Region getTransparentRegion() {
        return this.g.getTransparentRegion();
    }

    public int getIntrinsicWidth() {
        return this.g.getIntrinsicWidth();
    }

    public int getIntrinsicHeight() {
        return this.g.getIntrinsicHeight();
    }

    public int getMinimumWidth() {
        return this.g.getMinimumWidth();
    }

    public int getMinimumHeight() {
        return this.g.getMinimumHeight();
    }

    public boolean getPadding(Rect padding) {
        return this.g.getPadding(padding);
    }

    public void setAutoMirrored(boolean mirrored) {
        this.g.setAutoMirrored(mirrored);
    }

    public boolean isAutoMirrored() {
        return this.g.isAutoMirrored();
    }

    public Drawable.ConstantState getConstantState() {
        a aVar = this.e;
        if (aVar == null || !aVar.a()) {
            return null;
        }
        this.e.f176a = getChangingConfigurations();
        return this.e;
    }

    public Drawable mutate() {
        if (!this.f && super.mutate() == this) {
            this.e = d();
            Drawable drawable = this.g;
            if (drawable != null) {
                drawable.mutate();
            }
            a aVar = this.e;
            if (aVar != null) {
                Drawable drawable2 = this.g;
                aVar.f177b = drawable2 != null ? drawable2.getConstantState() : null;
            }
            this.f = true;
        }
        return this;
    }

    public a d() {
        return new b(this.e, (Resources) null);
    }

    public void invalidateDrawable(Drawable who) {
        invalidateSelf();
    }

    public void scheduleDrawable(Drawable who, Runnable what, long when) {
        scheduleSelf(what, when);
    }

    public void unscheduleDrawable(Drawable who, Runnable what) {
        unscheduleSelf(what);
    }

    public boolean onLevelChange(int level) {
        return this.g.setLevel(level);
    }

    public void setTint(int tint) {
        setTintList(ColorStateList.valueOf(tint));
    }

    public void setTintList(ColorStateList tint) {
        this.e.f178c = tint;
        f(getState());
    }

    public void setTintMode(PorterDuff.Mode tintMode) {
        this.e.d = tintMode;
        f(getState());
    }

    public final boolean f(int[] state) {
        if (!c()) {
            return false;
        }
        a aVar = this.e;
        ColorStateList tintList = aVar.f178c;
        PorterDuff.Mode tintMode = aVar.d;
        if (tintList == null || tintMode == null) {
            this.d = false;
            clearColorFilter();
        } else {
            int color = tintList.getColorForState(state, tintList.getDefaultColor());
            if (!(this.d && color == this.f174b && tintMode == this.f175c)) {
                setColorFilter(color, tintMode);
                this.f174b = color;
                this.f175c = tintMode;
                this.d = true;
                return true;
            }
        }
        return false;
    }

    public final Drawable a() {
        return this.g;
    }

    public final void b(Drawable dr) {
        Drawable drawable = this.g;
        if (drawable != null) {
            drawable.setCallback((Drawable.Callback) null);
        }
        this.g = dr;
        if (dr != null) {
            dr.setCallback(this);
            setVisible(dr.isVisible(), true);
            setState(dr.getState());
            setLevel(dr.getLevel());
            setBounds(dr.getBounds());
            a aVar = this.e;
            if (aVar != null) {
                aVar.f177b = dr.getConstantState();
            }
        }
        invalidateSelf();
    }

    public boolean c() {
        return true;
    }

    public static abstract class a extends Drawable.ConstantState {

        /* renamed from: a  reason: collision with root package name */
        public int f176a;

        /* renamed from: b  reason: collision with root package name */
        public Drawable.ConstantState f177b;

        /* renamed from: c  reason: collision with root package name */
        public ColorStateList f178c = null;
        public PorterDuff.Mode d = d.h;

        public abstract Drawable newDrawable(Resources resources);

        public a(a orig) {
            if (orig != null) {
                this.f176a = orig.f176a;
                this.f177b = orig.f177b;
                this.f178c = orig.f178c;
                this.d = orig.d;
            }
        }

        public Drawable newDrawable() {
            return newDrawable((Resources) null);
        }

        public int getChangingConfigurations() {
            int i = this.f176a;
            Drawable.ConstantState constantState = this.f177b;
            return i | (constantState != null ? constantState.getChangingConfigurations() : 0);
        }

        public boolean a() {
            return this.f177b != null;
        }
    }

    public static class b extends a {
        public b(a orig, Resources res) {
            super(orig);
        }

        public Drawable newDrawable(Resources res) {
            return new d(this, res);
        }
    }
}
