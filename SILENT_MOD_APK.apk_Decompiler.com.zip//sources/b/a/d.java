package b.a;

public final class d {
    public static final int Base_CardView = 2131558412;
    public static final int CardView = 2131558563;
    public static final int CardView_Dark = 2131558564;
    public static final int CardView_Light = 2131558565;
}
