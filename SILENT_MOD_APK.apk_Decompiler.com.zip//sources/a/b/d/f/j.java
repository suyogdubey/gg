package a.b.d.f;

import a.b.b.a.h;
import a.b.c.g.f;
import a.b.c.g.g;
import a.b.c.g.l;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.support.v4.util.LongSparseArray;
import android.support.v4.util.SparseArrayCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;

public final class j {
    public static final PorterDuff.Mode g = PorterDuff.Mode.SRC_IN;
    public static j h;
    public static final c i = new c(6);
    public static final int[] j = {a.b.d.b.e.abc_textfield_search_default_mtrl_alpha, a.b.d.b.e.abc_textfield_default_mtrl_alpha, a.b.d.b.e.abc_ab_share_pack_mtrl_alpha};
    public static final int[] k = {a.b.d.b.e.abc_ic_commit_search_api_mtrl_alpha, a.b.d.b.e.abc_seekbar_tick_mark_material, a.b.d.b.e.abc_ic_menu_share_mtrl_alpha, a.b.d.b.e.abc_ic_menu_copy_mtrl_am_alpha, a.b.d.b.e.abc_ic_menu_cut_mtrl_alpha, a.b.d.b.e.abc_ic_menu_selectall_mtrl_alpha, a.b.d.b.e.abc_ic_menu_paste_mtrl_am_alpha};
    public static final int[] l = {a.b.d.b.e.abc_textfield_activated_mtrl_alpha, a.b.d.b.e.abc_textfield_search_activated_mtrl_alpha, a.b.d.b.e.abc_cab_background_top_mtrl_alpha, a.b.d.b.e.abc_text_cursor_material, a.b.d.b.e.abc_text_select_handle_left_mtrl_dark, a.b.d.b.e.abc_text_select_handle_middle_mtrl_dark, a.b.d.b.e.abc_text_select_handle_right_mtrl_dark, a.b.d.b.e.abc_text_select_handle_left_mtrl_light, a.b.d.b.e.abc_text_select_handle_middle_mtrl_light, a.b.d.b.e.abc_text_select_handle_right_mtrl_light};
    public static final int[] m = {a.b.d.b.e.abc_popup_background_mtrl_mult, a.b.d.b.e.abc_cab_background_internal_bg, a.b.d.b.e.abc_menu_hardkey_panel_mtrl_mult};
    public static final int[] n = {a.b.d.b.e.abc_tab_indicator_material, a.b.d.b.e.abc_textfield_search_material};
    public static final int[] o = {a.b.d.b.e.abc_btn_check_material, a.b.d.b.e.abc_btn_radio_material};

    /* renamed from: a  reason: collision with root package name */
    public WeakHashMap<Context, l<ColorStateList>> f479a;

    /* renamed from: b  reason: collision with root package name */
    public a.b.c.g.a<String, d> f480b;

    /* renamed from: c  reason: collision with root package name */
    public l<String> f481c;
    public final WeakHashMap<Context, f<WeakReference<Drawable.ConstantState>>> d = new WeakHashMap<>(0);
    public TypedValue e;
    public boolean f;

    public interface d {
        Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme);
    }

    public static synchronized j n() {
        j jVar;
        synchronized (j.class) {
            if (h == null) {
                j jVar2 = new j();
                h = jVar2;
                v(jVar2);
            }
            jVar = h;
        }
        return jVar;
    }

    public static void v(j manager) {
        if (Build.VERSION.SDK_INT < 24) {
            manager.a("vector", new e());
            manager.a("animated-vector", new b());
            manager.a("animated-selector", new a());
        }
    }

    public synchronized Drawable p(Context context, int resId) {
        return q(context, resId, false);
    }

    public synchronized Drawable q(Context context, int resId, boolean failIfNotKnown) {
        Drawable drawable;
        e(context);
        drawable = x(context, resId);
        if (drawable == null) {
            drawable = k(context, resId);
        }
        if (drawable == null) {
            drawable = a.b.c.b.a.c(context, resId);
        }
        if (drawable != null) {
            drawable = A(context, resId, failIfNotKnown, drawable);
        }
        if (drawable != null) {
            c0.b(drawable);
        }
        return drawable;
    }

    public synchronized void y(Context context) {
        LongSparseArray<WeakReference<Drawable.ConstantState>> cache = (f) this.d.get(context);
        if (cache != null) {
            cache.b();
        }
    }

    public static long h(TypedValue tv) {
        return (((long) tv.assetCookie) << 32) | ((long) tv.data);
    }

    public final Drawable k(Context context, int resId) {
        if (this.e == null) {
            this.e = new TypedValue();
        }
        TypedValue tv = this.e;
        context.getResources().getValue(resId, tv, true);
        long key = h(tv);
        Drawable dr = o(context, key);
        if (dr != null) {
            return dr;
        }
        if (resId == a.b.d.b.e.abc_cab_background_top_material) {
            dr = new LayerDrawable(new Drawable[]{p(context, a.b.d.b.e.abc_cab_background_internal_bg), p(context, a.b.d.b.e.abc_cab_background_top_mtrl_alpha)});
        }
        if (dr != null) {
            dr.setChangingConfigurations(tv.changingConfigurations);
            b(context, key, dr);
        }
        return dr;
    }

    public final Drawable A(Context context, int resId, boolean failIfNotKnown, Drawable drawable) {
        ColorStateList tintList = s(context, resId);
        if (tintList != null) {
            if (c0.a(drawable)) {
                drawable = drawable.mutate();
            }
            Drawable drawable2 = a.b.c.c.j.a.p(drawable);
            a.b.c.c.j.a.n(drawable2, tintList);
            PorterDuff.Mode tintMode = u(resId);
            if (tintMode == null) {
                return drawable2;
            }
            a.b.c.c.j.a.o(drawable2, tintMode);
            return drawable2;
        } else if (resId == a.b.d.b.e.abc_seekbar_track_material) {
            LayerDrawable ld = (LayerDrawable) drawable;
            z(ld.findDrawableByLayerId(16908288), o0.b(context, a.b.d.b.a.colorControlNormal), g);
            z(ld.findDrawableByLayerId(16908303), o0.b(context, a.b.d.b.a.colorControlNormal), g);
            z(ld.findDrawableByLayerId(16908301), o0.b(context, a.b.d.b.a.colorControlActivated), g);
            return drawable;
        } else if (resId == a.b.d.b.e.abc_ratingbar_material || resId == a.b.d.b.e.abc_ratingbar_indicator_material || resId == a.b.d.b.e.abc_ratingbar_small_material) {
            LayerDrawable ld2 = (LayerDrawable) drawable;
            z(ld2.findDrawableByLayerId(16908288), o0.a(context, a.b.d.b.a.colorControlNormal), g);
            z(ld2.findDrawableByLayerId(16908303), o0.b(context, a.b.d.b.a.colorControlActivated), g);
            z(ld2.findDrawableByLayerId(16908301), o0.b(context, a.b.d.b.a.colorControlActivated), g);
            return drawable;
        } else if (C(context, resId, drawable) || !failIfNotKnown) {
            return drawable;
        } else {
            return null;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:30:0x0076 A[Catch:{ Exception -> 0x00a6 }] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x009e A[Catch:{ Exception -> 0x00a6 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.graphics.drawable.Drawable x(android.content.Context r13, int r14) {
        /*
            r12 = this;
            a.b.c.g.a<java.lang.String, a.b.d.f.j$d> r0 = r12.f480b
            r1 = 0
            if (r0 == 0) goto L_0x00b6
            boolean r0 = r0.isEmpty()
            if (r0 != 0) goto L_0x00b6
            a.b.c.g.l<java.lang.String> r0 = r12.f481c
            java.lang.String r2 = "appcompat_skip_skip"
            if (r0 == 0) goto L_0x002a
            java.lang.Object r0 = r0.f(r14)
            java.lang.String r0 = (java.lang.String) r0
            boolean r3 = r2.equals(r0)
            if (r3 != 0) goto L_0x0029
            if (r0 == 0) goto L_0x0028
            a.b.c.g.a<java.lang.String, a.b.d.f.j$d> r3 = r12.f480b
            java.lang.Object r3 = r3.get(r0)
            if (r3 != 0) goto L_0x0028
            goto L_0x0029
        L_0x0028:
            goto L_0x0031
        L_0x0029:
            return r1
        L_0x002a:
            a.b.c.g.l r0 = new a.b.c.g.l
            r0.<init>()
            r12.f481c = r0
        L_0x0031:
            android.util.TypedValue r0 = r12.e
            if (r0 != 0) goto L_0x003c
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            r12.e = r0
        L_0x003c:
            android.util.TypedValue r0 = r12.e
            android.content.res.Resources r1 = r13.getResources()
            r3 = 1
            r1.getValue(r14, r0, r3)
            long r4 = h(r0)
            android.graphics.drawable.Drawable r6 = r12.o(r13, r4)
            if (r6 == 0) goto L_0x0051
            return r6
        L_0x0051:
            java.lang.CharSequence r7 = r0.string
            if (r7 == 0) goto L_0x00ae
            java.lang.String r7 = r7.toString()
            java.lang.String r8 = ".xml"
            boolean r7 = r7.endsWith(r8)
            if (r7 == 0) goto L_0x00ae
            android.content.res.XmlResourceParser r7 = r1.getXml(r14)     // Catch:{ Exception -> 0x00a6 }
            android.util.AttributeSet r8 = android.util.Xml.asAttributeSet(r7)     // Catch:{ Exception -> 0x00a6 }
        L_0x0069:
            int r9 = r7.next()     // Catch:{ Exception -> 0x00a6 }
            r10 = r9
            r11 = 2
            if (r9 == r11) goto L_0x0074
            if (r10 == r3) goto L_0x0074
            goto L_0x0069
        L_0x0074:
            if (r10 != r11) goto L_0x009e
            java.lang.String r3 = r7.getName()     // Catch:{ Exception -> 0x00a6 }
            a.b.c.g.l<java.lang.String> r9 = r12.f481c     // Catch:{ Exception -> 0x00a6 }
            r9.a(r14, r3)     // Catch:{ Exception -> 0x00a6 }
            a.b.c.g.a<java.lang.String, a.b.d.f.j$d> r9 = r12.f480b     // Catch:{ Exception -> 0x00a6 }
            java.lang.Object r9 = r9.get(r3)     // Catch:{ Exception -> 0x00a6 }
            a.b.d.f.j$d r9 = (a.b.d.f.j.d) r9     // Catch:{ Exception -> 0x00a6 }
            if (r9 == 0) goto L_0x0093
            android.content.res.Resources$Theme r11 = r13.getTheme()     // Catch:{ Exception -> 0x00a6 }
            android.graphics.drawable.Drawable r11 = r9.a(r13, r7, r8, r11)     // Catch:{ Exception -> 0x00a6 }
            r6 = r11
        L_0x0093:
            if (r6 == 0) goto L_0x009d
            int r11 = r0.changingConfigurations     // Catch:{ Exception -> 0x00a6 }
            r6.setChangingConfigurations(r11)     // Catch:{ Exception -> 0x00a6 }
            r12.b(r13, r4, r6)     // Catch:{ Exception -> 0x00a6 }
        L_0x009d:
            goto L_0x00ae
        L_0x009e:
            org.xmlpull.v1.XmlPullParserException r3 = new org.xmlpull.v1.XmlPullParserException     // Catch:{ Exception -> 0x00a6 }
            java.lang.String r9 = "No start tag found"
            r3.<init>(r9)     // Catch:{ Exception -> 0x00a6 }
            throw r3     // Catch:{ Exception -> 0x00a6 }
        L_0x00a6:
            r3 = move-exception
            java.lang.String r7 = "AppCompatDrawableManag"
            java.lang.String r8 = "Exception while inflating drawable"
            android.util.Log.e(r7, r8, r3)
        L_0x00ae:
            if (r6 != 0) goto L_0x00b5
            a.b.c.g.l<java.lang.String> r3 = r12.f481c
            r3.a(r14, r2)
        L_0x00b5:
            return r6
        L_0x00b6:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.d.f.j.x(android.content.Context, int):android.graphics.drawable.Drawable");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x002c, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized android.graphics.drawable.Drawable o(android.content.Context r5, long r6) {
        /*
            r4 = this;
            monitor-enter(r4)
            java.util.WeakHashMap<android.content.Context, a.b.c.g.f<java.lang.ref.WeakReference<android.graphics.drawable.Drawable$ConstantState>>> r0 = r4.d     // Catch:{ all -> 0x002d }
            java.lang.Object r0 = r0.get(r5)     // Catch:{ all -> 0x002d }
            a.b.c.g.f r0 = (a.b.c.g.f) r0     // Catch:{ all -> 0x002d }
            r1 = 0
            if (r0 != 0) goto L_0x000e
            monitor-exit(r4)
            return r1
        L_0x000e:
            java.lang.Object r2 = r0.f(r6)     // Catch:{ all -> 0x002d }
            java.lang.ref.WeakReference r2 = (java.lang.ref.WeakReference) r2     // Catch:{ all -> 0x002d }
            if (r2 == 0) goto L_0x002b
            java.lang.Object r3 = r2.get()     // Catch:{ all -> 0x002d }
            android.graphics.drawable.Drawable$ConstantState r3 = (android.graphics.drawable.Drawable.ConstantState) r3     // Catch:{ all -> 0x002d }
            if (r3 == 0) goto L_0x0028
            android.content.res.Resources r1 = r5.getResources()     // Catch:{ all -> 0x002d }
            android.graphics.drawable.Drawable r1 = r3.newDrawable(r1)     // Catch:{ all -> 0x002d }
            monitor-exit(r4)
            return r1
        L_0x0028:
            r0.d(r6)     // Catch:{ all -> 0x002d }
        L_0x002b:
            monitor-exit(r4)
            return r1
        L_0x002d:
            r5 = move-exception
            monitor-exit(r4)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.d.f.j.o(android.content.Context, long):android.graphics.drawable.Drawable");
    }

    public final synchronized boolean b(Context context, long key, Drawable drawable) {
        Drawable.ConstantState cs = drawable.getConstantState();
        if (cs == null) {
            return false;
        }
        LongSparseArray<WeakReference<Drawable.ConstantState>> cache = (f) this.d.get(context);
        if (cache == null) {
            cache = new f<>();
            this.d.put(context, cache);
        }
        cache.i(key, new WeakReference(cs));
        return true;
    }

    public static boolean C(Context context, int resId, Drawable drawable) {
        PorterDuff.Mode tintMode = g;
        boolean colorAttrSet = false;
        int colorAttr = 0;
        int alpha = -1;
        if (d(j, resId)) {
            colorAttr = a.b.d.b.a.colorControlNormal;
            colorAttrSet = true;
        } else if (d(l, resId)) {
            colorAttr = a.b.d.b.a.colorControlActivated;
            colorAttrSet = true;
        } else if (d(m, resId)) {
            colorAttr = 16842801;
            colorAttrSet = true;
            tintMode = PorterDuff.Mode.MULTIPLY;
        } else if (resId == a.b.d.b.e.abc_list_divider_mtrl_alpha) {
            colorAttr = 16842800;
            colorAttrSet = true;
            alpha = Math.round(40.8f);
        } else if (resId == a.b.d.b.e.abc_dialog_material_background) {
            colorAttr = 16842801;
            colorAttrSet = true;
        }
        if (!colorAttrSet) {
            return false;
        }
        if (c0.a(drawable)) {
            drawable = drawable.mutate();
        }
        drawable.setColorFilter(r(o0.b(context, colorAttr), tintMode));
        if (alpha == -1) {
            return true;
        }
        drawable.setAlpha(alpha);
        return true;
    }

    public final void a(String tagName, d delegate) {
        if (this.f480b == null) {
            this.f480b = new a.b.c.g.a<>();
        }
        this.f480b.put(tagName, delegate);
    }

    public static boolean d(int[] array, int value) {
        for (int id : array) {
            if (id == value) {
                return true;
            }
        }
        return false;
    }

    public static PorterDuff.Mode u(int resId) {
        if (resId == a.b.d.b.e.abc_switch_thumb_material) {
            return PorterDuff.Mode.MULTIPLY;
        }
        return null;
    }

    public synchronized ColorStateList s(Context context, int resId) {
        ColorStateList tint;
        tint = t(context, resId);
        if (tint == null) {
            if (resId == a.b.d.b.e.abc_edit_text_material) {
                tint = a.b.d.c.a.a.c(context, a.b.d.b.c.abc_tint_edittext);
            } else if (resId == a.b.d.b.e.abc_switch_track_mtrl_alpha) {
                tint = a.b.d.c.a.a.c(context, a.b.d.b.c.abc_tint_switch_track);
            } else if (resId == a.b.d.b.e.abc_switch_thumb_material) {
                tint = l(context);
            } else if (resId == a.b.d.b.e.abc_btn_default_mtrl_shape) {
                tint = j(context);
            } else if (resId == a.b.d.b.e.abc_btn_borderless_material) {
                tint = f(context);
            } else if (resId == a.b.d.b.e.abc_btn_colored_material) {
                tint = i(context);
            } else {
                if (resId != a.b.d.b.e.abc_spinner_mtrl_am_alpha) {
                    if (resId != a.b.d.b.e.abc_spinner_textfield_background_material) {
                        if (d(k, resId)) {
                            tint = o0.d(context, a.b.d.b.a.colorControlNormal);
                        } else if (d(n, resId)) {
                            tint = a.b.d.c.a.a.c(context, a.b.d.b.c.abc_tint_default);
                        } else if (d(o, resId)) {
                            tint = a.b.d.c.a.a.c(context, a.b.d.b.c.abc_tint_btn_checkable);
                        } else if (resId == a.b.d.b.e.abc_seekbar_thumb_material) {
                            tint = a.b.d.c.a.a.c(context, a.b.d.b.c.abc_tint_seek_thumb);
                        }
                    }
                }
                tint = a.b.d.c.a.a.c(context, a.b.d.b.c.abc_tint_spinner);
            }
            if (tint != null) {
                c(context, resId, tint);
            }
        }
        return tint;
    }

    public final ColorStateList t(Context context, int resId) {
        SparseArrayCompat<ColorStateList> tints;
        WeakHashMap<Context, l<ColorStateList>> weakHashMap = this.f479a;
        if (weakHashMap == null || (tints = (l) weakHashMap.get(context)) == null) {
            return null;
        }
        return (ColorStateList) tints.f(resId);
    }

    public final void c(Context context, int resId, ColorStateList tintList) {
        if (this.f479a == null) {
            this.f479a = new WeakHashMap<>();
        }
        SparseArrayCompat<ColorStateList> themeTints = (l) this.f479a.get(context);
        if (themeTints == null) {
            themeTints = new l<>();
            this.f479a.put(context, themeTints);
        }
        themeTints.a(resId, tintList);
    }

    public final ColorStateList j(Context context) {
        return g(context, o0.b(context, a.b.d.b.a.colorButtonNormal));
    }

    public final ColorStateList f(Context context) {
        return g(context, 0);
    }

    public final ColorStateList i(Context context) {
        return g(context, o0.b(context, a.b.d.b.a.colorAccent));
    }

    public final ColorStateList g(Context context, int baseColor) {
        int[][] states = new int[4][];
        int[] colors = new int[4];
        int colorControlHighlight = o0.b(context, a.b.d.b.a.colorControlHighlight);
        int disabledColor = o0.a(context, a.b.d.b.a.colorButtonNormal);
        states[0] = o0.f503b;
        colors[0] = disabledColor;
        int i2 = 0 + 1;
        states[i2] = o0.d;
        colors[i2] = a.b.c.c.a.b(colorControlHighlight, baseColor);
        int i3 = i2 + 1;
        states[i3] = o0.f504c;
        colors[i3] = a.b.c.c.a.b(colorControlHighlight, baseColor);
        int i4 = i3 + 1;
        states[i4] = o0.f;
        colors[i4] = baseColor;
        int i5 = i4 + 1;
        return new ColorStateList(states, colors);
    }

    public final ColorStateList l(Context context) {
        int[][] states = new int[3][];
        int[] colors = new int[3];
        ColorStateList thumbColor = o0.d(context, a.b.d.b.a.colorSwitchThumbNormal);
        if (thumbColor == null || !thumbColor.isStateful()) {
            states[0] = o0.f503b;
            colors[0] = o0.a(context, a.b.d.b.a.colorSwitchThumbNormal);
            int i2 = 0 + 1;
            states[i2] = o0.e;
            colors[i2] = o0.b(context, a.b.d.b.a.colorControlActivated);
            int i3 = i2 + 1;
            states[i3] = o0.f;
            colors[i3] = o0.b(context, a.b.d.b.a.colorSwitchThumbNormal);
            int i4 = i3 + 1;
        } else {
            states[0] = o0.f503b;
            colors[0] = thumbColor.getColorForState(states[0], 0);
            int i5 = 0 + 1;
            states[i5] = o0.e;
            colors[i5] = o0.b(context, a.b.d.b.a.colorControlActivated);
            int i6 = i5 + 1;
            states[i6] = o0.f;
            colors[i6] = thumbColor.getDefaultColor();
            int i7 = i6 + 1;
        }
        return new ColorStateList(states, colors);
    }

    public static class c extends g<Integer, PorterDuffColorFilter> {
        public c(int maxSize) {
            super(maxSize);
        }

        public PorterDuffColorFilter i(int color, PorterDuff.Mode mode) {
            return (PorterDuffColorFilter) c(Integer.valueOf(h(color, mode)));
        }

        public PorterDuffColorFilter j(int color, PorterDuff.Mode mode, PorterDuffColorFilter filter) {
            return (PorterDuffColorFilter) d(Integer.valueOf(h(color, mode)), filter);
        }

        public static int h(int color, PorterDuff.Mode mode) {
            return (((1 * 31) + color) * 31) + mode.hashCode();
        }
    }

    public static void B(Drawable drawable, r0 tint, int[] state) {
        if (!c0.a(drawable) || drawable.mutate() == drawable) {
            if (tint.d || tint.f517c) {
                drawable.setColorFilter(m(tint.d ? tint.f515a : null, tint.f517c ? tint.f516b : g, state));
            } else {
                drawable.clearColorFilter();
            }
            if (Build.VERSION.SDK_INT <= 23) {
                drawable.invalidateSelf();
                return;
            }
            return;
        }
        Log.d("AppCompatDrawableManag", "Mutated drawable is not the same instance as the input.");
    }

    public static PorterDuffColorFilter m(ColorStateList tint, PorterDuff.Mode tintMode, int[] state) {
        if (tint == null || tintMode == null) {
            return null;
        }
        return r(tint.getColorForState(state, 0), tintMode);
    }

    public static synchronized PorterDuffColorFilter r(int color, PorterDuff.Mode mode) {
        PorterDuffColorFilter filter;
        synchronized (j.class) {
            filter = i.i(color, mode);
            if (filter == null) {
                filter = new PorterDuffColorFilter(color, mode);
                i.j(color, mode, filter);
            }
        }
        return filter;
    }

    public static void z(Drawable d2, int color, PorterDuff.Mode mode) {
        if (c0.a(d2)) {
            d2 = d2.mutate();
        }
        d2.setColorFilter(r(color, mode == null ? g : mode));
    }

    public final void e(Context context) {
        if (!this.f) {
            this.f = true;
            Drawable d2 = p(context, a.b.d.b.e.abc_vector_test);
            if (d2 == null || !w(d2)) {
                this.f = false;
                throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
            }
        }
    }

    public static boolean w(Drawable d2) {
        return (d2 instanceof h) || "android.graphics.drawable.VectorDrawable".equals(d2.getClass().getName());
    }

    public static class e implements d {
        public Drawable a(Context context, XmlPullParser parser, AttributeSet attrs, Resources.Theme theme) {
            try {
                return h.c(context.getResources(), parser, attrs, theme);
            } catch (Exception e) {
                Log.e("VdcInflateDelegate", "Exception while inflating <vector>", e);
                return null;
            }
        }
    }

    public static class b implements d {
        public Drawable a(Context context, XmlPullParser parser, AttributeSet attrs, Resources.Theme theme) {
            try {
                return a.b.b.a.b.a(context, context.getResources(), parser, attrs, theme);
            } catch (Exception e) {
                Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", e);
                return null;
            }
        }
    }

    public static class a implements d {
        public Drawable a(Context context, XmlPullParser parser, AttributeSet attrs, Resources.Theme theme) {
            try {
                return a.b.d.d.a.a.m(context, context.getResources(), parser, attrs, theme);
            } catch (Exception e) {
                Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", e);
                return null;
            }
        }
    }
}
