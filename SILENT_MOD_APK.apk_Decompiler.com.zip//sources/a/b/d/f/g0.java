package a.b.d.f;

import a.b.c.h.d;
import a.b.c.h.p;
import a.b.d.b.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class g0 extends ViewGroup {

    /* renamed from: b  reason: collision with root package name */
    public boolean f461b;

    /* renamed from: c  reason: collision with root package name */
    public int f462c;
    public int d;
    public int e;
    public int f;
    public int g;
    public float h;
    public boolean i;
    public int[] j;
    public int[] k;
    public Drawable l;
    public int m;
    public int n;
    public int o;
    public int p;

    public g0(Context context) {
        this(context, (AttributeSet) null);
    }

    public g0(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public g0(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.f461b = true;
        this.f462c = -1;
        this.d = 0;
        this.f = 8388659;
        t0 a2 = t0.t(context, attrs, j.LinearLayoutCompat, defStyleAttr, 0);
        int index = a2.j(j.LinearLayoutCompat_android_orientation, -1);
        if (index >= 0) {
            setOrientation(index);
        }
        int index2 = a2.j(j.LinearLayoutCompat_android_gravity, -1);
        if (index2 >= 0) {
            setGravity(index2);
        }
        boolean baselineAligned = a2.a(j.LinearLayoutCompat_android_baselineAligned, true);
        if (!baselineAligned) {
            setBaselineAligned(baselineAligned);
        }
        this.h = a2.h(j.LinearLayoutCompat_android_weightSum, -1.0f);
        this.f462c = a2.j(j.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
        this.i = a2.a(j.LinearLayoutCompat_measureWithLargestChild, false);
        setDividerDrawable(a2.f(j.LinearLayoutCompat_divider));
        this.o = a2.j(j.LinearLayoutCompat_showDividers, 0);
        this.p = a2.e(j.LinearLayoutCompat_dividerPadding, 0);
        a2.u();
    }

    public void setShowDividers(int showDividers) {
        if (showDividers != this.o) {
            requestLayout();
        }
        this.o = showDividers;
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public int getShowDividers() {
        return this.o;
    }

    public Drawable getDividerDrawable() {
        return this.l;
    }

    public void setDividerDrawable(Drawable divider) {
        if (divider != this.l) {
            this.l = divider;
            boolean z = false;
            if (divider != null) {
                this.m = divider.getIntrinsicWidth();
                this.n = divider.getIntrinsicHeight();
            } else {
                this.m = 0;
                this.n = 0;
            }
            if (divider == null) {
                z = true;
            }
            setWillNotDraw(z);
            requestLayout();
        }
    }

    public void setDividerPadding(int padding) {
        this.p = padding;
    }

    public int getDividerPadding() {
        return this.p;
    }

    public int getDividerWidth() {
        return this.m;
    }

    public void onDraw(Canvas canvas) {
        if (this.l != null) {
            if (this.e == 1) {
                f(canvas);
            } else {
                e(canvas);
            }
        }
    }

    public void f(Canvas canvas) {
        int bottom;
        int count = getVirtualChildCount();
        for (int i2 = 0; i2 < count; i2++) {
            View child = q(i2);
            if (!(child == null || child.getVisibility() == 8 || !r(i2))) {
                g(canvas, (child.getTop() - ((a) child.getLayoutParams()).topMargin) - this.n);
            }
        }
        if (r(count) != 0) {
            View child2 = q(count - 1);
            if (child2 == null) {
                bottom = (getHeight() - getPaddingBottom()) - this.n;
            } else {
                bottom = child2.getBottom() + ((a) child2.getLayoutParams()).bottomMargin;
            }
            g(canvas, bottom);
        }
    }

    public void e(Canvas canvas) {
        int position;
        int position2;
        int count = getVirtualChildCount();
        boolean isLayoutRtl = a1.b(this);
        for (int i2 = 0; i2 < count; i2++) {
            View child = q(i2);
            if (!(child == null || child.getVisibility() == 8 || !r(i2))) {
                a lp = (a) child.getLayoutParams();
                if (isLayoutRtl) {
                    position2 = child.getRight() + lp.rightMargin;
                } else {
                    position2 = (child.getLeft() - lp.leftMargin) - this.m;
                }
                h(canvas, position2);
            }
        }
        if (r(count) != 0) {
            View child2 = q(count - 1);
            if (child2 != null) {
                a lp2 = (a) child2.getLayoutParams();
                if (isLayoutRtl) {
                    position = (child2.getLeft() - lp2.leftMargin) - this.m;
                } else {
                    position = child2.getRight() + lp2.rightMargin;
                }
            } else if (isLayoutRtl) {
                position = getPaddingLeft();
            } else {
                position = (getWidth() - getPaddingRight()) - this.m;
            }
            h(canvas, position);
        }
    }

    public void g(Canvas canvas, int top) {
        this.l.setBounds(getPaddingLeft() + this.p, top, (getWidth() - getPaddingRight()) - this.p, this.n + top);
        this.l.draw(canvas);
    }

    public void h(Canvas canvas, int left) {
        this.l.setBounds(left, getPaddingTop() + this.p, this.m + left, (getHeight() - getPaddingBottom()) - this.p);
        this.l.draw(canvas);
    }

    public void setBaselineAligned(boolean baselineAligned) {
        this.f461b = baselineAligned;
    }

    public void setMeasureWithLargestChildEnabled(boolean enabled) {
        this.i = enabled;
    }

    public int getBaseline() {
        int majorGravity;
        if (this.f462c < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i2 = this.f462c;
        if (childCount > i2) {
            View child = getChildAt(i2);
            int childBaseline = child.getBaseline();
            if (childBaseline != -1) {
                int childTop = this.d;
                if (this.e == 1 && (majorGravity = this.f & j.AppCompatTheme_windowActionBarOverlay) != 48) {
                    if (majorGravity == 16) {
                        childTop += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.g) / 2;
                    } else if (majorGravity == 80) {
                        childTop = ((getBottom() - getTop()) - getPaddingBottom()) - this.g;
                    }
                }
                return ((a) child.getLayoutParams()).topMargin + childTop + childBaseline;
            } else if (this.f462c == 0) {
                return -1;
            } else {
                throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
            }
        } else {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
    }

    public int getBaselineAlignedChildIndex() {
        return this.f462c;
    }

    public void setBaselineAlignedChildIndex(int i2) {
        if (i2 < 0 || i2 >= getChildCount()) {
            throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
        }
        this.f462c = i2;
    }

    public View q(int index) {
        return getChildAt(index);
    }

    public int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.h;
    }

    public void setWeightSum(float weightSum) {
        this.h = Math.max(0.0f, weightSum);
    }

    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (this.e == 1) {
            x(widthMeasureSpec, heightMeasureSpec);
        } else {
            v(widthMeasureSpec, heightMeasureSpec);
        }
    }

    public boolean r(int childIndex) {
        if (childIndex == 0) {
            if ((this.o & 1) != 0) {
                return true;
            }
            return false;
        } else if (childIndex == getChildCount()) {
            if ((this.o & 4) != 0) {
                return true;
            }
            return false;
        } else if ((this.o & 2) == 0) {
            return false;
        } else {
            for (int i2 = childIndex - 1; i2 >= 0; i2--) {
                if (getChildAt(i2).getVisibility() != 8) {
                    return true;
                }
            }
            return false;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:154:0x03cb  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x03ce  */
    /* JADX WARNING: Removed duplicated region for block: B:158:0x03d5  */
    /* JADX WARNING: Removed duplicated region for block: B:161:0x03de  */
    /* JADX WARNING: Removed duplicated region for block: B:172:0x044c  */
    /* JADX WARNING: Removed duplicated region for block: B:190:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void x(int r40, int r41) {
        /*
            r39 = this;
            r6 = r39
            r7 = r40
            r8 = r41
            r9 = 0
            r6.g = r9
            r0 = 0
            r1 = 0
            r2 = 0
            r3 = 0
            r4 = 1
            r5 = 0
            int r10 = r39.getVirtualChildCount()
            int r11 = android.view.View.MeasureSpec.getMode(r40)
            int r12 = android.view.View.MeasureSpec.getMode(r41)
            r13 = 0
            r14 = 0
            int r15 = r6.f462c
            boolean r9 = r6.i
            r17 = 0
            r18 = 0
            r19 = r14
            r14 = r1
            r37 = r13
            r13 = r0
            r0 = r5
            r5 = r2
            r2 = r18
            r18 = r37
            r38 = r4
            r4 = r3
            r3 = r17
            r17 = r38
        L_0x0038:
            r20 = r3
            r1 = 8
            r22 = 1
            r23 = 0
            if (r2 >= r10) goto L_0x01ac
            android.view.View r25 = r6.q(r2)
            if (r25 != 0) goto L_0x0059
            int r1 = r6.g
            int r3 = r39.w()
            int r1 = r1 + r3
            r6.g = r1
            r21 = r12
            r3 = r20
            r20 = r10
            goto L_0x01a0
        L_0x0059:
            int r3 = r25.getVisibility()
            if (r3 != r1) goto L_0x006c
            int r1 = r39.n()
            int r2 = r2 + r1
            r21 = r12
            r3 = r20
            r20 = r10
            goto L_0x01a0
        L_0x006c:
            boolean r1 = r6.r(r2)
            if (r1 == 0) goto L_0x0079
            int r1 = r6.g
            int r3 = r6.n
            int r1 = r1 + r3
            r6.g = r1
        L_0x0079:
            android.view.ViewGroup$LayoutParams r1 = r25.getLayoutParams()
            r3 = r1
            a.b.d.f.g0$a r3 = (a.b.d.f.g0.a) r3
            float r1 = r3.f463a
            float r27 = r0 + r1
            r0 = 1073741824(0x40000000, float:2.0)
            if (r12 != r0) goto L_0x00b7
            int r0 = r3.height
            if (r0 != 0) goto L_0x00b7
            int r0 = (r1 > r23 ? 1 : (r1 == r23 ? 0 : -1))
            if (r0 <= 0) goto L_0x00b7
            int r0 = r6.g
            int r1 = r3.topMargin
            int r1 = r1 + r0
            r28 = r2
            int r2 = r3.bottomMargin
            int r1 = r1 + r2
            int r1 = java.lang.Math.max(r0, r1)
            r6.g = r1
            r19 = 1
            r32 = r4
            r33 = r5
            r21 = r12
            r24 = r14
            r7 = r28
            r14 = 1073741824(0x40000000, float:2.0)
            r37 = r10
            r10 = r3
            r3 = r20
            r20 = r37
            goto L_0x0123
        L_0x00b7:
            r28 = r2
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            int r1 = r3.height
            if (r1 != 0) goto L_0x00cb
            float r1 = r3.f463a
            int r1 = (r1 > r23 ? 1 : (r1 == r23 ? 0 : -1))
            if (r1 <= 0) goto L_0x00cb
            r0 = 0
            r1 = -2
            r3.height = r1
            r2 = r0
            goto L_0x00cc
        L_0x00cb:
            r2 = r0
        L_0x00cc:
            r29 = 0
            int r0 = (r27 > r23 ? 1 : (r27 == r23 ? 0 : -1))
            if (r0 != 0) goto L_0x00d7
            int r0 = r6.g
            r30 = r0
            goto L_0x00d9
        L_0x00d7:
            r30 = 0
        L_0x00d9:
            r26 = 1073741824(0x40000000, float:2.0)
            r0 = r39
            r1 = r25
            r8 = r2
            r7 = r28
            r2 = r40
            r21 = r12
            r24 = r14
            r12 = r20
            r14 = 1073741824(0x40000000, float:2.0)
            r20 = r10
            r10 = r3
            r3 = r29
            r32 = r4
            r4 = r41
            r33 = r5
            r5 = r30
            r0.u(r1, r2, r3, r4, r5)
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r8 == r2) goto L_0x0102
            r10.height = r8
        L_0x0102:
            int r0 = r25.getMeasuredHeight()
            int r1 = r6.g
            int r2 = r1 + r0
            int r3 = r10.topMargin
            int r2 = r2 + r3
            int r3 = r10.bottomMargin
            int r2 = r2 + r3
            int r3 = r39.p()
            int r2 = r2 + r3
            int r2 = java.lang.Math.max(r1, r2)
            r6.g = r2
            if (r9 == 0) goto L_0x0122
            int r3 = java.lang.Math.max(r0, r12)
            goto L_0x0123
        L_0x0122:
            r3 = r12
        L_0x0123:
            if (r15 < 0) goto L_0x012d
            int r2 = r7 + 1
            if (r15 != r2) goto L_0x012d
            int r0 = r6.g
            r6.d = r0
        L_0x012d:
            if (r7 >= r15) goto L_0x013e
            float r0 = r10.f463a
            int r0 = (r0 > r23 ? 1 : (r0 == r23 ? 0 : -1))
            if (r0 > 0) goto L_0x0136
            goto L_0x013e
        L_0x0136:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r1 = "A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex."
            r0.<init>(r1)
            throw r0
        L_0x013e:
            r0 = 0
            if (r11 == r14) goto L_0x0149
            int r1 = r10.width
            r2 = -1
            if (r1 != r2) goto L_0x0149
            r18 = 1
            r0 = 1
        L_0x0149:
            int r1 = r10.leftMargin
            int r2 = r10.rightMargin
            int r1 = r1 + r2
            int r2 = r25.getMeasuredWidth()
            int r2 = r2 + r1
            int r4 = java.lang.Math.max(r13, r2)
            int r5 = r25.getMeasuredState()
            r8 = r24
            int r5 = android.view.View.combineMeasuredStates(r8, r5)
            if (r17 == 0) goto L_0x016b
            int r8 = r10.width
            r12 = -1
            if (r8 != r12) goto L_0x016b
            r8 = 1
            goto L_0x016c
        L_0x016b:
            r8 = 0
        L_0x016c:
            float r12 = r10.f463a
            int r12 = (r12 > r23 ? 1 : (r12 == r23 ? 0 : -1))
            if (r12 <= 0) goto L_0x017f
            if (r0 == 0) goto L_0x0176
            r12 = r1
            goto L_0x0177
        L_0x0176:
            r12 = r2
        L_0x0177:
            r13 = r32
            int r12 = java.lang.Math.max(r13, r12)
            r13 = r12
            goto L_0x018e
        L_0x017f:
            r13 = r32
            if (r0 == 0) goto L_0x0185
            r12 = r1
            goto L_0x0186
        L_0x0185:
            r12 = r2
        L_0x0186:
            r14 = r33
            int r12 = java.lang.Math.max(r14, r12)
            r33 = r12
        L_0x018e:
            int r12 = r39.n()
            int r7 = r7 + r12
            r14 = r5
            r2 = r7
            r17 = r8
            r0 = r27
            r5 = r33
            r37 = r13
            r13 = r4
            r4 = r37
        L_0x01a0:
            int r2 = r2 + 1
            r7 = r40
            r8 = r41
            r10 = r20
            r12 = r21
            goto L_0x0038
        L_0x01ac:
            r7 = r2
            r3 = r4
            r21 = r12
            r8 = r14
            r12 = r20
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r14 = 1073741824(0x40000000, float:2.0)
            r20 = r10
            int r4 = r6.g
            if (r4 <= 0) goto L_0x01cd
            r4 = r20
            boolean r7 = r6.r(r4)
            if (r7 == 0) goto L_0x01cf
            int r7 = r6.g
            int r10 = r6.n
            int r7 = r7 + r10
            r6.g = r7
            goto L_0x01cf
        L_0x01cd:
            r4 = r20
        L_0x01cf:
            if (r9 == 0) goto L_0x0229
            r7 = r21
            if (r7 == r2) goto L_0x01d7
            if (r7 != 0) goto L_0x022b
        L_0x01d7:
            r2 = 0
            r6.g = r2
            r2 = 0
        L_0x01db:
            if (r2 >= r4) goto L_0x0226
            android.view.View r10 = r6.q(r2)
            if (r10 != 0) goto L_0x01f0
            int r14 = r6.g
            int r21 = r39.w()
            int r14 = r14 + r21
            r6.g = r14
            r25 = r2
            goto L_0x021d
        L_0x01f0:
            int r14 = r10.getVisibility()
            if (r14 != r1) goto L_0x01fc
            int r14 = r39.n()
            int r2 = r2 + r14
            goto L_0x021f
        L_0x01fc:
            android.view.ViewGroup$LayoutParams r14 = r10.getLayoutParams()
            a.b.d.f.g0$a r14 = (a.b.d.f.g0.a) r14
            int r1 = r6.g
            int r24 = r1 + r12
            r25 = r2
            int r2 = r14.topMargin
            int r24 = r24 + r2
            int r2 = r14.bottomMargin
            int r24 = r24 + r2
            int r2 = r39.p()
            int r2 = r24 + r2
            int r2 = java.lang.Math.max(r1, r2)
            r6.g = r2
        L_0x021d:
            r2 = r25
        L_0x021f:
            int r2 = r2 + 1
            r1 = 8
            r14 = 1073741824(0x40000000, float:2.0)
            goto L_0x01db
        L_0x0226:
            r25 = r2
            goto L_0x022b
        L_0x0229:
            r7 = r21
        L_0x022b:
            int r1 = r6.g
            int r2 = r39.getPaddingTop()
            int r10 = r39.getPaddingBottom()
            int r2 = r2 + r10
            int r1 = r1 + r2
            r6.g = r1
            int r1 = r6.g
            int r2 = r39.getSuggestedMinimumHeight()
            int r1 = java.lang.Math.max(r1, r2)
            r2 = r41
            r10 = 0
            int r14 = android.view.View.resolveSizeAndState(r1, r2, r10)
            r10 = 16777215(0xffffff, float:2.3509886E-38)
            r1 = r14 & r10
            int r10 = r6.g
            int r10 = r1 - r10
            if (r19 != 0) goto L_0x02f5
            if (r10 == 0) goto L_0x0265
            int r24 = (r0 > r23 ? 1 : (r0 == r23 ? 0 : -1))
            if (r24 <= 0) goto L_0x0265
            r24 = r0
            r25 = r1
            r32 = r3
            r27 = r8
            goto L_0x02fd
        L_0x0265:
            int r5 = java.lang.Math.max(r5, r3)
            if (r9 == 0) goto L_0x02db
            r24 = r0
            r0 = 1073741824(0x40000000, float:2.0)
            if (r7 == r0) goto L_0x02d2
            r0 = 0
        L_0x0272:
            if (r0 >= r4) goto L_0x02c9
            r25 = r1
            android.view.View r1 = r6.q(r0)
            if (r1 == 0) goto L_0x02b8
            r32 = r3
            int r3 = r1.getVisibility()
            r16 = r5
            r5 = 8
            if (r3 != r5) goto L_0x028b
            r27 = r8
            goto L_0x02be
        L_0x028b:
            android.view.ViewGroup$LayoutParams r3 = r1.getLayoutParams()
            a.b.d.f.g0$a r3 = (a.b.d.f.g0.a) r3
            float r5 = r3.f463a
            int r22 = (r5 > r23 ? 1 : (r5 == r23 ? 0 : -1))
            if (r22 <= 0) goto L_0x02b1
            r22 = r3
            int r3 = r1.getMeasuredWidth()
            r26 = r5
            r5 = 1073741824(0x40000000, float:2.0)
            int r3 = android.view.View.MeasureSpec.makeMeasureSpec(r3, r5)
            r27 = r8
            int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r12, r5)
            r1.measure(r3, r8)
            goto L_0x02be
        L_0x02b1:
            r22 = r3
            r26 = r5
            r27 = r8
            goto L_0x02be
        L_0x02b8:
            r32 = r3
            r16 = r5
            r27 = r8
        L_0x02be:
            int r0 = r0 + 1
            r5 = r16
            r1 = r25
            r8 = r27
            r3 = r32
            goto L_0x0272
        L_0x02c9:
            r25 = r1
            r32 = r3
            r16 = r5
            r27 = r8
            goto L_0x02e5
        L_0x02d2:
            r25 = r1
            r32 = r3
            r16 = r5
            r27 = r8
            goto L_0x02e5
        L_0x02db:
            r24 = r0
            r25 = r1
            r32 = r3
            r16 = r5
            r27 = r8
        L_0x02e5:
            r34 = r7
            r28 = r12
            r29 = r15
            r5 = r16
            r8 = r27
            r12 = r40
            r27 = r9
            goto L_0x042a
        L_0x02f5:
            r24 = r0
            r25 = r1
            r32 = r3
            r27 = r8
        L_0x02fd:
            float r0 = r6.h
            int r1 = (r0 > r23 ? 1 : (r0 == r23 ? 0 : -1))
            if (r1 <= 0) goto L_0x0304
            goto L_0x0306
        L_0x0304:
            r0 = r24
        L_0x0306:
            r1 = 0
            r6.g = r1
            r3 = 0
            r8 = r27
        L_0x030c:
            if (r3 >= r4) goto L_0x0411
            android.view.View r1 = r6.q(r3)
            r27 = r9
            int r9 = r1.getVisibility()
            r28 = r12
            r12 = 8
            if (r9 != r12) goto L_0x0326
            r12 = r40
            r34 = r7
            r29 = r15
            goto L_0x0404
        L_0x0326:
            android.view.ViewGroup$LayoutParams r9 = r1.getLayoutParams()
            a.b.d.f.g0$a r9 = (a.b.d.f.g0.a) r9
            float r12 = r9.f463a
            int r29 = (r12 > r23 ? 1 : (r12 == r23 ? 0 : -1))
            if (r29 <= 0) goto L_0x03a1
            r29 = r15
            float r15 = (float) r10
            float r15 = r15 * r12
            float r15 = r15 / r0
            int r15 = (int) r15
            float r0 = r0 - r12
            int r10 = r10 - r15
            int r30 = r39.getPaddingLeft()
            int r31 = r39.getPaddingRight()
            int r30 = r30 + r31
            r31 = r0
            int r0 = r9.leftMargin
            int r30 = r30 + r0
            int r0 = r9.rightMargin
            int r0 = r30 + r0
            r30 = r10
            int r10 = r9.width
            r33 = r12
            r12 = r40
            int r0 = android.view.ViewGroup.getChildMeasureSpec(r12, r0, r10)
            int r10 = r9.height
            if (r10 != 0) goto L_0x037a
            r10 = 1073741824(0x40000000, float:2.0)
            if (r7 == r10) goto L_0x0367
            r34 = r7
            goto L_0x037c
        L_0x0367:
            if (r15 <= 0) goto L_0x036b
            r10 = r15
            goto L_0x036c
        L_0x036b:
            r10 = 0
        L_0x036c:
            r34 = r7
            r7 = 1073741824(0x40000000, float:2.0)
            int r10 = android.view.View.MeasureSpec.makeMeasureSpec(r10, r7)
            r1.measure(r0, r10)
            r35 = r15
            goto L_0x0391
        L_0x037a:
            r34 = r7
        L_0x037c:
            int r7 = r1.getMeasuredHeight()
            int r7 = r7 + r15
            if (r7 >= 0) goto L_0x0384
            r7 = 0
        L_0x0384:
            r35 = r15
            r10 = 1073741824(0x40000000, float:2.0)
            int r15 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r10)
            r1.measure(r0, r15)
        L_0x0391:
            int r7 = r1.getMeasuredState()
            r7 = r7 & -256(0xffffffffffffff00, float:NaN)
            int r8 = android.view.View.combineMeasuredStates(r8, r7)
            r10 = r30
            r0 = r31
            goto L_0x03a9
        L_0x03a1:
            r34 = r7
            r33 = r12
            r29 = r15
            r12 = r40
        L_0x03a9:
            int r7 = r9.leftMargin
            int r15 = r9.rightMargin
            int r7 = r7 + r15
            int r15 = r1.getMeasuredWidth()
            int r15 = r15 + r7
            int r13 = java.lang.Math.max(r13, r15)
            r30 = r0
            r0 = 1073741824(0x40000000, float:2.0)
            if (r11 == r0) goto L_0x03c6
            int r0 = r9.width
            r31 = r7
            r7 = -1
            if (r0 != r7) goto L_0x03c8
            r0 = 1
            goto L_0x03c9
        L_0x03c6:
            r31 = r7
        L_0x03c8:
            r0 = 0
        L_0x03c9:
            if (r0 == 0) goto L_0x03ce
            r7 = r31
            goto L_0x03cf
        L_0x03ce:
            r7 = r15
        L_0x03cf:
            int r5 = java.lang.Math.max(r5, r7)
            if (r17 == 0) goto L_0x03de
            int r7 = r9.width
            r35 = r0
            r0 = -1
            if (r7 != r0) goto L_0x03e1
            r7 = 1
            goto L_0x03e2
        L_0x03de:
            r35 = r0
            r0 = -1
        L_0x03e1:
            r7 = 0
        L_0x03e2:
            int r0 = r6.g
            int r17 = r1.getMeasuredHeight()
            int r17 = r0 + r17
            r36 = r1
            int r1 = r9.topMargin
            int r17 = r17 + r1
            int r1 = r9.bottomMargin
            int r17 = r17 + r1
            int r1 = r39.p()
            int r1 = r17 + r1
            int r1 = java.lang.Math.max(r0, r1)
            r6.g = r1
            r17 = r7
            r0 = r30
        L_0x0404:
            int r3 = r3 + 1
            r9 = r27
            r12 = r28
            r15 = r29
            r7 = r34
            r1 = 0
            goto L_0x030c
        L_0x0411:
            r34 = r7
            r27 = r9
            r28 = r12
            r29 = r15
            r12 = r40
            int r1 = r6.g
            int r3 = r39.getPaddingTop()
            int r7 = r39.getPaddingBottom()
            int r3 = r3 + r7
            int r1 = r1 + r3
            r6.g = r1
        L_0x042a:
            if (r17 != 0) goto L_0x0431
            r0 = 1073741824(0x40000000, float:2.0)
            if (r11 == r0) goto L_0x0431
            r13 = r5
        L_0x0431:
            int r0 = r39.getPaddingLeft()
            int r1 = r39.getPaddingRight()
            int r0 = r0 + r1
            int r13 = r13 + r0
            int r0 = r39.getSuggestedMinimumWidth()
            int r0 = java.lang.Math.max(r13, r0)
            int r1 = android.view.View.resolveSizeAndState(r0, r12, r8)
            r6.setMeasuredDimension(r1, r14)
            if (r18 == 0) goto L_0x044f
            r6.j(r4, r2)
        L_0x044f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.d.f.g0.x(int, int):void");
    }

    public final void j(int count, int heightMeasureSpec) {
        int uniformMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
        for (int i2 = 0; i2 < count; i2++) {
            View child = q(i2);
            if (child.getVisibility() != 8) {
                a lp = (a) child.getLayoutParams();
                if (lp.width == -1) {
                    int oldHeight = lp.height;
                    lp.height = child.getMeasuredHeight();
                    measureChildWithMargins(child, uniformMeasureSpec, 0, heightMeasureSpec, 0);
                    lp.height = oldHeight;
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:201:0x0518  */
    /* JADX WARNING: Removed duplicated region for block: B:208:0x054d  */
    /* JADX WARNING: Removed duplicated region for block: B:228:0x05fc  */
    /* JADX WARNING: Removed duplicated region for block: B:229:0x0604  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x01c3  */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x01f5  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0204  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x0206  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x020d  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x021a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void v(int r48, int r49) {
        /*
            r47 = this;
            r6 = r47
            r7 = r48
            r8 = r49
            r9 = 0
            r6.g = r9
            r0 = 0
            r1 = 0
            r2 = 0
            r3 = 0
            r4 = 1
            r5 = 0
            int r10 = r47.getVirtualChildCount()
            int r11 = android.view.View.MeasureSpec.getMode(r48)
            int r12 = android.view.View.MeasureSpec.getMode(r49)
            r13 = 0
            r14 = 0
            int[] r15 = r6.j
            if (r15 == 0) goto L_0x0025
            int[] r15 = r6.k
            if (r15 != 0) goto L_0x002e
        L_0x0025:
            r15 = 4
            int[] r9 = new int[r15]
            r6.j = r9
            int[] r9 = new int[r15]
            r6.k = r9
        L_0x002e:
            int[] r9 = r6.j
            int[] r15 = r6.k
            r17 = 3
            r18 = r5
            r5 = -1
            r9[r17] = r5
            r19 = 2
            r9[r19] = r5
            r20 = 1
            r9[r20] = r5
            r16 = 0
            r9[r16] = r5
            r15[r17] = r5
            r15[r19] = r5
            r15[r20] = r5
            r15[r16] = r5
            boolean r5 = r6.f461b
            r22 = r13
            boolean r13 = r6.i
            r23 = r14
            r14 = 1073741824(0x40000000, float:2.0)
            if (r11 != r14) goto L_0x005c
            r24 = 1
            goto L_0x005e
        L_0x005c:
            r24 = 0
        L_0x005e:
            r25 = 0
            r26 = 0
            r27 = r25
            r14 = r26
            r45 = r4
            r4 = r0
            r0 = r18
            r18 = r45
            r46 = r3
            r3 = r1
            r1 = r46
        L_0x0072:
            r29 = 0
            if (r14 >= r10) goto L_0x0246
            android.view.View r8 = r6.q(r14)
            if (r8 != 0) goto L_0x0090
            r31 = r1
            int r1 = r6.g
            int r26 = r47.w()
            int r1 = r1 + r26
            r6.g = r1
            r21 = r5
            r1 = r31
            r31 = r11
            goto L_0x023a
        L_0x0090:
            r31 = r1
            int r1 = r8.getVisibility()
            r32 = r2
            r2 = 8
            if (r1 != r2) goto L_0x00ab
            int r1 = r47.n()
            int r14 = r14 + r1
            r21 = r5
            r1 = r31
            r2 = r32
            r31 = r11
            goto L_0x023a
        L_0x00ab:
            boolean r1 = r6.r(r14)
            if (r1 == 0) goto L_0x00b8
            int r1 = r6.g
            int r2 = r6.m
            int r1 = r1 + r2
            r6.g = r1
        L_0x00b8:
            android.view.ViewGroup$LayoutParams r1 = r8.getLayoutParams()
            r2 = r1
            a.b.d.f.g0$a r2 = (a.b.d.f.g0.a) r2
            float r1 = r2.f463a
            float r30 = r0 + r1
            r0 = 1073741824(0x40000000, float:2.0)
            if (r11 != r0) goto L_0x011b
            int r0 = r2.width
            if (r0 != 0) goto L_0x011b
            int r0 = (r1 > r29 ? 1 : (r1 == r29 ? 0 : -1))
            if (r0 <= 0) goto L_0x011b
            if (r24 == 0) goto L_0x00df
            int r0 = r6.g
            int r1 = r2.leftMargin
            r33 = r3
            int r3 = r2.rightMargin
            int r1 = r1 + r3
            int r0 = r0 + r1
            r6.g = r0
            goto L_0x00ef
        L_0x00df:
            r33 = r3
            int r0 = r6.g
            int r1 = r2.leftMargin
            int r1 = r1 + r0
            int r3 = r2.rightMargin
            int r1 = r1 + r3
            int r1 = java.lang.Math.max(r0, r1)
            r6.g = r1
        L_0x00ef:
            if (r5 == 0) goto L_0x010a
            r0 = 0
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r0)
            r8.measure(r1, r1)
            r1 = r2
            r7 = r4
            r21 = r5
            r3 = r27
            r36 = r31
            r37 = r32
            r39 = r33
            r31 = r11
            r11 = -1
            goto L_0x019f
        L_0x010a:
            r23 = 1
            r1 = r2
            r7 = r4
            r21 = r5
            r36 = r31
            r37 = r32
            r39 = r33
            r31 = r11
            r11 = -1
            goto L_0x01a1
        L_0x011b:
            r33 = r3
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            int r1 = r2.width
            if (r1 != 0) goto L_0x012f
            float r1 = r2.f463a
            int r1 = (r1 > r29 ? 1 : (r1 == r29 ? 0 : -1))
            if (r1 <= 0) goto L_0x012f
            r0 = 0
            r1 = -2
            r2.width = r1
            r3 = r0
            goto L_0x0130
        L_0x012f:
            r3 = r0
        L_0x0130:
            int r0 = (r30 > r29 ? 1 : (r30 == r29 ? 0 : -1))
            if (r0 != 0) goto L_0x0139
            int r0 = r6.g
            r34 = r0
            goto L_0x013b
        L_0x0139:
            r34 = 0
        L_0x013b:
            r35 = 0
            r0 = r47
            r36 = r31
            r1 = r8
            r38 = r2
            r37 = r32
            r2 = r48
            r40 = r3
            r39 = r33
            r3 = r34
            r7 = r4
            r4 = r49
            r21 = r5
            r31 = r11
            r11 = -1
            r5 = r35
            r0.u(r1, r2, r3, r4, r5)
            r0 = r40
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r0 == r1) goto L_0x0166
            r1 = r38
            r1.width = r0
            goto L_0x0168
        L_0x0166:
            r1 = r38
        L_0x0168:
            int r2 = r8.getMeasuredWidth()
            if (r24 == 0) goto L_0x017f
            int r3 = r6.g
            int r4 = r1.leftMargin
            int r4 = r4 + r2
            int r5 = r1.rightMargin
            int r4 = r4 + r5
            int r5 = r47.p()
            int r4 = r4 + r5
            int r3 = r3 + r4
            r6.g = r3
            goto L_0x0194
        L_0x017f:
            int r3 = r6.g
            int r4 = r3 + r2
            int r5 = r1.leftMargin
            int r4 = r4 + r5
            int r5 = r1.rightMargin
            int r4 = r4 + r5
            int r5 = r47.p()
            int r4 = r4 + r5
            int r4 = java.lang.Math.max(r3, r4)
            r6.g = r4
        L_0x0194:
            if (r13 == 0) goto L_0x019d
            r3 = r27
            int r27 = java.lang.Math.max(r2, r3)
            goto L_0x01a1
        L_0x019d:
            r3 = r27
        L_0x019f:
            r27 = r3
        L_0x01a1:
            r0 = 0
            r2 = 1073741824(0x40000000, float:2.0)
            if (r12 == r2) goto L_0x01ad
            int r2 = r1.height
            if (r2 != r11) goto L_0x01ad
            r22 = 1
            r0 = 1
        L_0x01ad:
            int r2 = r1.topMargin
            int r3 = r1.bottomMargin
            int r2 = r2 + r3
            int r3 = r8.getMeasuredHeight()
            int r3 = r3 + r2
            int r4 = r8.getMeasuredState()
            r5 = r39
            int r4 = android.view.View.combineMeasuredStates(r5, r4)
            if (r21 == 0) goto L_0x01f5
            int r5 = r8.getBaseline()
            if (r5 == r11) goto L_0x01f0
            int r11 = r1.f464b
            if (r11 >= 0) goto L_0x01cf
            int r11 = r6.f
        L_0x01cf:
            r11 = r11 & 112(0x70, float:1.57E-43)
            int r26 = r11 >> 4
            r28 = -2
            r26 = r26 & -2
            int r26 = r26 >> 1
            r28 = r2
            r2 = r9[r26]
            int r2 = java.lang.Math.max(r2, r5)
            r9[r26] = r2
            r2 = r15[r26]
            r33 = r4
            int r4 = r3 - r5
            int r2 = java.lang.Math.max(r2, r4)
            r15[r26] = r2
            goto L_0x01f9
        L_0x01f0:
            r28 = r2
            r33 = r4
            goto L_0x01f9
        L_0x01f5:
            r28 = r2
            r33 = r4
        L_0x01f9:
            int r2 = java.lang.Math.max(r7, r3)
            if (r18 == 0) goto L_0x0206
            int r4 = r1.height
            r5 = -1
            if (r4 != r5) goto L_0x0206
            r4 = 1
            goto L_0x0207
        L_0x0206:
            r4 = 0
        L_0x0207:
            float r5 = r1.f463a
            int r5 = (r5 > r29 ? 1 : (r5 == r29 ? 0 : -1))
            if (r5 <= 0) goto L_0x021a
            if (r0 == 0) goto L_0x0212
            r5 = r28
            goto L_0x0213
        L_0x0212:
            r5 = r3
        L_0x0213:
            r11 = r36
            int r5 = java.lang.Math.max(r11, r5)
            goto L_0x022b
        L_0x021a:
            r11 = r36
            if (r0 == 0) goto L_0x0221
            r5 = r28
            goto L_0x0222
        L_0x0221:
            r5 = r3
        L_0x0222:
            r7 = r37
            int r5 = java.lang.Math.max(r7, r5)
            r37 = r5
            r5 = r11
        L_0x022b:
            int r7 = r47.n()
            int r14 = r14 + r7
            r18 = r4
            r1 = r5
            r0 = r30
            r3 = r33
            r4 = r2
            r2 = r37
        L_0x023a:
            int r14 = r14 + 1
            r7 = r48
            r8 = r49
            r5 = r21
            r11 = r31
            goto L_0x0072
        L_0x0246:
            r7 = r4
            r21 = r5
            r31 = r11
            r11 = r1
            r5 = r3
            r3 = r27
            int r1 = r6.g
            if (r1 <= 0) goto L_0x0260
            boolean r1 = r6.r(r10)
            if (r1 == 0) goto L_0x0260
            int r1 = r6.g
            int r4 = r6.m
            int r1 = r1 + r4
            r6.g = r1
        L_0x0260:
            r1 = r9[r20]
            r4 = -1
            if (r1 != r4) goto L_0x0277
            r1 = 0
            r8 = r9[r1]
            if (r8 != r4) goto L_0x0277
            r1 = r9[r19]
            if (r1 != r4) goto L_0x0277
            r1 = r9[r17]
            if (r1 == r4) goto L_0x0273
            goto L_0x0277
        L_0x0273:
            r39 = r5
            r4 = r7
            goto L_0x02aa
        L_0x0277:
            r1 = r9[r17]
            r4 = 0
            r8 = r9[r4]
            r14 = r9[r20]
            r4 = r9[r19]
            int r4 = java.lang.Math.max(r14, r4)
            int r4 = java.lang.Math.max(r8, r4)
            int r1 = java.lang.Math.max(r1, r4)
            r4 = r15[r17]
            r8 = 0
            r14 = r15[r8]
            r8 = r15[r20]
            r39 = r5
            r5 = r15[r19]
            int r5 = java.lang.Math.max(r8, r5)
            int r5 = java.lang.Math.max(r14, r5)
            int r4 = java.lang.Math.max(r4, r5)
            int r5 = r1 + r4
            int r5 = java.lang.Math.max(r7, r5)
            r4 = r5
        L_0x02aa:
            if (r13 == 0) goto L_0x0323
            r1 = r31
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 == r5) goto L_0x02b9
            if (r1 != 0) goto L_0x02b5
            goto L_0x02b9
        L_0x02b5:
            r26 = r4
            goto L_0x0327
        L_0x02b9:
            r5 = 0
            r6.g = r5
            r5 = 0
        L_0x02bd:
            if (r5 >= r10) goto L_0x0320
            android.view.View r7 = r6.q(r5)
            if (r7 != 0) goto L_0x02d1
            int r8 = r6.g
            int r14 = r47.w()
            int r8 = r8 + r14
            r6.g = r8
            r26 = r4
            goto L_0x031b
        L_0x02d1:
            int r8 = r7.getVisibility()
            r14 = 8
            if (r8 != r14) goto L_0x02e1
            int r8 = r47.n()
            int r5 = r5 + r8
            r26 = r4
            goto L_0x031b
        L_0x02e1:
            android.view.ViewGroup$LayoutParams r8 = r7.getLayoutParams()
            a.b.d.f.g0$a r8 = (a.b.d.f.g0.a) r8
            if (r24 == 0) goto L_0x0301
            int r14 = r6.g
            r26 = r4
            int r4 = r8.leftMargin
            int r27 = r3 + r4
            int r4 = r8.rightMargin
            int r27 = r27 + r4
            int r4 = r47.p()
            int r27 = r27 + r4
            int r14 = r14 + r27
            r6.g = r14
            goto L_0x031b
        L_0x0301:
            r26 = r4
            int r4 = r6.g
            int r27 = r4 + r3
            int r14 = r8.leftMargin
            int r27 = r27 + r14
            int r14 = r8.rightMargin
            int r27 = r27 + r14
            int r14 = r47.p()
            int r14 = r27 + r14
            int r14 = java.lang.Math.max(r4, r14)
            r6.g = r14
        L_0x031b:
            int r5 = r5 + 1
            r4 = r26
            goto L_0x02bd
        L_0x0320:
            r26 = r4
            goto L_0x0327
        L_0x0323:
            r26 = r4
            r1 = r31
        L_0x0327:
            int r4 = r6.g
            int r5 = r47.getPaddingLeft()
            int r7 = r47.getPaddingRight()
            int r5 = r5 + r7
            int r4 = r4 + r5
            r6.g = r4
            int r4 = r6.g
            int r5 = r47.getSuggestedMinimumWidth()
            int r4 = java.lang.Math.max(r4, r5)
            r5 = r48
            r7 = 0
            int r8 = android.view.View.resolveSizeAndState(r4, r5, r7)
            r7 = 16777215(0xffffff, float:2.3509886E-38)
            r4 = r8 & r7
            int r7 = r6.g
            int r7 = r4 - r7
            if (r23 != 0) goto L_0x03e4
            if (r7 == 0) goto L_0x035f
            int r27 = (r0 > r29 ? 1 : (r0 == r29 ? 0 : -1))
            if (r27 <= 0) goto L_0x035f
            r31 = r0
            r34 = r3
            r33 = r4
            goto L_0x03ea
        L_0x035f:
            int r2 = java.lang.Math.max(r2, r11)
            if (r13 == 0) goto L_0x03ca
            r14 = 1073741824(0x40000000, float:2.0)
            if (r1 == r14) goto L_0x03ca
            r14 = 0
        L_0x036a:
            if (r14 >= r10) goto L_0x03c1
            r31 = r0
            android.view.View r0 = r6.q(r14)
            if (r0 == 0) goto L_0x03b0
            r16 = r2
            int r2 = r0.getVisibility()
            r33 = r4
            r4 = 8
            if (r2 != r4) goto L_0x0383
            r34 = r3
            goto L_0x03b6
        L_0x0383:
            android.view.ViewGroup$LayoutParams r2 = r0.getLayoutParams()
            a.b.d.f.g0$a r2 = (a.b.d.f.g0.a) r2
            float r4 = r2.f463a
            int r17 = (r4 > r29 ? 1 : (r4 == r29 ? 0 : -1))
            if (r17 <= 0) goto L_0x03a9
            r17 = r2
            r19 = r4
            r2 = 1073741824(0x40000000, float:2.0)
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r3, r2)
            r34 = r3
            int r3 = r0.getMeasuredHeight()
            int r3 = android.view.View.MeasureSpec.makeMeasureSpec(r3, r2)
            r0.measure(r4, r3)
            goto L_0x03b6
        L_0x03a9:
            r17 = r2
            r34 = r3
            r19 = r4
            goto L_0x03b6
        L_0x03b0:
            r16 = r2
            r34 = r3
            r33 = r4
        L_0x03b6:
            int r14 = r14 + 1
            r2 = r16
            r0 = r31
            r4 = r33
            r3 = r34
            goto L_0x036a
        L_0x03c1:
            r31 = r0
            r16 = r2
            r34 = r3
            r33 = r4
            goto L_0x03d2
        L_0x03ca:
            r31 = r0
            r16 = r2
            r34 = r3
            r33 = r4
        L_0x03d2:
            r14 = r49
            r40 = r1
            r35 = r10
            r36 = r11
            r2 = r16
            r4 = r26
            r3 = r39
            r26 = r13
            goto L_0x05d4
        L_0x03e4:
            r31 = r0
            r34 = r3
            r33 = r4
        L_0x03ea:
            float r0 = r6.h
            int r3 = (r0 > r29 ? 1 : (r0 == r29 ? 0 : -1))
            if (r3 <= 0) goto L_0x03f1
            goto L_0x03f3
        L_0x03f1:
            r0 = r31
        L_0x03f3:
            r3 = -1
            r9[r17] = r3
            r9[r19] = r3
            r9[r20] = r3
            r4 = 0
            r9[r4] = r3
            r15[r17] = r3
            r15[r19] = r3
            r15[r20] = r3
            r15[r4] = r3
            r3 = -1
            r6.g = r4
            r4 = 0
            r14 = r7
            r7 = r4
            r4 = r39
        L_0x040d:
            if (r7 >= r10) goto L_0x0574
            r36 = r11
            android.view.View r11 = r6.q(r7)
            if (r11 == 0) goto L_0x055a
            r26 = r13
            int r13 = r11.getVisibility()
            r5 = 8
            if (r13 != r5) goto L_0x042c
            r40 = r1
            r35 = r10
            r1 = r14
            r28 = -2
            r14 = r49
            goto L_0x0565
        L_0x042c:
            android.view.ViewGroup$LayoutParams r13 = r11.getLayoutParams()
            a.b.d.f.g0$a r13 = (a.b.d.f.g0.a) r13
            float r5 = r13.f463a
            int r35 = (r5 > r29 ? 1 : (r5 == r29 ? 0 : -1))
            if (r35 <= 0) goto L_0x04a7
            r35 = r10
            float r10 = (float) r14
            float r10 = r10 * r5
            float r10 = r10 / r0
            int r10 = (int) r10
            float r0 = r0 - r5
            int r14 = r14 - r10
            int r37 = r47.getPaddingTop()
            int r38 = r47.getPaddingBottom()
            int r37 = r37 + r38
            r38 = r0
            int r0 = r13.topMargin
            int r37 = r37 + r0
            int r0 = r13.bottomMargin
            int r0 = r37 + r0
            r37 = r5
            int r5 = r13.height
            r39 = r14
            r14 = r49
            int r0 = android.view.ViewGroup.getChildMeasureSpec(r14, r0, r5)
            int r5 = r13.width
            if (r5 != 0) goto L_0x047f
            r5 = 1073741824(0x40000000, float:2.0)
            if (r1 == r5) goto L_0x046e
            r40 = r1
            goto L_0x0481
        L_0x046e:
            r40 = r1
            if (r10 <= 0) goto L_0x0474
            r1 = r10
            goto L_0x0475
        L_0x0474:
            r1 = 0
        L_0x0475:
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r1, r5)
            r11.measure(r1, r0)
            r41 = r10
            goto L_0x0496
        L_0x047f:
            r40 = r1
        L_0x0481:
            int r1 = r11.getMeasuredWidth()
            int r1 = r1 + r10
            if (r1 >= 0) goto L_0x0489
            r1 = 0
        L_0x0489:
            r41 = r10
            r5 = 1073741824(0x40000000, float:2.0)
            int r10 = android.view.View.MeasureSpec.makeMeasureSpec(r1, r5)
            r11.measure(r10, r0)
        L_0x0496:
            int r1 = r11.getMeasuredState()
            r5 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r1 = r1 & r5
            int r4 = android.view.View.combineMeasuredStates(r4, r1)
            r0 = r38
            r1 = r39
            goto L_0x04b0
        L_0x04a7:
            r40 = r1
            r37 = r5
            r35 = r10
            r1 = r14
            r14 = r49
        L_0x04b0:
            if (r24 == 0) goto L_0x04c9
            int r5 = r6.g
            int r10 = r11.getMeasuredWidth()
            r38 = r0
            int r0 = r13.leftMargin
            int r10 = r10 + r0
            int r0 = r13.rightMargin
            int r10 = r10 + r0
            int r0 = r47.p()
            int r10 = r10 + r0
            int r5 = r5 + r10
            r6.g = r5
            goto L_0x04e3
        L_0x04c9:
            r38 = r0
            int r0 = r6.g
            int r5 = r11.getMeasuredWidth()
            int r5 = r5 + r0
            int r10 = r13.leftMargin
            int r5 = r5 + r10
            int r10 = r13.rightMargin
            int r5 = r5 + r10
            int r10 = r47.p()
            int r5 = r5 + r10
            int r5 = java.lang.Math.max(r0, r5)
            r6.g = r5
        L_0x04e3:
            r0 = 1073741824(0x40000000, float:2.0)
            if (r12 == r0) goto L_0x04ee
            int r0 = r13.height
            r5 = -1
            if (r0 != r5) goto L_0x04ee
            r0 = 1
            goto L_0x04ef
        L_0x04ee:
            r0 = 0
        L_0x04ef:
            int r5 = r13.topMargin
            int r10 = r13.bottomMargin
            int r5 = r5 + r10
            int r10 = r11.getMeasuredHeight()
            int r10 = r10 + r5
            int r3 = java.lang.Math.max(r3, r10)
            r39 = r0
            if (r0 == 0) goto L_0x0503
            r0 = r5
            goto L_0x0504
        L_0x0503:
            r0 = r10
        L_0x0504:
            int r0 = java.lang.Math.max(r2, r0)
            if (r18 == 0) goto L_0x0513
            int r2 = r13.height
            r41 = r0
            r0 = -1
            if (r2 != r0) goto L_0x0515
            r0 = 1
            goto L_0x0516
        L_0x0513:
            r41 = r0
        L_0x0515:
            r0 = 0
        L_0x0516:
            if (r21 == 0) goto L_0x054d
            int r2 = r11.getBaseline()
            r18 = r0
            r0 = -1
            if (r2 == r0) goto L_0x0548
            int r0 = r13.f464b
            if (r0 >= 0) goto L_0x0527
            int r0 = r6.f
        L_0x0527:
            r0 = r0 & 112(0x70, float:1.57E-43)
            int r42 = r0 >> 4
            r28 = -2
            r42 = r42 & -2
            int r42 = r42 >> 1
            r43 = r0
            r0 = r9[r42]
            int r0 = java.lang.Math.max(r0, r2)
            r9[r42] = r0
            r0 = r15[r42]
            r44 = r1
            int r1 = r10 - r2
            int r0 = java.lang.Math.max(r0, r1)
            r15[r42] = r0
            goto L_0x0553
        L_0x0548:
            r44 = r1
            r28 = -2
            goto L_0x0553
        L_0x054d:
            r18 = r0
            r44 = r1
            r28 = -2
        L_0x0553:
            r0 = r38
            r2 = r41
            r1 = r44
            goto L_0x0565
        L_0x055a:
            r40 = r1
            r35 = r10
            r26 = r13
            r1 = r14
            r28 = -2
            r14 = r49
        L_0x0565:
            int r7 = r7 + 1
            r5 = r48
            r14 = r1
            r13 = r26
            r10 = r35
            r11 = r36
            r1 = r40
            goto L_0x040d
        L_0x0574:
            r40 = r1
            r35 = r10
            r36 = r11
            r26 = r13
            r1 = r14
            r14 = r49
            int r5 = r6.g
            int r7 = r47.getPaddingLeft()
            int r10 = r47.getPaddingRight()
            int r7 = r7 + r10
            int r5 = r5 + r7
            r6.g = r5
            r5 = r9[r20]
            r7 = -1
            if (r5 != r7) goto L_0x059f
            r5 = 0
            r10 = r9[r5]
            if (r10 != r7) goto L_0x059f
            r5 = r9[r19]
            if (r5 != r7) goto L_0x059f
            r5 = r9[r17]
            if (r5 == r7) goto L_0x05ce
        L_0x059f:
            r5 = r9[r17]
            r7 = 0
            r10 = r9[r7]
            r11 = r9[r20]
            r13 = r9[r19]
            int r11 = java.lang.Math.max(r11, r13)
            int r10 = java.lang.Math.max(r10, r11)
            int r5 = java.lang.Math.max(r5, r10)
            r10 = r15[r17]
            r7 = r15[r7]
            r11 = r15[r20]
            r13 = r15[r19]
            int r11 = java.lang.Math.max(r11, r13)
            int r7 = java.lang.Math.max(r7, r11)
            int r7 = java.lang.Math.max(r10, r7)
            int r10 = r5 + r7
            int r3 = java.lang.Math.max(r3, r10)
        L_0x05ce:
            r7 = r1
            r45 = r4
            r4 = r3
            r3 = r45
        L_0x05d4:
            if (r18 != 0) goto L_0x05db
            r0 = 1073741824(0x40000000, float:2.0)
            if (r12 == r0) goto L_0x05db
            r4 = r2
        L_0x05db:
            int r0 = r47.getPaddingTop()
            int r1 = r47.getPaddingBottom()
            int r0 = r0 + r1
            int r4 = r4 + r0
            int r0 = r47.getSuggestedMinimumHeight()
            int r0 = java.lang.Math.max(r4, r0)
            r1 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r1 = r1 & r3
            r1 = r1 | r8
            int r4 = r3 << 16
            int r4 = android.view.View.resolveSizeAndState(r0, r14, r4)
            r6.setMeasuredDimension(r1, r4)
            if (r22 == 0) goto L_0x0604
            r1 = r48
            r4 = r35
            r6.i(r4, r1)
            goto L_0x0608
        L_0x0604:
            r1 = r48
            r4 = r35
        L_0x0608:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.d.f.g0.v(int, int):void");
    }

    public final void i(int count, int widthMeasureSpec) {
        int uniformMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
        for (int i2 = 0; i2 < count; i2++) {
            View child = q(i2);
            if (child.getVisibility() != 8) {
                a lp = (a) child.getLayoutParams();
                if (lp.height == -1) {
                    int oldWidth = lp.width;
                    lp.width = child.getMeasuredWidth();
                    measureChildWithMargins(child, widthMeasureSpec, 0, uniformMeasureSpec, 0);
                    lp.width = oldWidth;
                }
            }
        }
    }

    public int n() {
        return 0;
    }

    public int w() {
        return 0;
    }

    public void u(View child, int widthMeasureSpec, int totalWidth, int heightMeasureSpec, int totalHeight) {
        measureChildWithMargins(child, widthMeasureSpec, totalWidth, heightMeasureSpec, totalHeight);
    }

    public int o() {
        return 0;
    }

    public int p() {
        return 0;
    }

    public void onLayout(boolean changed, int l2, int t, int r, int b2) {
        if (this.e == 1) {
            t(l2, t, r, b2);
        } else {
            s(l2, t, r, b2);
        }
    }

    public void t(int left, int top, int right, int bottom) {
        int childTop;
        int gravity;
        int childLeft;
        g0 g0Var = this;
        int paddingLeft = getPaddingLeft();
        int width = right - left;
        int childRight = width - getPaddingRight();
        int childSpace = (width - paddingLeft) - getPaddingRight();
        int count = getVirtualChildCount();
        int i2 = g0Var.f;
        int majorGravity = i2 & j.AppCompatTheme_windowActionBarOverlay;
        int minorGravity = i2 & 8388615;
        if (majorGravity == 16) {
            childTop = getPaddingTop() + (((bottom - top) - g0Var.g) / 2);
        } else if (majorGravity != 80) {
            childTop = getPaddingTop();
        } else {
            childTop = ((getPaddingTop() + bottom) - top) - g0Var.g;
        }
        int i3 = 0;
        while (i3 < count) {
            View child = g0Var.q(i3);
            if (child == null) {
                childTop += w();
            } else if (child.getVisibility() != 8) {
                int childWidth = child.getMeasuredWidth();
                int childHeight = child.getMeasuredHeight();
                a lp = (a) child.getLayoutParams();
                int gravity2 = lp.f464b;
                if (gravity2 < 0) {
                    gravity = minorGravity;
                } else {
                    gravity = gravity2;
                }
                int layoutDirection = p.f(this);
                int a2 = d.a(gravity, layoutDirection) & 7;
                if (a2 == 1) {
                    childLeft = ((((childSpace - childWidth) / 2) + paddingLeft) + lp.leftMargin) - lp.rightMargin;
                } else if (a2 != 5) {
                    childLeft = lp.leftMargin + paddingLeft;
                } else {
                    childLeft = (childRight - childWidth) - lp.rightMargin;
                }
                if (g0Var.r(i3) != 0) {
                    childTop += g0Var.n;
                }
                int childTop2 = childTop + lp.topMargin;
                int i4 = layoutDirection;
                int i5 = gravity;
                y(child, childLeft, childTop2 + o(), childWidth, childHeight);
                int childTop3 = childTop2 + childHeight + lp.bottomMargin + p();
                i3 += n();
                childTop = childTop3;
            }
            i3++;
            g0Var = this;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:0x00c1  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00c5  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00cf  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0103  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x0116  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void s(int r33, int r34, int r35, int r36) {
        /*
            r32 = this;
            r6 = r32
            boolean r7 = a.b.d.f.a1.b(r32)
            int r8 = r32.getPaddingTop()
            int r9 = r36 - r34
            int r0 = r32.getPaddingBottom()
            int r10 = r9 - r0
            int r0 = r9 - r8
            int r1 = r32.getPaddingBottom()
            int r11 = r0 - r1
            int r12 = r32.getVirtualChildCount()
            int r0 = r6.f
            r1 = 8388615(0x800007, float:1.1754953E-38)
            r13 = r0 & r1
            r14 = r0 & 112(0x70, float:1.57E-43)
            boolean r15 = r6.f461b
            int[] r5 = r6.j
            int[] r4 = r6.k
            int r3 = a.b.c.h.p.f(r32)
            int r0 = a.b.c.h.d.a(r13, r3)
            r16 = 2
            r2 = 1
            if (r0 == r2) goto L_0x004e
            r1 = 5
            if (r0 == r1) goto L_0x0042
            int r0 = r32.getPaddingLeft()
            goto L_0x005b
        L_0x0042:
            int r0 = r32.getPaddingLeft()
            int r0 = r0 + r35
            int r0 = r0 - r33
            int r1 = r6.g
            int r0 = r0 - r1
            goto L_0x005b
        L_0x004e:
            int r0 = r32.getPaddingLeft()
            int r1 = r35 - r33
            int r2 = r6.g
            int r1 = r1 - r2
            int r1 = r1 / 2
            int r0 = r0 + r1
        L_0x005b:
            r1 = 0
            r2 = 1
            if (r7 == 0) goto L_0x0067
            int r1 = r12 + -1
            r2 = -1
            r18 = r1
            r19 = r2
            goto L_0x006b
        L_0x0067:
            r18 = r1
            r19 = r2
        L_0x006b:
            r1 = 0
            r2 = r1
        L_0x006d:
            if (r2 >= r12) goto L_0x016e
            int r1 = r19 * r2
            int r1 = r18 + r1
            android.view.View r20 = r6.q(r1)
            if (r20 != 0) goto L_0x008d
            int r21 = r32.w()
            int r0 = r0 + r21
            r22 = r3
            r30 = r4
            r31 = r5
            r26 = r7
            r28 = r9
            r21 = 1
            goto L_0x015e
        L_0x008d:
            r21 = r2
            int r2 = r20.getVisibility()
            r22 = r3
            r3 = 8
            if (r2 == r3) goto L_0x014e
            int r23 = r20.getMeasuredWidth()
            int r24 = r20.getMeasuredHeight()
            r2 = -1
            android.view.ViewGroup$LayoutParams r3 = r20.getLayoutParams()
            a.b.d.f.g0$a r3 = (a.b.d.f.g0.a) r3
            r25 = r2
            r2 = -1
            if (r15 == 0) goto L_0x00b9
            r26 = r7
            int r7 = r3.height
            if (r7 == r2) goto L_0x00bb
            int r7 = r20.getBaseline()
            goto L_0x00bd
        L_0x00b9:
            r26 = r7
        L_0x00bb:
            r7 = r25
        L_0x00bd:
            int r2 = r3.f464b
            if (r2 >= 0) goto L_0x00c5
            r2 = r14
            r27 = r2
            goto L_0x00c7
        L_0x00c5:
            r27 = r2
        L_0x00c7:
            r2 = r27 & 112(0x70, float:1.57E-43)
            r28 = r9
            r9 = 16
            if (r2 == r9) goto L_0x0103
            r9 = 48
            if (r2 == r9) goto L_0x00f1
            r9 = 80
            if (r2 == r9) goto L_0x00da
            r2 = r8
            r9 = r2
            goto L_0x0110
        L_0x00da:
            int r2 = r10 - r24
            int r9 = r3.bottomMargin
            int r2 = r2 - r9
            r9 = -1
            if (r7 == r9) goto L_0x00ef
            int r9 = r20.getMeasuredHeight()
            int r9 = r9 - r7
            r25 = r4[r16]
            int r25 = r25 - r9
            int r2 = r2 - r25
            r9 = r2
            goto L_0x0110
        L_0x00ef:
            r9 = r2
            goto L_0x0110
        L_0x00f1:
            int r2 = r3.topMargin
            int r2 = r2 + r8
            r9 = -1
            if (r7 == r9) goto L_0x0100
            r9 = 1
            r17 = r5[r9]
            int r17 = r17 - r7
            int r2 = r2 + r17
            r9 = r2
            goto L_0x0110
        L_0x0100:
            r9 = 1
            r9 = r2
            goto L_0x0110
        L_0x0103:
            r9 = 1
            int r2 = r11 - r24
            int r2 = r2 / 2
            int r2 = r2 + r8
            int r9 = r3.topMargin
            int r2 = r2 + r9
            int r9 = r3.bottomMargin
            int r2 = r2 - r9
            r9 = r2
        L_0x0110:
            boolean r2 = r6.r(r1)
            if (r2 == 0) goto L_0x0119
            int r2 = r6.m
            int r0 = r0 + r2
        L_0x0119:
            int r2 = r3.leftMargin
            int r25 = r0 + r2
            int r0 = r32.o()
            int r2 = r25 + r0
            r0 = r32
            r29 = r1
            r1 = r20
            r17 = r21
            r21 = 1
            r6 = r3
            r3 = r9
            r30 = r4
            r4 = r23
            r31 = r5
            r5 = r24
            r0.y(r1, r2, r3, r4, r5)
            int r0 = r6.rightMargin
            int r0 = r23 + r0
            int r1 = r32.p()
            int r0 = r0 + r1
            int r25 = r25 + r0
            int r0 = r32.n()
            int r2 = r17 + r0
            r0 = r25
            goto L_0x015e
        L_0x014e:
            r29 = r1
            r30 = r4
            r31 = r5
            r26 = r7
            r28 = r9
            r17 = r21
            r21 = 1
            r2 = r17
        L_0x015e:
            int r2 = r2 + 1
            r6 = r32
            r3 = r22
            r7 = r26
            r9 = r28
            r4 = r30
            r5 = r31
            goto L_0x006d
        L_0x016e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.d.f.g0.s(int, int, int, int):void");
    }

    public final void y(View child, int left, int top, int width, int height) {
        child.layout(left, top, left + width, top + height);
    }

    public void setOrientation(int orientation) {
        if (this.e != orientation) {
            this.e = orientation;
            requestLayout();
        }
    }

    public int getOrientation() {
        return this.e;
    }

    public void setGravity(int gravity) {
        if (this.f != gravity) {
            if ((8388615 & gravity) == 0) {
                gravity |= 8388611;
            }
            if ((gravity & j.AppCompatTheme_windowActionBarOverlay) == 0) {
                gravity |= 48;
            }
            this.f = gravity;
            requestLayout();
        }
    }

    public int getGravity() {
        return this.f;
    }

    public void setHorizontalGravity(int horizontalGravity) {
        int gravity = horizontalGravity & 8388615;
        int i2 = this.f;
        if ((8388615 & i2) != gravity) {
            this.f = (-8388616 & i2) | gravity;
            requestLayout();
        }
    }

    public void setVerticalGravity(int verticalGravity) {
        int gravity = verticalGravity & j.AppCompatTheme_windowActionBarOverlay;
        int i2 = this.f;
        if ((i2 & j.AppCompatTheme_windowActionBarOverlay) != gravity) {
            this.f = (i2 & -113) | gravity;
            requestLayout();
        }
    }

    /* renamed from: l */
    public a generateLayoutParams(AttributeSet attrs) {
        return new a(getContext(), attrs);
    }

    /* renamed from: k */
    public a generateDefaultLayoutParams() {
        int i2 = this.e;
        if (i2 == 0) {
            return new a(-2, -2);
        }
        if (i2 == 1) {
            return new a(-1, -2);
        }
        return null;
    }

    /* renamed from: m */
    public a generateLayoutParams(ViewGroup.LayoutParams p2) {
        return new a(p2);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams p2) {
        return p2 instanceof a;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent event) {
        super.onInitializeAccessibilityEvent(event);
        event.setClassName(g0.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        info.setClassName(g0.class.getName());
    }

    public static class a extends ViewGroup.MarginLayoutParams {

        /* renamed from: a  reason: collision with root package name */
        public float f463a;

        /* renamed from: b  reason: collision with root package name */
        public int f464b;

        public a(Context c2, AttributeSet attrs) {
            super(c2, attrs);
            this.f464b = -1;
            TypedArray a2 = c2.obtainStyledAttributes(attrs, j.LinearLayoutCompat_Layout);
            this.f463a = a2.getFloat(j.LinearLayoutCompat_Layout_android_layout_weight, 0.0f);
            this.f464b = a2.getInt(j.LinearLayoutCompat_Layout_android_layout_gravity, -1);
            a2.recycle();
        }

        public a(int width, int height) {
            super(width, height);
            this.f464b = -1;
            this.f463a = 0.0f;
        }

        public a(ViewGroup.LayoutParams p) {
            super(p);
            this.f464b = -1;
        }
    }
}
