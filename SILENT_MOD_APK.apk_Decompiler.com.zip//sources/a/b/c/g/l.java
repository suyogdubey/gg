package a.b.c.g;

import android.support.v4.util.SparseArrayCompat;

public class l<E> implements Cloneable {
    public static final Object f = new Object();

    /* renamed from: b  reason: collision with root package name */
    public boolean f238b;

    /* renamed from: c  reason: collision with root package name */
    public int[] f239c;
    public Object[] d;
    public int e;

    public l() {
        this(10);
    }

    public l(int initialCapacity) {
        this.f238b = false;
        if (initialCapacity == 0) {
            this.f239c = c.f216a;
            this.d = c.f218c;
        } else {
            int initialCapacity2 = c.e(initialCapacity);
            this.f239c = new int[initialCapacity2];
            this.d = new Object[initialCapacity2];
        }
        this.e = 0;
    }

    /* renamed from: c */
    public l<E> clone() {
        try {
            SparseArrayCompat<E> clone = (l) super.clone();
            clone.f239c = (int[]) this.f239c.clone();
            clone.d = (Object[]) this.d.clone();
            return clone;
        } catch (CloneNotSupportedException e2) {
            throw new AssertionError(e2);
        }
    }

    public E f(int key) {
        return g(key, (Object) null);
    }

    public E g(int key, E valueIfKeyNotFound) {
        int i = c.a(this.f239c, this.e, key);
        if (i >= 0) {
            E[] eArr = this.d;
            if (eArr[i] != f) {
                return eArr[i];
            }
        }
        return valueIfKeyNotFound;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x000a, code lost:
        r1 = r4.d;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void d(int r5) {
        /*
            r4 = this;
            int[] r0 = r4.f239c
            int r1 = r4.e
            int r0 = a.b.c.g.c.a(r0, r1, r5)
            if (r0 < 0) goto L_0x0017
            java.lang.Object[] r1 = r4.d
            r2 = r1[r0]
            java.lang.Object r3 = f
            if (r2 == r3) goto L_0x0017
            r1[r0] = r3
            r1 = 1
            r4.f238b = r1
        L_0x0017:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.g.l.d(int):void");
    }

    public void j(int key) {
        d(key);
    }

    public final void e() {
        int n = this.e;
        int o = 0;
        int[] keys = this.f239c;
        Object[] values = this.d;
        for (int i = 0; i < n; i++) {
            Object val = values[i];
            if (val != f) {
                if (i != o) {
                    keys[o] = keys[i];
                    values[o] = val;
                    values[i] = null;
                }
                o++;
            }
        }
        this.f238b = false;
        this.e = o;
    }

    public void i(int key, E value) {
        int i = c.a(this.f239c, this.e, key);
        if (i >= 0) {
            this.d[i] = value;
            return;
        }
        int i2 = i ^ -1;
        if (i2 < this.e) {
            Object[] objArr = this.d;
            if (objArr[i2] == f) {
                this.f239c[i2] = key;
                objArr[i2] = value;
                return;
            }
        }
        if (this.f238b && this.e >= this.f239c.length) {
            e();
            i2 = c.a(this.f239c, this.e, key) ^ -1;
        }
        int i3 = this.e;
        if (i3 >= this.f239c.length) {
            int n = c.e(i3 + 1);
            int[] nkeys = new int[n];
            Object[] nvalues = new Object[n];
            int[] iArr = this.f239c;
            System.arraycopy(iArr, 0, nkeys, 0, iArr.length);
            Object[] objArr2 = this.d;
            System.arraycopy(objArr2, 0, nvalues, 0, objArr2.length);
            this.f239c = nkeys;
            this.d = nvalues;
        }
        int n2 = this.e;
        if (n2 - i2 != 0) {
            int[] iArr2 = this.f239c;
            System.arraycopy(iArr2, i2, iArr2, i2 + 1, n2 - i2);
            Object[] objArr3 = this.d;
            System.arraycopy(objArr3, i2, objArr3, i2 + 1, this.e - i2);
        }
        this.f239c[i2] = key;
        this.d[i2] = value;
        this.e++;
    }

    public int k() {
        if (this.f238b) {
            e();
        }
        return this.e;
    }

    public int h(int index) {
        if (this.f238b) {
            e();
        }
        return this.f239c[index];
    }

    public E l(int index) {
        if (this.f238b) {
            e();
        }
        return this.d[index];
    }

    public void b() {
        int n = this.e;
        Object[] values = this.d;
        for (int i = 0; i < n; i++) {
            values[i] = null;
        }
        this.e = 0;
        this.f238b = false;
    }

    public void a(int key, E value) {
        int i = this.e;
        if (i == 0 || key > this.f239c[i - 1]) {
            if (this.f238b && this.e >= this.f239c.length) {
                e();
            }
            int pos = this.e;
            if (pos >= this.f239c.length) {
                int n = c.e(pos + 1);
                int[] nkeys = new int[n];
                Object[] nvalues = new Object[n];
                int[] iArr = this.f239c;
                System.arraycopy(iArr, 0, nkeys, 0, iArr.length);
                Object[] objArr = this.d;
                System.arraycopy(objArr, 0, nvalues, 0, objArr.length);
                this.f239c = nkeys;
                this.d = nvalues;
            }
            this.f239c[pos] = key;
            this.d[pos] = value;
            this.e = pos + 1;
            return;
        }
        i(key, value);
    }

    public String toString() {
        if (k() <= 0) {
            return "{}";
        }
        StringBuilder buffer = new StringBuilder(this.e * 28);
        buffer.append('{');
        for (int i = 0; i < this.e; i++) {
            if (i > 0) {
                buffer.append(", ");
            }
            buffer.append(h(i));
            buffer.append('=');
            Object value = l(i);
            if (value != this) {
                buffer.append(value);
            } else {
                buffer.append("(this Map)");
            }
        }
        buffer.append('}');
        return buffer.toString();
    }
}
