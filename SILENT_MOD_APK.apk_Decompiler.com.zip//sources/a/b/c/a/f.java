package a.b.c.a;

import a.a.b.c;
import a.a.b.n;
import a.a.b.o;
import a.b.c.a.a;
import a.b.c.g.l;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;

public class f extends x implements o, a.b, a.d {

    /* renamed from: c  reason: collision with root package name */
    public final Handler f71c = new a();
    public final h d = h.b(new b());
    public n e;
    public boolean f;
    public boolean g;
    public boolean h = true;
    public int i;
    public l<String> j;

    public static final class c {

        /* renamed from: a  reason: collision with root package name */
        public n f73a;

        /* renamed from: b  reason: collision with root package name */
        public l f74b;
    }

    public class a extends Handler {
        public a() {
        }

        public void handleMessage(Message msg) {
            if (msg.what != 2) {
                super.handleMessage(msg);
                return;
            }
            f.this.p();
            f.this.d.s();
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        this.d.v();
        int requestIndex = requestCode >> 16;
        if (requestIndex != 0) {
            int requestIndex2 = requestIndex - 1;
            String who = this.j.f(requestIndex2);
            this.j.j(requestIndex2);
            if (who == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
                return;
            }
            e targetFragment = this.d.t(who);
            if (targetFragment == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + who);
                return;
            }
            targetFragment.N();
            return;
        }
        a.f();
        a.c delegate = null;
        if (delegate == null || !delegate.a(this, requestCode, resultCode, data)) {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void onBackPressed() {
        j fragmentManager = this.d.u();
        boolean isStateSaved = fragmentManager.c();
        if (isStateSaved && Build.VERSION.SDK_INT <= 25) {
            return;
        }
        if (isStateSaved || !fragmentManager.d()) {
            super.onBackPressed();
        }
    }

    public void onMultiWindowModeChanged(boolean isInMultiWindowMode) {
        this.d.j(isInMultiWindowMode);
    }

    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode) {
        this.d.n(isInPictureInPictureMode);
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        this.d.v();
        this.d.d(newConfig);
    }

    public n d() {
        if (getApplication() != null) {
            if (this.e == null) {
                c nc = (c) getLastNonConfigurationInstance();
                if (nc != null) {
                    this.e = nc.f73a;
                }
                if (this.e == null) {
                    this.e = new n();
                }
            }
            return this.e;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    public a.a.b.c a() {
        return super.a();
    }

    public void onCreate(Bundle savedInstanceState) {
        n nVar;
        l lVar = null;
        this.d.a((e) null);
        super.onCreate(savedInstanceState);
        c nc = (c) getLastNonConfigurationInstance();
        if (!(nc == null || (nVar = nc.f73a) == null || this.e != null)) {
            this.e = nVar;
        }
        if (savedInstanceState != null) {
            Parcelable p = savedInstanceState.getParcelable("android:support:fragments");
            h hVar = this.d;
            if (nc != null) {
                lVar = nc.f74b;
            }
            hVar.x(p, lVar);
            if (savedInstanceState.containsKey("android:support:next_request_index")) {
                this.i = savedInstanceState.getInt("android:support:next_request_index");
                int[] requestCodes = savedInstanceState.getIntArray("android:support:request_indicies");
                String[] fragmentWhos = savedInstanceState.getStringArray("android:support:request_fragment_who");
                if (requestCodes == null || fragmentWhos == null || requestCodes.length != fragmentWhos.length) {
                    Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
                } else {
                    this.j = new l<>(requestCodes.length);
                    for (int i2 = 0; i2 < requestCodes.length; i2++) {
                        this.j.i(requestCodes[i2], fragmentWhos[i2]);
                    }
                }
            }
        }
        if (this.j == null) {
            this.j = new l<>();
            this.i = 0;
        }
        this.d.f();
    }

    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        if (featureId == 0) {
            return super.onCreatePanelMenu(featureId, menu) | this.d.g(menu, getMenuInflater());
        }
        return super.onCreatePanelMenu(featureId, menu);
    }

    public View onCreateView(View parent, String name, Context context, AttributeSet attrs) {
        View v = j(parent, name, context, attrs);
        if (v == null) {
            return super.onCreateView(parent, name, context, attrs);
        }
        return v;
    }

    public View onCreateView(String name, Context context, AttributeSet attrs) {
        View v = j((View) null, name, context, attrs);
        if (v == null) {
            return super.onCreateView(name, context, attrs);
        }
        return v;
    }

    public final View j(View parent, String name, Context context, AttributeSet attrs) {
        return this.d.w(parent, name, context, attrs);
    }

    public void onDestroy() {
        super.onDestroy();
        if (this.e != null && !isChangingConfigurations()) {
            this.e.a();
        }
        this.d.h();
    }

    public void onLowMemory() {
        super.onLowMemory();
        this.d.i();
    }

    public boolean onMenuItemSelected(int featureId, MenuItem item) {
        if (super.onMenuItemSelected(featureId, item)) {
            return true;
        }
        if (featureId == 0) {
            return this.d.k(item);
        }
        if (featureId != 6) {
            return false;
        }
        return this.d.e(item);
    }

    public void onPanelClosed(int featureId, Menu menu) {
        if (featureId == 0) {
            this.d.l(menu);
        }
        super.onPanelClosed(featureId, menu);
    }

    public void onPause() {
        super.onPause();
        this.g = false;
        if (this.f71c.hasMessages(2)) {
            this.f71c.removeMessages(2);
            p();
        }
        this.d.m();
    }

    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.d.v();
    }

    public void onStateNotSaved() {
        this.d.v();
    }

    public void onResume() {
        super.onResume();
        this.f71c.sendEmptyMessage(2);
        this.g = true;
        this.d.s();
    }

    public void onPostResume() {
        super.onPostResume();
        this.f71c.removeMessages(2);
        p();
        this.d.s();
    }

    public void p() {
        this.d.p();
    }

    public boolean onPreparePanel(int featureId, View view, Menu menu) {
        if (featureId != 0 || menu == null) {
            return super.onPreparePanel(featureId, view, menu);
        }
        return o(view, menu) | this.d.o(menu);
    }

    public boolean o(View view, Menu menu) {
        return super.onPreparePanel(0, view, menu);
    }

    public final Object onRetainNonConfigurationInstance() {
        q();
        l fragments = this.d.y();
        if (fragments == null && this.e == null && 0 == 0) {
            return null;
        }
        c nci = new c();
        nci.f73a = this.e;
        nci.f74b = fragments;
        return nci;
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        l();
        Parcelable p = this.d.z();
        if (p != null) {
            outState.putParcelable("android:support:fragments", p);
        }
        if (this.j.k() > 0) {
            outState.putInt("android:support:next_request_index", this.i);
            int[] requestCodes = new int[this.j.k()];
            String[] fragmentWhos = new String[this.j.k()];
            for (int i2 = 0; i2 < this.j.k(); i2++) {
                requestCodes[i2] = this.j.h(i2);
                fragmentWhos[i2] = this.j.l(i2);
            }
            outState.putIntArray("android:support:request_indicies", requestCodes);
            outState.putStringArray("android:support:request_fragment_who", fragmentWhos);
        }
    }

    public void onStart() {
        super.onStart();
        this.h = false;
        if (!this.f) {
            this.f = true;
            this.d.c();
        }
        this.d.v();
        this.d.s();
        this.d.q();
    }

    public void onStop() {
        super.onStop();
        this.h = true;
        l();
        this.d.r();
    }

    public Object q() {
        return null;
    }

    @Deprecated
    public void r() {
        invalidateOptionsMenu();
    }

    public void dump(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
        super.dump(prefix, fd, writer, args);
        writer.print(prefix);
        writer.print("Local FragmentActivity ");
        writer.print(Integer.toHexString(System.identityHashCode(this)));
        writer.println(" State:");
        String innerPrefix = prefix + "  ";
        writer.print(innerPrefix);
        writer.print("mCreated=");
        writer.print(this.f);
        writer.print(" mResumed=");
        writer.print(this.g);
        writer.print(" mStopped=");
        writer.print(this.h);
        if (getApplication() != null) {
            s.b(this).a(innerPrefix, fd, writer, args);
        }
        this.d.u().a(prefix, fd, writer, args);
    }

    public void n() {
    }

    public j k() {
        return this.d.u();
    }

    public void startActivityForResult(Intent intent, int requestCode) {
        if (requestCode != -1) {
            i(requestCode);
        }
        super.startActivityForResult(intent, requestCode);
    }

    public void startActivityForResult(Intent intent, int requestCode, Bundle options) {
        if (requestCode != -1) {
            i(requestCode);
        }
        super.startActivityForResult(intent, requestCode, options);
    }

    public void startIntentSenderForResult(IntentSender intent, int requestCode, Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags) {
        if (requestCode != -1) {
            i(requestCode);
        }
        super.startIntentSenderForResult(intent, requestCode, fillInIntent, flagsMask, flagsValues, extraFlags);
    }

    public void startIntentSenderForResult(IntentSender intent, int requestCode, Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags, Bundle options) {
        if (requestCode != -1) {
            i(requestCode);
        }
        super.startIntentSenderForResult(intent, requestCode, fillInIntent, flagsMask, flagsValues, extraFlags, options);
    }

    public static void i(int requestCode) {
        if ((-65536 & requestCode) != 0) {
            throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
        }
    }

    public final void b(int requestCode) {
        if (requestCode != -1) {
            i(requestCode);
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        this.d.v();
        int index = (requestCode >> 16) & 65535;
        if (index != 0) {
            int index2 = index - 1;
            String who = this.j.f(index2);
            this.j.j(index2);
            if (who == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
                return;
            }
            e frag = this.d.t(who);
            if (frag == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + who);
                return;
            }
            frag.h0();
        }
    }

    public class b extends i<f> {
        public b() {
            super(f.this);
        }

        public void i(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
            f.this.dump(prefix, fd, writer, args);
        }

        public boolean m(e fragment) {
            return !f.this.isFinishing();
        }

        public LayoutInflater j() {
            return f.this.getLayoutInflater().cloneInContext(f.this);
        }

        public void n() {
            f.this.r();
        }

        public boolean l() {
            return f.this.getWindow() != null;
        }

        public int k() {
            Window w = f.this.getWindow();
            if (w == null) {
                return 0;
            }
            return w.getAttributes().windowAnimations;
        }

        public void h(e fragment) {
            f.this.n();
        }

        public View b(int id) {
            return f.this.findViewById(id);
        }

        public boolean c() {
            Window w = f.this.getWindow();
            return (w == null || w.peekDecorView() == null) ? false : true;
        }
    }

    public final void l() {
        do {
        } while (m(k(), c.b.CREATED));
    }

    public static boolean m(j manager, c.b state) {
        boolean hadNotMarked = false;
        Iterator<Fragment> it = manager.b().iterator();
        while (it.hasNext()) {
            e fragment = (e) it.next();
            if (fragment != null) {
                if (fragment.a().a().a(c.b.STARTED)) {
                    fragment.T.i(state);
                    hadNotMarked = true;
                }
                j childFragmentManager = fragment.o0();
                if (childFragmentManager != null) {
                    hadNotMarked |= m(childFragmentManager, state);
                }
            }
        }
        return hadNotMarked;
    }
}
