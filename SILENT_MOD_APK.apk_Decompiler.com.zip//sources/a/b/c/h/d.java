package a.b.c.h;

import android.view.Gravity;

public final class d {
    public static int a(int gravity, int layoutDirection) {
        return Gravity.getAbsoluteGravity(gravity, layoutDirection);
    }
}
