package a.b.c.a;

public abstract class o {
}
