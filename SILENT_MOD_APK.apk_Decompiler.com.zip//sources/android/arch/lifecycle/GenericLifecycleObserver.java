package android.arch.lifecycle;

import a.a.b.c;
import a.a.b.d;
import a.a.b.e;

public interface GenericLifecycleObserver extends d {
    void g(e eVar, c.a aVar);
}
