package android.support.v4.widget;

import a.b.c.h.i;
import a.b.c.h.j;
import a.b.c.h.k;
import a.b.c.h.m;
import a.b.c.h.p;
import a.b.c.i.f;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.app.AlertController;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import java.util.List;

public class NestedScrollView extends FrameLayout implements k, i {
    public static final a B = new a();
    public static final int[] C = {16843130};
    public b A;

    /* renamed from: b  reason: collision with root package name */
    public long f580b;

    /* renamed from: c  reason: collision with root package name */
    public final Rect f581c;
    public OverScroller d;
    public EdgeEffect e;
    public EdgeEffect f;
    public int g;
    public boolean h;
    public boolean i;
    public View j;
    public boolean k;
    public VelocityTracker l;
    public boolean m;
    public boolean n;
    public int o;
    public int p;
    public int q;
    public int r;
    public final int[] s;
    public final int[] t;
    public int u;
    public int v;
    public c w;
    public final m x;
    public final j y;
    public float z;

    public interface b {
    }

    public NestedScrollView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public NestedScrollView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.f581c = new Rect();
        this.h = true;
        this.i = false;
        this.j = null;
        this.k = false;
        this.n = true;
        this.r = -1;
        this.s = new int[2];
        this.t = new int[2];
        w();
        TypedArray a2 = context.obtainStyledAttributes(attrs, C, defStyleAttr, 0);
        setFillViewport(a2.getBoolean(0, false));
        a2.recycle();
        this.x = new m(this);
        this.y = new j(this);
        setNestedScrollingEnabled(true);
        p.s(this, B);
    }

    public boolean K(int axes, int type) {
        return this.y.j(axes, type);
    }

    public void L(int type) {
        this.y.k(type);
    }

    public boolean t(int type) {
        return this.y.f(type);
    }

    public boolean f(int i2, int i3, int i4, int i5, int[] iArr, int i6) {
        return this.y.d(i2, i3, i4, i5, iArr, i6);
    }

    public boolean e(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return this.y.c(i2, i3, iArr, iArr2, i4);
    }

    public void setNestedScrollingEnabled(boolean enabled) {
        this.y.h(enabled);
    }

    public boolean isNestedScrollingEnabled() {
        return this.y.g();
    }

    public boolean startNestedScroll(int axes) {
        return K(axes, 0);
    }

    public void stopNestedScroll() {
        L(0);
    }

    public boolean hasNestedScrollingParent() {
        return t(0);
    }

    public boolean dispatchNestedScroll(int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed, int[] offsetInWindow) {
        return f(dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed, offsetInWindow, 0);
    }

    public boolean dispatchNestedPreScroll(int dx, int dy, int[] consumed, int[] offsetInWindow) {
        return e(dx, dy, consumed, offsetInWindow, 0);
    }

    public boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        return this.y.a(f2, f3, z2);
    }

    public boolean dispatchNestedPreFling(float velocityX, float velocityY) {
        return this.y.b(velocityX, velocityY);
    }

    public boolean n(View child, View target, int axes, int type) {
        return (axes & 2) != 0;
    }

    public void i(View child, View target, int axes, int type) {
        this.x.b(axes);
        K(2, type);
    }

    public void l(View target, int type) {
        this.x.d();
        L(type);
    }

    public void k(View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed, int type) {
        int i2 = dyUnconsumed;
        int oldScrollY = getScrollY();
        scrollBy(0, i2);
        int myConsumed = getScrollY() - oldScrollY;
        f(0, myConsumed, 0, i2 - myConsumed, (int[]) null, type);
    }

    public void m(View target, int dx, int dy, int[] consumed, int type) {
        e(dx, dy, consumed, (int[]) null, type);
    }

    public boolean onStartNestedScroll(View child, View target, int nestedScrollAxes) {
        return n(child, target, nestedScrollAxes, 0);
    }

    public void onNestedScrollAccepted(View child, View target, int nestedScrollAxes) {
        i(child, target, nestedScrollAxes, 0);
    }

    public void onStopNestedScroll(View target) {
        l(target, 0);
    }

    public void onNestedScroll(View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
        k(target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed, 0);
    }

    public void onNestedPreScroll(View target, int dx, int dy, int[] consumed) {
        m(target, dx, dy, consumed, 0);
    }

    public boolean onNestedFling(View target, float velocityX, float velocityY, boolean consumed) {
        if (consumed) {
            return false;
        }
        r((int) velocityY);
        return true;
    }

    public boolean onNestedPreFling(View target, float velocityX, float velocityY) {
        return dispatchNestedPreFling(velocityX, velocityY);
    }

    public int getNestedScrollAxes() {
        return this.x.a();
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int length = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < length) {
            return ((float) scrollY) / ((float) length);
        }
        return 1.0f;
    }

    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View child = getChildAt(0);
        int length = getVerticalFadingEdgeLength();
        int span = ((child.getBottom() + ((FrameLayout.LayoutParams) child.getLayoutParams()).bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (span < length) {
            return ((float) span) / ((float) length);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (((float) getHeight()) * 0.5f);
    }

    public final void w() {
        this.d = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration configuration = ViewConfiguration.get(getContext());
        this.o = configuration.getScaledTouchSlop();
        this.p = configuration.getScaledMinimumFlingVelocity();
        this.q = configuration.getScaledMaximumFlingVelocity();
    }

    public void addView(View child) {
        if (getChildCount() <= 0) {
            super.addView(child);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View child, int index) {
        if (getChildCount() <= 0) {
            super.addView(child, index);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View child, ViewGroup.LayoutParams params) {
        if (getChildCount() <= 0) {
            super.addView(child, params);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View child, int index, ViewGroup.LayoutParams params) {
        if (getChildCount() <= 0) {
            super.addView(child, index, params);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void setOnScrollChangeListener(b l2) {
        this.A = l2;
    }

    public final boolean b() {
        if (getChildCount() <= 0) {
            return false;
        }
        View child = getChildAt(0);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) child.getLayoutParams();
        if (child.getHeight() + lp.topMargin + lp.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
            return true;
        }
        return false;
    }

    public void setFillViewport(boolean fillViewport) {
        if (fillViewport != this.m) {
            this.m = fillViewport;
            requestLayout();
        }
    }

    public void setSmoothScrollingEnabled(boolean smoothScrollingEnabled) {
        this.n = smoothScrollingEnabled;
    }

    public void onScrollChanged(int l2, int t2, int oldl, int oldt) {
        super.onScrollChanged(l2, t2, oldl, oldt);
        b bVar = this.A;
        if (bVar != null) {
            ((AlertController.b) bVar).a(this, l2, t2, oldl, oldt);
        }
    }

    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        if (this.m && View.MeasureSpec.getMode(heightMeasureSpec) != 0 && getChildCount() > 0) {
            View child = getChildAt(0);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) child.getLayoutParams();
            int childSize = child.getMeasuredHeight();
            int parentSpace = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - lp.topMargin) - lp.bottomMargin;
            if (childSize < parentSpace) {
                child.measure(FrameLayout.getChildMeasureSpec(widthMeasureSpec, getPaddingLeft() + getPaddingRight() + lp.leftMargin + lp.rightMargin, lp.width), View.MeasureSpec.makeMeasureSpec(parentSpace, 1073741824));
            }
        }
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        return super.dispatchKeyEvent(event) || o(event);
    }

    public boolean o(KeyEvent event) {
        this.f581c.setEmpty();
        int i2 = 130;
        if (!b()) {
            if (!isFocused() || event.getKeyCode() == 4) {
                return false;
            }
            View currentFocused = findFocus();
            if (currentFocused == this) {
                currentFocused = null;
            }
            View nextFocused = FocusFinder.getInstance().findNextFocus(this, currentFocused, 130);
            if (nextFocused == null || nextFocused == this || !nextFocused.requestFocus(130)) {
                return false;
            }
            return true;
        } else if (event.getAction() != 0) {
            return false;
        } else {
            int keyCode = event.getKeyCode();
            if (keyCode != 19) {
                if (keyCode != 20) {
                    if (keyCode != 62) {
                        return false;
                    }
                    if (event.isShiftPressed()) {
                        i2 = 33;
                    }
                    D(i2);
                    return false;
                } else if (!event.isAltPressed()) {
                    return a(130);
                } else {
                    return s(130);
                }
            } else if (!event.isAltPressed()) {
                return a(33);
            } else {
                return s(33);
            }
        }
    }

    public final boolean u(int x2, int y2) {
        if (getChildCount() <= 0) {
            return false;
        }
        int scrollY = getScrollY();
        View child = getChildAt(0);
        if (y2 < child.getTop() - scrollY || y2 >= child.getBottom() - scrollY || x2 < child.getLeft() || x2 >= child.getRight()) {
            return false;
        }
        return true;
    }

    public final void v() {
        VelocityTracker velocityTracker = this.l;
        if (velocityTracker == null) {
            this.l = VelocityTracker.obtain();
        } else {
            velocityTracker.clear();
        }
    }

    public final void x() {
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
    }

    public final void E() {
        VelocityTracker velocityTracker = this.l;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.l = null;
        }
    }

    public void requestDisallowInterceptTouchEvent(boolean disallowIntercept) {
        if (disallowIntercept) {
            E();
        }
        super.requestDisallowInterceptTouchEvent(disallowIntercept);
    }

    public boolean onInterceptTouchEvent(MotionEvent ev) {
        MotionEvent motionEvent = ev;
        int action = ev.getAction();
        if (action == 2 && this.k) {
            return true;
        }
        int i2 = action & 255;
        if (i2 != 0) {
            if (i2 != 1) {
                if (i2 == 2) {
                    int activePointerId = this.r;
                    if (activePointerId != -1) {
                        int pointerIndex = motionEvent.findPointerIndex(activePointerId);
                        if (pointerIndex == -1) {
                            Log.e("NestedScrollView", "Invalid pointerId=" + activePointerId + " in onInterceptTouchEvent");
                        } else {
                            int y2 = (int) motionEvent.getY(pointerIndex);
                            if (Math.abs(y2 - this.g) > this.o && (2 & getNestedScrollAxes()) == 0) {
                                this.k = true;
                                this.g = y2;
                                x();
                                this.l.addMovement(motionEvent);
                                this.u = 0;
                                ViewParent parent = getParent();
                                if (parent != null) {
                                    parent.requestDisallowInterceptTouchEvent(true);
                                }
                            }
                        }
                    }
                } else if (i2 != 3) {
                    if (i2 == 6) {
                        B(ev);
                    }
                }
            }
            this.k = false;
            this.r = -1;
            E();
            if (this.d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                p.o(this);
            }
            L(0);
        } else {
            int y3 = (int) ev.getY();
            if (!u((int) ev.getX(), y3)) {
                this.k = false;
                E();
            } else {
                this.g = y3;
                this.r = motionEvent.getPointerId(0);
                v();
                this.l.addMovement(motionEvent);
                this.d.computeScrollOffset();
                this.k = true ^ this.d.isFinished();
                K(2, 0);
            }
        }
        return this.k;
    }

    public boolean onTouchEvent(MotionEvent ev) {
        ViewParent parent;
        MotionEvent motionEvent = ev;
        x();
        MotionEvent vtev = MotionEvent.obtain(ev);
        int actionMasked = ev.getActionMasked();
        if (actionMasked == 0) {
            this.u = 0;
        }
        vtev.offsetLocation(0.0f, (float) this.u);
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.l;
                velocityTracker.computeCurrentVelocity(1000, (float) this.q);
                int initialVelocity = (int) velocityTracker.getYVelocity(this.r);
                if (Math.abs(initialVelocity) > this.p) {
                    r(-initialVelocity);
                } else {
                    if (this.d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                        p.o(this);
                    }
                }
                this.r = -1;
                h();
            } else if (actionMasked == 2) {
                int activePointerIndex = motionEvent.findPointerIndex(this.r);
                if (activePointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + this.r + " in onTouchEvent");
                } else {
                    int y2 = (int) motionEvent.getY(activePointerIndex);
                    int deltaY = this.g - y2;
                    if (e(0, deltaY, this.t, this.s, 0)) {
                        deltaY -= this.t[1];
                        vtev.offsetLocation(0.0f, (float) this.s[1]);
                        this.u += this.s[1];
                    }
                    if (!this.k && Math.abs(deltaY) > this.o) {
                        ViewParent parent2 = getParent();
                        if (parent2 != null) {
                            parent2.requestDisallowInterceptTouchEvent(true);
                        }
                        this.k = true;
                        if (deltaY > 0) {
                            deltaY -= this.o;
                        } else {
                            deltaY += this.o;
                        }
                    }
                    if (this.k) {
                        this.g = y2 - this.s[1];
                        int oldY = getScrollY();
                        int range = getScrollRange();
                        int overscrollMode = getOverScrollMode();
                        boolean canOverscroll = overscrollMode == 0 || (overscrollMode == 1 && range > 0);
                        int i2 = overscrollMode;
                        int range2 = range;
                        int deltaY2 = deltaY;
                        int i3 = y2;
                        int activePointerIndex2 = activePointerIndex;
                        if (C(0, deltaY, 0, getScrollY(), 0, range2, 0, 0) && !t(0)) {
                            this.l.clear();
                        }
                        int scrolledDeltaY = getScrollY() - oldY;
                        if (f(0, scrolledDeltaY, 0, deltaY2 - scrolledDeltaY, this.s, 0)) {
                            int i4 = this.g;
                            int[] iArr = this.s;
                            this.g = i4 - iArr[1];
                            vtev.offsetLocation(0.0f, (float) iArr[1]);
                            this.u += this.s[1];
                            int i5 = activePointerIndex2;
                        } else if (canOverscroll) {
                            j();
                            int pulledToY = oldY + deltaY2;
                            if (pulledToY < 0) {
                                f.a(this.e, ((float) deltaY2) / ((float) getHeight()), motionEvent.getX(activePointerIndex2) / ((float) getWidth()));
                                if (!this.f.isFinished()) {
                                    this.f.onRelease();
                                    int i6 = range2;
                                } else {
                                    int i7 = range2;
                                }
                            } else {
                                int activePointerIndex3 = activePointerIndex2;
                                if (pulledToY > range2) {
                                    f.a(this.f, ((float) deltaY2) / ((float) getHeight()), 1.0f - (motionEvent.getX(activePointerIndex3) / ((float) getWidth())));
                                    if (!this.e.isFinished()) {
                                        this.e.onRelease();
                                    }
                                }
                            }
                            EdgeEffect edgeEffect = this.e;
                            if (edgeEffect != null && (!edgeEffect.isFinished() || !this.f.isFinished())) {
                                p.o(this);
                            }
                        } else {
                            int i8 = activePointerIndex2;
                        }
                    } else {
                        int i9 = y2;
                        int i10 = activePointerIndex;
                    }
                }
            } else if (actionMasked == 3) {
                if (this.k != 0 && getChildCount() > 0 && this.d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    p.o(this);
                }
                this.r = -1;
                h();
            } else if (actionMasked == 5) {
                int index = ev.getActionIndex();
                this.g = (int) motionEvent.getY(index);
                this.r = motionEvent.getPointerId(index);
            } else if (actionMasked == 6) {
                B(ev);
                this.g = (int) motionEvent.getY(motionEvent.findPointerIndex(this.r));
            }
        } else if (getChildCount() == 0) {
            return false;
        } else {
            boolean z2 = !this.d.isFinished();
            this.k = z2;
            if (z2 && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.d.isFinished()) {
                this.d.abortAnimation();
            }
            this.g = (int) ev.getY();
            this.r = motionEvent.getPointerId(0);
            K(2, 0);
        }
        VelocityTracker velocityTracker2 = this.l;
        if (velocityTracker2 != null) {
            velocityTracker2.addMovement(vtev);
        }
        vtev.recycle();
        return true;
    }

    public final void B(MotionEvent ev) {
        int pointerIndex = ev.getActionIndex();
        if (ev.getPointerId(pointerIndex) == this.r) {
            int newPointerIndex = pointerIndex == 0 ? 1 : 0;
            this.g = (int) ev.getY(newPointerIndex);
            this.r = ev.getPointerId(newPointerIndex);
            VelocityTracker velocityTracker = this.l;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    public boolean onGenericMotionEvent(MotionEvent event) {
        if ((event.getSource() & 2) == 0 || event.getAction() != 8 || this.k) {
            return false;
        }
        float vscroll = event.getAxisValue(9);
        if (vscroll == 0.0f) {
            return false;
        }
        int range = getScrollRange();
        int oldScrollY = getScrollY();
        int newScrollY = oldScrollY - ((int) (getVerticalScrollFactorCompat() * vscroll));
        if (newScrollY < 0) {
            newScrollY = 0;
        } else if (newScrollY > range) {
            newScrollY = range;
        }
        if (newScrollY == oldScrollY) {
            return false;
        }
        super.scrollTo(getScrollX(), newScrollY);
        return true;
    }

    private float getVerticalScrollFactorCompat() {
        if (this.z == 0.0f) {
            TypedValue outValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(16842829, outValue, true)) {
                this.z = outValue.getDimension(context.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.z;
    }

    public void onOverScrolled(int scrollX, int scrollY, boolean clampedX, boolean clampedY) {
        super.scrollTo(scrollX, scrollY);
    }

    public boolean C(int deltaX, int deltaY, int scrollX, int scrollY, int scrollRangeX, int scrollRangeY, int maxOverScrollX, int maxOverScrollY) {
        int maxOverScrollX2;
        int maxOverScrollY2;
        boolean clampedX;
        boolean clampedY;
        int overScrollMode = getOverScrollMode();
        boolean canScrollHorizontal = computeHorizontalScrollRange() > computeHorizontalScrollExtent();
        boolean canScrollVertical = computeVerticalScrollRange() > computeVerticalScrollExtent();
        boolean overScrollHorizontal = overScrollMode == 0 || (overScrollMode == 1 && canScrollHorizontal);
        boolean overScrollVertical = overScrollMode == 0 || (overScrollMode == 1 && canScrollVertical);
        int newScrollX = scrollX + deltaX;
        if (!overScrollHorizontal) {
            maxOverScrollX2 = 0;
        } else {
            maxOverScrollX2 = maxOverScrollX;
        }
        int newScrollY = scrollY + deltaY;
        if (!overScrollVertical) {
            maxOverScrollY2 = 0;
        } else {
            maxOverScrollY2 = maxOverScrollY;
        }
        int left = -maxOverScrollX2;
        int right = maxOverScrollX2 + scrollRangeX;
        int top = -maxOverScrollY2;
        int bottom = maxOverScrollY2 + scrollRangeY;
        if (newScrollX > right) {
            newScrollX = right;
            clampedX = true;
        } else if (newScrollX < left) {
            newScrollX = left;
            clampedX = true;
        } else {
            clampedX = false;
        }
        if (newScrollY > bottom) {
            newScrollY = bottom;
            clampedY = true;
        } else if (newScrollY < top) {
            newScrollY = top;
            clampedY = true;
        } else {
            clampedY = false;
        }
        if (clampedY) {
            if (!t(1)) {
                this.d.springBack(newScrollX, newScrollY, 0, 0, 0, getScrollRange());
            }
        }
        boolean isTouchEvent = clampedX;
        onOverScrolled(newScrollX, newScrollY, isTouchEvent, clampedY);
        return isTouchEvent || clampedY;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View child = getChildAt(0);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) child.getLayoutParams();
        return Math.max(0, ((child.getHeight() + lp.topMargin) + lp.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    public final View p(boolean topFocus, int top, int bottom) {
        List<View> focusables = getFocusables(2);
        View focusCandidate = null;
        boolean foundFullyContainedFocusable = false;
        int count = focusables.size();
        for (int i2 = 0; i2 < count; i2++) {
            View view = focusables.get(i2);
            int viewTop = view.getTop();
            int viewBottom = view.getBottom();
            if (top < viewBottom && viewTop < bottom) {
                boolean viewIsCloserToBoundary = false;
                boolean viewIsFullyContained = top < viewTop && viewBottom < bottom;
                if (focusCandidate == null) {
                    focusCandidate = view;
                    foundFullyContainedFocusable = viewIsFullyContained;
                } else {
                    if ((topFocus && viewTop < focusCandidate.getTop()) || (!topFocus && viewBottom > focusCandidate.getBottom())) {
                        viewIsCloserToBoundary = true;
                    }
                    if (foundFullyContainedFocusable) {
                        if (viewIsFullyContained && viewIsCloserToBoundary) {
                            focusCandidate = view;
                        }
                    } else if (viewIsFullyContained) {
                        focusCandidate = view;
                        foundFullyContainedFocusable = true;
                    } else if (viewIsCloserToBoundary) {
                        focusCandidate = view;
                    }
                }
            }
        }
        return focusCandidate;
    }

    public boolean D(int direction) {
        boolean down = direction == 130;
        int height = getHeight();
        if (down) {
            this.f581c.top = getScrollY() + height;
            int count = getChildCount();
            if (count > 0) {
                View view = getChildAt(count - 1);
                int bottom = view.getBottom() + ((FrameLayout.LayoutParams) view.getLayoutParams()).bottomMargin + getPaddingBottom();
                Rect rect = this.f581c;
                if (rect.top + height > bottom) {
                    rect.top = bottom - height;
                }
            }
        } else {
            this.f581c.top = getScrollY() - height;
            Rect rect2 = this.f581c;
            if (rect2.top < 0) {
                rect2.top = 0;
            }
        }
        Rect rect3 = this.f581c;
        int i2 = rect3.top;
        int i3 = i2 + height;
        rect3.bottom = i3;
        return F(direction, i2, i3);
    }

    public boolean s(int direction) {
        int count;
        boolean down = direction == 130;
        int height = getHeight();
        Rect rect = this.f581c;
        rect.top = 0;
        rect.bottom = height;
        if (down && (count = getChildCount()) > 0) {
            View view = getChildAt(count - 1);
            this.f581c.bottom = view.getBottom() + ((FrameLayout.LayoutParams) view.getLayoutParams()).bottomMargin + getPaddingBottom();
            Rect rect2 = this.f581c;
            rect2.top = rect2.bottom - height;
        }
        Rect rect3 = this.f581c;
        return F(direction, rect3.top, rect3.bottom);
    }

    public final boolean F(int direction, int top, int bottom) {
        boolean handled = true;
        int height = getHeight();
        int containerTop = getScrollY();
        int containerBottom = containerTop + height;
        boolean up = direction == 33;
        View newFocused = p(up, top, bottom);
        if (newFocused == null) {
            newFocused = this;
        }
        if (top < containerTop || bottom > containerBottom) {
            g(up ? top - containerTop : bottom - containerBottom);
        } else {
            handled = false;
        }
        if (newFocused != findFocus()) {
            newFocused.requestFocus(direction);
        }
        return handled;
    }

    public boolean a(int direction) {
        View currentFocused = findFocus();
        if (currentFocused == this) {
            currentFocused = null;
        }
        View nextFocused = FocusFinder.getInstance().findNextFocus(this, currentFocused, direction);
        int maxJump = getMaxScrollAmount();
        if (nextFocused == null || !A(nextFocused, maxJump, getHeight())) {
            int scrollDelta = maxJump;
            if (direction == 33 && getScrollY() < scrollDelta) {
                scrollDelta = getScrollY();
            } else if (direction == 130 && getChildCount() > 0) {
                View child = getChildAt(0);
                scrollDelta = Math.min((child.getBottom() + ((FrameLayout.LayoutParams) child.getLayoutParams()).bottomMargin) - ((getScrollY() + getHeight()) - getPaddingBottom()), maxJump);
            }
            if (scrollDelta == 0) {
                return false;
            }
            g(direction == 130 ? scrollDelta : -scrollDelta);
        } else {
            nextFocused.getDrawingRect(this.f581c);
            offsetDescendantRectToMyCoords(nextFocused, this.f581c);
            g(d(this.f581c));
            nextFocused.requestFocus(direction);
        }
        if (currentFocused == null || !currentFocused.isFocused() || !y(currentFocused)) {
            return true;
        }
        int descendantFocusability = getDescendantFocusability();
        setDescendantFocusability(131072);
        requestFocus();
        setDescendantFocusability(descendantFocusability);
        return true;
    }

    public final boolean y(View descendant) {
        return !A(descendant, 0, getHeight());
    }

    public final boolean A(View descendant, int delta, int height) {
        descendant.getDrawingRect(this.f581c);
        offsetDescendantRectToMyCoords(descendant, this.f581c);
        return this.f581c.bottom + delta >= getScrollY() && this.f581c.top - delta <= getScrollY() + height;
    }

    public final void g(int delta) {
        if (delta == 0) {
            return;
        }
        if (this.n) {
            I(0, delta);
        } else {
            scrollBy(0, delta);
        }
    }

    public final void I(int dx, int dy) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.f580b > 250) {
                View child = getChildAt(0);
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) child.getLayoutParams();
                int childSize = child.getHeight() + lp.topMargin + lp.bottomMargin;
                int parentSpace = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int scrollY = getScrollY();
                int dy2 = Math.max(0, Math.min(scrollY + dy, Math.max(0, childSize - parentSpace))) - scrollY;
                this.v = getScrollY();
                this.d.startScroll(getScrollX(), scrollY, 0, dy2);
                p.o(this);
            } else {
                if (!this.d.isFinished()) {
                    this.d.abortAnimation();
                }
                scrollBy(dx, dy);
            }
            this.f580b = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    public final void J(int x2, int y2) {
        I(x2 - getScrollX(), y2 - getScrollY());
    }

    public int computeVerticalScrollRange() {
        int count = getChildCount();
        int parentSpace = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (count == 0) {
            return parentSpace;
        }
        View child = getChildAt(0);
        int scrollRange = child.getBottom() + ((FrameLayout.LayoutParams) child.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int overscrollBottom = Math.max(0, scrollRange - parentSpace);
        if (scrollY < 0) {
            return scrollRange - scrollY;
        }
        if (scrollY > overscrollBottom) {
            return scrollRange + (scrollY - overscrollBottom);
        }
        return scrollRange;
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public void measureChild(View child, int parentWidthMeasureSpec, int parentHeightMeasureSpec) {
        child.measure(FrameLayout.getChildMeasureSpec(parentWidthMeasureSpec, getPaddingLeft() + getPaddingRight(), child.getLayoutParams().width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    public void measureChildWithMargins(View child, int parentWidthMeasureSpec, int widthUsed, int parentHeightMeasureSpec, int heightUsed) {
        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) child.getLayoutParams();
        child.measure(FrameLayout.getChildMeasureSpec(parentWidthMeasureSpec, getPaddingLeft() + getPaddingRight() + lp.leftMargin + lp.rightMargin + widthUsed, lp.width), View.MeasureSpec.makeMeasureSpec(lp.topMargin + lp.bottomMargin, 0));
    }

    public void computeScroll() {
        int dy;
        if (this.d.computeScrollOffset()) {
            int currX = this.d.getCurrX();
            int y2 = this.d.getCurrY();
            int dy2 = y2 - this.v;
            if (e(0, dy2, this.t, (int[]) null, 1)) {
                dy = dy2 - this.t[1];
            } else {
                dy = dy2;
            }
            if (dy != 0) {
                int range = getScrollRange();
                int oldScrollY = getScrollY();
                int oldScrollY2 = oldScrollY;
                C(0, dy, getScrollX(), oldScrollY, 0, range, 0, 0);
                int scrolledDeltaY = getScrollY() - oldScrollY2;
                if (!f(0, scrolledDeltaY, 0, dy - scrolledDeltaY, (int[]) null, 1)) {
                    int mode = getOverScrollMode();
                    if (mode == 0 || (mode == 1 && range > 0)) {
                        j();
                        if (y2 <= 0 && oldScrollY2 > 0) {
                            this.e.onAbsorb((int) this.d.getCurrVelocity());
                        } else if (y2 >= range && oldScrollY2 < range) {
                            this.f.onAbsorb((int) this.d.getCurrVelocity());
                        }
                    }
                }
            }
            this.v = y2;
            p.o(this);
            return;
        }
        if (t(1)) {
            L(1);
        }
        this.v = 0;
    }

    public final void G(View child) {
        child.getDrawingRect(this.f581c);
        offsetDescendantRectToMyCoords(child, this.f581c);
        int scrollDelta = d(this.f581c);
        if (scrollDelta != 0) {
            scrollBy(0, scrollDelta);
        }
    }

    public final boolean H(Rect rect, boolean immediate) {
        int delta = d(rect);
        boolean scroll = delta != 0;
        if (scroll) {
            if (immediate) {
                scrollBy(0, delta);
            } else {
                I(0, delta);
            }
        }
        return scroll;
    }

    public int d(Rect rect) {
        int scrollYDelta;
        int scrollYDelta2;
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int screenTop = getScrollY();
        int screenBottom = screenTop + height;
        int actualScreenBottom = screenBottom;
        int fadingEdge = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            screenTop += fadingEdge;
        }
        View child = getChildAt(0);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) child.getLayoutParams();
        if (rect.bottom < child.getHeight() + lp.topMargin + lp.bottomMargin) {
            screenBottom -= fadingEdge;
        }
        if (rect.bottom > screenBottom && rect.top > screenTop) {
            if (rect.height() > height) {
                scrollYDelta2 = 0 + (rect.top - screenTop);
            } else {
                scrollYDelta2 = 0 + (rect.bottom - screenBottom);
            }
            return Math.min(scrollYDelta2, (child.getBottom() + lp.bottomMargin) - actualScreenBottom);
        } else if (rect.top >= screenTop || rect.bottom >= screenBottom) {
            return 0;
        } else {
            if (rect.height() > height) {
                scrollYDelta = 0 - (screenBottom - rect.bottom);
            } else {
                scrollYDelta = 0 - (screenTop - rect.top);
            }
            return Math.max(scrollYDelta, -getScrollY());
        }
    }

    public void requestChildFocus(View child, View focused) {
        if (!this.h) {
            G(focused);
        } else {
            this.j = focused;
        }
        super.requestChildFocus(child, focused);
    }

    public boolean onRequestFocusInDescendants(int direction, Rect previouslyFocusedRect) {
        View nextFocus;
        if (direction == 2) {
            direction = 130;
        } else if (direction == 1) {
            direction = 33;
        }
        if (previouslyFocusedRect == null) {
            nextFocus = FocusFinder.getInstance().findNextFocus(this, (View) null, direction);
        } else {
            nextFocus = FocusFinder.getInstance().findNextFocusFromRect(this, previouslyFocusedRect, direction);
        }
        if (nextFocus != null && !y(nextFocus)) {
            return nextFocus.requestFocus(direction, previouslyFocusedRect);
        }
        return false;
    }

    public boolean requestChildRectangleOnScreen(View child, Rect rectangle, boolean immediate) {
        rectangle.offset(child.getLeft() - child.getScrollX(), child.getTop() - child.getScrollY());
        return H(rectangle, immediate);
    }

    public void requestLayout() {
        this.h = true;
        super.requestLayout();
    }

    public void onLayout(boolean changed, int l2, int t2, int r2, int b2) {
        super.onLayout(changed, l2, t2, r2, b2);
        this.h = false;
        View view = this.j;
        if (view != null && z(view, this)) {
            G(this.j);
        }
        this.j = null;
        if (!this.i) {
            if (this.w != null) {
                scrollTo(getScrollX(), this.w.f582b);
                this.w = null;
            }
            int childSize = 0;
            if (getChildCount() > 0) {
                View child = getChildAt(0);
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) child.getLayoutParams();
                childSize = child.getMeasuredHeight() + lp.topMargin + lp.bottomMargin;
            }
            int parentSpace = ((b2 - t2) - getPaddingTop()) - getPaddingBottom();
            int currentScrollY = getScrollY();
            int newScrollY = c(currentScrollY, parentSpace, childSize);
            if (newScrollY != currentScrollY) {
                scrollTo(getScrollX(), newScrollY);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.i = true;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.i = false;
    }

    public void onSizeChanged(int w2, int h2, int oldw, int oldh) {
        super.onSizeChanged(w2, h2, oldw, oldh);
        View currentFocused = findFocus();
        if (currentFocused != null && this != currentFocused && A(currentFocused, 0, oldh)) {
            currentFocused.getDrawingRect(this.f581c);
            offsetDescendantRectToMyCoords(currentFocused, this.f581c);
            g(d(this.f581c));
        }
    }

    public static boolean z(View child, View parent) {
        if (child == parent) {
            return true;
        }
        ViewParent theParent = child.getParent();
        if (!(theParent instanceof ViewGroup) || !z((View) theParent, parent)) {
            return false;
        }
        return true;
    }

    public void q(int velocityY) {
        if (getChildCount() > 0) {
            K(2, 1);
            this.d.fling(getScrollX(), getScrollY(), 0, velocityY, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            this.v = getScrollY();
            p.o(this);
        }
    }

    public final void r(int velocityY) {
        int scrollY = getScrollY();
        boolean canFling = (scrollY > 0 || velocityY > 0) && (scrollY < getScrollRange() || velocityY < 0);
        if (!dispatchNestedPreFling(0.0f, (float) velocityY)) {
            dispatchNestedFling(0.0f, (float) velocityY, canFling);
            q(velocityY);
        }
    }

    public final void h() {
        this.k = false;
        E();
        L(0);
        EdgeEffect edgeEffect = this.e;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            this.f.onRelease();
        }
    }

    public void scrollTo(int x2, int y2) {
        if (getChildCount() > 0) {
            View child = getChildAt(0);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) child.getLayoutParams();
            int x3 = c(x2, (getWidth() - getPaddingLeft()) - getPaddingRight(), child.getWidth() + lp.leftMargin + lp.rightMargin);
            int y3 = c(y2, (getHeight() - getPaddingTop()) - getPaddingBottom(), child.getHeight() + lp.topMargin + lp.bottomMargin);
            if (x3 != getScrollX() || y3 != getScrollY()) {
                super.scrollTo(x3, y3);
            }
        }
    }

    public final void j() {
        if (getOverScrollMode() == 2) {
            this.e = null;
            this.f = null;
        } else if (this.e == null) {
            Context context = getContext();
            this.e = new EdgeEffect(context);
            this.f = new EdgeEffect(context);
        }
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.e != null) {
            int scrollY = getScrollY();
            if (!this.e.isFinished()) {
                int restoreCount = canvas.save();
                int width = getWidth();
                int height = getHeight();
                int xTranslation = 0;
                int yTranslation = Math.min(0, scrollY);
                if (Build.VERSION.SDK_INT < 21 || getClipToPadding()) {
                    width -= getPaddingLeft() + getPaddingRight();
                    xTranslation = 0 + getPaddingLeft();
                }
                if (Build.VERSION.SDK_INT >= 21 && getClipToPadding()) {
                    height -= getPaddingTop() + getPaddingBottom();
                    yTranslation += getPaddingTop();
                }
                canvas.translate((float) xTranslation, (float) yTranslation);
                this.e.setSize(width, height);
                if (this.e.draw(canvas)) {
                    p.o(this);
                }
                canvas.restoreToCount(restoreCount);
            }
            if (!this.f.isFinished()) {
                int restoreCount2 = canvas.save();
                int width2 = getWidth();
                int height2 = getHeight();
                int xTranslation2 = 0;
                int yTranslation2 = Math.max(getScrollRange(), scrollY) + height2;
                if (Build.VERSION.SDK_INT < 21 || getClipToPadding()) {
                    width2 -= getPaddingLeft() + getPaddingRight();
                    xTranslation2 = 0 + getPaddingLeft();
                }
                if (Build.VERSION.SDK_INT >= 21 && getClipToPadding()) {
                    height2 -= getPaddingTop() + getPaddingBottom();
                    yTranslation2 -= getPaddingBottom();
                }
                canvas.translate((float) (xTranslation2 - width2), (float) yTranslation2);
                canvas.rotate(180.0f, (float) width2, 0.0f);
                this.f.setSize(width2, height2);
                if (this.f.draw(canvas)) {
                    p.o(this);
                }
                canvas.restoreToCount(restoreCount2);
            }
        }
    }

    public static int c(int n2, int my, int child) {
        if (my >= child || n2 < 0) {
            return 0;
        }
        if (my + n2 > child) {
            return child - my;
        }
        return n2;
    }

    public void onRestoreInstanceState(Parcelable state) {
        if (!(state instanceof c)) {
            super.onRestoreInstanceState(state);
            return;
        }
        c ss = (c) state;
        super.onRestoreInstanceState(ss.getSuperState());
        this.w = ss;
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        c ss = new c(super.onSaveInstanceState());
        ss.f582b = getScrollY();
        return ss;
    }

    public static class c extends View.BaseSavedState {
        public static final Parcelable.Creator<c> CREATOR = new a();

        /* renamed from: b  reason: collision with root package name */
        public int f582b;

        public c(Parcelable superState) {
            super(superState);
        }

        public c(Parcel source) {
            super(source);
            this.f582b = source.readInt();
        }

        public void writeToParcel(Parcel dest, int flags) {
            super.writeToParcel(dest, flags);
            dest.writeInt(this.f582b);
        }

        public String toString() {
            return "HorizontalScrollView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " scrollPosition=" + this.f582b + "}";
        }

        public static class a implements Parcelable.Creator<c> {
            /* renamed from: a */
            public c createFromParcel(Parcel in) {
                return new c(in);
            }

            /* renamed from: b */
            public c[] newArray(int size) {
                return new c[size];
            }
        }
    }

    public static class a extends a.b.c.h.b {
        public boolean h(View host, int action, Bundle arguments) {
            if (super.h(host, action, arguments)) {
                return true;
            }
            NestedScrollView nsvHost = (NestedScrollView) host;
            if (!nsvHost.isEnabled()) {
                return false;
            }
            if (action == 4096) {
                int targetScrollY = Math.min(nsvHost.getScrollY() + ((nsvHost.getHeight() - nsvHost.getPaddingBottom()) - nsvHost.getPaddingTop()), nsvHost.getScrollRange());
                if (targetScrollY == nsvHost.getScrollY()) {
                    return false;
                }
                nsvHost.J(0, targetScrollY);
                return true;
            } else if (action != 8192) {
                return false;
            } else {
                int targetScrollY2 = Math.max(nsvHost.getScrollY() - ((nsvHost.getHeight() - nsvHost.getPaddingBottom()) - nsvHost.getPaddingTop()), 0);
                if (targetScrollY2 == nsvHost.getScrollY()) {
                    return false;
                }
                nsvHost.J(0, targetScrollY2);
                return true;
            }
        }

        public void e(View host, a.b.c.h.y.a info) {
            int scrollRange;
            super.e(host, info);
            NestedScrollView nsvHost = (NestedScrollView) host;
            info.u(ScrollView.class.getName());
            if (nsvHost.isEnabled() && (scrollRange = nsvHost.getScrollRange()) > 0) {
                info.v(true);
                if (nsvHost.getScrollY() > 0) {
                    info.a(8192);
                }
                if (nsvHost.getScrollY() < scrollRange) {
                    info.a(4096);
                }
            }
        }

        public void d(View host, AccessibilityEvent event) {
            super.d(host, event);
            NestedScrollView nsvHost = (NestedScrollView) host;
            event.setClassName(ScrollView.class.getName());
            event.setScrollable(nsvHost.getScrollRange() > 0);
            event.setScrollX(nsvHost.getScrollX());
            event.setScrollY(nsvHost.getScrollY());
            a.b.c.h.y.c.a(event, nsvHost.getScrollX());
            a.b.c.h.y.c.b(event, nsvHost.getScrollRange());
        }
    }
}
