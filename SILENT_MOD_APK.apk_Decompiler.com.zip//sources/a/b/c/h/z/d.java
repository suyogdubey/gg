package a.b.c.h.z;

import android.view.animation.Interpolator;

public abstract class d implements Interpolator {

    /* renamed from: a  reason: collision with root package name */
    public final float[] f274a;

    /* renamed from: b  reason: collision with root package name */
    public final float f275b;

    public d(float[] values) {
        this.f274a = values;
        this.f275b = 1.0f / ((float) (values.length - 1));
    }

    public float getInterpolation(float input) {
        if (input >= 1.0f) {
            return 1.0f;
        }
        if (input <= 0.0f) {
            return 0.0f;
        }
        float[] fArr = this.f274a;
        int position = Math.min((int) (((float) (fArr.length - 1)) * input), fArr.length - 2);
        float f = this.f275b;
        float[] fArr2 = this.f274a;
        return fArr2[position] + ((fArr2[position + 1] - fArr2[position]) * ((input - (((float) position) * f)) / f));
    }
}
