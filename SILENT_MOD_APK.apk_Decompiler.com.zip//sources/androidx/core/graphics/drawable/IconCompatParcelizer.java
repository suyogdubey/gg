package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.support.v4.graphics.drawable.IconCompat;
import b.b.a;

public class IconCompatParcelizer {
    public static IconCompat read(a parcel) {
        IconCompat obj = new IconCompat();
        obj.f577a = parcel.k(obj.f577a, 1);
        obj.f579c = parcel.g(obj.f579c, 2);
        obj.d = parcel.m(obj.d, 3);
        obj.e = parcel.k(obj.e, 4);
        obj.f = parcel.k(obj.f, 5);
        obj.g = (ColorStateList) parcel.m(obj.g, 6);
        obj.i = parcel.o(obj.i, 7);
        obj.e();
        return obj;
    }

    public static void write(IconCompat obj, a parcel) {
        parcel.r();
        parcel.e();
        obj.f(false);
        parcel.v(obj.f577a, 1);
        parcel.t(obj.f579c, 2);
        parcel.x(obj.d, 3);
        parcel.v(obj.e, 4);
        parcel.v(obj.f, 5);
        parcel.x(obj.g, 6);
        parcel.z(obj.i, 7);
    }
}
