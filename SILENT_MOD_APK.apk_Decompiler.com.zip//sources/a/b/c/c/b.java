package a.b.c.c;

import a.b.d.b.j;
import android.graphics.Path;
import android.support.v4.graphics.PathParser;
import android.util.Log;
import java.util.ArrayList;

public class b {

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        public int f159a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f160b;
    }

    public static float[] c(float[] original, int start, int end) {
        if (start <= end) {
            int originalLength = original.length;
            if (start < 0 || start > originalLength) {
                throw new ArrayIndexOutOfBoundsException();
            }
            int resultLength = end - start;
            float[] result = new float[resultLength];
            System.arraycopy(original, start, result, 0, Math.min(resultLength, originalLength - start));
            return result;
        }
        throw new IllegalArgumentException();
    }

    public static Path e(String pathData) {
        Path path = new Path();
        C0009b[] nodes = d(pathData);
        if (nodes == null) {
            return null;
        }
        try {
            C0009b.e(nodes, path);
            return path;
        } catch (RuntimeException e) {
            throw new RuntimeException("Error in parsing " + pathData, e);
        }
    }

    public static C0009b[] d(String pathData) {
        if (pathData == null) {
            return null;
        }
        int start = 0;
        int end = 1;
        ArrayList<PathParser.PathDataNode> list = new ArrayList<>();
        while (end < pathData.length()) {
            int end2 = i(pathData, end);
            String s = pathData.substring(start, end2).trim();
            if (s.length() > 0) {
                a(list, s.charAt(0), h(s));
            }
            start = end2;
            end = end2 + 1;
        }
        if (end - start == 1 && start < pathData.length()) {
            a(list, pathData.charAt(start), new float[0]);
        }
        return (C0009b[]) list.toArray(new C0009b[list.size()]);
    }

    public static C0009b[] f(C0009b[] source) {
        if (source == null) {
            return null;
        }
        C0009b[] copy = new C0009b[source.length];
        for (int i = 0; i < source.length; i++) {
            copy[i] = new C0009b(source[i]);
        }
        return copy;
    }

    public static boolean b(C0009b[] nodesFrom, C0009b[] nodesTo) {
        if (nodesFrom == null || nodesTo == null || nodesFrom.length != nodesTo.length) {
            return false;
        }
        for (int i = 0; i < nodesFrom.length; i++) {
            if (nodesFrom[i].f161a != nodesTo[i].f161a || nodesFrom[i].f162b.length != nodesTo[i].f162b.length) {
                return false;
            }
        }
        return true;
    }

    public static void j(C0009b[] target, C0009b[] source) {
        for (int i = 0; i < source.length; i++) {
            target[i].f161a = source[i].f161a;
            for (int j = 0; j < source[i].f162b.length; j++) {
                target[i].f162b[j] = source[i].f162b[j];
            }
        }
    }

    public static int i(String s, int end) {
        while (end < s.length()) {
            char c2 = s.charAt(end);
            if (((c2 - 'A') * (c2 - 'Z') <= 0 || (c2 - 'a') * (c2 - 'z') <= 0) && c2 != 'e' && c2 != 'E') {
                return end;
            }
            end++;
        }
        return end;
    }

    public static void a(ArrayList<C0009b> list, char cmd, float[] val) {
        list.add(new C0009b(cmd, val));
    }

    public static float[] h(String s) {
        if (s.charAt(0) == 'z' || s.charAt(0) == 'Z') {
            return new float[0];
        }
        try {
            float[] results = new float[s.length()];
            int count = 0;
            int startPosition = 1;
            a result = new a();
            int totalLength = s.length();
            while (startPosition < totalLength) {
                g(s, startPosition, result);
                int endPosition = result.f159a;
                if (startPosition < endPosition) {
                    results[count] = Float.parseFloat(s.substring(startPosition, endPosition));
                    count++;
                }
                if (result.f160b != 0) {
                    startPosition = endPosition;
                } else {
                    startPosition = endPosition + 1;
                }
            }
            return c(results, 0, count);
        } catch (NumberFormatException e) {
            throw new RuntimeException("error in parsing \"" + s + "\"", e);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x003b A[LOOP:0: B:1:0x0007->B:20:0x003b, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x003e A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void g(java.lang.String r7, int r8, a.b.c.c.b.a r9) {
        /*
            r0 = r8
            r1 = 0
            r2 = 0
            r9.f160b = r2
            r2 = 0
            r3 = 0
        L_0x0007:
            int r4 = r7.length()
            if (r0 >= r4) goto L_0x003e
            r4 = r3
            r3 = 0
            char r5 = r7.charAt(r0)
            r6 = 32
            if (r5 == r6) goto L_0x0036
            r6 = 69
            if (r5 == r6) goto L_0x0034
            r6 = 101(0x65, float:1.42E-43)
            if (r5 == r6) goto L_0x0034
            r6 = 1
            switch(r5) {
                case 44: goto L_0x0036;
                case 45: goto L_0x002c;
                case 46: goto L_0x0024;
                default: goto L_0x0023;
            }
        L_0x0023:
            goto L_0x0038
        L_0x0024:
            if (r2 != 0) goto L_0x0028
            r2 = 1
            goto L_0x0038
        L_0x0028:
            r1 = 1
            r9.f160b = r6
            goto L_0x0038
        L_0x002c:
            if (r0 == r8) goto L_0x0038
            if (r4 != 0) goto L_0x0038
            r1 = 1
            r9.f160b = r6
            goto L_0x0038
        L_0x0034:
            r3 = 1
            goto L_0x0038
        L_0x0036:
            r1 = 1
        L_0x0038:
            if (r1 == 0) goto L_0x003b
            goto L_0x003e
        L_0x003b:
            int r0 = r0 + 1
            goto L_0x0007
        L_0x003e:
            r9.f159a = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.c.b.g(java.lang.String, int, a.b.c.c.b$a):void");
    }

    /* renamed from: a.b.c.c.b$b  reason: collision with other inner class name */
    public static class C0009b {

        /* renamed from: a  reason: collision with root package name */
        public char f161a;

        /* renamed from: b  reason: collision with root package name */
        public float[] f162b;

        public C0009b(char type, float[] params) {
            this.f161a = type;
            this.f162b = params;
        }

        public C0009b(C0009b n) {
            this.f161a = n.f161a;
            float[] fArr = n.f162b;
            this.f162b = b.c(fArr, 0, fArr.length);
        }

        public static void e(C0009b[] node, Path path) {
            float[] current = new float[6];
            char previousCommand = 'm';
            for (int i = 0; i < node.length; i++) {
                a(path, current, previousCommand, node[i].f161a, node[i].f162b);
                previousCommand = node[i].f161a;
            }
        }

        public void d(C0009b nodeFrom, C0009b nodeTo, float fraction) {
            int i = 0;
            while (true) {
                float[] fArr = nodeFrom.f162b;
                if (i < fArr.length) {
                    this.f162b[i] = (fArr[i] * (1.0f - fraction)) + (nodeTo.f162b[i] * fraction);
                    i++;
                } else {
                    return;
                }
            }
        }

        public static void a(Path path, float[] current, char previousCmd, char cmd, float[] val) {
            int incr;
            int k;
            float reflectiveCtrlPointY;
            float reflectiveCtrlPointX;
            float reflectiveCtrlPointY2;
            float reflectiveCtrlPointX2;
            Path path2 = path;
            char c2 = cmd;
            float[] fArr = val;
            float currentX = current[0];
            float currentY = current[1];
            float ctrlPointX = current[2];
            float ctrlPointY = current[3];
            float currentSegmentStartX = current[4];
            float currentSegmentStartY = current[5];
            switch (c2) {
                case j.AppCompatTheme_dropdownListPreferredItemHeight /*65*/:
                case j.AppCompatTheme_textAppearanceListItem /*97*/:
                    incr = 7;
                    break;
                case j.AppCompatTheme_editTextColor /*67*/:
                case j.AppCompatTheme_textAppearanceListItemSmall /*99*/:
                    incr = 6;
                    break;
                case j.AppCompatTheme_listDividerAlertDialog /*72*/:
                case j.AppCompatTheme_ratingBarStyle /*86*/:
                case j.AppCompatTheme_textColorAlertDialogListItem /*104*/:
                case j.AppCompatTheme_windowMinWidthMajor /*118*/:
                    incr = 1;
                    break;
                case j.AppCompatTheme_listPreferredItemHeightLarge /*76*/:
                case j.AppCompatTheme_listPreferredItemHeightSmall /*77*/:
                case j.AppCompatTheme_popupWindowStyle /*84*/:
                case j.AppCompatTheme_tooltipForegroundColor /*108*/:
                case j.AppCompatTheme_tooltipFrameBackground /*109*/:
                case j.AppCompatTheme_windowFixedWidthMajor /*116*/:
                    incr = 2;
                    break;
                case j.AppCompatTheme_panelMenuListTheme /*81*/:
                case j.AppCompatTheme_popupMenuStyle /*83*/:
                case j.AppCompatTheme_windowActionModeOverlay /*113*/:
                case j.AppCompatTheme_windowFixedHeightMinor /*115*/:
                    incr = 4;
                    break;
                case j.AppCompatTheme_seekBarStyle /*90*/:
                case 'z':
                    path.close();
                    currentX = currentSegmentStartX;
                    currentY = currentSegmentStartY;
                    ctrlPointX = currentSegmentStartX;
                    ctrlPointY = currentSegmentStartY;
                    path2.moveTo(currentX, currentY);
                    incr = 2;
                    break;
                default:
                    incr = 2;
                    break;
            }
            char previousCmd2 = previousCmd;
            int k2 = 0;
            float currentX2 = currentX;
            float ctrlPointX2 = ctrlPointX;
            float ctrlPointY2 = ctrlPointY;
            float currentSegmentStartX2 = currentSegmentStartX;
            float currentSegmentStartY2 = currentSegmentStartY;
            float currentY2 = currentY;
            while (k2 < fArr.length) {
                if (c2 == 'A') {
                    k = k2;
                    char c3 = previousCmd2;
                    c(path, currentX2, currentY2, fArr[k + 5], fArr[k + 6], fArr[k + 0], fArr[k + 1], fArr[k + 2], fArr[k + 3] != 0.0f, fArr[k + 4] != 0.0f);
                    float currentX3 = fArr[k + 5];
                    float currentY3 = fArr[k + 6];
                    currentX2 = currentX3;
                    currentY2 = currentY3;
                    ctrlPointX2 = currentX3;
                    ctrlPointY2 = currentY3;
                } else if (c2 == 'C') {
                    float f = currentX2;
                    k = k2;
                    char c4 = previousCmd2;
                    path.cubicTo(fArr[k + 0], fArr[k + 1], fArr[k + 2], fArr[k + 3], fArr[k + 4], fArr[k + 5]);
                    currentX2 = fArr[k + 4];
                    currentY2 = fArr[k + 5];
                    ctrlPointX2 = fArr[k + 2];
                    ctrlPointY2 = fArr[k + 3];
                } else if (c2 == 'H') {
                    float f2 = currentX2;
                    k = k2;
                    char c5 = previousCmd2;
                    path2.lineTo(fArr[k + 0], currentY2);
                    currentX2 = fArr[k + 0];
                } else if (c2 == 'Q') {
                    float f3 = currentY2;
                    float f4 = currentX2;
                    k = k2;
                    char c6 = previousCmd2;
                    path2.quadTo(fArr[k + 0], fArr[k + 1], fArr[k + 2], fArr[k + 3]);
                    ctrlPointX2 = fArr[k + 0];
                    ctrlPointY2 = fArr[k + 1];
                    currentX2 = fArr[k + 2];
                    currentY2 = fArr[k + 3];
                } else if (c2 == 'V') {
                    float f5 = currentY2;
                    k = k2;
                    char c7 = previousCmd2;
                    path2.lineTo(currentX2, fArr[k + 0]);
                    currentY2 = fArr[k + 0];
                } else if (c2 == 'a') {
                    float currentY4 = currentY2;
                    float f6 = fArr[k2 + 5] + currentX2;
                    float f7 = fArr[k2 + 6] + currentY4;
                    float f8 = fArr[k2 + 0];
                    float f9 = fArr[k2 + 1];
                    float f10 = fArr[k2 + 2];
                    boolean z = fArr[k2 + 3] != 0.0f;
                    boolean z2 = fArr[k2 + 4] != 0.0f;
                    float currentX4 = currentX2;
                    float currentX5 = f10;
                    k = k2;
                    boolean z3 = z;
                    char c8 = previousCmd2;
                    c(path, currentX2, currentY4, f6, f7, f8, f9, currentX5, z3, z2);
                    currentX2 = currentX4 + fArr[k + 5];
                    currentY2 = currentY4 + fArr[k + 6];
                    ctrlPointX2 = currentX2;
                    ctrlPointY2 = currentY2;
                } else if (c2 == 'c') {
                    float currentY5 = currentY2;
                    path.rCubicTo(fArr[k2 + 0], fArr[k2 + 1], fArr[k2 + 2], fArr[k2 + 3], fArr[k2 + 4], fArr[k2 + 5]);
                    float ctrlPointX3 = fArr[k2 + 2] + currentX2;
                    float ctrlPointY3 = currentY5 + fArr[k2 + 3];
                    currentX2 += fArr[k2 + 4];
                    ctrlPointX2 = ctrlPointX3;
                    ctrlPointY2 = ctrlPointY3;
                    k = k2;
                    char c9 = previousCmd2;
                    currentY2 = fArr[k2 + 5] + currentY5;
                } else if (c2 == 'h') {
                    float f11 = currentY2;
                    path2.rLineTo(fArr[k2 + 0], 0.0f);
                    currentX2 += fArr[k2 + 0];
                    k = k2;
                    char c10 = previousCmd2;
                } else if (c2 == 'q') {
                    float currentY6 = currentY2;
                    path2.rQuadTo(fArr[k2 + 0], fArr[k2 + 1], fArr[k2 + 2], fArr[k2 + 3]);
                    float ctrlPointX4 = fArr[k2 + 0] + currentX2;
                    float ctrlPointY4 = currentY6 + fArr[k2 + 1];
                    currentX2 += fArr[k2 + 2];
                    ctrlPointX2 = ctrlPointX4;
                    ctrlPointY2 = ctrlPointY4;
                    k = k2;
                    char c11 = previousCmd2;
                    currentY2 = fArr[k2 + 3] + currentY6;
                } else if (c2 == 'v') {
                    path2.rLineTo(0.0f, fArr[k2 + 0]);
                    currentY2 += fArr[k2 + 0];
                    k = k2;
                    char c12 = previousCmd2;
                } else if (c2 == 'L') {
                    float f12 = currentY2;
                    path2.lineTo(fArr[k2 + 0], fArr[k2 + 1]);
                    currentX2 = fArr[k2 + 0];
                    currentY2 = fArr[k2 + 1];
                    k = k2;
                    char c13 = previousCmd2;
                } else if (c2 == 'M') {
                    float f13 = currentY2;
                    float currentX6 = fArr[k2 + 0];
                    float currentY7 = fArr[k2 + 1];
                    if (k2 > 0) {
                        path2.lineTo(fArr[k2 + 0], fArr[k2 + 1]);
                        currentX2 = currentX6;
                        currentY2 = currentY7;
                        k = k2;
                        char c14 = previousCmd2;
                    } else {
                        path2.moveTo(fArr[k2 + 0], fArr[k2 + 1]);
                        currentX2 = currentX6;
                        currentY2 = currentY7;
                        currentSegmentStartX2 = currentX6;
                        currentSegmentStartY2 = currentY7;
                        k = k2;
                        char c15 = previousCmd2;
                    }
                } else if (c2 == 'S') {
                    float currentY8 = currentY2;
                    float reflectiveCtrlPointX3 = currentX2;
                    float reflectiveCtrlPointY3 = currentY8;
                    if (previousCmd2 == 'c' || previousCmd2 == 's' || previousCmd2 == 'C' || previousCmd2 == 'S') {
                        reflectiveCtrlPointX = (currentX2 * 2.0f) - ctrlPointX2;
                        reflectiveCtrlPointY = (currentY8 * 2.0f) - ctrlPointY2;
                    } else {
                        reflectiveCtrlPointX = reflectiveCtrlPointX3;
                        reflectiveCtrlPointY = reflectiveCtrlPointY3;
                    }
                    path.cubicTo(reflectiveCtrlPointX, reflectiveCtrlPointY, fArr[k2 + 0], fArr[k2 + 1], fArr[k2 + 2], fArr[k2 + 3]);
                    ctrlPointX2 = fArr[k2 + 0];
                    ctrlPointY2 = fArr[k2 + 1];
                    currentX2 = fArr[k2 + 2];
                    currentY2 = fArr[k2 + 3];
                    k = k2;
                    float reflectiveCtrlPointY4 = previousCmd2;
                } else if (c2 == 'T') {
                    float currentY9 = currentY2;
                    float reflectiveCtrlPointX4 = currentX2;
                    float reflectiveCtrlPointY5 = currentY9;
                    if (previousCmd2 == 'q' || previousCmd2 == 't' || previousCmd2 == 'Q' || previousCmd2 == 'T') {
                        reflectiveCtrlPointX4 = (currentX2 * 2.0f) - ctrlPointX2;
                        reflectiveCtrlPointY5 = (currentY9 * 2.0f) - ctrlPointY2;
                    }
                    path2.quadTo(reflectiveCtrlPointX4, reflectiveCtrlPointY5, fArr[k2 + 0], fArr[k2 + 1]);
                    ctrlPointX2 = reflectiveCtrlPointX4;
                    ctrlPointY2 = reflectiveCtrlPointY5;
                    currentX2 = fArr[k2 + 0];
                    currentY2 = fArr[k2 + 1];
                    k = k2;
                    char c16 = previousCmd2;
                } else if (c2 == 'l') {
                    path2.rLineTo(fArr[k2 + 0], fArr[k2 + 1]);
                    currentX2 += fArr[k2 + 0];
                    currentY2 += fArr[k2 + 1];
                    k = k2;
                    char c17 = previousCmd2;
                } else if (c2 == 'm') {
                    currentX2 += fArr[k2 + 0];
                    currentY2 += fArr[k2 + 1];
                    if (k2 > 0) {
                        path2.rLineTo(fArr[k2 + 0], fArr[k2 + 1]);
                        k = k2;
                        char c18 = previousCmd2;
                    } else {
                        path2.rMoveTo(fArr[k2 + 0], fArr[k2 + 1]);
                        currentSegmentStartX2 = currentX2;
                        currentSegmentStartY2 = currentY2;
                        k = k2;
                        char c19 = previousCmd2;
                    }
                } else if (c2 == 's') {
                    if (previousCmd2 == 'c' || previousCmd2 == 's' || previousCmd2 == 'C' || previousCmd2 == 'S') {
                        reflectiveCtrlPointX2 = currentX2 - ctrlPointX2;
                        reflectiveCtrlPointY2 = currentY2 - ctrlPointY2;
                    } else {
                        reflectiveCtrlPointX2 = 0.0f;
                        reflectiveCtrlPointY2 = 0.0f;
                    }
                    float f14 = reflectiveCtrlPointY2;
                    float f15 = reflectiveCtrlPointY2;
                    float currentY10 = currentY2;
                    path.rCubicTo(reflectiveCtrlPointX2, f14, fArr[k2 + 0], fArr[k2 + 1], fArr[k2 + 2], fArr[k2 + 3]);
                    float ctrlPointX5 = fArr[k2 + 0] + currentX2;
                    float ctrlPointY5 = currentY10 + fArr[k2 + 1];
                    currentX2 += fArr[k2 + 2];
                    ctrlPointX2 = ctrlPointX5;
                    ctrlPointY2 = ctrlPointY5;
                    k = k2;
                    char c20 = previousCmd2;
                    currentY2 = fArr[k2 + 3] + currentY10;
                } else if (c2 != 't') {
                    k = k2;
                    char c21 = previousCmd2;
                } else {
                    float reflectiveCtrlPointX5 = 0.0f;
                    float reflectiveCtrlPointY6 = 0.0f;
                    if (previousCmd2 == 'q' || previousCmd2 == 't' || previousCmd2 == 'Q' || previousCmd2 == 'T') {
                        reflectiveCtrlPointX5 = currentX2 - ctrlPointX2;
                        reflectiveCtrlPointY6 = currentY2 - ctrlPointY2;
                    }
                    path2.rQuadTo(reflectiveCtrlPointX5, reflectiveCtrlPointY6, fArr[k2 + 0], fArr[k2 + 1]);
                    float ctrlPointX6 = currentX2 + reflectiveCtrlPointX5;
                    float ctrlPointY6 = currentY2 + reflectiveCtrlPointY6;
                    currentX2 += fArr[k2 + 0];
                    currentY2 += fArr[k2 + 1];
                    ctrlPointX2 = ctrlPointX6;
                    ctrlPointY2 = ctrlPointY6;
                    k = k2;
                    char c22 = previousCmd2;
                }
                previousCmd2 = cmd;
                k2 = k + incr;
                c2 = cmd;
            }
            current[0] = currentX2;
            current[1] = currentY2;
            current[2] = ctrlPointX2;
            current[3] = ctrlPointY2;
            current[4] = currentSegmentStartX2;
            current[5] = currentSegmentStartY2;
        }

        public static void c(Path p, float x0, float y0, float x1, float y1, float a2, float b2, float theta, boolean isMoreThanHalf, boolean isPositiveArc) {
            double cy;
            double cx;
            float f = x0;
            float f2 = y0;
            float f3 = x1;
            float f4 = y1;
            float f5 = a2;
            float f6 = b2;
            boolean z = isPositiveArc;
            double thetaD = Math.toRadians((double) theta);
            double cosTheta = Math.cos(thetaD);
            double sinTheta = Math.sin(thetaD);
            double d = (double) f;
            Double.isNaN(d);
            double d2 = (double) f2;
            Double.isNaN(d2);
            double d3 = (d * cosTheta) + (d2 * sinTheta);
            double d4 = (double) f5;
            Double.isNaN(d4);
            double x0p = d3 / d4;
            double d5 = (double) (-f);
            Double.isNaN(d5);
            double d6 = (double) f2;
            Double.isNaN(d6);
            double d7 = (d5 * sinTheta) + (d6 * cosTheta);
            double d8 = (double) f6;
            Double.isNaN(d8);
            double y0p = d7 / d8;
            double d9 = (double) f3;
            Double.isNaN(d9);
            double d10 = (double) f4;
            Double.isNaN(d10);
            double d11 = (d9 * cosTheta) + (d10 * sinTheta);
            double d12 = (double) f5;
            Double.isNaN(d12);
            double x1p = d11 / d12;
            double d13 = (double) (-f3);
            Double.isNaN(d13);
            double d14 = (double) f4;
            Double.isNaN(d14);
            double d15 = (d13 * sinTheta) + (d14 * cosTheta);
            double d16 = (double) f6;
            Double.isNaN(d16);
            double y1p = d15 / d16;
            double dx = x0p - x1p;
            double dy = y0p - y1p;
            double xm = (x0p + x1p) / 2.0d;
            double ym = (y0p + y1p) / 2.0d;
            double dsq = (dx * dx) + (dy * dy);
            if (dsq == 0.0d) {
                Log.w("PathParser", " Points are coincident");
                return;
            }
            double disc = (1.0d / dsq) - 0.25d;
            if (disc < 0.0d) {
                Log.w("PathParser", "Points are too far apart " + dsq);
                float adjust = (float) (Math.sqrt(dsq) / 1.99999d);
                float f7 = adjust;
                double d17 = dsq;
                boolean z2 = z;
                c(p, x0, y0, x1, y1, f5 * adjust, f6 * adjust, theta, isMoreThanHalf, isPositiveArc);
                return;
            }
            boolean z3 = z;
            double s = Math.sqrt(disc);
            double sdx = s * dx;
            double sdy = s * dy;
            if (isMoreThanHalf == z3) {
                cx = xm - sdy;
                cy = ym + sdx;
            } else {
                cx = xm + sdy;
                cy = ym - sdx;
            }
            double d18 = s;
            double eta0 = Math.atan2(y0p - cy, x0p - cx);
            double d19 = sdx;
            double eta1 = Math.atan2(y1p - cy, x1p - cx);
            double sweep = eta1 - eta0;
            if (z3 != (sweep >= 0.0d)) {
                if (sweep > 0.0d) {
                    sweep -= 6.283185307179586d;
                } else {
                    sweep += 6.283185307179586d;
                }
            }
            double d20 = eta1;
            double eta12 = (double) f5;
            Double.isNaN(eta12);
            double cx2 = cx * eta12;
            double d21 = (double) f6;
            Double.isNaN(d21);
            double cy2 = d21 * cy;
            double cy3 = (cx2 * sinTheta) + (cy2 * cosTheta);
            double d22 = cy3;
            b(p, (cx2 * cosTheta) - (cy2 * sinTheta), cy3, (double) f5, (double) f6, (double) f, (double) f2, thetaD, eta0, sweep);
        }

        public static void b(Path p, double cx, double cy, double a2, double b2, double e1x, double e1y, double theta, double start, double sweep) {
            double e1x2 = a2;
            int numSegments = (int) Math.ceil(Math.abs((sweep * 4.0d) / 3.141592653589793d));
            double eta1 = start;
            double cosTheta = Math.cos(theta);
            double sinTheta = Math.sin(theta);
            double cosEta1 = Math.cos(eta1);
            double sinEta1 = Math.sin(eta1);
            double ep1y = ((-e1x2) * sinTheta * sinEta1) + (b2 * cosTheta * cosEta1);
            double ep1y2 = (double) numSegments;
            Double.isNaN(ep1y2);
            double anglePerSegment = sweep / ep1y2;
            double eta12 = eta1;
            int i = 0;
            double eta13 = e1x;
            double ep1x = (((-e1x2) * cosTheta) * sinEta1) - ((b2 * sinTheta) * cosEta1);
            double e1y2 = e1y;
            while (i < numSegments) {
                double eta2 = eta12 + anglePerSegment;
                double sinEta2 = Math.sin(eta2);
                double cosEta2 = Math.cos(eta2);
                double anglePerSegment2 = anglePerSegment;
                double e2x = (cx + ((e1x2 * cosTheta) * cosEta2)) - ((b2 * sinTheta) * sinEta2);
                double cosEta12 = cosEta1;
                double sinEta12 = sinEta1;
                double ep2x = (((-e1x2) * cosTheta) * sinEta2) - ((b2 * sinTheta) * cosEta2);
                double e2y = cy + (e1x2 * sinTheta * cosEta2) + (b2 * cosTheta * sinEta2);
                double ep2y = ((-e1x2) * sinTheta * sinEta2) + (b2 * cosTheta * cosEta2);
                double tanDiff2 = Math.tan((eta2 - eta12) / 2.0d);
                double alpha = (Math.sin(eta2 - eta12) * (Math.sqrt(((tanDiff2 * 3.0d) * tanDiff2) + 4.0d) - 1.0d)) / 3.0d;
                double q1x = eta13 + (alpha * ep1x);
                int numSegments2 = numSegments;
                double d = eta13;
                double q1y = e1y2 + (alpha * ep1y);
                double q2x = e2x - (alpha * ep2x);
                double q2y = e2y - (alpha * ep2y);
                p.rLineTo(0.0f, 0.0f);
                double d2 = q1x;
                double d3 = q1y;
                double d4 = q2x;
                double q2x2 = e2y;
                double e2y2 = q2y;
                p.cubicTo((float) q1x, (float) q1y, (float) q2x, (float) q2y, (float) e2x, (float) q2x2);
                eta12 = eta2;
                e1y2 = q2x2;
                ep1x = ep2x;
                ep1y = ep2y;
                eta13 = e2x;
                i++;
                numSegments = numSegments2;
                sinEta1 = sinEta12;
                anglePerSegment = anglePerSegment2;
                cosEta1 = cosEta12;
                cosTheta = cosTheta;
                sinTheta = sinTheta;
                e1x2 = a2;
            }
        }
    }
}
