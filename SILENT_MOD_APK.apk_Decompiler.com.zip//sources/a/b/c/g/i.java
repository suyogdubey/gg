package a.b.c.g;

import android.os.Build;
import java.util.Arrays;

public class i {
    public static int a(Object... values) {
        if (Build.VERSION.SDK_INT >= 19) {
            return Arrays.hashCode(values);
        }
        return Arrays.hashCode(values);
    }
}
