package a.b.c.a;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

public final class y implements Iterable<Intent> {

    /* renamed from: b  reason: collision with root package name */
    public final ArrayList<Intent> f140b = new ArrayList<>();

    /* renamed from: c  reason: collision with root package name */
    public final Context f141c;

    public interface a {
        Intent g();
    }

    public y(Context a2) {
        this.f141c = a2;
    }

    public static y d(Context context) {
        return new y(context);
    }

    public y a(Intent nextIntent) {
        this.f140b.add(nextIntent);
        return this;
    }

    public y b(Activity sourceActivity) {
        Intent parent = null;
        if (sourceActivity instanceof a) {
            parent = ((a) sourceActivity).g();
        }
        if (parent == null) {
            parent = t.a(sourceActivity);
        }
        if (parent != null) {
            ComponentName target = parent.getComponent();
            if (target == null) {
                target = parent.resolveActivity(this.f141c.getPackageManager());
            }
            c(target);
            a(parent);
        }
        return this;
    }

    public y c(ComponentName sourceActivityName) {
        int insertAt = this.f140b.size();
        try {
            Intent parent = t.b(this.f141c, sourceActivityName);
            while (parent != null) {
                this.f140b.add(insertAt, parent);
                parent = t.b(this.f141c, parent.getComponent());
            }
            return this;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
            throw new IllegalArgumentException(e);
        }
    }

    @Deprecated
    public Iterator<Intent> iterator() {
        return this.f140b.iterator();
    }

    public void e() {
        f((Bundle) null);
    }

    public void f(Bundle options) {
        if (!this.f140b.isEmpty()) {
            ArrayList<Intent> arrayList = this.f140b;
            Intent[] intents = (Intent[]) arrayList.toArray(new Intent[arrayList.size()]);
            intents[0] = new Intent(intents[0]).addFlags(268484608);
            a.b.c.b.a.d(this.f141c, intents, options);
            return;
        }
        throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
    }
}
