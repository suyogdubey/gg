package b.a.f;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

public class f extends Drawable {

    /* renamed from: a  reason: collision with root package name */
    public float f662a;

    /* renamed from: b  reason: collision with root package name */
    public final Paint f663b;

    /* renamed from: c  reason: collision with root package name */
    public final RectF f664c;
    public final Rect d;
    public float e;
    public boolean f = false;
    public boolean g = true;
    public ColorStateList h;
    public PorterDuffColorFilter i;
    public ColorStateList j;
    public PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;

    public f(ColorStateList backgroundColor, float radius) {
        this.f662a = radius;
        this.f663b = new Paint(5);
        e(backgroundColor);
        this.f664c = new RectF();
        this.d = new Rect();
    }

    public final void e(ColorStateList color) {
        ColorStateList valueOf = color == null ? ColorStateList.valueOf(0) : color;
        this.h = valueOf;
        this.f663b.setColor(valueOf.getColorForState(getState(), this.h.getDefaultColor()));
    }

    public void g(float padding, boolean insetForPadding, boolean insetForRadius) {
        if (padding != this.e || this.f != insetForPadding || this.g != insetForRadius) {
            this.e = padding;
            this.f = insetForPadding;
            this.g = insetForRadius;
            i((Rect) null);
            invalidateSelf();
        }
    }

    public float c() {
        return this.e;
    }

    public void draw(Canvas canvas) {
        boolean clearColorFilter;
        Paint paint = this.f663b;
        if (this.i == null || paint.getColorFilter() != null) {
            clearColorFilter = false;
        } else {
            paint.setColorFilter(this.i);
            clearColorFilter = true;
        }
        RectF rectF = this.f664c;
        float f2 = this.f662a;
        canvas.drawRoundRect(rectF, f2, f2, paint);
        if (clearColorFilter) {
            paint.setColorFilter((ColorFilter) null);
        }
    }

    public final void i(Rect bounds) {
        if (bounds == null) {
            bounds = getBounds();
        }
        this.f664c.set((float) bounds.left, (float) bounds.top, (float) bounds.right, (float) bounds.bottom);
        this.d.set(bounds);
        if (this.f) {
            float vInset = g.d(this.e, this.f662a, this.g);
            this.d.inset((int) Math.ceil((double) g.c(this.e, this.f662a, this.g)), (int) Math.ceil((double) vInset));
            this.f664c.set(this.d);
        }
    }

    public void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        i(bounds);
    }

    public void getOutline(Outline outline) {
        outline.setRoundRect(this.d, this.f662a);
    }

    public void h(float radius) {
        if (radius != this.f662a) {
            this.f662a = radius;
            i((Rect) null);
            invalidateSelf();
        }
    }

    public void setAlpha(int alpha) {
        this.f663b.setAlpha(alpha);
    }

    public void setColorFilter(ColorFilter cf) {
        this.f663b.setColorFilter(cf);
    }

    public int getOpacity() {
        return -3;
    }

    public float d() {
        return this.f662a;
    }

    public void f(ColorStateList color) {
        e(color);
        invalidateSelf();
    }

    public ColorStateList b() {
        return this.h;
    }

    public void setTintList(ColorStateList tint) {
        this.j = tint;
        this.i = a(tint, this.k);
        invalidateSelf();
    }

    public void setTintMode(PorterDuff.Mode tintMode) {
        this.k = tintMode;
        this.i = a(this.j, tintMode);
        invalidateSelf();
    }

    public boolean onStateChange(int[] stateSet) {
        PorterDuff.Mode mode;
        ColorStateList colorStateList = this.h;
        int newColor = colorStateList.getColorForState(stateSet, colorStateList.getDefaultColor());
        boolean colorChanged = newColor != this.f663b.getColor();
        if (colorChanged) {
            this.f663b.setColor(newColor);
        }
        ColorStateList colorStateList2 = this.j;
        if (colorStateList2 == null || (mode = this.k) == null) {
            return colorChanged;
        }
        this.i = a(colorStateList2, mode);
        return true;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:4:0x000a, code lost:
        r0 = r1.h;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isStateful() {
        /*
            r1 = this;
            android.content.res.ColorStateList r0 = r1.j
            if (r0 == 0) goto L_0x000a
            boolean r0 = r0.isStateful()
            if (r0 != 0) goto L_0x001a
        L_0x000a:
            android.content.res.ColorStateList r0 = r1.h
            if (r0 == 0) goto L_0x0014
            boolean r0 = r0.isStateful()
            if (r0 != 0) goto L_0x001a
        L_0x0014:
            boolean r0 = super.isStateful()
            if (r0 == 0) goto L_0x001c
        L_0x001a:
            r0 = 1
            goto L_0x001d
        L_0x001c:
            r0 = 0
        L_0x001d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.f.f.isStateful():boolean");
    }

    public final PorterDuffColorFilter a(ColorStateList tint, PorterDuff.Mode tintMode) {
        if (tint == null || tintMode == null) {
            return null;
        }
        return new PorterDuffColorFilter(tint.getColorForState(getState(), 0), tintMode);
    }
}
