package a.b.c.a;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

public class a extends a.b.c.b.a {

    public interface b {
        void onRequestPermissionsResult(int i, String[] strArr, int[] iArr);
    }

    public interface c {
        boolean a(Activity activity, int i, int i2, Intent intent);
    }

    public interface d {
        void b(int i);
    }

    public static c f() {
        return null;
    }

    public static void e(Activity activity) {
        activity.finishAffinity();
    }

    public static void g(Activity activity, String[] permissions, int requestCode) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (activity instanceof d) {
                ((d) activity).b(requestCode);
            }
            activity.requestPermissions(permissions, requestCode);
        } else if (activity instanceof b) {
            new Handler(Looper.getMainLooper()).post(new C0004a(permissions, activity, requestCode));
        }
    }

    /* renamed from: a.b.c.a.a$a  reason: collision with other inner class name */
    public static class C0004a implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ String[] f53b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ Activity f54c;
        public final /* synthetic */ int d;

        public C0004a(String[] strArr, Activity activity, int i) {
            this.f53b = strArr;
            this.f54c = activity;
            this.d = i;
        }

        public void run() {
            int[] grantResults = new int[this.f53b.length];
            PackageManager packageManager = this.f54c.getPackageManager();
            String packageName = this.f54c.getPackageName();
            int permissionCount = this.f53b.length;
            for (int i = 0; i < permissionCount; i++) {
                grantResults[i] = packageManager.checkPermission(this.f53b[i], packageName);
            }
            ((b) this.f54c).onRequestPermissionsResult(this.d, this.f53b, grantResults);
        }
    }
}
