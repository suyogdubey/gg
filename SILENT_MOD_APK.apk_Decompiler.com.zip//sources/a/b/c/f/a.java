package a.b.c.f;

import a.b.c.g.i;
import android.os.Build;
import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;

public class a implements Spannable {
    static {
        new Object();
    }

    /* renamed from: a.b.c.f.a$a  reason: collision with other inner class name */
    public static final class C0012a {

        /* renamed from: a  reason: collision with root package name */
        public final TextPaint f208a;

        /* renamed from: b  reason: collision with root package name */
        public final TextDirectionHeuristic f209b;

        /* renamed from: c  reason: collision with root package name */
        public final int f210c;
        public final int d;
        public final PrecomputedText.Params e;

        /* renamed from: a.b.c.f.a$a$a  reason: collision with other inner class name */
        public static class C0013a {

            /* renamed from: a  reason: collision with root package name */
            public final TextPaint f211a;

            /* renamed from: b  reason: collision with root package name */
            public TextDirectionHeuristic f212b;

            /* renamed from: c  reason: collision with root package name */
            public int f213c;
            public int d;

            public C0013a(TextPaint paint) {
                this.f211a = paint;
                if (Build.VERSION.SDK_INT >= 23) {
                    this.f213c = 1;
                    this.d = 1;
                } else {
                    this.d = 0;
                    this.f213c = 0;
                }
                this.f212b = TextDirectionHeuristics.FIRSTSTRONG_LTR;
            }

            public C0013a b(int strategy) {
                this.f213c = strategy;
                return this;
            }

            public C0013a c(int frequency) {
                this.d = frequency;
                return this;
            }

            public C0013a d(TextDirectionHeuristic textDir) {
                this.f212b = textDir;
                return this;
            }

            public C0012a a() {
                return new C0012a(this.f211a, this.f212b, this.f213c, this.d);
            }
        }

        public C0012a(TextPaint paint, TextDirectionHeuristic textDir, int strategy, int frequency) {
            if (Build.VERSION.SDK_INT >= 28) {
                this.e = new PrecomputedText.Params.Builder(paint).setBreakStrategy(strategy).setHyphenationFrequency(frequency).setTextDirection(textDir).build();
            } else {
                this.e = null;
            }
            this.f208a = paint;
            this.f209b = textDir;
            this.f210c = strategy;
            this.d = frequency;
        }

        public C0012a(PrecomputedText.Params wrapped) {
            this.f208a = wrapped.getTextPaint();
            this.f209b = wrapped.getTextDirection();
            this.f210c = wrapped.getBreakStrategy();
            this.d = wrapped.getHyphenationFrequency();
            this.e = wrapped;
        }

        public TextPaint d() {
            return this.f208a;
        }

        public TextDirectionHeuristic c() {
            return this.f209b;
        }

        public int a() {
            return this.f210c;
        }

        public int b() {
            return this.d;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (o == null || !(o instanceof C0012a)) {
                return false;
            }
            C0012a other = (C0012a) o;
            PrecomputedText.Params params = this.e;
            if (params != null) {
                return params.equals(other.e);
            }
            if ((Build.VERSION.SDK_INT >= 23 && (this.f210c != other.a() || this.d != other.b())) || this.f209b != other.c() || this.f208a.getTextSize() != other.d().getTextSize() || this.f208a.getTextScaleX() != other.d().getTextScaleX() || this.f208a.getTextSkewX() != other.d().getTextSkewX()) {
                return false;
            }
            if ((Build.VERSION.SDK_INT >= 21 && (this.f208a.getLetterSpacing() != other.d().getLetterSpacing() || !TextUtils.equals(this.f208a.getFontFeatureSettings(), other.d().getFontFeatureSettings()))) || this.f208a.getFlags() != other.d().getFlags()) {
                return false;
            }
            if (Build.VERSION.SDK_INT >= 24) {
                if (!this.f208a.getTextLocales().equals(other.d().getTextLocales())) {
                    return false;
                }
            } else if (!this.f208a.getTextLocale().equals(other.d().getTextLocale())) {
                return false;
            }
            if (this.f208a.getTypeface() == null) {
                if (other.d().getTypeface() != null) {
                    return false;
                }
            } else if (!this.f208a.getTypeface().equals(other.d().getTypeface())) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            int i = Build.VERSION.SDK_INT;
            if (i >= 24) {
                return i.a(Float.valueOf(this.f208a.getTextSize()), Float.valueOf(this.f208a.getTextScaleX()), Float.valueOf(this.f208a.getTextSkewX()), Float.valueOf(this.f208a.getLetterSpacing()), Integer.valueOf(this.f208a.getFlags()), this.f208a.getTextLocales(), this.f208a.getTypeface(), Boolean.valueOf(this.f208a.isElegantTextHeight()), this.f209b, Integer.valueOf(this.f210c), Integer.valueOf(this.d));
            } else if (i >= 21) {
                return i.a(Float.valueOf(this.f208a.getTextSize()), Float.valueOf(this.f208a.getTextScaleX()), Float.valueOf(this.f208a.getTextSkewX()), Float.valueOf(this.f208a.getLetterSpacing()), Integer.valueOf(this.f208a.getFlags()), this.f208a.getTextLocale(), this.f208a.getTypeface(), Boolean.valueOf(this.f208a.isElegantTextHeight()), this.f209b, Integer.valueOf(this.f210c), Integer.valueOf(this.d));
            } else {
                return i.a(Float.valueOf(this.f208a.getTextSize()), Float.valueOf(this.f208a.getTextScaleX()), Float.valueOf(this.f208a.getTextSkewX()), Integer.valueOf(this.f208a.getFlags()), this.f208a.getTextLocale(), this.f208a.getTypeface(), this.f209b, Integer.valueOf(this.f210c), Integer.valueOf(this.d));
            }
        }

        public String toString() {
            StringBuilder sb = new StringBuilder("{");
            sb.append("textSize=" + this.f208a.getTextSize());
            sb.append(", textScaleX=" + this.f208a.getTextScaleX());
            sb.append(", textSkewX=" + this.f208a.getTextSkewX());
            if (Build.VERSION.SDK_INT >= 21) {
                sb.append(", letterSpacing=" + this.f208a.getLetterSpacing());
                sb.append(", elegantTextHeight=" + this.f208a.isElegantTextHeight());
            }
            if (Build.VERSION.SDK_INT >= 24) {
                sb.append(", textLocale=" + this.f208a.getTextLocales());
            } else {
                sb.append(", textLocale=" + this.f208a.getTextLocale());
            }
            sb.append(", typeface=" + this.f208a.getTypeface());
            if (Build.VERSION.SDK_INT >= 26) {
                sb.append(", variationSettings=" + this.f208a.getFontVariationSettings());
            }
            sb.append(", textDir=" + this.f209b);
            sb.append(", breakStrategy=" + this.f210c);
            sb.append(", hyphenationFrequency=" + this.d);
            sb.append("}");
            return sb.toString();
        }
    }

    public PrecomputedText b() {
        return null;
    }

    public C0012a a() {
        return null;
    }

    public void setSpan(Object what, int start, int end, int flags) {
        if (what instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
        } else if (Build.VERSION.SDK_INT >= 28) {
            throw null;
        } else {
            throw null;
        }
    }

    public void removeSpan(Object what) {
        if (what instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
        } else if (Build.VERSION.SDK_INT >= 28) {
            throw null;
        } else {
            throw null;
        }
    }

    public <T> T[] getSpans(int start, int end, Class<T> cls) {
        if (Build.VERSION.SDK_INT >= 28) {
            throw null;
        }
        throw null;
    }

    public int getSpanStart(Object tag) {
        throw null;
    }

    public int getSpanEnd(Object tag) {
        throw null;
    }

    public int getSpanFlags(Object tag) {
        throw null;
    }

    public int nextSpanTransition(int start, int limit, Class type) {
        throw null;
    }

    public int length() {
        throw null;
    }

    public char charAt(int index) {
        throw null;
    }

    public CharSequence subSequence(int start, int end) {
        throw null;
    }

    public String toString() {
        throw null;
    }
}
