package a.b.c.a;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class j {
    public abstract void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract List<e> b();

    public abstract boolean c();

    public abstract boolean d();
}
