package a.b.c.b.c;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.support.v4.content.res.FontResourcesParserCompat;
import android.util.Base64;
import android.util.TypedValue;
import android.util.Xml;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

public class c {

    public interface a {
    }

    public static final class d implements a {

        /* renamed from: a  reason: collision with root package name */
        public final a.b.c.e.a f150a;

        /* renamed from: b  reason: collision with root package name */
        public final int f151b;

        /* renamed from: c  reason: collision with root package name */
        public final int f152c;

        public d(a.b.c.e.a request, int strategy, int timeoutMs) {
            this.f150a = request;
            this.f152c = strategy;
            this.f151b = timeoutMs;
        }

        public a.b.c.e.a b() {
            return this.f150a;
        }

        public int a() {
            return this.f152c;
        }

        public int c() {
            return this.f151b;
        }
    }

    /* renamed from: a.b.c.b.c.c$c  reason: collision with other inner class name */
    public static final class C0007c {

        /* renamed from: a  reason: collision with root package name */
        public final String f147a;

        /* renamed from: b  reason: collision with root package name */
        public int f148b;

        /* renamed from: c  reason: collision with root package name */
        public boolean f149c;
        public String d;
        public int e;
        public int f;

        public C0007c(String fileName, int weight, boolean italic, String variationSettings, int ttcIndex, int resourceId) {
            this.f147a = fileName;
            this.f148b = weight;
            this.f149c = italic;
            this.d = variationSettings;
            this.e = ttcIndex;
            this.f = resourceId;
        }

        public String a() {
            return this.f147a;
        }

        public int e() {
            return this.f148b;
        }

        public boolean f() {
            return this.f149c;
        }

        public String d() {
            return this.d;
        }

        public int c() {
            return this.e;
        }

        public int b() {
            return this.f;
        }
    }

    public static final class b implements a {

        /* renamed from: a  reason: collision with root package name */
        public final C0007c[] f146a;

        public b(C0007c[] entries) {
            this.f146a = entries;
        }

        public C0007c[] a() {
            return this.f146a;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:0:0x0000 A[LOOP_START, MTH_ENTER_BLOCK] */
    /* JADX WARNING: Removed duplicated region for block: B:5:0x000e  */
    /* JADX WARNING: Removed duplicated region for block: B:7:0x0013  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static a.b.c.b.c.c.a b(org.xmlpull.v1.XmlPullParser r3, android.content.res.Resources r4) {
        /*
        L_0x0000:
            int r0 = r3.next()
            r1 = r0
            r2 = 2
            if (r0 == r2) goto L_0x000c
            r0 = 1
            if (r1 == r0) goto L_0x000c
            goto L_0x0000
        L_0x000c:
            if (r1 != r2) goto L_0x0013
            a.b.c.b.c.c$a r0 = d(r3, r4)
            return r0
        L_0x0013:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.String r2 = "No start tag found"
            r0.<init>(r2)
            goto L_0x001c
        L_0x001b:
            throw r0
        L_0x001c:
            goto L_0x001b
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.b.c.c.b(org.xmlpull.v1.XmlPullParser, android.content.res.Resources):a.b.c.b.c.c$a");
    }

    public static a d(XmlPullParser parser, Resources resources) {
        parser.require(2, (String) null, "font-family");
        if (parser.getName().equals("font-family")) {
            return e(parser, resources);
        }
        g(parser);
        return null;
    }

    public static a e(XmlPullParser parser, Resources resources) {
        TypedArray array = resources.obtainAttributes(Xml.asAttributeSet(parser), a.b.a.c.FontFamily);
        String authority = array.getString(a.b.a.c.FontFamily_fontProviderAuthority);
        String providerPackage = array.getString(a.b.a.c.FontFamily_fontProviderPackage);
        String query = array.getString(a.b.a.c.FontFamily_fontProviderQuery);
        int certsId = array.getResourceId(a.b.a.c.FontFamily_fontProviderCerts, 0);
        int strategy = array.getInteger(a.b.a.c.FontFamily_fontProviderFetchStrategy, 1);
        int timeoutMs = array.getInteger(a.b.a.c.FontFamily_fontProviderFetchTimeout, 500);
        array.recycle();
        if (authority == null || providerPackage == null || query == null) {
            List<FontResourcesParserCompat.FontFileResourceEntry> fonts = new ArrayList<>();
            while (parser.next() != 3) {
                if (parser.getEventType() == 2) {
                    if (parser.getName().equals("font")) {
                        fonts.add(f(parser, resources));
                    } else {
                        g(parser);
                    }
                }
            }
            if (fonts.isEmpty()) {
                return null;
            }
            return new b((C0007c[]) fonts.toArray(new C0007c[fonts.size()]));
        }
        while (parser.next() != 3) {
            g(parser);
        }
        return new d(new a.b.c.e.a(authority, providerPackage, query, c(resources, certsId)), strategy, timeoutMs);
    }

    public static int a(TypedArray typedArray, int index) {
        if (Build.VERSION.SDK_INT >= 21) {
            return typedArray.getType(index);
        }
        TypedValue tv = new TypedValue();
        typedArray.getValue(index, tv);
        return tv.type;
    }

    public static List<List<byte[]>> c(Resources resources, int certsId) {
        if (certsId == 0) {
            return Collections.emptyList();
        }
        TypedArray typedArray = resources.obtainTypedArray(certsId);
        try {
            if (typedArray.length() == 0) {
                return Collections.emptyList();
            }
            List<List<byte[]>> result = new ArrayList<>();
            if (a(typedArray, 0) == 1) {
                for (int i = 0; i < typedArray.length(); i++) {
                    int certId = typedArray.getResourceId(i, 0);
                    if (certId != 0) {
                        result.add(h(resources.getStringArray(certId)));
                    }
                }
            } else {
                result.add(h(resources.getStringArray(certsId)));
            }
            typedArray.recycle();
            return result;
        } finally {
            typedArray.recycle();
        }
    }

    public static List<byte[]> h(String[] stringArray) {
        List<byte[]> result = new ArrayList<>();
        for (String item : stringArray) {
            result.add(Base64.decode(item, 0));
        }
        return result;
    }

    public static C0007c f(XmlPullParser parser, Resources resources) {
        TypedArray array = resources.obtainAttributes(Xml.asAttributeSet(parser), a.b.a.c.FontFamilyFont);
        int weight = array.getInt(array.hasValue(a.b.a.c.FontFamilyFont_fontWeight) ? a.b.a.c.FontFamilyFont_fontWeight : a.b.a.c.FontFamilyFont_android_fontWeight, 400);
        boolean isItalic = 1 == array.getInt(array.hasValue(a.b.a.c.FontFamilyFont_fontStyle) ? a.b.a.c.FontFamilyFont_fontStyle : a.b.a.c.FontFamilyFont_android_fontStyle, 0);
        int ttcIndexAttr = array.hasValue(a.b.a.c.FontFamilyFont_ttcIndex) ? a.b.a.c.FontFamilyFont_ttcIndex : a.b.a.c.FontFamilyFont_android_ttcIndex;
        String variationSettings = array.getString(array.hasValue(a.b.a.c.FontFamilyFont_fontVariationSettings) ? a.b.a.c.FontFamilyFont_fontVariationSettings : a.b.a.c.FontFamilyFont_android_fontVariationSettings);
        int ttcIndex = array.getInt(ttcIndexAttr, 0);
        int resourceAttr = array.hasValue(a.b.a.c.FontFamilyFont_font) ? a.b.a.c.FontFamilyFont_font : a.b.a.c.FontFamilyFont_android_font;
        int resourceId = array.getResourceId(resourceAttr, 0);
        String filename = array.getString(resourceAttr);
        array.recycle();
        while (parser.next() != 3) {
            g(parser);
        }
        int i = resourceAttr;
        return new C0007c(filename, weight, isItalic, variationSettings, ttcIndex, resourceId);
    }

    public static void g(XmlPullParser parser) {
        int depth = 1;
        while (depth > 0) {
            int next = parser.next();
            if (next == 2) {
                depth++;
            } else if (next == 3) {
                depth--;
            }
        }
    }
}
