package androidx.versionedparcelable;

import b.b.c;

public abstract class CustomVersionedParcelable implements c {
}
