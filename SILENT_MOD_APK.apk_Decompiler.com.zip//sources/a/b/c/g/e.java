package a.b.c.g;

import android.util.Log;
import java.io.Writer;

public class e extends Writer {

    /* renamed from: b  reason: collision with root package name */
    public final String f219b;

    /* renamed from: c  reason: collision with root package name */
    public StringBuilder f220c = new StringBuilder(128);

    public e(String tag) {
        this.f219b = tag;
    }

    public void close() {
        a();
    }

    public void flush() {
        a();
    }

    public void write(char[] buf, int offset, int count) {
        for (int i = 0; i < count; i++) {
            char c2 = buf[offset + i];
            if (c2 == 10) {
                a();
            } else {
                this.f220c.append(c2);
            }
        }
    }

    public final void a() {
        if (this.f220c.length() > 0) {
            Log.d(this.f219b, this.f220c.toString());
            StringBuilder sb = this.f220c;
            sb.delete(0, sb.length());
        }
    }
}
