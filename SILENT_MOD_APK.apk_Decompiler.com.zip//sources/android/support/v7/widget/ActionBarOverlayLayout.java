package android.support.v7.widget;

import a.b.c.h.l;
import a.b.c.h.m;
import a.b.c.h.p;
import a.b.d.a.k;
import a.b.d.b.f;
import a.b.d.e.j.o;
import a.b.d.f.a0;
import a.b.d.f.a1;
import a.b.d.f.b0;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.widget.OverScroller;

public class ActionBarOverlayLayout extends ViewGroup implements a0, l {
    public static final int[] C = {a.b.d.b.a.actionBarSize, 16842841};
    public final Runnable A = new c();
    public final m B;

    /* renamed from: b  reason: collision with root package name */
    public int f615b;

    /* renamed from: c  reason: collision with root package name */
    public int f616c = 0;
    public ContentFrameLayout d;
    public ActionBarContainer e;
    public b0 f;
    public Drawable g;
    public boolean h;
    public boolean i;
    public boolean j;
    public boolean k;
    public boolean l;
    public int m;
    public int n;
    public final Rect o = new Rect();
    public final Rect p = new Rect();
    public final Rect q = new Rect();
    public final Rect r = new Rect();
    public final Rect s = new Rect();
    public final Rect t = new Rect();
    public final Rect u = new Rect();
    public d v;
    public OverScroller w;
    public ViewPropertyAnimator x;
    public final AnimatorListenerAdapter y = new a();
    public final Runnable z = new b();

    public interface d {
    }

    public class a extends AnimatorListenerAdapter {
        public a() {
        }

        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.x = null;
            actionBarOverlayLayout.l = false;
        }

        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.x = null;
            actionBarOverlayLayout.l = false;
        }
    }

    public class b implements Runnable {
        public b() {
        }

        public void run() {
            ActionBarOverlayLayout.this.t();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.x = actionBarOverlayLayout.e.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.y);
        }
    }

    public class c implements Runnable {
        public c() {
        }

        public void run() {
            ActionBarOverlayLayout.this.t();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.x = actionBarOverlayLayout.e.animate().translationY((float) (-ActionBarOverlayLayout.this.e.getHeight())).setListener(ActionBarOverlayLayout.this.y);
        }
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        u(context);
        this.B = new m(this);
    }

    public final void u(Context context) {
        TypedArray ta = getContext().getTheme().obtainStyledAttributes(C);
        boolean z2 = false;
        this.f615b = ta.getDimensionPixelSize(0, 0);
        Drawable drawable = ta.getDrawable(1);
        this.g = drawable;
        setWillNotDraw(drawable == null);
        ta.recycle();
        if (context.getApplicationInfo().targetSdkVersion < 19) {
            z2 = true;
        }
        this.h = z2;
        this.w = new OverScroller(context);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        t();
    }

    public void setActionBarVisibilityCallback(d cb) {
        this.v = cb;
        if (getWindowToken() != null) {
            ((k) this.v).D(this.f616c);
            if (this.n != 0) {
                onWindowSystemUiVisibilityChanged(this.n);
                p.r(this);
            }
        }
    }

    public void setOverlayMode(boolean overlayMode) {
        this.i = overlayMode;
        this.h = overlayMode && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public boolean v() {
        return this.i;
    }

    public void setHasNonEmbeddedTabs(boolean hasNonEmbeddedTabs) {
        this.j = hasNonEmbeddedTabs;
    }

    public void setShowingForActionMode(boolean showing) {
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        u(getContext());
        p.r(this);
    }

    public void onWindowSystemUiVisibilityChanged(int visible) {
        super.onWindowSystemUiVisibilityChanged(visible);
        y();
        int diff = this.n ^ visible;
        this.n = visible;
        boolean z2 = true;
        boolean barVisible = (visible & 4) == 0;
        boolean stable = (visible & 256) != 0;
        d dVar = this.v;
        if (dVar != null) {
            if (stable) {
                z2 = false;
            }
            ((k) dVar).v(z2);
            if (barVisible || !stable) {
                ((k) this.v).M();
            } else {
                ((k) this.v).z();
            }
        }
        if ((diff & 256) != 0 && this.v != null) {
            p.r(this);
        }
    }

    public void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        this.f616c = visibility;
        d dVar = this.v;
        if (dVar != null) {
            ((k) dVar).D(visibility);
        }
    }

    public final boolean p(View view, Rect insets, boolean left, boolean top, boolean bottom, boolean right) {
        int i2;
        int i3;
        int i4;
        int i5;
        boolean changed = false;
        e lp = (e) view.getLayoutParams();
        if (left && lp.leftMargin != (i5 = insets.left)) {
            changed = true;
            lp.leftMargin = i5;
        }
        if (top && lp.topMargin != (i4 = insets.top)) {
            changed = true;
            lp.topMargin = i4;
        }
        if (right && lp.rightMargin != (i3 = insets.right)) {
            changed = true;
            lp.rightMargin = i3;
        }
        if (!bottom || lp.bottomMargin == (i2 = insets.bottom)) {
            return changed;
        }
        lp.bottomMargin = i2;
        return true;
    }

    public boolean fitSystemWindows(Rect insets) {
        y();
        if ((p.i(this) & 256) != 0) {
        }
        Rect systemInsets = insets;
        boolean changed = p(this.e, systemInsets, true, true, false, true);
        this.r.set(systemInsets);
        a1.a(this, this.r, this.o);
        if (!this.s.equals(this.r)) {
            changed = true;
            this.s.set(this.r);
        }
        if (!this.p.equals(this.o)) {
            changed = true;
            this.p.set(this.o);
        }
        if (changed) {
            requestLayout();
        }
        return true;
    }

    /* renamed from: q */
    public e generateDefaultLayoutParams() {
        return new e(-1, -1);
    }

    /* renamed from: r */
    public e generateLayoutParams(AttributeSet attrs) {
        return new e(getContext(), attrs);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams p2) {
        return new e(p2);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams p2) {
        return p2 instanceof e;
    }

    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        y();
        int topInset = 0;
        measureChildWithMargins(this.e, widthMeasureSpec, 0, heightMeasureSpec, 0);
        e lp = (e) this.e.getLayoutParams();
        int maxWidth = Math.max(0, this.e.getMeasuredWidth() + lp.leftMargin + lp.rightMargin);
        int maxHeight = Math.max(0, this.e.getMeasuredHeight() + lp.topMargin + lp.bottomMargin);
        int childState = View.combineMeasuredStates(0, this.e.getMeasuredState());
        boolean stable = (p.i(this) & 256) != 0;
        if (stable) {
            topInset = this.f615b;
            if (this.j && this.e.getTabContainer() != null) {
                topInset += this.f615b;
            }
        } else if (this.e.getVisibility() != 8) {
            topInset = this.e.getMeasuredHeight();
        }
        this.q.set(this.o);
        this.t.set(this.r);
        if (this.i || stable) {
            Rect rect = this.t;
            rect.top += topInset;
            rect.bottom += 0;
        } else {
            Rect rect2 = this.q;
            rect2.top += topInset;
            rect2.bottom += 0;
        }
        p(this.d, this.q, true, true, true, true);
        if (!this.u.equals(this.t)) {
            this.u.set(this.t);
            this.d.a(this.t);
        }
        measureChildWithMargins(this.d, widthMeasureSpec, 0, heightMeasureSpec, 0);
        e lp2 = (e) this.d.getLayoutParams();
        int maxWidth2 = Math.max(maxWidth, this.d.getMeasuredWidth() + lp2.leftMargin + lp2.rightMargin);
        int maxHeight2 = Math.max(maxHeight, this.d.getMeasuredHeight() + lp2.topMargin + lp2.bottomMargin);
        int childState2 = View.combineMeasuredStates(childState, this.d.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(maxWidth2 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), widthMeasureSpec, childState2), View.resolveSizeAndState(Math.max(maxHeight2 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), heightMeasureSpec, childState2 << 16));
    }

    public void onLayout(boolean changed, int left, int top, int right, int bottom) {
        int count = getChildCount();
        int parentLeft = getPaddingLeft();
        int paddingRight = (right - left) - getPaddingRight();
        int parentTop = getPaddingTop();
        int paddingBottom = (bottom - top) - getPaddingBottom();
        for (int i2 = 0; i2 < count; i2++) {
            View child = getChildAt(i2);
            if (child.getVisibility() != 8) {
                e lp = (e) child.getLayoutParams();
                int width = child.getMeasuredWidth();
                int height = child.getMeasuredHeight();
                int childLeft = lp.leftMargin + parentLeft;
                int childTop = lp.topMargin + parentTop;
                child.layout(childLeft, childTop, childLeft + width, childTop + height);
            }
        }
    }

    public void draw(Canvas c2) {
        super.draw(c2);
        if (this.g != null && !this.h) {
            int top = this.e.getVisibility() == 0 ? (int) (((float) this.e.getBottom()) + this.e.getTranslationY() + 0.5f) : 0;
            this.g.setBounds(0, top, getWidth(), this.g.getIntrinsicHeight() + top);
            this.g.draw(c2);
        }
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public boolean onStartNestedScroll(View child, View target, int axes) {
        if ((axes & 2) == 0 || this.e.getVisibility() != 0) {
            return false;
        }
        return this.k;
    }

    public void onNestedScrollAccepted(View child, View target, int axes) {
        this.B.c(child, target, axes);
        this.m = getActionBarHideOffset();
        t();
        d dVar = this.v;
        if (dVar != null) {
            ((k) dVar).B();
        }
    }

    public void onNestedScroll(View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
        int i2 = this.m + dyConsumed;
        this.m = i2;
        setActionBarHideOffset(i2);
    }

    public void onStopNestedScroll(View target) {
        if (this.k && !this.l) {
            if (this.m <= this.e.getHeight()) {
                x();
            } else {
                w();
            }
        }
        d dVar = this.v;
        if (dVar != null) {
            ((k) dVar).C();
        }
    }

    public boolean onNestedFling(View target, float velocityX, float velocityY, boolean consumed) {
        if (!this.k || !consumed) {
            return false;
        }
        if (A(velocityY)) {
            o();
        } else {
            z();
        }
        this.l = true;
        return true;
    }

    public void onNestedPreScroll(View target, int dx, int dy, int[] consumed) {
    }

    public boolean onNestedPreFling(View target, float velocityX, float velocityY) {
        return false;
    }

    public int getNestedScrollAxes() {
        return this.B.a();
    }

    public void y() {
        if (this.d == null) {
            this.d = (ContentFrameLayout) findViewById(f.action_bar_activity_content);
            this.e = (ActionBarContainer) findViewById(f.action_bar_container);
            this.f = s(findViewById(f.action_bar));
        }
    }

    public final b0 s(View view) {
        if (view instanceof b0) {
            return (b0) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        throw new IllegalStateException("Can't make a decor toolbar out of " + view.getClass().getSimpleName());
    }

    public void setHideOnContentScrollEnabled(boolean hideOnContentScroll) {
        if (hideOnContentScroll != this.k) {
            this.k = hideOnContentScroll;
            if (!hideOnContentScroll) {
                t();
                setActionBarHideOffset(0);
            }
        }
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.e;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    public void setActionBarHideOffset(int offset) {
        t();
        this.e.setTranslationY((float) (-Math.max(0, Math.min(offset, this.e.getHeight()))));
    }

    public void t() {
        removeCallbacks(this.z);
        removeCallbacks(this.A);
        ViewPropertyAnimator viewPropertyAnimator = this.x;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void x() {
        t();
        postDelayed(this.z, 600);
    }

    public final void w() {
        t();
        postDelayed(this.A, 600);
    }

    public final void z() {
        t();
        this.z.run();
    }

    public final void o() {
        t();
        this.A.run();
    }

    public final boolean A(float velocityY) {
        this.w.fling(0, 0, 0, (int) velocityY, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        return this.w.getFinalY() > this.e.getHeight();
    }

    public void setWindowCallback(Window.Callback cb) {
        y();
        this.f.setWindowCallback(cb);
    }

    public void setWindowTitle(CharSequence title) {
        y();
        this.f.setWindowTitle(title);
    }

    public CharSequence getTitle() {
        y();
        return this.f.getTitle();
    }

    public void h(int windowFeature) {
        y();
        if (windowFeature == 2) {
            this.f.m();
        } else if (windowFeature == 5) {
            this.f.r();
        } else if (windowFeature == 109) {
            setOverlayMode(true);
        }
    }

    public void setUiOptions(int uiOptions) {
    }

    public void setIcon(int resId) {
        y();
        this.f.setIcon(resId);
    }

    public void setIcon(Drawable d2) {
        y();
        this.f.setIcon(d2);
    }

    public void setLogo(int resId) {
        y();
        this.f.o(resId);
    }

    public boolean e() {
        y();
        return this.f.e();
    }

    public boolean d() {
        y();
        return this.f.d();
    }

    public boolean b() {
        y();
        return this.f.b();
    }

    public boolean a() {
        y();
        return this.f.a();
    }

    public boolean g() {
        y();
        return this.f.g();
    }

    public void c() {
        y();
        this.f.c();
    }

    public void f(Menu menu, o.a cb) {
        y();
        this.f.f(menu, cb);
    }

    public void j() {
        y();
        this.f.h();
    }

    public static class e extends ViewGroup.MarginLayoutParams {
        public e(Context c2, AttributeSet attrs) {
            super(c2, attrs);
        }

        public e(int width, int height) {
            super(width, height);
        }

        public e(ViewGroup.LayoutParams source) {
            super(source);
        }
    }
}
