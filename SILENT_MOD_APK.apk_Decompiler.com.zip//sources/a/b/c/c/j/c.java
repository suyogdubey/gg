package a.b.c.c.j;

import android.graphics.drawable.Drawable;

public interface c {
    Drawable a();

    void b(Drawable drawable);
}
