package a.b.c.a;

import android.util.AndroidRuntimeException;

public final class w extends AndroidRuntimeException {
    public w(String msg) {
        super(msg);
    }
}
