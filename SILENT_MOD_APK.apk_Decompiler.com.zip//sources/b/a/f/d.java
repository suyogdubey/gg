package b.a.f;

public interface d {
}
