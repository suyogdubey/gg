package a.b.c.c;

import a.b.c.b.c.c;
import a.b.c.e.b;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class h {

    public interface c<T> {
        int a(T t);

        boolean b(T t);
    }

    public static <T> T f(T[] fonts, int style, c<T> extractor) {
        int targetWeight = (style & 1) == 0 ? 400 : 700;
        boolean isTargetItalic = (style & 2) != 0;
        T best = null;
        int bestScore = Integer.MAX_VALUE;
        for (T font : fonts) {
            int score = (Math.abs(extractor.a(font) - targetWeight) * 2) + (extractor.b(font) == isTargetItalic ? 0 : 1);
            if (best == null || bestScore > score) {
                best = font;
                bestScore = score;
            }
        }
        return best;
    }

    public class a implements c<b.f> {
        public a(h this$0) {
        }

        /* renamed from: c */
        public int a(b.f info) {
            return info.d();
        }

        /* renamed from: d */
        public boolean b(b.f info) {
            return info.e();
        }
    }

    public b.f g(b.f[] fonts, int style) {
        return (b.f) f(fonts, style, new a(this));
    }

    public Typeface c(Context context, InputStream is) {
        File tmpFile = i.e(context);
        if (tmpFile == null) {
            return null;
        }
        try {
            if (!i.d(tmpFile, is)) {
                return null;
            }
            Typeface createFromFile = Typeface.createFromFile(tmpFile.getPath());
            tmpFile.delete();
            return createFromFile;
        } catch (RuntimeException e) {
            return null;
        } finally {
            tmpFile.delete();
        }
    }

    public Typeface b(Context context, CancellationSignal cancellationSignal, b.f[] fonts, int style) {
        if (fonts.length < 1) {
            return null;
        }
        InputStream is = null;
        try {
            is = context.getContentResolver().openInputStream(g(fonts, style).c());
            return c(context, is);
        } catch (IOException e) {
            return null;
        } finally {
            i.a(is);
        }
    }

    public class b implements c<c.C0007c> {
        public b(h this$0) {
        }

        /* renamed from: c */
        public int a(c.C0007c entry) {
            return entry.e();
        }

        /* renamed from: d */
        public boolean b(c.C0007c entry) {
            return entry.f();
        }
    }

    public final c.C0007c e(c.b entry, int style) {
        return (c.C0007c) f(entry.a(), style, new b(this));
    }

    public Typeface a(Context context, c.b entry, Resources resources, int style) {
        c.C0007c best = e(entry, style);
        if (best == null) {
            return null;
        }
        return c.c(context, resources, best.b(), best.a(), style);
    }

    public Typeface d(Context context, Resources resources, int id, String path, int style) {
        File tmpFile = i.e(context);
        if (tmpFile == null) {
            return null;
        }
        try {
            if (!i.c(tmpFile, resources, id)) {
                return null;
            }
            Typeface createFromFile = Typeface.createFromFile(tmpFile.getPath());
            tmpFile.delete();
            return createFromFile;
        } catch (RuntimeException e) {
            return null;
        } finally {
            tmpFile.delete();
        }
    }
}
