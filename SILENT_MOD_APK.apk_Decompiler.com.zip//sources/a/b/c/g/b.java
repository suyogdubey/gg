package a.b.c.g;

import a.b.c.g.h;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class b<E> implements Collection<E>, Set<E> {
    public static final int[] f = new int[0];
    public static final Object[] g = new Object[0];
    public static Object[] h;
    public static int i;
    public static Object[] j;
    public static int k;

    /* renamed from: b  reason: collision with root package name */
    public int[] f214b;

    /* renamed from: c  reason: collision with root package name */
    public Object[] f215c;
    public int d;
    public h<E, E> e;

    public final int f(Object key, int hash) {
        int N = this.d;
        if (N == 0) {
            return -1;
        }
        int index = c.a(this.f214b, N, hash);
        if (index < 0 || key.equals(this.f215c[index])) {
            return index;
        }
        int end = index + 1;
        while (end < N && this.f214b[end] == hash) {
            if (key.equals(this.f215c[end])) {
                return end;
            }
            end++;
        }
        int i2 = index - 1;
        while (i2 >= 0 && this.f214b[i2] == hash) {
            if (key.equals(this.f215c[i2])) {
                return i2;
            }
            i2--;
        }
        return end ^ -1;
    }

    public final int g() {
        int N = this.d;
        if (N == 0) {
            return -1;
        }
        int index = c.a(this.f214b, N, 0);
        if (index < 0 || this.f215c[index] == null) {
            return index;
        }
        int end = index + 1;
        while (end < N && this.f214b[end] == 0) {
            if (this.f215c[end] == null) {
                return end;
            }
            end++;
        }
        int i2 = index - 1;
        while (i2 >= 0 && this.f214b[i2] == 0) {
            if (this.f215c[i2] == null) {
                return i2;
            }
            i2--;
        }
        return end ^ -1;
    }

    public final void a(int size) {
        if (size == 8) {
            synchronized (b.class) {
                if (j != null) {
                    Object[] array = j;
                    this.f215c = array;
                    j = (Object[]) array[0];
                    this.f214b = (int[]) array[1];
                    array[1] = null;
                    array[0] = null;
                    k--;
                    return;
                }
            }
        } else if (size == 4) {
            synchronized (b.class) {
                if (h != null) {
                    Object[] array2 = h;
                    this.f215c = array2;
                    h = (Object[]) array2[0];
                    this.f214b = (int[]) array2[1];
                    array2[1] = null;
                    array2[0] = null;
                    i--;
                    return;
                }
            }
        }
        this.f214b = new int[size];
        this.f215c = new Object[size];
    }

    public static void c(int[] hashes, Object[] array, int size) {
        if (hashes.length == 8) {
            synchronized (b.class) {
                if (k < 10) {
                    array[0] = j;
                    array[1] = hashes;
                    for (int i2 = size - 1; i2 >= 2; i2--) {
                        array[i2] = null;
                    }
                    j = array;
                    k++;
                }
            }
        } else if (hashes.length == 4) {
            synchronized (b.class) {
                if (i < 10) {
                    array[0] = h;
                    array[1] = hashes;
                    for (int i3 = size - 1; i3 >= 2; i3--) {
                        array[i3] = null;
                    }
                    h = array;
                    i++;
                }
            }
        }
    }

    public b() {
        this(0);
    }

    public b(int capacity) {
        if (capacity == 0) {
            this.f214b = f;
            this.f215c = g;
        } else {
            a(capacity);
        }
        this.d = 0;
    }

    public void clear() {
        int i2 = this.d;
        if (i2 != 0) {
            c(this.f214b, this.f215c, i2);
            this.f214b = f;
            this.f215c = g;
            this.d = 0;
        }
    }

    public void b(int minimumCapacity) {
        if (this.f214b.length < minimumCapacity) {
            int[] ohashes = this.f214b;
            Object[] oarray = this.f215c;
            a(minimumCapacity);
            int i2 = this.d;
            if (i2 > 0) {
                System.arraycopy(ohashes, 0, this.f214b, 0, i2);
                System.arraycopy(oarray, 0, this.f215c, 0, this.d);
            }
            c(ohashes, oarray, this.d);
        }
    }

    public boolean contains(Object key) {
        return e(key) >= 0;
    }

    public int e(Object key) {
        return key == null ? g() : f(key, key.hashCode());
    }

    public E i(int index) {
        return this.f215c[index];
    }

    public boolean isEmpty() {
        return this.d <= 0;
    }

    public boolean add(E value) {
        int index;
        int hash;
        if (value == null) {
            hash = 0;
            index = g();
        } else {
            hash = value.hashCode();
            index = f(value, hash);
        }
        if (index >= 0) {
            return false;
        }
        int index2 = index ^ -1;
        int i2 = this.d;
        if (i2 >= this.f214b.length) {
            int i3 = 4;
            if (i2 >= 8) {
                i3 = (i2 >> 1) + i2;
            } else if (i2 >= 4) {
                i3 = 8;
            }
            int n = i3;
            int[] ohashes = this.f214b;
            Object[] oarray = this.f215c;
            a(n);
            int[] iArr = this.f214b;
            if (iArr.length > 0) {
                System.arraycopy(ohashes, 0, iArr, 0, ohashes.length);
                System.arraycopy(oarray, 0, this.f215c, 0, oarray.length);
            }
            c(ohashes, oarray, this.d);
        }
        int i4 = this.d;
        if (index2 < i4) {
            int[] iArr2 = this.f214b;
            System.arraycopy(iArr2, index2, iArr2, index2 + 1, i4 - index2);
            Object[] objArr = this.f215c;
            System.arraycopy(objArr, index2, objArr, index2 + 1, this.d - index2);
        }
        this.f214b[index2] = hash;
        this.f215c[index2] = value;
        this.d++;
        return true;
    }

    public boolean remove(Object object) {
        int index = e(object);
        if (index < 0) {
            return false;
        }
        h(index);
        return true;
    }

    public E h(int index) {
        Object[] objArr = this.f215c;
        Object old = objArr[index];
        int i2 = this.d;
        if (i2 <= 1) {
            c(this.f214b, objArr, i2);
            this.f214b = f;
            this.f215c = g;
            this.d = 0;
        } else {
            int[] iArr = this.f214b;
            int n = 8;
            if (iArr.length <= 8 || i2 >= iArr.length / 3) {
                int i3 = this.d - 1;
                this.d = i3;
                if (index < i3) {
                    int[] iArr2 = this.f214b;
                    System.arraycopy(iArr2, index + 1, iArr2, index, i3 - index);
                    Object[] objArr2 = this.f215c;
                    System.arraycopy(objArr2, index + 1, objArr2, index, this.d - index);
                }
                this.f215c[this.d] = null;
            } else {
                if (i2 > 8) {
                    n = i2 + (i2 >> 1);
                }
                int[] ohashes = this.f214b;
                Object[] oarray = this.f215c;
                a(n);
                this.d--;
                if (index > 0) {
                    System.arraycopy(ohashes, 0, this.f214b, 0, index);
                    System.arraycopy(oarray, 0, this.f215c, 0, index);
                }
                int i4 = this.d;
                if (index < i4) {
                    System.arraycopy(ohashes, index + 1, this.f214b, index, i4 - index);
                    System.arraycopy(oarray, index + 1, this.f215c, index, this.d - index);
                }
            }
        }
        return old;
    }

    public int size() {
        return this.d;
    }

    public Object[] toArray() {
        int i2 = this.d;
        Object[] result = new Object[i2];
        System.arraycopy(this.f215c, 0, result, 0, i2);
        return result;
    }

    public <T> T[] toArray(T[] array) {
        if (array.length < this.d) {
            array = (Object[]) Array.newInstance(array.getClass().getComponentType(), this.d);
        }
        System.arraycopy(this.f215c, 0, array, 0, this.d);
        int length = array.length;
        int i2 = this.d;
        if (length > i2) {
            array[i2] = null;
        }
        return array;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof Set)) {
            return false;
        }
        Set<?> set = (Set) object;
        if (size() != set.size()) {
            return false;
        }
        int i2 = 0;
        while (i2 < this.d) {
            try {
                if (!set.contains(i(i2))) {
                    return false;
                }
                i2++;
            } catch (NullPointerException e2) {
                return false;
            } catch (ClassCastException e3) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        int[] hashes = this.f214b;
        int result = 0;
        int s = this.d;
        for (int i2 = 0; i2 < s; i2++) {
            result += hashes[i2];
        }
        return result;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder buffer = new StringBuilder(this.d * 14);
        buffer.append('{');
        for (int i2 = 0; i2 < this.d; i2++) {
            if (i2 > 0) {
                buffer.append(", ");
            }
            Object value = i(i2);
            if (value != this) {
                buffer.append(value);
            } else {
                buffer.append("(this Set)");
            }
        }
        buffer.append('}');
        return buffer.toString();
    }

    public class a extends h<E, E> {
        public a() {
        }

        public int d() {
            return b.this.d;
        }

        public Object b(int index, int offset) {
            return b.this.f215c[index];
        }

        public int e(Object key) {
            return b.this.e(key);
        }

        public int f(Object value) {
            return b.this.e(value);
        }

        public Map<E, E> c() {
            throw new UnsupportedOperationException("not a map");
        }

        public void g(E key, E e) {
            b.this.add(key);
        }

        public E i(int index, E e) {
            throw new UnsupportedOperationException("not a map");
        }

        public void h(int index) {
            b.this.h(index);
        }

        public void a() {
            b.this.clear();
        }
    }

    public final h<E, E> d() {
        if (this.e == null) {
            this.e = new a();
        }
        return this.e;
    }

    public Iterator<E> iterator() {
        return ((h.c) d().m()).iterator();
    }

    public boolean containsAll(Collection<?> collection) {
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public boolean addAll(Collection<? extends E> collection) {
        b(this.d + collection.size());
        boolean added = false;
        for (E value : collection) {
            added |= add(value);
        }
        return added;
    }

    public boolean removeAll(Collection<?> collection) {
        boolean removed = false;
        for (Object value : collection) {
            removed |= remove(value);
        }
        return removed;
    }

    public boolean retainAll(Collection<?> collection) {
        boolean removed = false;
        for (int i2 = this.d - 1; i2 >= 0; i2--) {
            if (!collection.contains(this.f215c[i2])) {
                h(i2);
                removed = true;
            }
        }
        return removed;
    }
}
