package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import b.a.f.b;
import b.a.f.d;
import b.a.f.e;

public class CardView extends FrameLayout {
    public static final int[] i = {16842801};
    public static final e j;

    /* renamed from: b  reason: collision with root package name */
    public boolean f656b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f657c;
    public int d;
    public int e;
    public final Rect f;
    public final Rect g;
    public final d h;

    static {
        if (Build.VERSION.SDK_INT >= 21) {
            j = new b();
        } else {
            j = new b.a.f.a();
        }
        j.l();
    }

    public CardView(Context context, AttributeSet attrs) {
        this(context, attrs, b.a.a.cardViewStyle);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CardView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        ColorStateList backgroundColor;
        float maxElevation;
        int i2;
        this.f = new Rect();
        this.g = new Rect();
        this.h = new a();
        TypedArray a2 = context.obtainStyledAttributes(attrs, b.a.e.CardView, defStyleAttr, b.a.d.CardView);
        if (a2.hasValue(b.a.e.CardView_cardBackgroundColor)) {
            backgroundColor = a2.getColorStateList(b.a.e.CardView_cardBackgroundColor);
        } else {
            TypedArray aa = getContext().obtainStyledAttributes(i);
            int themeColorBackground = aa.getColor(0, 0);
            aa.recycle();
            float[] hsv = new float[3];
            Color.colorToHSV(themeColorBackground, hsv);
            if (hsv[2] > 0.5f) {
                i2 = getResources().getColor(b.a.b.cardview_light_background);
            } else {
                i2 = getResources().getColor(b.a.b.cardview_dark_background);
            }
            backgroundColor = ColorStateList.valueOf(i2);
        }
        float radius = a2.getDimension(b.a.e.CardView_cardCornerRadius, 0.0f);
        float elevation = a2.getDimension(b.a.e.CardView_cardElevation, 0.0f);
        float maxElevation2 = a2.getDimension(b.a.e.CardView_cardMaxElevation, 0.0f);
        this.f656b = a2.getBoolean(b.a.e.CardView_cardUseCompatPadding, false);
        this.f657c = a2.getBoolean(b.a.e.CardView_cardPreventCornerOverlap, true);
        int defaultPadding = a2.getDimensionPixelSize(b.a.e.CardView_contentPadding, 0);
        this.f.left = a2.getDimensionPixelSize(b.a.e.CardView_contentPaddingLeft, defaultPadding);
        this.f.top = a2.getDimensionPixelSize(b.a.e.CardView_contentPaddingTop, defaultPadding);
        this.f.right = a2.getDimensionPixelSize(b.a.e.CardView_contentPaddingRight, defaultPadding);
        this.f.bottom = a2.getDimensionPixelSize(b.a.e.CardView_contentPaddingBottom, defaultPadding);
        if (elevation > maxElevation2) {
            maxElevation = elevation;
        } else {
            maxElevation = maxElevation2;
        }
        this.d = a2.getDimensionPixelSize(b.a.e.CardView_android_minWidth, 0);
        this.e = a2.getDimensionPixelSize(b.a.e.CardView_android_minHeight, 0);
        a2.recycle();
        j.m(this.h, context, backgroundColor, radius, elevation, maxElevation);
    }

    public void setPadding(int left, int top, int right, int bottom) {
    }

    public void setPaddingRelative(int start, int top, int end, int bottom) {
    }

    public boolean getUseCompatPadding() {
        return this.f656b;
    }

    public void setUseCompatPadding(boolean useCompatPadding) {
        if (this.f656b != useCompatPadding) {
            this.f656b = useCompatPadding;
            j.h(this.h);
        }
    }

    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (!(j instanceof b)) {
            int widthMode = View.MeasureSpec.getMode(widthMeasureSpec);
            if (widthMode == Integer.MIN_VALUE || widthMode == 1073741824) {
                widthMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil((double) j.g(this.h)), View.MeasureSpec.getSize(widthMeasureSpec)), widthMode);
            }
            int minWidth = View.MeasureSpec.getMode(heightMeasureSpec);
            if (minWidth == Integer.MIN_VALUE || minWidth == 1073741824) {
                heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil((double) j.e(this.h)), View.MeasureSpec.getSize(heightMeasureSpec)), minWidth);
            }
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            return;
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    public void setMinimumWidth(int minWidth) {
        this.d = minWidth;
        super.setMinimumWidth(minWidth);
    }

    public void setMinimumHeight(int minHeight) {
        this.e = minHeight;
        super.setMinimumHeight(minHeight);
    }

    public void setCardBackgroundColor(int color) {
        j.d(this.h, ColorStateList.valueOf(color));
    }

    public void setCardBackgroundColor(ColorStateList color) {
        j.d(this.h, color);
    }

    public ColorStateList getCardBackgroundColor() {
        return j.i(this.h);
    }

    public int getContentPaddingLeft() {
        return this.f.left;
    }

    public int getContentPaddingRight() {
        return this.f.right;
    }

    public int getContentPaddingTop() {
        return this.f.top;
    }

    public int getContentPaddingBottom() {
        return this.f.bottom;
    }

    public void setRadius(float radius) {
        j.n(this.h, radius);
    }

    public float getRadius() {
        return j.b(this.h);
    }

    public void setCardElevation(float elevation) {
        j.j(this.h, elevation);
    }

    public float getCardElevation() {
        return j.f(this.h);
    }

    public void setMaxCardElevation(float maxElevation) {
        j.k(this.h, maxElevation);
    }

    public float getMaxCardElevation() {
        return j.a(this.h);
    }

    public boolean getPreventCornerOverlap() {
        return this.f657c;
    }

    public void setPreventCornerOverlap(boolean preventCornerOverlap) {
        if (preventCornerOverlap != this.f657c) {
            this.f657c = preventCornerOverlap;
            j.c(this.h);
        }
    }

    public class a implements d {

        /* renamed from: a  reason: collision with root package name */
        public Drawable f658a;

        public a() {
        }

        public void e(Drawable drawable) {
            this.f658a = drawable;
            CardView.this.setBackgroundDrawable(drawable);
        }

        public boolean d() {
            return CardView.this.getUseCompatPadding();
        }

        public boolean c() {
            return CardView.this.getPreventCornerOverlap();
        }

        public void g(int left, int top, int right, int bottom) {
            CardView.this.g.set(left, top, right, bottom);
            CardView cardView = CardView.this;
            Rect rect = cardView.f;
            CardView.super.setPadding(rect.left + left, rect.top + top, rect.right + right, rect.bottom + bottom);
        }

        public void f(int width, int height) {
            CardView cardView = CardView.this;
            if (width > cardView.d) {
                CardView.super.setMinimumWidth(width);
            }
            CardView cardView2 = CardView.this;
            if (height > cardView2.e) {
                CardView.super.setMinimumHeight(height);
            }
        }

        public Drawable a() {
            return this.f658a;
        }

        public View b() {
            return CardView.this;
        }
    }
}
