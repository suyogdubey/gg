package a.b.d.f;

import a.b.c.i.k;
import a.b.d.b.f;
import android.app.SearchManager;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.TextAppearanceSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.WeakHashMap;

public class n0 extends k implements View.OnClickListener {
    public final SearchView m;
    public final SearchableInfo n;
    public final Context o;
    public final WeakHashMap<String, Drawable.ConstantState> p;
    public final int q;
    public boolean r = false;
    public int s = 1;
    public ColorStateList t;
    public int u = -1;
    public int v = -1;
    public int w = -1;
    public int x = -1;
    public int y = -1;
    public int z = -1;

    public n0(Context context, SearchView searchView, SearchableInfo searchable, WeakHashMap<String, Drawable.ConstantState> outsideDrawablesCache) {
        super(context, searchView.getSuggestionRowLayout(), (Cursor) null, true);
        SearchManager searchManager = (SearchManager) this.e.getSystemService("search");
        this.m = searchView;
        this.n = searchable;
        this.q = searchView.getSuggestionCommitIconResId();
        this.o = context;
        this.p = outsideDrawablesCache;
    }

    public void x(int refineWhat) {
        this.s = refineWhat;
    }

    public boolean hasStableIds() {
        return false;
    }

    public Cursor w(CharSequence constraint) {
        String query = constraint == null ? "" : constraint.toString();
        if (this.m.getVisibility() != 0 || this.m.getWindowVisibility() != 0) {
            return null;
        }
        try {
            Cursor cursor = u(this.n, query, 50);
            if (cursor != null) {
                cursor.getCount();
                return cursor;
            }
        } catch (RuntimeException e) {
            Log.w("SuggestionsAdapter", "Search suggestions query threw an exception.", e);
        }
        return null;
    }

    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        B(d());
    }

    public void notifyDataSetInvalidated() {
        super.notifyDataSetInvalidated();
        B(d());
    }

    public final void B(Cursor cursor) {
        Bundle extras = cursor != null ? cursor.getExtras() : null;
        if (extras != null && !extras.getBoolean("in_progress")) {
        }
    }

    public void b(Cursor c2) {
        if (this.r) {
            Log.w("SuggestionsAdapter", "Tried to change cursor after adapter was closed.");
            if (c2 != null) {
                c2.close();
                return;
            }
            return;
        }
        try {
            super.b(c2);
            if (c2 != null) {
                this.u = c2.getColumnIndex("suggest_text_1");
                this.v = c2.getColumnIndex("suggest_text_2");
                this.w = c2.getColumnIndex("suggest_text_2_url");
                this.x = c2.getColumnIndex("suggest_icon_1");
                this.y = c2.getColumnIndex("suggest_icon_2");
                this.z = c2.getColumnIndex("suggest_flags");
            }
        } catch (Exception e) {
            Log.e("SuggestionsAdapter", "error changing cursor and caching columns", e);
        }
    }

    public View g(Context context, Cursor cursor, ViewGroup parent) {
        View v2 = super.g(context, cursor, parent);
        v2.setTag(new a(v2));
        ((ImageView) v2.findViewById(f.edit_query)).setImageResource(this.q);
        return v2;
    }

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final TextView f497a;

        /* renamed from: b  reason: collision with root package name */
        public final TextView f498b;

        /* renamed from: c  reason: collision with root package name */
        public final ImageView f499c;
        public final ImageView d;
        public final ImageView e;

        public a(View v) {
            this.f497a = (TextView) v.findViewById(16908308);
            this.f498b = (TextView) v.findViewById(16908309);
            this.f499c = (ImageView) v.findViewById(16908295);
            this.d = (ImageView) v.findViewById(16908296);
            this.e = (ImageView) v.findViewById(f.edit_query);
        }
    }

    public void a(View view, Context context, Cursor cursor) {
        CharSequence text2;
        a views = (a) view.getTag();
        int flags = 0;
        int i = this.z;
        if (i != -1) {
            flags = cursor.getInt(i);
        }
        if (views.f497a != null) {
            z(views.f497a, v(cursor, this.u));
        }
        if (views.f498b != null) {
            CharSequence text22 = v(cursor, this.w);
            if (text22 != null) {
                text2 = k(text22);
            } else {
                text2 = v(cursor, this.v);
            }
            if (TextUtils.isEmpty(text2)) {
                TextView textView = views.f497a;
                if (textView != null) {
                    textView.setSingleLine(false);
                    views.f497a.setMaxLines(2);
                }
            } else {
                TextView textView2 = views.f497a;
                if (textView2 != null) {
                    textView2.setSingleLine(true);
                    views.f497a.setMaxLines(1);
                }
            }
            z(views.f498b, text2);
        }
        ImageView imageView = views.f499c;
        if (imageView != null) {
            y(imageView, s(cursor), 4);
        }
        ImageView imageView2 = views.d;
        if (imageView2 != null) {
            y(imageView2, t(cursor), 8);
        }
        int i2 = this.s;
        if (i2 == 2 || (i2 == 1 && (flags & 1) != 0)) {
            views.e.setVisibility(0);
            views.e.setTag(views.f497a.getText());
            views.e.setOnClickListener(this);
            return;
        }
        views.e.setVisibility(8);
    }

    public void onClick(View v2) {
        Object tag = v2.getTag();
        if (tag instanceof CharSequence) {
            this.m.S((CharSequence) tag);
        }
    }

    public final CharSequence k(CharSequence url) {
        if (this.t == null) {
            TypedValue colorValue = new TypedValue();
            this.e.getTheme().resolveAttribute(a.b.d.b.a.textColorSearchUrl, colorValue, true);
            this.t = this.e.getResources().getColorStateList(colorValue.resourceId);
        }
        SpannableString text = new SpannableString(url);
        text.setSpan(new TextAppearanceSpan((String) null, 0, 0, this.t, (ColorStateList) null), 0, url.length(), 33);
        return text;
    }

    public final void z(TextView v2, CharSequence text) {
        v2.setText(text);
        if (TextUtils.isEmpty(text)) {
            v2.setVisibility(8);
        } else {
            v2.setVisibility(0);
        }
    }

    public final Drawable s(Cursor cursor) {
        int i = this.x;
        if (i == -1) {
            return null;
        }
        Drawable drawable = r(cursor.getString(i));
        if (drawable != null) {
            return drawable;
        }
        return o();
    }

    public final Drawable t(Cursor cursor) {
        int i = this.y;
        if (i == -1) {
            return null;
        }
        return r(cursor.getString(i));
    }

    public final void y(ImageView v2, Drawable drawable, int nullVisibility) {
        v2.setImageDrawable(drawable);
        if (drawable == null) {
            v2.setVisibility(nullVisibility);
            return;
        }
        v2.setVisibility(0);
        drawable.setVisible(false, false);
        drawable.setVisible(true, false);
    }

    public CharSequence c(Cursor cursor) {
        String text1;
        String data;
        if (cursor == null) {
            return null;
        }
        String query = n(cursor, "suggest_intent_query");
        if (query != null) {
            return query;
        }
        if (this.n.shouldRewriteQueryFromData() && (data = n(cursor, "suggest_intent_data")) != null) {
            return data;
        }
        if (!this.n.shouldRewriteQueryFromText() || (text1 = n(cursor, "suggest_text_1")) == null) {
            return null;
        }
        return text1;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        try {
            return super.getView(position, convertView, parent);
        } catch (RuntimeException e) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e);
            View v2 = g(this.e, this.d, parent);
            ((a) v2.getTag()).f497a.setText(e.toString());
            return v2;
        }
    }

    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        try {
            return super.getDropDownView(position, convertView, parent);
        } catch (RuntimeException e) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e);
            View v2 = f(this.e, this.d, parent);
            if (v2 != null) {
                ((a) v2.getTag()).f497a.setText(e.toString());
            }
            return v2;
        }
    }

    public final Drawable r(String drawableId) {
        if (drawableId == null || drawableId.isEmpty() || "0".equals(drawableId)) {
            return null;
        }
        try {
            int resourceId = Integer.parseInt(drawableId);
            String drawableUri = "android.resource://" + this.o.getPackageName() + "/" + resourceId;
            Drawable drawable = j(drawableUri);
            if (drawable != null) {
                return drawable;
            }
            Drawable drawable2 = a.b.c.b.a.c(this.o, resourceId);
            A(drawableUri, drawable2);
            return drawable2;
        } catch (NumberFormatException e) {
            Drawable drawable3 = j(drawableId);
            if (drawable3 != null) {
                return drawable3;
            }
            Drawable drawable4 = p(Uri.parse(drawableId));
            A(drawableId, drawable4);
            return drawable4;
        } catch (Resources.NotFoundException e2) {
            Log.w("SuggestionsAdapter", "Icon resource not found: " + drawableId);
            return null;
        }
    }

    public final Drawable p(Uri uri) {
        InputStream stream;
        try {
            if ("android.resource".equals(uri.getScheme())) {
                return q(uri);
            }
            stream = this.o.getContentResolver().openInputStream(uri);
            if (stream != null) {
                Drawable createFromStream = Drawable.createFromStream(stream, (String) null);
                try {
                    stream.close();
                } catch (IOException ex) {
                    Log.e("SuggestionsAdapter", "Error closing icon stream for " + uri, ex);
                }
                return createFromStream;
            }
            throw new FileNotFoundException("Failed to open " + uri);
        } catch (Resources.NotFoundException e) {
            throw new FileNotFoundException("Resource does not exist: " + uri);
        } catch (FileNotFoundException fnfe) {
            Log.w("SuggestionsAdapter", "Icon not found: " + uri + ", " + fnfe.getMessage());
            return null;
        } catch (Throwable th) {
            try {
                stream.close();
            } catch (IOException ex2) {
                Log.e("SuggestionsAdapter", "Error closing icon stream for " + uri, ex2);
            }
            throw th;
        }
    }

    public final Drawable j(String resourceUri) {
        Drawable.ConstantState cached = this.p.get(resourceUri);
        if (cached == null) {
            return null;
        }
        return cached.newDrawable();
    }

    public final void A(String resourceUri, Drawable drawable) {
        if (drawable != null) {
            this.p.put(resourceUri, drawable.getConstantState());
        }
    }

    public final Drawable o() {
        Drawable drawable = m(this.n.getSearchActivity());
        if (drawable != null) {
            return drawable;
        }
        return this.e.getPackageManager().getDefaultActivityIcon();
    }

    public final Drawable m(ComponentName component) {
        String componentIconKey = component.flattenToShortString();
        Drawable.ConstantState toCache = null;
        if (this.p.containsKey(componentIconKey)) {
            Drawable.ConstantState cached = this.p.get(componentIconKey);
            if (cached == null) {
                return null;
            }
            return cached.newDrawable(this.o.getResources());
        }
        Drawable drawable = l(component);
        if (drawable != null) {
            toCache = drawable.getConstantState();
        }
        this.p.put(componentIconKey, toCache);
        return drawable;
    }

    public final Drawable l(ComponentName component) {
        PackageManager pm = this.e.getPackageManager();
        try {
            ActivityInfo activityInfo = pm.getActivityInfo(component, 128);
            int iconId = activityInfo.getIconResource();
            if (iconId == 0) {
                return null;
            }
            Drawable drawable = pm.getDrawable(component.getPackageName(), iconId, activityInfo.applicationInfo);
            if (drawable != null) {
                return drawable;
            }
            Log.w("SuggestionsAdapter", "Invalid icon resource " + iconId + " for " + component.flattenToShortString());
            return null;
        } catch (PackageManager.NameNotFoundException ex) {
            Log.w("SuggestionsAdapter", ex.toString());
            return null;
        }
    }

    public static String n(Cursor cursor, String columnName) {
        return v(cursor, cursor.getColumnIndex(columnName));
    }

    public static String v(Cursor cursor, int col) {
        if (col == -1) {
            return null;
        }
        try {
            return cursor.getString(col);
        } catch (Exception e) {
            Log.e("SuggestionsAdapter", "unexpected error retrieving valid column from cursor, did the remote process die?", e);
            return null;
        }
    }

    public Drawable q(Uri uri) {
        int id;
        String authority = uri.getAuthority();
        if (!TextUtils.isEmpty(authority)) {
            try {
                Resources r2 = this.e.getPackageManager().getResourcesForApplication(authority);
                List<String> path = uri.getPathSegments();
                if (path != null) {
                    int len = path.size();
                    if (len == 1) {
                        try {
                            id = Integer.parseInt(path.get(0));
                        } catch (NumberFormatException e) {
                            throw new FileNotFoundException("Single path segment is not a resource ID: " + uri);
                        }
                    } else if (len == 2) {
                        id = r2.getIdentifier(path.get(1), path.get(0), authority);
                    } else {
                        throw new FileNotFoundException("More than two path segments: " + uri);
                    }
                    if (id != 0) {
                        return r2.getDrawable(id);
                    }
                    throw new FileNotFoundException("No resource found for: " + uri);
                }
                throw new FileNotFoundException("No path: " + uri);
            } catch (PackageManager.NameNotFoundException e2) {
                throw new FileNotFoundException("No package found for authority: " + uri);
            }
        } else {
            throw new FileNotFoundException("No authority: " + uri);
        }
    }

    public Cursor u(SearchableInfo searchable, String query, int limit) {
        String authority;
        String[] selArgs;
        if (searchable == null || (authority = searchable.getSuggestAuthority()) == null) {
            return null;
        }
        Uri.Builder uriBuilder = new Uri.Builder().scheme("content").authority(authority).query("").fragment("");
        String contentPath = searchable.getSuggestPath();
        if (contentPath != null) {
            uriBuilder.appendEncodedPath(contentPath);
        }
        uriBuilder.appendPath("search_suggest_query");
        String selection = searchable.getSuggestSelection();
        if (selection != null) {
            selArgs = new String[]{query};
        } else {
            uriBuilder.appendPath(query);
            selArgs = null;
        }
        if (limit > 0) {
            uriBuilder.appendQueryParameter("limit", String.valueOf(limit));
        }
        return this.e.getContentResolver().query(uriBuilder.build(), (String[]) null, selection, selArgs, (String) null);
    }
}
