package com.gjjiitld;

import a.b.d.a.c;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends c implements View.OnClickListener {
    public LinearLayout n;
    public LinearLayout o;

    public final void D(Activity activity) {
        if (Build.VERSION.SDK_INT >= 23) {
            activity.getWindow().setStatusBarColor(Color.parseColor("#0F0F1B"));
            activity.getWindow().setNavigationBarColor(Color.parseColor("#0F0F1B"));
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        D(this);
        requestWindowFeature(1);
        t().f();
        setContentView((int) R.layout.activity_main);
        if (Build.VERSION.SDK_INT >= 23) {
            B();
        }
        if (!getIntent().getStringExtra("CURRVERSION").equals("1.3")) {
            AlertDialog.Builder ab = new AlertDialog.Builder(this);
            ab.setTitle("A new version is available.");
            ab.setMessage("Current version: 1.3\nNew version: " + getIntent().getStringExtra("CURRVERSION"));
            ab.setPositiveButton("Download", new a());
            ab.setNegativeButton("Exit", new b());
            ab.setCancelable(false);
            ab.show();
            return;
        }
        this.n = (LinearLayout) findViewById(R.id.button1);
        this.o = (LinearLayout) findViewById(R.id.button2);
        this.n.setOnClickListener(this);
        this.o.setOnClickListener(this);
        GradientDrawable gradientdrawable = new GradientDrawable();
        gradientdrawable.setCornerRadius(10.0f);
        gradientdrawable.setColor(Color.parseColor("#FF1500"));
        gradientdrawable.setStroke(2, Color.parseColor("#FF1500"));
        findViewById(R.id.button2).setBackground(gradientdrawable);
        GradientDrawable gradientdrawable2 = new GradientDrawable();
        gradientdrawable2.setCornerRadius(10.0f);
        gradientdrawable2.setColor(Color.parseColor("#0091EA"));
        gradientdrawable2.setStroke(2, Color.parseColor("#0091EA"));
        findViewById(R.id.button1).setBackground(gradientdrawable2);
    }

    public class a implements DialogInterface.OnClickListener {
        public a() {
        }

        public void onClick(DialogInterface dialog, int which) {
            Intent i = new Intent("android.intent.action.VIEW");
            i.setData(Uri.parse(MainActivity.this.getIntent().getStringExtra("DOWNLINK")));
            MainActivity.this.startActivity(i);
        }
    }

    public class b implements DialogInterface.OnClickListener {
        public b() {
        }

        public void onClick(DialogInterface dialog, int which) {
            MainActivity.this.finish();
        }
    }

    @SuppressLint({"NonConstantResourceId"})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button1 /*2131230756*/:
                F();
                return;
            case R.id.button2 /*2131230757*/:
                stopService(new Intent(this, Floater.class));
                return;
            default:
                return;
        }
    }

    public void B() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Enable Floating Permission ", 1).show();
            startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 0);
        }
    }

    public final boolean C() {
        ActivityManager manager = (ActivityManager) getSystemService("activity");
        if (manager == null) {
            return false;
        }
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (Floater.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void F() {
        if (Build.VERSION.SDK_INT < 23) {
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 123);
            return;
        }
        E();
    }

    public final void E() {
        if (!C()) {
            startService(new Intent(this, Floater.class));
        } else {
            Toast.makeText(this, "Service Already Running!", 0).show();
        }
    }
}
