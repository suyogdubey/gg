package a.b.c.a;

import a.b.c.a.e;
import java.io.PrintWriter;
import java.util.ArrayList;

public final class c extends o {

    /* renamed from: a  reason: collision with root package name */
    public final k f55a;

    /* renamed from: b  reason: collision with root package name */
    public ArrayList<a> f56b = new ArrayList<>();

    /* renamed from: c  reason: collision with root package name */
    public int f57c;
    public int d;
    public int e;
    public int f;
    public int g;
    public int h;
    public boolean i;
    public String j;
    public int k = -1;
    public int l;
    public CharSequence m;
    public int n;
    public CharSequence o;
    public ArrayList<String> p;
    public ArrayList<String> q;
    public boolean r = false;
    public ArrayList<Runnable> s;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public int f58a;

        /* renamed from: b  reason: collision with root package name */
        public e f59b;

        /* renamed from: c  reason: collision with root package name */
        public int f60c;
        public int d;
        public int e;
        public int f;

        public a() {
        }

        public a(int cmd, e fragment) {
            this.f58a = cmd;
            this.f59b = fragment;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.k >= 0) {
            sb.append(" #");
            sb.append(this.k);
        }
        if (this.j != null) {
            sb.append(" ");
            sb.append(this.j);
        }
        sb.append("}");
        return sb.toString();
    }

    public void c(String prefix, PrintWriter writer) {
        d(prefix, writer, true);
    }

    public void d(String prefix, PrintWriter writer, boolean full) {
        String cmdStr;
        if (full) {
            writer.print(prefix);
            writer.print("mName=");
            writer.print(this.j);
            writer.print(" mIndex=");
            writer.print(this.k);
            writer.print(" mCommitted=");
            writer.println(false);
            if (this.g != 0) {
                writer.print(prefix);
                writer.print("mTransition=#");
                writer.print(Integer.toHexString(this.g));
                writer.print(" mTransitionStyle=#");
                writer.println(Integer.toHexString(this.h));
            }
            if (!(this.f57c == 0 && this.d == 0)) {
                writer.print(prefix);
                writer.print("mEnterAnim=#");
                writer.print(Integer.toHexString(this.f57c));
                writer.print(" mExitAnim=#");
                writer.println(Integer.toHexString(this.d));
            }
            if (!(this.e == 0 && this.f == 0)) {
                writer.print(prefix);
                writer.print("mPopEnterAnim=#");
                writer.print(Integer.toHexString(this.e));
                writer.print(" mPopExitAnim=#");
                writer.println(Integer.toHexString(this.f));
            }
            if (!(this.l == 0 && this.m == null)) {
                writer.print(prefix);
                writer.print("mBreadCrumbTitleRes=#");
                writer.print(Integer.toHexString(this.l));
                writer.print(" mBreadCrumbTitleText=");
                writer.println(this.m);
            }
            if (!(this.n == 0 && this.o == null)) {
                writer.print(prefix);
                writer.print("mBreadCrumbShortTitleRes=#");
                writer.print(Integer.toHexString(this.n));
                writer.print(" mBreadCrumbShortTitleText=");
                writer.println(this.o);
            }
        }
        if (!this.f56b.isEmpty()) {
            writer.print(prefix);
            writer.println("Operations:");
            String str = prefix + "    ";
            int numOps = this.f56b.size();
            for (int opNum = 0; opNum < numOps; opNum++) {
                a op = this.f56b.get(opNum);
                switch (op.f58a) {
                    case 0:
                        cmdStr = "NULL";
                        break;
                    case 1:
                        cmdStr = "ADD";
                        break;
                    case 2:
                        cmdStr = "REPLACE";
                        break;
                    case 3:
                        cmdStr = "REMOVE";
                        break;
                    case 4:
                        cmdStr = "HIDE";
                        break;
                    case 5:
                        cmdStr = "SHOW";
                        break;
                    case 6:
                        cmdStr = "DETACH";
                        break;
                    case 7:
                        cmdStr = "ATTACH";
                        break;
                    case 8:
                        cmdStr = "SET_PRIMARY_NAV";
                        break;
                    case 9:
                        cmdStr = "UNSET_PRIMARY_NAV";
                        break;
                    default:
                        cmdStr = "cmd=" + op.f58a;
                        break;
                }
                writer.print(prefix);
                writer.print("  Op #");
                writer.print(opNum);
                writer.print(": ");
                writer.print(cmdStr);
                writer.print(" ");
                writer.println(op.f59b);
                if (full) {
                    if (!(op.f60c == 0 && op.d == 0)) {
                        writer.print(prefix);
                        writer.print("enterAnim=#");
                        writer.print(Integer.toHexString(op.f60c));
                        writer.print(" exitAnim=#");
                        writer.println(Integer.toHexString(op.d));
                    }
                    if (op.e != 0 || op.f != 0) {
                        writer.print(prefix);
                        writer.print("popEnterAnim=#");
                        writer.print(Integer.toHexString(op.e));
                        writer.print(" popExitAnim=#");
                        writer.println(Integer.toHexString(op.f));
                    }
                }
            }
        }
    }

    public c(k manager) {
        this.f55a = manager;
    }

    public void a(a op) {
        this.f56b.add(op);
        op.f60c = this.f57c;
        op.d = this.d;
        op.e = this.e;
        op.f = this.f;
    }

    public void b(int amt) {
        if (this.i) {
            boolean z = k.C;
            int numOps = this.f56b.size();
            for (int opNum = 0; opNum < numOps; opNum++) {
                e eVar = this.f56b.get(opNum).f59b;
                if (eVar != null) {
                    eVar.r += amt;
                    boolean z2 = k.C;
                }
            }
        }
    }

    public void m() {
        ArrayList<Runnable> arrayList = this.s;
        if (arrayList != null) {
            int N = arrayList.size();
            for (int i2 = 0; i2 < N; i2++) {
                this.s.get(i2).run();
            }
            this.s = null;
        }
    }

    public boolean i(int containerId) {
        int numOps = this.f56b.size();
        int opNum = 0;
        while (true) {
            int fragContainer = 0;
            if (opNum >= numOps) {
                return false;
            }
            e eVar = this.f56b.get(opNum).f59b;
            if (eVar != null) {
                fragContainer = eVar.z;
            }
            if (fragContainer != 0 && fragContainer == containerId) {
                return true;
            }
            opNum++;
        }
    }

    public boolean j(ArrayList<c> records, int startIndex, int endIndex) {
        if (endIndex == startIndex) {
            return false;
        }
        int numOps = this.f56b.size();
        int lastContainer = -1;
        for (int opNum = 0; opNum < numOps; opNum++) {
            e eVar = this.f56b.get(opNum).f59b;
            int container = eVar != null ? eVar.z : 0;
            if (!(container == 0 || container == lastContainer)) {
                lastContainer = container;
                for (int i2 = startIndex; i2 < endIndex; i2++) {
                    c record = records.get(i2);
                    int numThoseOps = record.f56b.size();
                    for (int thoseOpIndex = 0; thoseOpIndex < numThoseOps; thoseOpIndex++) {
                        e eVar2 = record.f56b.get(thoseOpIndex).f59b;
                        if ((eVar2 != null ? eVar2.z : 0) == container) {
                            return true;
                        }
                    }
                }
                continue;
            }
        }
        return false;
    }

    public void e() {
        int numOps = this.f56b.size();
        for (int opNum = 0; opNum < numOps; opNum++) {
            a op = this.f56b.get(opNum);
            e f2 = op.f59b;
            if (f2 != null) {
                f2.T0(this.g, this.h);
            }
            switch (op.f58a) {
                case 1:
                    f2.S0(op.f60c);
                    this.f55a.f(f2, false);
                    break;
                case 3:
                    f2.S0(op.d);
                    this.f55a.I0(f2);
                    break;
                case 4:
                    f2.S0(op.d);
                    this.f55a.o0(f2);
                    break;
                case 5:
                    f2.S0(op.f60c);
                    this.f55a.Y0(f2);
                    break;
                case 6:
                    f2.S0(op.d);
                    this.f55a.o(f2);
                    break;
                case 7:
                    f2.S0(op.f60c);
                    this.f55a.i(f2);
                    break;
                case 8:
                    this.f55a.V0(f2);
                    break;
                case 9:
                    this.f55a.V0((e) null);
                    break;
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + op.f58a);
            }
            if (!(this.r || op.f58a == 1 || f2 == null)) {
                this.f55a.y0(f2);
            }
        }
        if (this.r == 0) {
            k kVar = this.f55a;
            kVar.z0(kVar.k, true);
        }
    }

    public void f(boolean moveToState) {
        for (int opNum = this.f56b.size() - 1; opNum >= 0; opNum--) {
            a op = this.f56b.get(opNum);
            e f2 = op.f59b;
            if (f2 != null) {
                f2.T0(k.N0(this.g), this.h);
            }
            switch (op.f58a) {
                case 1:
                    f2.S0(op.f);
                    this.f55a.I0(f2);
                    break;
                case 3:
                    f2.S0(op.e);
                    this.f55a.f(f2, false);
                    break;
                case 4:
                    f2.S0(op.e);
                    this.f55a.Y0(f2);
                    break;
                case 5:
                    f2.S0(op.f);
                    this.f55a.o0(f2);
                    break;
                case 6:
                    f2.S0(op.e);
                    this.f55a.i(f2);
                    break;
                case 7:
                    f2.S0(op.f);
                    this.f55a.o(f2);
                    break;
                case 8:
                    this.f55a.V0((e) null);
                    break;
                case 9:
                    this.f55a.V0(f2);
                    break;
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + op.f58a);
            }
            if (!(this.r || op.f58a == 3 || f2 == null)) {
                this.f55a.y0(f2);
            }
        }
        if (this.r == 0 && moveToState) {
            k kVar = this.f55a;
            kVar.z0(kVar.k, true);
        }
    }

    public e g(ArrayList<e> added, e oldPrimaryNav) {
        int opNum = 0;
        while (opNum < this.f56b.size()) {
            a op = this.f56b.get(opNum);
            int i2 = op.f58a;
            if (i2 != 1) {
                if (i2 == 2) {
                    e f2 = op.f59b;
                    int containerId = f2.z;
                    boolean alreadyAdded = false;
                    for (int i3 = added.size() - 1; i3 >= 0; i3--) {
                        e old = added.get(i3);
                        if (old.z == containerId) {
                            if (old == f2) {
                                alreadyAdded = true;
                            } else {
                                if (old == oldPrimaryNav) {
                                    this.f56b.add(opNum, new a(9, old));
                                    opNum++;
                                    oldPrimaryNav = null;
                                }
                                a removeOp = new a(3, old);
                                removeOp.f60c = op.f60c;
                                removeOp.e = op.e;
                                removeOp.d = op.d;
                                removeOp.f = op.f;
                                this.f56b.add(opNum, removeOp);
                                added.remove(old);
                                opNum++;
                            }
                        }
                    }
                    if (alreadyAdded) {
                        this.f56b.remove(opNum);
                        opNum--;
                    } else {
                        op.f58a = 1;
                        added.add(f2);
                    }
                } else if (i2 == 3 || i2 == 6) {
                    added.remove(op.f59b);
                    e eVar = op.f59b;
                    if (eVar == oldPrimaryNav) {
                        this.f56b.add(opNum, new a(9, eVar));
                        opNum++;
                        oldPrimaryNav = null;
                    }
                } else if (i2 != 7) {
                    if (i2 == 8) {
                        this.f56b.add(opNum, new a(9, oldPrimaryNav));
                        opNum++;
                        oldPrimaryNav = op.f59b;
                    }
                }
                opNum++;
            }
            added.add(op.f59b);
            opNum++;
        }
        return oldPrimaryNav;
    }

    public e o(ArrayList<e> added, e oldPrimaryNav) {
        for (int opNum = 0; opNum < this.f56b.size(); opNum++) {
            a op = this.f56b.get(opNum);
            int i2 = op.f58a;
            if (i2 != 1) {
                if (i2 != 3) {
                    switch (i2) {
                        case 6:
                            break;
                        case 7:
                            break;
                        case 8:
                            oldPrimaryNav = null;
                            break;
                        case 9:
                            oldPrimaryNav = op.f59b;
                            break;
                    }
                }
                added.add(op.f59b);
            }
            added.remove(op.f59b);
        }
        return oldPrimaryNav;
    }

    public boolean l() {
        for (int opNum = 0; opNum < this.f56b.size(); opNum++) {
            if (k(this.f56b.get(opNum))) {
                return true;
            }
        }
        return false;
    }

    public void n(e.f listener) {
        for (int opNum = 0; opNum < this.f56b.size(); opNum++) {
            a op = this.f56b.get(opNum);
            if (k(op)) {
                op.f59b.U0(listener);
            }
        }
    }

    public static boolean k(a op) {
        e fragment = op.f59b;
        return fragment != null && fragment.l && fragment.J != null && !fragment.C && !fragment.B && fragment.I();
    }

    public String h() {
        return this.j;
    }
}
