package a.b.c.i;

import android.os.Build;

public interface b {

    /* renamed from: a  reason: collision with root package name */
    public static final boolean f282a = (Build.VERSION.SDK_INT >= 27);
}
