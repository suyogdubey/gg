package a.b.c.c;

import a.b.c.b.c.c;
import a.b.c.e.b;
import a.b.c.g.k;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.support.v4.util.SimpleArrayMap;
import android.util.Log;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.List;

public class e extends h {

    /* renamed from: a  reason: collision with root package name */
    public static final Class f165a;

    /* renamed from: b  reason: collision with root package name */
    public static final Constructor f166b;

    /* renamed from: c  reason: collision with root package name */
    public static final Method f167c;
    public static final Method d;

    static {
        Method addFontMethod;
        Constructor fontFamilyCtor;
        Class fontFamilyClass;
        Method createFromFamiliesWithDefaultMethod;
        try {
            fontFamilyClass = Class.forName("android.graphics.FontFamily");
            try {
                fontFamilyCtor = fontFamilyClass.getConstructor(new Class[0]);
                try {
                    addFontMethod = fontFamilyClass.getMethod("addFontWeightStyle", new Class[]{ByteBuffer.class, Integer.TYPE, List.class, Integer.TYPE, Boolean.TYPE});
                    try {
                        createFromFamiliesWithDefaultMethod = Typeface.class.getMethod("createFromFamiliesWithDefault", new Class[]{Array.newInstance(fontFamilyClass, 1).getClass()});
                    } catch (ClassNotFoundException | NoSuchMethodException e) {
                        e = e;
                        Log.e("TypefaceCompatApi24Impl", e.getClass().getName(), e);
                        fontFamilyClass = null;
                        fontFamilyCtor = null;
                        addFontMethod = null;
                        createFromFamiliesWithDefaultMethod = null;
                        f166b = fontFamilyCtor;
                        f165a = fontFamilyClass;
                        f167c = addFontMethod;
                        d = createFromFamiliesWithDefaultMethod;
                    }
                } catch (ClassNotFoundException | NoSuchMethodException e2) {
                    e = e2;
                    Log.e("TypefaceCompatApi24Impl", e.getClass().getName(), e);
                    fontFamilyClass = null;
                    fontFamilyCtor = null;
                    addFontMethod = null;
                    createFromFamiliesWithDefaultMethod = null;
                    f166b = fontFamilyCtor;
                    f165a = fontFamilyClass;
                    f167c = addFontMethod;
                    d = createFromFamiliesWithDefaultMethod;
                }
            } catch (ClassNotFoundException | NoSuchMethodException e3) {
                e = e3;
                Log.e("TypefaceCompatApi24Impl", e.getClass().getName(), e);
                fontFamilyClass = null;
                fontFamilyCtor = null;
                addFontMethod = null;
                createFromFamiliesWithDefaultMethod = null;
                f166b = fontFamilyCtor;
                f165a = fontFamilyClass;
                f167c = addFontMethod;
                d = createFromFamiliesWithDefaultMethod;
            }
        } catch (ClassNotFoundException | NoSuchMethodException e4) {
            e = e4;
            Log.e("TypefaceCompatApi24Impl", e.getClass().getName(), e);
            fontFamilyClass = null;
            fontFamilyCtor = null;
            addFontMethod = null;
            createFromFamiliesWithDefaultMethod = null;
            f166b = fontFamilyCtor;
            f165a = fontFamilyClass;
            f167c = addFontMethod;
            d = createFromFamiliesWithDefaultMethod;
        }
        f166b = fontFamilyCtor;
        f165a = fontFamilyClass;
        f167c = addFontMethod;
        d = createFromFamiliesWithDefaultMethod;
    }

    public static boolean j() {
        if (f167c == null) {
            Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
        }
        return f167c != null;
    }

    public static Object k() {
        try {
            return f166b.newInstance(new Object[0]);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean h(Object family, ByteBuffer buffer, int ttcIndex, int weight, boolean style) {
        try {
            return ((Boolean) f167c.invoke(family, new Object[]{buffer, Integer.valueOf(ttcIndex), null, Integer.valueOf(weight), Boolean.valueOf(style)})).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    public static Typeface i(Object family) {
        try {
            Object familyArray = Array.newInstance(f165a, 1);
            Array.set(familyArray, 0, family);
            return (Typeface) d.invoke((Object) null, new Object[]{familyArray});
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    public Typeface b(Context context, CancellationSignal cancellationSignal, b.f[] fonts, int style) {
        Object family = k();
        SimpleArrayMap<Uri, ByteBuffer> bufferCache = new k<>();
        for (b.f font : fonts) {
            Uri uri = font.c();
            ByteBuffer buffer = (ByteBuffer) bufferCache.get(uri);
            if (buffer == null) {
                buffer = i.f(context, cancellationSignal, uri);
                bufferCache.put(uri, buffer);
            }
            if (!h(family, buffer, font.b(), font.d(), font.e())) {
                return null;
            }
        }
        return Typeface.create(i(family), style);
    }

    public Typeface a(Context context, c.b entry, Resources resources, int style) {
        Object family = k();
        for (c.C0007c e : entry.a()) {
            ByteBuffer buffer = i.b(context, resources, e.b());
            if (buffer == null || !h(family, buffer, e.c(), e.e(), e.f())) {
                return null;
            }
        }
        return i(family);
    }
}
