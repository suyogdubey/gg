package a.b.c.h;

import android.os.Parcel;
import android.os.Parcelable;

public abstract class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new b();

    /* renamed from: c  reason: collision with root package name */
    public static final a f240c = new C0015a();

    /* renamed from: b  reason: collision with root package name */
    public final Parcelable f241b;

    /* renamed from: a.b.c.h.a$a  reason: collision with other inner class name */
    public static class C0015a extends a {
        public C0015a() {
            super((C0015a) null);
        }
    }

    public /* synthetic */ a(C0015a x0) {
        this();
    }

    public a() {
        this.f241b = null;
    }

    public a(Parcelable superState) {
        if (superState != null) {
            this.f241b = superState != f240c ? superState : null;
            return;
        }
        throw new IllegalArgumentException("superState must not be null");
    }

    public a(Parcel source, ClassLoader loader) {
        Parcelable superState = source.readParcelable(loader);
        this.f241b = superState != null ? superState : f240c;
    }

    public final Parcelable a() {
        return this.f241b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.f241b, flags);
    }

    public static class b implements Parcelable.ClassLoaderCreator<a> {
        /* renamed from: b */
        public a createFromParcel(Parcel in, ClassLoader loader) {
            if (in.readParcelable(loader) == null) {
                return a.f240c;
            }
            throw new IllegalStateException("superState must be null");
        }

        /* renamed from: a */
        public a createFromParcel(Parcel in) {
            return createFromParcel(in, (ClassLoader) null);
        }

        /* renamed from: c */
        public a[] newArray(int size) {
            return new a[size];
        }
    }
}
