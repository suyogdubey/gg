package android.support.v4.app;

import android.app.Activity;
import android.app.AppComponentFactory;
import android.app.Application;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.Intent;

public class CoreComponentFactory extends AppComponentFactory {

    public interface a {
        Object a();
    }

    public Activity instantiateActivity(ClassLoader cl, String className, Intent intent) {
        return (Activity) a(super.instantiateActivity(cl, className, intent));
    }

    public Application instantiateApplication(ClassLoader cl, String className) {
        return (Application) a(super.instantiateApplication(cl, className));
    }

    public BroadcastReceiver instantiateReceiver(ClassLoader cl, String className, Intent intent) {
        return (BroadcastReceiver) a(super.instantiateReceiver(cl, className, intent));
    }

    public ContentProvider instantiateProvider(ClassLoader cl, String className) {
        return (ContentProvider) a(super.instantiateProvider(cl, className));
    }

    public Service instantiateService(ClassLoader cl, String className, Intent intent) {
        return (Service) a(super.instantiateService(cl, className, intent));
    }

    public static <T> T a(T obj) {
        T wrapper;
        if (!(obj instanceof a) || (wrapper = ((a) obj).a()) == null) {
            return obj;
        }
        return wrapper;
    }
}
