package a.b.d.f;

import a.b.d.b.j;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.PopupWindow;

public class q extends PopupWindow {

    /* renamed from: b  reason: collision with root package name */
    public static final boolean f507b = (Build.VERSION.SDK_INT < 21);

    /* renamed from: a  reason: collision with root package name */
    public boolean f508a;

    public q(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        a(context, attrs, defStyleAttr, defStyleRes);
    }

    public final void a(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        t0 a2 = t0.t(context, attrs, j.PopupWindow, defStyleAttr, defStyleRes);
        if (a2.q(j.PopupWindow_overlapAnchor)) {
            b(a2.a(j.PopupWindow_overlapAnchor, false));
        }
        setBackgroundDrawable(a2.f(j.PopupWindow_android_popupBackground));
        a2.u();
    }

    public void showAsDropDown(View anchor, int xoff, int yoff) {
        if (f507b && this.f508a) {
            yoff -= anchor.getHeight();
        }
        super.showAsDropDown(anchor, xoff, yoff);
    }

    public void showAsDropDown(View anchor, int xoff, int yoff, int gravity) {
        if (f507b && this.f508a) {
            yoff -= anchor.getHeight();
        }
        super.showAsDropDown(anchor, xoff, yoff, gravity);
    }

    public void update(View anchor, int xoff, int yoff, int width, int height) {
        if (f507b && this.f508a) {
            yoff -= anchor.getHeight();
        }
        super.update(anchor, xoff, yoff, width, height);
    }

    public final void b(boolean overlapAnchor) {
        if (f507b) {
            this.f508a = overlapAnchor;
        } else {
            a.b.c.i.j.a(this, overlapAnchor);
        }
    }
}
