package a.b.d.f;

public interface e0 {

    public interface a {
    }

    void setOnFitSystemWindowsListener(a aVar);
}
