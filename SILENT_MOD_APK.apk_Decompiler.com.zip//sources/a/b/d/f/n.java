package a.b.d.f;

import a.b.c.i.g;
import a.b.d.b.j;
import a.b.d.c.a.a;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;

public class n {

    /* renamed from: a  reason: collision with root package name */
    public final ImageView f494a;

    /* renamed from: b  reason: collision with root package name */
    public r0 f495b;

    /* renamed from: c  reason: collision with root package name */
    public r0 f496c;

    public n(ImageView view) {
        this.f494a = view;
    }

    public void f(AttributeSet attrs, int defStyleAttr) {
        int id;
        t0 a2 = t0.t(this.f494a.getContext(), attrs, j.AppCompatImageView, defStyleAttr, 0);
        try {
            Drawable drawable = this.f494a.getDrawable();
            if (!(drawable != null || (id = a2.m(j.AppCompatImageView_srcCompat, -1)) == -1 || (drawable = a.d(this.f494a.getContext(), id)) == null)) {
                this.f494a.setImageDrawable(drawable);
            }
            if (drawable != null) {
                c0.b(drawable);
            }
            if (a2.q(j.AppCompatImageView_tint)) {
                g.c(this.f494a, a2.c(j.AppCompatImageView_tint));
            }
            if (a2.q(j.AppCompatImageView_tintMode)) {
                g.d(this.f494a, c0.d(a2.j(j.AppCompatImageView_tintMode, -1), (PorterDuff.Mode) null));
            }
        } finally {
            a2.u();
        }
    }

    public void g(int resId) {
        if (resId != 0) {
            Drawable d = a.d(this.f494a.getContext(), resId);
            if (d != null) {
                c0.b(d);
            }
            this.f494a.setImageDrawable(d);
        } else {
            this.f494a.setImageDrawable((Drawable) null);
        }
        b();
    }

    public boolean e() {
        Drawable background = this.f494a.getBackground();
        if (Build.VERSION.SDK_INT < 21 || !(background instanceof RippleDrawable)) {
            return true;
        }
        return false;
    }

    public void h(ColorStateList tint) {
        if (this.f495b == null) {
            this.f495b = new r0();
        }
        r0 r0Var = this.f495b;
        r0Var.f515a = tint;
        r0Var.d = true;
        b();
    }

    public ColorStateList c() {
        r0 r0Var = this.f495b;
        if (r0Var != null) {
            return r0Var.f515a;
        }
        return null;
    }

    public void i(PorterDuff.Mode tintMode) {
        if (this.f495b == null) {
            this.f495b = new r0();
        }
        r0 r0Var = this.f495b;
        r0Var.f516b = tintMode;
        r0Var.f517c = true;
        b();
    }

    public PorterDuff.Mode d() {
        r0 r0Var = this.f495b;
        if (r0Var != null) {
            return r0Var.f516b;
        }
        return null;
    }

    public void b() {
        r0 r0Var;
        Drawable imageViewDrawable = this.f494a.getDrawable();
        if (imageViewDrawable != null) {
            c0.b(imageViewDrawable);
        }
        if (imageViewDrawable == null) {
            return;
        }
        if ((!j() || !a(imageViewDrawable)) && (r0Var = this.f495b) != null) {
            j.B(imageViewDrawable, r0Var, this.f494a.getDrawableState());
        }
    }

    public final boolean j() {
        int sdk = Build.VERSION.SDK_INT;
        if (sdk <= 21 && sdk == 21) {
            return true;
        }
        return false;
    }

    public final boolean a(Drawable imageSource) {
        if (this.f496c == null) {
            this.f496c = new r0();
        }
        r0 info = this.f496c;
        info.a();
        ColorStateList tintList = g.a(this.f494a);
        if (tintList != null) {
            info.d = true;
            info.f515a = tintList;
        }
        PorterDuff.Mode mode = g.b(this.f494a);
        if (mode != null) {
            info.f517c = true;
            info.f516b = mode;
        }
        if (!info.d && !info.f517c) {
            return false;
        }
        j.B(imageSource, info, this.f494a.getDrawableState());
        return true;
    }
}
