package a.b.d.f;

import a.b.c.h.o;
import a.b.c.i.l;
import a.b.d.b.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;

public class k extends EditText implements o {

    /* renamed from: b  reason: collision with root package name */
    public final e f482b;

    /* renamed from: c  reason: collision with root package name */
    public final x f483c;

    public k(Context context, AttributeSet attrs) {
        this(context, attrs, a.editTextStyle);
    }

    public k(Context context, AttributeSet attrs, int defStyleAttr) {
        super(q0.b(context), attrs, defStyleAttr);
        e eVar = new e(this);
        this.f482b = eVar;
        eVar.e(attrs, defStyleAttr);
        x xVar = new x(this);
        this.f483c = xVar;
        xVar.k(attrs, defStyleAttr);
        this.f483c.b();
    }

    public Editable getText() {
        if (Build.VERSION.SDK_INT >= 28) {
            return super.getText();
        }
        return super.getEditableText();
    }

    public void setBackgroundResource(int resId) {
        super.setBackgroundResource(resId);
        e eVar = this.f482b;
        if (eVar != null) {
            eVar.g(resId);
        }
    }

    public void setBackgroundDrawable(Drawable background) {
        super.setBackgroundDrawable(background);
        e eVar = this.f482b;
        if (eVar != null) {
            eVar.f();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList tint) {
        e eVar = this.f482b;
        if (eVar != null) {
            eVar.i(tint);
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        e eVar = this.f482b;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode tintMode) {
        e eVar = this.f482b;
        if (eVar != null) {
            eVar.j(tintMode);
        }
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        e eVar = this.f482b;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        e eVar = this.f482b;
        if (eVar != null) {
            eVar.b();
        }
        x xVar = this.f483c;
        if (xVar != null) {
            xVar.b();
        }
    }

    public void setTextAppearance(Context context, int resId) {
        super.setTextAppearance(context, resId);
        x xVar = this.f483c;
        if (xVar != null) {
            xVar.n(context, resId);
        }
    }

    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(outAttrs);
        l.a(onCreateInputConnection, outAttrs, this);
        return onCreateInputConnection;
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback actionModeCallback) {
        super.setCustomSelectionActionModeCallback(l.k(this, actionModeCallback));
    }
}
