package a.b.c.h;

import a.b.d.a.f;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.view.ViewCompat;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class p {

    /* renamed from: a  reason: collision with root package name */
    public static WeakHashMap<View, String> f255a;

    /* renamed from: b  reason: collision with root package name */
    public static WeakHashMap<View, t> f256b = null;

    public interface b {
        boolean a(View view, KeyEvent keyEvent);
    }

    static {
        new AtomicInteger(1);
    }

    public static void s(View v, b delegate) {
        v.setAccessibilityDelegate(delegate == null ? null : delegate.c());
    }

    public static void o(View view) {
        view.postInvalidateOnAnimation();
    }

    public static void p(View view, Runnable action) {
        view.postOnAnimation(action);
    }

    public static void q(View view, Runnable action, long delayMillis) {
        view.postOnAnimationDelayed(action, delayMillis);
    }

    public static int f(View view) {
        return view.getLayoutDirection();
    }

    public static int g(View view) {
        return view.getMinimumHeight();
    }

    public static t a(View view) {
        if (f256b == null) {
            f256b = new WeakHashMap<>();
        }
        t vpa = f256b.get(view);
        if (vpa != null) {
            return vpa;
        }
        t vpa2 = new t(view);
        f256b.put(view, vpa2);
        return vpa2;
    }

    public static void w(View view, float elevation) {
        if (Build.VERSION.SDK_INT >= 21) {
            view.setElevation(elevation);
        }
    }

    public static void z(View view, String transitionName) {
        if (Build.VERSION.SDK_INT >= 21) {
            view.setTransitionName(transitionName);
            return;
        }
        if (f255a == null) {
            f255a = new WeakHashMap<>();
        }
        f255a.put(view, transitionName);
    }

    public static String h(View view) {
        if (Build.VERSION.SDK_INT >= 21) {
            return view.getTransitionName();
        }
        WeakHashMap<View, String> weakHashMap = f255a;
        if (weakHashMap == null) {
            return null;
        }
        return weakHashMap.get(view);
    }

    public static int i(View view) {
        return view.getWindowSystemUiVisibility();
    }

    public static void r(View view) {
        if (Build.VERSION.SDK_INT >= 20) {
            view.requestApplyInsets();
        } else {
            view.requestFitSystemWindows();
        }
    }

    public static void x(View v, n listener) {
        if (Build.VERSION.SDK_INT < 21) {
            return;
        }
        if (listener == null) {
            v.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener) null);
        } else {
            v.setOnApplyWindowInsetsListener(new a(listener));
        }
    }

    public static class a implements View.OnApplyWindowInsetsListener {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ n f257a;

        public a(n nVar) {
            this.f257a = nVar;
        }

        public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
            return (WindowInsets) x.f(((f.c) this.f257a).a(view, x.g(insets)));
        }
    }

    public static x n(View view, x insets) {
        if (Build.VERSION.SDK_INT < 21) {
            return insets;
        }
        WindowInsets unwrapped = (WindowInsets) x.f(insets);
        WindowInsets result = view.onApplyWindowInsets(unwrapped);
        if (result != unwrapped) {
            unwrapped = new WindowInsets(result);
        }
        return x.g(unwrapped);
    }

    public static boolean k(View view) {
        return view.hasOverlappingRendering();
    }

    public static void t(View view, Drawable background) {
        view.setBackground(background);
    }

    public static ColorStateList d(View view) {
        if (Build.VERSION.SDK_INT >= 21) {
            return view.getBackgroundTintList();
        }
        if (view instanceof o) {
            return ((o) view).getSupportBackgroundTintList();
        }
        return null;
    }

    public static void u(View view, ColorStateList tintList) {
        if (Build.VERSION.SDK_INT >= 21) {
            view.setBackgroundTintList(tintList);
            if (Build.VERSION.SDK_INT == 21) {
                Drawable background = view.getBackground();
                boolean hasTint = (view.getBackgroundTintList() == null && view.getBackgroundTintMode() == null) ? false : true;
                if (background != null && hasTint) {
                    if (background.isStateful()) {
                        background.setState(view.getDrawableState());
                    }
                    view.setBackground(background);
                }
            }
        } else if (view instanceof o) {
            ((o) view).setSupportBackgroundTintList(tintList);
        }
    }

    public static PorterDuff.Mode e(View view) {
        if (Build.VERSION.SDK_INT >= 21) {
            return view.getBackgroundTintMode();
        }
        if (view instanceof o) {
            return ((o) view).getSupportBackgroundTintMode();
        }
        return null;
    }

    public static void v(View view, PorterDuff.Mode mode) {
        if (Build.VERSION.SDK_INT >= 21) {
            view.setBackgroundTintMode(mode);
            if (Build.VERSION.SDK_INT == 21) {
                Drawable background = view.getBackground();
                boolean hasTint = (view.getBackgroundTintList() == null && view.getBackgroundTintMode() == null) ? false : true;
                if (background != null && hasTint) {
                    if (background.isStateful()) {
                        background.setState(view.getDrawableState());
                    }
                    view.setBackground(background);
                }
            }
        } else if (view instanceof o) {
            ((o) view).setSupportBackgroundTintMode(mode);
        }
    }

    public static void A(View view) {
        if (Build.VERSION.SDK_INT >= 21) {
            view.stopNestedScroll();
        } else if (view instanceof i) {
            ((i) view).stopNestedScroll();
        }
    }

    public static boolean m(View view) {
        if (Build.VERSION.SDK_INT >= 19) {
            return view.isLaidOut();
        }
        return view.getWidth() > 0 && view.getHeight() > 0;
    }

    public static boolean l(View view) {
        if (Build.VERSION.SDK_INT >= 19) {
            return view.isAttachedToWindow();
        }
        return view.getWindowToken() != null;
    }

    public static boolean j(View view) {
        return view.hasOnClickListeners();
    }

    public static void y(View view, int indicators, int mask) {
        if (Build.VERSION.SDK_INT >= 23) {
            view.setScrollIndicators(indicators, mask);
        }
    }

    public static boolean c(View root, KeyEvent evt) {
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        return c.a(root).f(evt);
    }

    public static boolean b(View root, KeyEvent evt) {
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        return c.a(root).b(root, evt);
    }

    public static class c {
        public static final ArrayList<WeakReference<View>> d = new ArrayList<>();

        /* renamed from: a  reason: collision with root package name */
        public WeakHashMap<View, Boolean> f258a = null;

        /* renamed from: b  reason: collision with root package name */
        public SparseArray<WeakReference<View>> f259b = null;

        /* renamed from: c  reason: collision with root package name */
        public WeakReference<KeyEvent> f260c = null;

        public final SparseArray<WeakReference<View>> d() {
            if (this.f259b == null) {
                this.f259b = new SparseArray<>();
            }
            return this.f259b;
        }

        public static c a(View root) {
            c manager = (c) root.getTag(a.b.a.b.tag_unhandled_key_event_manager);
            if (manager != null) {
                return manager;
            }
            c manager2 = new c();
            root.setTag(a.b.a.b.tag_unhandled_key_event_manager, manager2);
            return manager2;
        }

        public boolean b(View root, KeyEvent event) {
            if (event.getAction() == 0) {
                g();
            }
            View consumer = c(root, event);
            if (event.getAction() == 0) {
                int keycode = event.getKeyCode();
                if (consumer != null && !KeyEvent.isModifierKey(keycode)) {
                    d().put(keycode, new WeakReference(consumer));
                }
            }
            return consumer != null;
        }

        public final View c(View view, KeyEvent event) {
            WeakHashMap<View, Boolean> weakHashMap = this.f258a;
            if (weakHashMap == null || !weakHashMap.containsKey(view)) {
                return null;
            }
            if (view instanceof ViewGroup) {
                ViewGroup vg = (ViewGroup) view;
                for (int i = vg.getChildCount() - 1; i >= 0; i--) {
                    View consumer = c(vg.getChildAt(i), event);
                    if (consumer != null) {
                        return consumer;
                    }
                }
            }
            if (e(view, event)) {
                return view;
            }
            return null;
        }

        public boolean f(KeyEvent event) {
            int idx;
            WeakReference<KeyEvent> weakReference = this.f260c;
            if (weakReference != null && weakReference.get() == event) {
                return false;
            }
            this.f260c = new WeakReference<>(event);
            WeakReference<View> currentReceiver = null;
            SparseArray<WeakReference<View>> capturedKeys = d();
            if (event.getAction() == 1 && (idx = capturedKeys.indexOfKey(event.getKeyCode())) >= 0) {
                currentReceiver = capturedKeys.valueAt(idx);
                capturedKeys.removeAt(idx);
            }
            if (currentReceiver == null) {
                currentReceiver = capturedKeys.get(event.getKeyCode());
            }
            if (currentReceiver == null) {
                return false;
            }
            View target = (View) currentReceiver.get();
            if (target != null && p.l(target)) {
                e(target, event);
            }
            return true;
        }

        public final boolean e(View v, KeyEvent event) {
            ArrayList<ViewCompat.OnUnhandledKeyEventListenerCompat> viewListeners = (ArrayList) v.getTag(a.b.a.b.tag_unhandled_key_listeners);
            if (viewListeners == null) {
                return false;
            }
            for (int i = viewListeners.size() - 1; i >= 0; i--) {
                if (((b) viewListeners.get(i)).a(v, event)) {
                    return true;
                }
            }
            return false;
        }

        public final void g() {
            WeakHashMap<View, Boolean> weakHashMap = this.f258a;
            if (weakHashMap != null) {
                weakHashMap.clear();
            }
            if (!d.isEmpty()) {
                synchronized (d) {
                    if (this.f258a == null) {
                        this.f258a = new WeakHashMap<>();
                    }
                    for (int i = d.size() - 1; i >= 0; i--) {
                        View v = (View) d.get(i).get();
                        if (v == null) {
                            d.remove(i);
                        } else {
                            this.f258a.put(v, Boolean.TRUE);
                            for (ViewParent nxt = v.getParent(); nxt instanceof View; nxt = nxt.getParent()) {
                                this.f258a.put((View) nxt, Boolean.TRUE);
                            }
                        }
                    }
                }
            }
        }
    }
}
