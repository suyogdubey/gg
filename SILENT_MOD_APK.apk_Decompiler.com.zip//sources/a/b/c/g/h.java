package a.b.c.g;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

public abstract class h<K, V> {

    /* renamed from: a  reason: collision with root package name */
    public h<K, V>.b f226a;

    /* renamed from: b  reason: collision with root package name */
    public h<K, V>.c f227b;

    /* renamed from: c  reason: collision with root package name */
    public h<K, V>.e f228c;

    public abstract void a();

    public abstract Object b(int i, int i2);

    public abstract Map<K, V> c();

    public abstract int d();

    public abstract int e(Object obj);

    public abstract int f(Object obj);

    public abstract void g(K k, V v);

    public abstract void h(int i);

    public abstract V i(int i, V v);

    public final class a<T> implements Iterator<T> {

        /* renamed from: b  reason: collision with root package name */
        public final int f229b;

        /* renamed from: c  reason: collision with root package name */
        public int f230c;
        public int d;
        public boolean e = false;

        public a(int offset) {
            this.f229b = offset;
            this.f230c = h.this.d();
        }

        public boolean hasNext() {
            return this.d < this.f230c;
        }

        public T next() {
            if (hasNext()) {
                Object res = h.this.b(this.d, this.f229b);
                this.d++;
                this.e = true;
                return res;
            }
            throw new NoSuchElementException();
        }

        public void remove() {
            if (this.e) {
                int i = this.d - 1;
                this.d = i;
                this.f230c--;
                this.e = false;
                h.this.h(i);
                return;
            }
            throw new IllegalStateException();
        }
    }

    public final class d implements Iterator<Map.Entry<K, V>>, Map.Entry<K, V> {

        /* renamed from: b  reason: collision with root package name */
        public int f233b;

        /* renamed from: c  reason: collision with root package name */
        public int f234c;
        public boolean d = false;

        public /* bridge */ /* synthetic */ Object next() {
            a();
            return this;
        }

        public d() {
            this.f233b = h.this.d() - 1;
            this.f234c = -1;
        }

        public boolean hasNext() {
            return this.f234c < this.f233b;
        }

        public Map.Entry<K, V> a() {
            if (hasNext()) {
                this.f234c++;
                this.d = true;
                return this;
            }
            throw new NoSuchElementException();
        }

        public void remove() {
            if (this.d) {
                h.this.h(this.f234c);
                this.f234c--;
                this.f233b--;
                this.d = false;
                return;
            }
            throw new IllegalStateException();
        }

        public K getKey() {
            if (this.d) {
                return h.this.b(this.f234c, 0);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public V getValue() {
            if (this.d) {
                return h.this.b(this.f234c, 1);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public V setValue(V object) {
            if (this.d) {
                return h.this.i(this.f234c, object);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public boolean equals(Object o) {
            if (!this.d) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            } else if (!(o instanceof Map.Entry)) {
                return false;
            } else {
                Map.Entry<?, ?> e2 = (Map.Entry) o;
                if (!c.c(e2.getKey(), h.this.b(this.f234c, 0)) || !c.c(e2.getValue(), h.this.b(this.f234c, 1))) {
                    return false;
                }
                return true;
            }
        }

        public int hashCode() {
            if (this.d) {
                int i = 0;
                Object key = h.this.b(this.f234c, 0);
                Object value = h.this.b(this.f234c, 1);
                int hashCode = key == null ? 0 : key.hashCode();
                if (value != null) {
                    i = value.hashCode();
                }
                return i ^ hashCode;
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public String toString() {
            return getKey() + "=" + getValue();
        }
    }

    public final class b implements Set<Map.Entry<K, V>> {
        public b() {
        }

        public /* bridge */ /* synthetic */ boolean add(Object obj) {
            Map.Entry entry = (Map.Entry) obj;
            a();
            throw null;
        }

        public boolean a() {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends Map.Entry<K, V>> collection) {
            int oldSize = h.this.d();
            for (Map.Entry<K, V> entry : collection) {
                h.this.g(entry.getKey(), entry.getValue());
            }
            return oldSize != h.this.d();
        }

        public void clear() {
            h.this.a();
        }

        public boolean contains(Object o) {
            if (!(o instanceof Map.Entry)) {
                return false;
            }
            Map.Entry<?, ?> e = (Map.Entry) o;
            int index = h.this.e(e.getKey());
            if (index < 0) {
                return false;
            }
            return c.c(h.this.b(index, 1), e.getValue());
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean isEmpty() {
            return h.this.d() == 0;
        }

        public Iterator<Map.Entry<K, V>> iterator() {
            return new d();
        }

        public boolean remove(Object object) {
            throw new UnsupportedOperationException();
        }

        public boolean removeAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public boolean retainAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public int size() {
            return h.this.d();
        }

        public Object[] toArray() {
            throw new UnsupportedOperationException();
        }

        public <T> T[] toArray(T[] tArr) {
            throw new UnsupportedOperationException();
        }

        public boolean equals(Object object) {
            return h.k(this, object);
        }

        public int hashCode() {
            int result = 0;
            for (int i = h.this.d() - 1; i >= 0; i--) {
                int i2 = 0;
                Object key = h.this.b(i, 0);
                Object value = h.this.b(i, 1);
                int hashCode = key == null ? 0 : key.hashCode();
                if (value != null) {
                    i2 = value.hashCode();
                }
                result += i2 ^ hashCode;
            }
            return result;
        }
    }

    public final class c implements Set<K> {
        public c() {
        }

        public boolean add(K k) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends K> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            h.this.a();
        }

        public boolean contains(Object object) {
            return h.this.e(object) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            return h.j(h.this.c(), collection);
        }

        public boolean isEmpty() {
            return h.this.d() == 0;
        }

        public Iterator<K> iterator() {
            return new a(0);
        }

        public boolean remove(Object object) {
            int index = h.this.e(object);
            if (index < 0) {
                return false;
            }
            h.this.h(index);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            return h.o(h.this.c(), collection);
        }

        public boolean retainAll(Collection<?> collection) {
            return h.p(h.this.c(), collection);
        }

        public int size() {
            return h.this.d();
        }

        public Object[] toArray() {
            return h.this.q(0);
        }

        public <T> T[] toArray(T[] array) {
            return h.this.r(array, 0);
        }

        public boolean equals(Object object) {
            return h.k(this, object);
        }

        public int hashCode() {
            int result = 0;
            for (int i = h.this.d() - 1; i >= 0; i--) {
                int i2 = 0;
                Object obj = h.this.b(i, 0);
                if (obj != null) {
                    i2 = obj.hashCode();
                }
                result += i2;
            }
            return result;
        }
    }

    public final class e implements Collection<V> {
        public e() {
        }

        public boolean add(V v) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends V> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            h.this.a();
        }

        public boolean contains(Object object) {
            return h.this.f(object) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean isEmpty() {
            return h.this.d() == 0;
        }

        public Iterator<V> iterator() {
            return new a(1);
        }

        public boolean remove(Object object) {
            int index = h.this.f(object);
            if (index < 0) {
                return false;
            }
            h.this.h(index);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            int N = h.this.d();
            boolean changed = false;
            int i = 0;
            while (i < N) {
                if (collection.contains(h.this.b(i, 1))) {
                    h.this.h(i);
                    i--;
                    N--;
                    changed = true;
                }
                i++;
            }
            return changed;
        }

        public boolean retainAll(Collection<?> collection) {
            int N = h.this.d();
            boolean changed = false;
            int i = 0;
            while (i < N) {
                if (!collection.contains(h.this.b(i, 1))) {
                    h.this.h(i);
                    i--;
                    N--;
                    changed = true;
                }
                i++;
            }
            return changed;
        }

        public int size() {
            return h.this.d();
        }

        public Object[] toArray() {
            return h.this.q(1);
        }

        public <T> T[] toArray(T[] array) {
            return h.this.r(array, 1);
        }
    }

    public static <K, V> boolean j(Map<K, V> map, Collection<?> collection) {
        for (Object containsKey : collection) {
            if (!map.containsKey(containsKey)) {
                return false;
            }
        }
        return true;
    }

    public static <K, V> boolean o(Map<K, V> map, Collection<?> collection) {
        int oldSize = map.size();
        for (Object remove : collection) {
            map.remove(remove);
        }
        return oldSize != map.size();
    }

    public static <K, V> boolean p(Map<K, V> map, Collection<?> collection) {
        int oldSize = map.size();
        Iterator<K> it = map.keySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(it.next())) {
                it.remove();
            }
        }
        return oldSize != map.size();
    }

    public Object[] q(int offset) {
        int N = d();
        Object[] result = new Object[N];
        for (int i = 0; i < N; i++) {
            result[i] = b(i, offset);
        }
        return result;
    }

    public <T> T[] r(T[] array, int offset) {
        int N = d();
        if (array.length < N) {
            array = (Object[]) Array.newInstance(array.getClass().getComponentType(), N);
        }
        for (int i = 0; i < N; i++) {
            array[i] = b(i, offset);
        }
        if (array.length > N) {
            array[N] = null;
        }
        return array;
    }

    public static <T> boolean k(Set<T> set, Object object) {
        if (set == object) {
            return true;
        }
        if (!(object instanceof Set)) {
            return false;
        }
        Set<?> s = (Set) object;
        try {
            if (set.size() != s.size() || !set.containsAll(s)) {
                return false;
            }
            return true;
        } catch (NullPointerException e2) {
            return false;
        } catch (ClassCastException e3) {
            return false;
        }
    }

    public Set<Map.Entry<K, V>> l() {
        if (this.f226a == null) {
            this.f226a = new b();
        }
        return this.f226a;
    }

    public Set<K> m() {
        if (this.f227b == null) {
            this.f227b = new c();
        }
        return this.f227b;
    }

    public Collection<V> n() {
        if (this.f228c == null) {
            this.f228c = new e();
        }
        return this.f228c;
    }
}
