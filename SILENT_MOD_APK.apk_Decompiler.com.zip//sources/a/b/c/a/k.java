package a.b.c.a;

import a.a.b.n;
import a.b.c.a.e;
import a.b.c.h.p;
import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.arch.lifecycle.ViewModelStore;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.support.v4.app.BackStackRecord;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManagerNonConfig;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class k extends j implements LayoutInflater.Factory2 {
    public static boolean C = false;
    public static Field D = null;
    public static final Interpolator E = new DecelerateInterpolator(2.5f);
    public static final Interpolator F = new DecelerateInterpolator(1.5f);
    public l A;
    public Runnable B = new a();

    /* renamed from: b  reason: collision with root package name */
    public boolean f79b;

    /* renamed from: c  reason: collision with root package name */
    public int f80c = 0;
    public final ArrayList<e> d = new ArrayList<>();
    public SparseArray<e> e;
    public ArrayList<c> f;
    public ArrayList<e> g;
    public ArrayList<c> h;
    public ArrayList<Integer> i;
    public final CopyOnWriteArrayList<j> j = new CopyOnWriteArrayList<>();
    public int k = 0;
    public i l;
    public g m;
    public e n;
    public e o;
    public boolean p;
    public boolean q;
    public boolean r;
    public boolean s;
    public boolean t;
    public ArrayList<c> u;
    public ArrayList<Boolean> v;
    public ArrayList<e> w;
    public Bundle x = null;
    public SparseArray<Parcelable> y = null;
    public ArrayList<l> z;

    public static final class j {

        /* renamed from: a  reason: collision with root package name */
        public final boolean f99a;
    }

    /* renamed from: a.b.c.a.k$k  reason: collision with other inner class name */
    public static class C0006k {

        /* renamed from: a  reason: collision with root package name */
        public static final int[] f100a = {16842755, 16842960, 16842961};
    }

    static {
        new AccelerateInterpolator(2.5f);
        new AccelerateInterpolator(1.5f);
    }

    public class a implements Runnable {
        public a() {
        }

        public void run() {
            k.this.Z();
        }
    }

    public static boolean x0(g anim) {
        Animation animation = anim.f94a;
        if (animation instanceof AlphaAnimation) {
            return true;
        }
        if (!(animation instanceof AnimationSet)) {
            return w0(anim.f95b);
        }
        List<Animation> anims = ((AnimationSet) animation).getAnimations();
        for (int i2 = 0; i2 < anims.size(); i2++) {
            if (anims.get(i2) instanceof AlphaAnimation) {
                return true;
            }
        }
        return false;
    }

    public static boolean w0(Animator anim) {
        if (anim == null) {
            return false;
        }
        if (anim instanceof ValueAnimator) {
            PropertyValuesHolder[] values = ((ValueAnimator) anim).getValues();
            for (PropertyValuesHolder propertyName : values) {
                if ("alpha".equals(propertyName.getPropertyName())) {
                    return true;
                }
            }
        } else if (anim instanceof AnimatorSet) {
            List<Animator> animList = ((AnimatorSet) anim).getChildAnimations();
            for (int i2 = 0; i2 < animList.size(); i2++) {
                if (w0(animList.get(i2))) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean X0(View v2, g anim) {
        if (v2 == null || anim == null || Build.VERSION.SDK_INT < 19 || v2.getLayerType() != 0 || !p.k(v2) || !x0(anim)) {
            return false;
        }
        return true;
    }

    public final void a1(RuntimeException ex) {
        Log.e("FragmentManager", ex.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter pw = new PrintWriter(new a.b.c.g.e("FragmentManager"));
        i iVar = this.l;
        if (iVar != null) {
            try {
                iVar.i("  ", (FileDescriptor) null, pw, new String[0]);
            } catch (Exception e2) {
                Log.e("FragmentManager", "Failed dumping state", e2);
            }
        } else {
            try {
                a("  ", (FileDescriptor) null, pw, new String[0]);
            } catch (Exception e3) {
                Log.e("FragmentManager", "Failed dumping state", e3);
            }
        }
        throw ex;
    }

    public boolean d() {
        k();
        return E0((String) null, -1, 0);
    }

    public final boolean E0(String name, int id, int flags) {
        j childManager;
        Z();
        X(true);
        e eVar = this.o;
        if (eVar != null && id < 0 && name == null && (childManager = eVar.o0()) != null && childManager.d()) {
            return true;
        }
        boolean executePop = F0(this.u, this.v, name, id, flags);
        if (executePop) {
            this.f79b = true;
            try {
                J0(this.u, this.v);
            } finally {
                l();
            }
        }
        V();
        j();
        return executePop;
    }

    public void H0(Bundle bundle, String key, e fragment) {
        int i2 = fragment.f;
        if (i2 >= 0) {
            bundle.putInt(key, i2);
            return;
        }
        a1(new IllegalStateException("Fragment " + fragment + " is not currently in the FragmentManager"));
        throw null;
    }

    public e l0(Bundle bundle, String key) {
        int index = bundle.getInt(key, -1);
        if (index == -1) {
            return null;
        }
        e f2 = this.e.get(index);
        if (f2 != null) {
            return f2;
        }
        a1(new IllegalStateException("Fragment no longer exists for key " + key + ": index " + index));
        throw null;
    }

    public List<e> b() {
        List<e> list;
        if (this.d.isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (this.d) {
            list = (List) this.d.clone();
        }
        return list;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        e eVar = this.n;
        if (eVar != null) {
            a.b.c.g.d.a(eVar, sb);
        } else {
            a.b.c.g.d.a(this.l, sb);
        }
        sb.append("}}");
        return sb.toString();
    }

    public void a(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
        int N;
        int N2;
        int N3;
        int N4;
        String innerPrefix = prefix + "    ";
        SparseArray<e> sparseArray = this.e;
        if (sparseArray != null && (N4 = sparseArray.size()) > 0) {
            writer.print(prefix);
            writer.print("Active Fragments in ");
            writer.print(Integer.toHexString(System.identityHashCode(this)));
            writer.println(":");
            for (int i2 = 0; i2 < N4; i2++) {
                e f2 = this.e.valueAt(i2);
                writer.print(prefix);
                writer.print("  #");
                writer.print(i2);
                writer.print(": ");
                writer.println(f2);
                if (f2 != null) {
                    f2.c(innerPrefix, fd, writer, args);
                }
            }
        }
        int N5 = this.d.size();
        if (N5 > 0) {
            writer.print(prefix);
            writer.println("Added Fragments:");
            for (int i3 = 0; i3 < N5; i3++) {
                writer.print(prefix);
                writer.print("  #");
                writer.print(i3);
                writer.print(": ");
                writer.println(this.d.get(i3).toString());
            }
        }
        ArrayList<e> arrayList = this.g;
        if (arrayList != null && (N3 = arrayList.size()) > 0) {
            writer.print(prefix);
            writer.println("Fragments Created Menus:");
            for (int i4 = 0; i4 < N3; i4++) {
                writer.print(prefix);
                writer.print("  #");
                writer.print(i4);
                writer.print(": ");
                writer.println(this.g.get(i4).toString());
            }
        }
        ArrayList<c> arrayList2 = this.f;
        if (arrayList2 != null && (N2 = arrayList2.size()) > 0) {
            writer.print(prefix);
            writer.println("Back Stack:");
            for (int i5 = 0; i5 < N2; i5++) {
                c bs = this.f.get(i5);
                writer.print(prefix);
                writer.print("  #");
                writer.print(i5);
                writer.print(": ");
                writer.println(bs.toString());
                bs.c(innerPrefix, writer);
            }
        }
        synchronized (this) {
            if (this.h != null && (N = this.h.size()) > 0) {
                writer.print(prefix);
                writer.println("Back Stack Indices:");
                for (int i6 = 0; i6 < N; i6++) {
                    writer.print(prefix);
                    writer.print("  #");
                    writer.print(i6);
                    writer.print(": ");
                    writer.println(this.h.get(i6));
                }
            }
            if (this.i != null && this.i.size() > 0) {
                writer.print(prefix);
                writer.print("mAvailBackStackIndices: ");
                writer.println(Arrays.toString(this.i.toArray()));
            }
        }
        writer.print(prefix);
        writer.println("FragmentManager misc state:");
        writer.print(prefix);
        writer.print("  mHost=");
        writer.println(this.l);
        writer.print(prefix);
        writer.print("  mContainer=");
        writer.println(this.m);
        if (this.n != null) {
            writer.print(prefix);
            writer.print("  mParent=");
            writer.println(this.n);
        }
        writer.print(prefix);
        writer.print("  mCurState=");
        writer.print(this.k);
        writer.print(" mStateSaved=");
        writer.print(this.q);
        writer.print(" mStopped=");
        writer.print(this.r);
        writer.print(" mDestroyed=");
        writer.println(this.s);
        if (this.p) {
            writer.print(prefix);
            writer.print("  mNeedMenuInvalidate=");
            writer.println(this.p);
        }
    }

    public static g u0(Context context, float startScale, float endScale, float startAlpha, float endAlpha) {
        AnimationSet set = new AnimationSet(false);
        ScaleAnimation scale = new ScaleAnimation(startScale, endScale, startScale, endScale, 1, 0.5f, 1, 0.5f);
        scale.setInterpolator(E);
        scale.setDuration(220);
        set.addAnimation(scale);
        AlphaAnimation alpha = new AlphaAnimation(startAlpha, endAlpha);
        alpha.setInterpolator(F);
        alpha.setDuration(220);
        set.addAnimation(alpha);
        return new g((Animation) set);
    }

    public static g s0(Context context, float start, float end) {
        AlphaAnimation anim = new AlphaAnimation(start, end);
        anim.setInterpolator(F);
        anim.setDuration(220);
        return new g((Animation) anim);
    }

    public g q0(e fragment, int transit, boolean enter, int transitionStyle) {
        int styleIndex;
        int nextAnim = fragment.t();
        fragment.T();
        if (0 != 0) {
            return new g((Animation) null);
        }
        fragment.U();
        if (0 != 0) {
            return new g((Animator) null);
        }
        if (nextAnim != 0) {
            boolean isAnim = "anim".equals(this.l.e().getResources().getResourceTypeName(nextAnim));
            boolean successfulLoad = false;
            if (isAnim) {
                try {
                    Animation animation = AnimationUtils.loadAnimation(this.l.e(), nextAnim);
                    if (animation != null) {
                        return new g(animation);
                    }
                    successfulLoad = true;
                } catch (Resources.NotFoundException e2) {
                    throw e2;
                } catch (RuntimeException e3) {
                }
            }
            if (!successfulLoad) {
                try {
                    Animator animator = AnimatorInflater.loadAnimator(this.l.e(), nextAnim);
                    if (animator != null) {
                        return new g(animator);
                    }
                } catch (RuntimeException e4) {
                    if (!isAnim) {
                        Animation animation2 = AnimationUtils.loadAnimation(this.l.e(), nextAnim);
                        if (animation2 != null) {
                            return new g(animation2);
                        }
                    } else {
                        throw e4;
                    }
                }
            }
        }
        if (transit == 0 || (styleIndex = b1(transit, enter)) < 0) {
            return null;
        }
        switch (styleIndex) {
            case 1:
                return u0(this.l.e(), 1.125f, 1.0f, 0.0f, 1.0f);
            case 2:
                return u0(this.l.e(), 1.0f, 0.975f, 1.0f, 0.0f);
            case 3:
                return u0(this.l.e(), 0.975f, 1.0f, 0.0f, 1.0f);
            case 4:
                return u0(this.l.e(), 1.0f, 1.075f, 1.0f, 0.0f);
            case 5:
                return s0(this.l.e(), 0.0f, 1.0f);
            case 6:
                return s0(this.l.e(), 1.0f, 0.0f);
            default:
                if (transitionStyle == 0 && this.l.l()) {
                    transitionStyle = this.l.k();
                }
                return transitionStyle == 0 ? null : null;
        }
    }

    public void D0(e f2) {
        if (!f2.L) {
            return;
        }
        if (this.f79b) {
            this.t = true;
            return;
        }
        f2.L = false;
        B0(f2, this.k, 0, 0, false);
    }

    public static void U0(View v2, g anim) {
        if (v2 != null && anim != null && X0(v2, anim)) {
            Animator animator = anim.f95b;
            if (animator != null) {
                animator.addListener(new h(v2));
                return;
            }
            Animation.AnimationListener originalListener = k0(anim.f94a);
            v2.setLayerType(2, (Paint) null);
            anim.f94a.setAnimationListener(new e(v2, originalListener));
        }
    }

    public static Animation.AnimationListener k0(Animation animation) {
        try {
            if (D == null) {
                Field declaredField = Animation.class.getDeclaredField("mListener");
                D = declaredField;
                declaredField.setAccessible(true);
            }
            return (Animation.AnimationListener) D.get(animation);
        } catch (NoSuchFieldException e2) {
            Log.e("FragmentManager", "No field with the name mListener is found in Animation class", e2);
            return null;
        } catch (IllegalAccessException e3) {
            Log.e("FragmentManager", "Cannot access Animation's mListener field", e3);
            return null;
        }
    }

    public boolean p0(int state) {
        return this.k >= state;
    }

    /* JADX WARNING: type inference failed for: r2v30, types: [android.view.View] */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x006c, code lost:
        if (r1 != 3) goto L_0x026f;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x025b  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x0264  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void B0(a.b.c.a.e r16, int r17, int r18, int r19, boolean r20) {
        /*
            r15 = this;
            r7 = r15
            r8 = r16
            boolean r0 = r8.l
            r9 = 1
            if (r0 == 0) goto L_0x0010
            boolean r0 = r8.C
            if (r0 == 0) goto L_0x000d
            goto L_0x0010
        L_0x000d:
            r0 = r17
            goto L_0x0015
        L_0x0010:
            r0 = r17
            if (r0 <= r9) goto L_0x0015
            r0 = 1
        L_0x0015:
            boolean r1 = r8.m
            if (r1 == 0) goto L_0x0029
            int r1 = r8.f63b
            if (r0 <= r1) goto L_0x0029
            if (r1 != 0) goto L_0x0027
            boolean r1 = r16.H()
            if (r1 == 0) goto L_0x0027
            r0 = 1
            goto L_0x0029
        L_0x0027:
            int r0 = r8.f63b
        L_0x0029:
            boolean r1 = r8.L
            r10 = 3
            r11 = 2
            if (r1 == 0) goto L_0x0036
            int r1 = r8.f63b
            if (r1 >= r10) goto L_0x0036
            if (r0 <= r11) goto L_0x0036
            r0 = 2
        L_0x0036:
            int r1 = r8.f63b
            r12 = 0
            r13 = 0
            if (r1 > r0) goto L_0x0275
            boolean r1 = r8.n
            if (r1 == 0) goto L_0x0045
            boolean r1 = r8.o
            if (r1 != 0) goto L_0x0045
            return
        L_0x0045:
            android.view.View r1 = r16.j()
            if (r1 != 0) goto L_0x0051
            android.animation.Animator r1 = r16.k()
            if (r1 == 0) goto L_0x0064
        L_0x0051:
            r8.N0(r12)
            r8.O0(r12)
            int r3 = r16.B()
            r4 = 0
            r5 = 0
            r6 = 1
            r1 = r15
            r2 = r16
            r1.B0(r2, r3, r4, r5, r6)
        L_0x0064:
            int r1 = r8.f63b
            if (r1 == 0) goto L_0x0070
            if (r1 == r9) goto L_0x017f
            if (r1 == r11) goto L_0x0259
            if (r1 == r10) goto L_0x0262
            goto L_0x026f
        L_0x0070:
            if (r0 <= 0) goto L_0x017f
            android.os.Bundle r1 = r8.f64c
            if (r1 == 0) goto L_0x00c4
            a.b.c.a.i r2 = r7.l
            android.content.Context r2 = r2.e()
            java.lang.ClassLoader r2 = r2.getClassLoader()
            r1.setClassLoader(r2)
            android.os.Bundle r1 = r8.f64c
            java.lang.String r2 = "android:view_state"
            android.util.SparseArray r1 = r1.getSparseParcelableArray(r2)
            r8.d = r1
            android.os.Bundle r1 = r8.f64c
            java.lang.String r2 = "android:target_state"
            a.b.c.a.e r1 = r15.l0(r1, r2)
            r8.i = r1
            if (r1 == 0) goto L_0x00a4
            android.os.Bundle r1 = r8.f64c
            java.lang.String r2 = "android:target_req_state"
            int r1 = r1.getInt(r2, r13)
            r8.k = r1
        L_0x00a4:
            java.lang.Boolean r1 = r8.e
            if (r1 == 0) goto L_0x00b1
            boolean r1 = r1.booleanValue()
            r8.M = r1
            r8.e = r12
            goto L_0x00bb
        L_0x00b1:
            android.os.Bundle r1 = r8.f64c
            java.lang.String r2 = "android:user_visible_hint"
            boolean r1 = r1.getBoolean(r2, r9)
            r8.M = r1
        L_0x00bb:
            boolean r1 = r8.M
            if (r1 != 0) goto L_0x00c4
            r8.L = r9
            if (r0 <= r11) goto L_0x00c4
            r0 = 2
        L_0x00c4:
            a.b.c.a.i r1 = r7.l
            r8.t = r1
            a.b.c.a.e r2 = r7.n
            r8.x = r2
            if (r2 == 0) goto L_0x00d1
            a.b.c.a.k r1 = r2.u
            goto L_0x00d5
        L_0x00d1:
            a.b.c.a.k r1 = r1.f()
        L_0x00d5:
            r8.s = r1
            a.b.c.a.e r1 = r8.i
            java.lang.String r14 = "Fragment "
            if (r1 == 0) goto L_0x011a
            android.util.SparseArray<a.b.c.a.e> r2 = r7.e
            int r1 = r1.f
            java.lang.Object r1 = r2.get(r1)
            a.b.c.a.e r2 = r8.i
            if (r1 != r2) goto L_0x00f6
            int r1 = r2.f63b
            if (r1 >= r9) goto L_0x011a
            r3 = 1
            r4 = 0
            r5 = 0
            r6 = 1
            r1 = r15
            r1.B0(r2, r3, r4, r5, r6)
            goto L_0x011a
        L_0x00f6:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            r2.append(r14)
            r2.append(r8)
            java.lang.String r3 = " declared target fragment "
            r2.append(r3)
            a.b.c.a.e r3 = r8.i
            r2.append(r3)
            java.lang.String r3 = " that does not belong to this FragmentManager!"
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x011a:
            a.b.c.a.i r1 = r7.l
            android.content.Context r1 = r1.e()
            r15.E(r8, r1, r13)
            r8.H = r13
            a.b.c.a.i r1 = r7.l
            r1.e()
            r16.O()
            boolean r1 = r8.H
            if (r1 == 0) goto L_0x0165
            a.b.c.a.e r1 = r8.x
            if (r1 != 0) goto L_0x013b
            a.b.c.a.i r1 = r7.l
            r1.h(r8)
            goto L_0x013e
        L_0x013b:
            r1.Q()
        L_0x013e:
            a.b.c.a.i r1 = r7.l
            android.content.Context r1 = r1.e()
            r15.z(r8, r1, r13)
            boolean r1 = r8.S
            if (r1 != 0) goto L_0x015b
            android.os.Bundle r1 = r8.f64c
            r15.F(r8, r1, r13)
            android.os.Bundle r1 = r8.f64c
            r8.s0(r1)
            android.os.Bundle r1 = r8.f64c
            r15.A(r8, r1, r13)
            goto L_0x0162
        L_0x015b:
            android.os.Bundle r1 = r8.f64c
            r8.L0(r1)
            r8.f63b = r9
        L_0x0162:
            r8.E = r13
            goto L_0x017f
        L_0x0165:
            a.b.c.a.w r1 = new a.b.c.a.w
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            r2.append(r14)
            r2.append(r8)
            java.lang.String r3 = " did not call through to super.onAttach()"
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x017f:
            r15.Y(r16)
            if (r0 <= r9) goto L_0x0259
            boolean r1 = r8.n
            if (r1 != 0) goto L_0x0244
            r1 = 0
            int r2 = r8.z
            if (r2 == 0) goto L_0x01ff
            r3 = -1
            if (r2 == r3) goto L_0x01e0
            a.b.c.a.g r3 = r7.m
            android.view.View r2 = r3.b(r2)
            r1 = r2
            android.view.ViewGroup r1 = (android.view.ViewGroup) r1
            if (r1 != 0) goto L_0x01ff
            boolean r2 = r8.p
            if (r2 == 0) goto L_0x01a1
            goto L_0x01ff
        L_0x01a1:
            android.content.res.Resources r0 = r16.x()     // Catch:{ NotFoundException -> 0x01ac }
            int r1 = r8.z     // Catch:{ NotFoundException -> 0x01ac }
            java.lang.String r0 = r0.getResourceName(r1)     // Catch:{ NotFoundException -> 0x01ac }
            goto L_0x01b0
        L_0x01ac:
            r0 = move-exception
            java.lang.String r1 = "unknown"
            r0 = r1
        L_0x01b0:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "No view found for id 0x"
            r2.append(r3)
            int r3 = r8.z
            java.lang.String r3 = java.lang.Integer.toHexString(r3)
            r2.append(r3)
            java.lang.String r3 = " ("
            r2.append(r3)
            r2.append(r0)
            java.lang.String r0 = ") for fragment "
            r2.append(r0)
            r2.append(r8)
            java.lang.String r0 = r2.toString()
            r1.<init>(r0)
            r15.a1(r1)
            throw r12
        L_0x01e0:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Cannot create fragment "
            r1.append(r2)
            r1.append(r8)
            java.lang.String r2 = " for a container view with no id"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            r15.a1(r0)
            throw r12
        L_0x01ff:
            r8.I = r1
            android.os.Bundle r2 = r8.f64c
            android.view.LayoutInflater r2 = r8.y0(r2)
            android.os.Bundle r3 = r8.f64c
            r8.u0(r2, r1, r3)
            android.view.View r2 = r8.J
            if (r2 == 0) goto L_0x0242
            r8.K = r2
            r2.setSaveFromParentEnabled(r13)
            if (r1 == 0) goto L_0x021c
            android.view.View r2 = r8.J
            r1.addView(r2)
        L_0x021c:
            boolean r2 = r8.B
            if (r2 == 0) goto L_0x0227
            android.view.View r2 = r8.J
            r3 = 8
            r2.setVisibility(r3)
        L_0x0227:
            r16.m0()
            android.view.View r2 = r8.J
            android.os.Bundle r3 = r8.f64c
            r15.K(r8, r2, r3, r13)
            android.view.View r2 = r8.J
            int r2 = r2.getVisibility()
            if (r2 != 0) goto L_0x023e
            android.view.ViewGroup r2 = r8.I
            if (r2 == 0) goto L_0x023e
            goto L_0x023f
        L_0x023e:
            r9 = 0
        L_0x023f:
            r8.O = r9
            goto L_0x0244
        L_0x0242:
            r8.K = r12
        L_0x0244:
            android.os.Bundle r1 = r8.f64c
            r8.p0(r1)
            android.os.Bundle r1 = r8.f64c
            r15.y(r8, r1, r13)
            android.view.View r1 = r8.J
            if (r1 == 0) goto L_0x0257
            android.os.Bundle r1 = r8.f64c
            r8.M0(r1)
        L_0x0257:
            r8.f64c = r12
        L_0x0259:
            if (r0 <= r11) goto L_0x0262
            r16.I0()
            r15.I(r8, r13)
        L_0x0262:
            if (r0 <= r10) goto L_0x026f
            r16.G0()
            r15.G(r8, r13)
            r8.f64c = r12
            r8.d = r12
        L_0x026f:
            r2 = r18
            r4 = r19
            goto L_0x037d
        L_0x0275:
            if (r1 <= r0) goto L_0x0379
            if (r1 == r9) goto L_0x0316
            if (r1 == r11) goto L_0x0298
            if (r1 == r10) goto L_0x028f
            r2 = 4
            if (r1 == r2) goto L_0x0286
            r2 = r18
            r4 = r19
            goto L_0x037d
        L_0x0286:
            if (r0 >= r2) goto L_0x028f
            r16.D0()
            r15.D(r8, r13)
        L_0x028f:
            if (r0 >= r10) goto L_0x0298
            r16.J0()
            r15.J(r8, r13)
        L_0x0298:
            if (r0 >= r11) goto L_0x0311
            android.view.View r1 = r8.J
            if (r1 == 0) goto L_0x02ae
            a.b.c.a.i r1 = r7.l
            boolean r1 = r1.m(r8)
            if (r1 == 0) goto L_0x02ae
            android.util.SparseArray<android.os.Parcelable> r1 = r8.d
            if (r1 != 0) goto L_0x02ae
            r15.Q0(r16)
        L_0x02ae:
            r16.w0()
            r15.L(r8, r13)
            android.view.View r1 = r8.J
            if (r1 == 0) goto L_0x02fd
            android.view.ViewGroup r2 = r8.I
            if (r2 == 0) goto L_0x02fd
            r2.endViewTransition(r1)
            android.view.View r1 = r8.J
            r1.clearAnimation()
            r1 = 0
            int r2 = r7.k
            r3 = 0
            if (r2 <= 0) goto L_0x02ea
            boolean r2 = r7.s
            if (r2 != 0) goto L_0x02ea
            android.view.View r2 = r8.J
            int r2 = r2.getVisibility()
            if (r2 != 0) goto L_0x02e5
            float r2 = r8.Q
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L_0x02e5
            r2 = r18
            r4 = r19
            a.b.c.a.k$g r1 = r15.q0(r8, r2, r13, r4)
            goto L_0x02ee
        L_0x02e5:
            r2 = r18
            r4 = r19
            goto L_0x02ee
        L_0x02ea:
            r2 = r18
            r4 = r19
        L_0x02ee:
            r8.Q = r3
            if (r1 == 0) goto L_0x02f5
            r15.g(r8, r1, r0)
        L_0x02f5:
            android.view.ViewGroup r3 = r8.I
            android.view.View r5 = r8.J
            r3.removeView(r5)
            goto L_0x0301
        L_0x02fd:
            r2 = r18
            r4 = r19
        L_0x0301:
            r8.I = r12
            r8.J = r12
            r8.V = r12
            a.a.b.i<a.a.b.e> r1 = r8.W
            r1.n(r12)
            r8.K = r12
            r8.o = r13
            goto L_0x031a
        L_0x0311:
            r2 = r18
            r4 = r19
            goto L_0x031a
        L_0x0316:
            r2 = r18
            r4 = r19
        L_0x031a:
            if (r0 >= r9) goto L_0x037d
            boolean r1 = r7.s
            if (r1 == 0) goto L_0x0342
            android.view.View r1 = r16.j()
            if (r1 == 0) goto L_0x0331
            android.view.View r1 = r16.j()
            r8.N0(r12)
            r1.clearAnimation()
            goto L_0x0342
        L_0x0331:
            android.animation.Animator r1 = r16.k()
            if (r1 == 0) goto L_0x0342
            android.animation.Animator r1 = r16.k()
            r8.O0(r12)
            r1.cancel()
        L_0x0342:
            android.view.View r1 = r16.j()
            if (r1 != 0) goto L_0x0374
            android.animation.Animator r1 = r16.k()
            if (r1 == 0) goto L_0x034f
            goto L_0x0374
        L_0x034f:
            boolean r1 = r8.E
            if (r1 != 0) goto L_0x035b
            r16.v0()
            r15.B(r8, r13)
            goto L_0x035d
        L_0x035b:
            r8.f63b = r13
        L_0x035d:
            r16.x0()
            r15.C(r8, r13)
            if (r20 != 0) goto L_0x037d
            boolean r1 = r8.E
            if (r1 != 0) goto L_0x036d
            r15.t0(r16)
            goto L_0x037d
        L_0x036d:
            r8.t = r12
            r8.x = r12
            r8.s = r12
            goto L_0x037d
        L_0x0374:
            r8.V0(r0)
            r0 = 1
            goto L_0x037d
        L_0x0379:
            r2 = r18
            r4 = r19
        L_0x037d:
            int r1 = r8.f63b
            if (r1 == r0) goto L_0x03b0
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = "moveToState: Fragment state for "
            r1.append(r3)
            r1.append(r8)
            java.lang.String r3 = " not updated inline; "
            r1.append(r3)
            java.lang.String r3 = "expected state "
            r1.append(r3)
            r1.append(r0)
            java.lang.String r3 = " found "
            r1.append(r3)
            int r3 = r8.f63b
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            java.lang.String r3 = "FragmentManager"
            android.util.Log.w(r3, r1)
            r8.f63b = r0
        L_0x03b0:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.B0(a.b.c.a.e, int, int, int, boolean):void");
    }

    public final void g(e fragment, g anim, int newState) {
        View viewToAnimate = fragment.J;
        ViewGroup container = fragment.I;
        container.startViewTransition(viewToAnimate);
        fragment.V0(newState);
        if (anim.f94a != null) {
            Animation animation = new i(anim.f94a, container, viewToAnimate);
            fragment.N0(fragment.J);
            animation.setAnimationListener(new b(k0(animation), container, fragment));
            U0(viewToAnimate, anim);
            fragment.J.startAnimation(animation);
            return;
        }
        Animator animator = anim.f95b;
        fragment.O0(anim.f95b);
        animator.addListener(new c(container, viewToAnimate, fragment));
        animator.setTarget(fragment.J);
        U0(fragment.J, anim);
        animator.start();
    }

    public class b extends f {

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ ViewGroup f82b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ e f83c;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(Animation.AnimationListener wrapped, ViewGroup viewGroup, e eVar) {
            super(wrapped);
            this.f82b = viewGroup;
            this.f83c = eVar;
        }

        public void onAnimationEnd(Animation animation) {
            super.onAnimationEnd(animation);
            this.f82b.post(new a());
        }

        public class a implements Runnable {
            public a() {
            }

            public void run() {
                if (b.this.f83c.j() != null) {
                    b.this.f83c.N0((View) null);
                    b bVar = b.this;
                    k kVar = k.this;
                    e eVar = bVar.f83c;
                    kVar.B0(eVar, eVar.B(), 0, 0, false);
                }
            }
        }
    }

    public class c extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ ViewGroup f85a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ View f86b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ e f87c;

        public c(ViewGroup viewGroup, View view, e eVar) {
            this.f85a = viewGroup;
            this.f86b = view;
            this.f87c = eVar;
        }

        public void onAnimationEnd(Animator anim) {
            this.f85a.endViewTransition(this.f86b);
            Animator animator = this.f87c.k();
            this.f87c.O0((Animator) null);
            if (animator != null && this.f85a.indexOfChild(this.f86b) < 0) {
                k kVar = k.this;
                e eVar = this.f87c;
                kVar.B0(eVar, eVar.B(), 0, 0, false);
            }
        }
    }

    public void A0(e f2) {
        B0(f2, this.k, 0, 0, false);
    }

    public void Y(e f2) {
        if (f2.n && !f2.q) {
            f2.u0(f2.y0(f2.f64c), (ViewGroup) null, f2.f64c);
            View view = f2.J;
            if (view != null) {
                f2.K = view;
                view.setSaveFromParentEnabled(false);
                if (f2.B) {
                    f2.J.setVisibility(8);
                }
                f2.m0();
                K(f2, f2.J, f2.f64c, false);
                return;
            }
            f2.K = null;
        }
    }

    public void n(e fragment) {
        Animator animator;
        if (fragment.J != null) {
            g anim = q0(fragment, fragment.u(), !fragment.B, fragment.v());
            if (anim == null || (animator = anim.f95b) == null) {
                if (anim != null) {
                    U0(fragment.J, anim);
                    fragment.J.startAnimation(anim.f94a);
                    anim.f94a.start();
                }
                fragment.J.setVisibility((!fragment.B || fragment.G()) ? 0 : 8);
                if (fragment.G()) {
                    fragment.Q0(false);
                }
            } else {
                animator.setTarget(fragment.J);
                if (!fragment.B) {
                    fragment.J.setVisibility(0);
                } else if (fragment.G()) {
                    fragment.Q0(false);
                } else {
                    ViewGroup container = fragment.I;
                    View animatingView = fragment.J;
                    container.startViewTransition(animatingView);
                    anim.f95b.addListener(new d(this, container, animatingView, fragment));
                }
                U0(fragment.J, anim);
                anim.f95b.start();
            }
        }
        if (fragment.l && fragment.F && fragment.G) {
            this.p = true;
        }
        fragment.P = false;
        fragment.b0();
    }

    public class d extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ ViewGroup f88a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ View f89b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ e f90c;

        public d(k this$0, ViewGroup viewGroup, View view, e eVar) {
            this.f88a = viewGroup;
            this.f89b = view;
            this.f90c = eVar;
        }

        public void onAnimationEnd(Animator animation) {
            this.f88a.endViewTransition(this.f89b);
            animation.removeListener(this);
            View view = this.f90c.J;
            if (view != null) {
                view.setVisibility(8);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0033, code lost:
        r4 = r1.J;
        r5 = r11.I;
        r6 = r5.indexOfChild(r4);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void y0(a.b.c.a.e r11) {
        /*
            r10 = this;
            if (r11 != 0) goto L_0x0003
            return
        L_0x0003:
            int r0 = r10.k
            boolean r1 = r11.m
            r2 = 1
            r3 = 0
            if (r1 == 0) goto L_0x001a
            boolean r1 = r11.H()
            if (r1 == 0) goto L_0x0016
            int r0 = java.lang.Math.min(r0, r2)
            goto L_0x001a
        L_0x0016:
            int r0 = java.lang.Math.min(r0, r3)
        L_0x001a:
            int r7 = r11.u()
            int r8 = r11.v()
            r9 = 0
            r4 = r10
            r5 = r11
            r6 = r0
            r4.B0(r5, r6, r7, r8, r9)
            android.view.View r1 = r11.J
            if (r1 == 0) goto L_0x008c
            a.b.c.a.e r1 = r10.g0(r11)
            if (r1 == 0) goto L_0x004b
            android.view.View r4 = r1.J
            android.view.ViewGroup r5 = r11.I
            int r6 = r5.indexOfChild(r4)
            android.view.View r7 = r11.J
            int r7 = r5.indexOfChild(r7)
            if (r7 >= r6) goto L_0x004b
            r5.removeViewAt(r7)
            android.view.View r8 = r11.J
            r5.addView(r8, r6)
        L_0x004b:
            boolean r4 = r11.O
            if (r4 == 0) goto L_0x008c
            android.view.ViewGroup r4 = r11.I
            if (r4 == 0) goto L_0x008c
            float r4 = r11.Q
            r5 = 0
            int r6 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r6 <= 0) goto L_0x005f
            android.view.View r6 = r11.J
            r6.setAlpha(r4)
        L_0x005f:
            r11.Q = r5
            r11.O = r3
            int r3 = r11.u()
            int r4 = r11.v()
            a.b.c.a.k$g r2 = r10.q0(r11, r3, r2, r4)
            if (r2 == 0) goto L_0x008c
            android.view.View r3 = r11.J
            U0(r3, r2)
            android.view.animation.Animation r3 = r2.f94a
            if (r3 == 0) goto L_0x0080
            android.view.View r4 = r11.J
            r4.startAnimation(r3)
            goto L_0x008c
        L_0x0080:
            android.animation.Animator r3 = r2.f95b
            android.view.View r4 = r11.J
            r3.setTarget(r4)
            android.animation.Animator r3 = r2.f95b
            r3.start()
        L_0x008c:
            boolean r1 = r11.P
            if (r1 == 0) goto L_0x0093
            r10.n(r11)
        L_0x0093:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.y0(a.b.c.a.e):void");
    }

    public void z0(int newState, boolean always) {
        i iVar;
        if (this.l == null && newState != 0) {
            throw new IllegalStateException("No activity");
        } else if (always || newState != this.k) {
            this.k = newState;
            if (this.e != null) {
                int numAdded = this.d.size();
                for (int i2 = 0; i2 < numAdded; i2++) {
                    y0(this.d.get(i2));
                }
                int numActive = this.e.size();
                for (int i3 = 0; i3 < numActive; i3++) {
                    e f2 = this.e.valueAt(i3);
                    if (f2 != null && ((f2.m || f2.C) && !f2.O)) {
                        y0(f2);
                    }
                }
                Z0();
                if (this.p && (iVar = this.l) != null && this.k == 4) {
                    iVar.n();
                    this.p = false;
                }
            }
        }
    }

    public void Z0() {
        if (this.e != null) {
            for (int i2 = 0; i2 < this.e.size(); i2++) {
                e f2 = this.e.valueAt(i2);
                if (f2 != null) {
                    D0(f2);
                }
            }
        }
    }

    public void r0(e f2) {
        if (f2.f < 0) {
            int i2 = this.f80c;
            this.f80c = i2 + 1;
            f2.R0(i2, this.n);
            if (this.e == null) {
                this.e = new SparseArray<>();
            }
            this.e.put(f2.f, f2);
        }
    }

    public void t0(e f2) {
        int i2 = f2.f;
        if (i2 >= 0) {
            this.e.put(i2, (Object) null);
            f2.D();
        }
    }

    public void f(e fragment, boolean moveToStateNow) {
        r0(fragment);
        if (fragment.C) {
            return;
        }
        if (!this.d.contains(fragment)) {
            synchronized (this.d) {
                this.d.add(fragment);
            }
            fragment.l = true;
            fragment.m = false;
            if (fragment.J == null) {
                fragment.P = false;
            }
            if (fragment.F && fragment.G) {
                this.p = true;
            }
            if (moveToStateNow) {
                A0(fragment);
                return;
            }
            return;
        }
        throw new IllegalStateException("Fragment already added: " + fragment);
    }

    public void I0(e fragment) {
        boolean inactive = !fragment.H();
        if (!fragment.C || inactive) {
            synchronized (this.d) {
                this.d.remove(fragment);
            }
            if (fragment.F && fragment.G) {
                this.p = true;
            }
            fragment.l = false;
            fragment.m = true;
        }
    }

    public void o0(e fragment) {
        if (!fragment.B) {
            fragment.B = true;
            fragment.P = true ^ fragment.P;
        }
    }

    public void Y0(e fragment) {
        if (fragment.B) {
            fragment.B = false;
            fragment.P = !fragment.P;
        }
    }

    public void o(e fragment) {
        if (!fragment.C) {
            fragment.C = true;
            if (fragment.l) {
                synchronized (this.d) {
                    this.d.remove(fragment);
                }
                if (fragment.F && fragment.G) {
                    this.p = true;
                }
                fragment.l = false;
            }
        }
    }

    public void i(e fragment) {
        if (fragment.C) {
            fragment.C = false;
            if (fragment.l) {
                return;
            }
            if (!this.d.contains(fragment)) {
                synchronized (this.d) {
                    this.d.add(fragment);
                }
                fragment.l = true;
                if (fragment.F && fragment.G) {
                    this.p = true;
                    return;
                }
                return;
            }
            throw new IllegalStateException("Fragment already added: " + fragment);
        }
    }

    public e d0(int id) {
        for (int i2 = this.d.size() - 1; i2 >= 0; i2--) {
            e f2 = this.d.get(i2);
            if (f2 != null && f2.y == id) {
                return f2;
            }
        }
        SparseArray<e> sparseArray = this.e;
        if (sparseArray == null) {
            return null;
        }
        for (int i3 = sparseArray.size() - 1; i3 >= 0; i3--) {
            e f3 = this.e.valueAt(i3);
            if (f3 != null && f3.y == id) {
                return f3;
            }
        }
        return null;
    }

    public e e0(String tag) {
        if (tag != null) {
            for (int i2 = this.d.size() - 1; i2 >= 0; i2--) {
                e f2 = this.d.get(i2);
                if (f2 != null && tag.equals(f2.A)) {
                    return f2;
                }
            }
        }
        SparseArray<e> sparseArray = this.e;
        if (sparseArray == null || tag == null) {
            return null;
        }
        for (int i3 = sparseArray.size() - 1; i3 >= 0; i3--) {
            e f3 = this.e.valueAt(i3);
            if (f3 != null && tag.equals(f3.A)) {
                return f3;
            }
        }
        return null;
    }

    public e f0(String who) {
        SparseArray<e> sparseArray = this.e;
        if (sparseArray == null || who == null) {
            return null;
        }
        for (int i2 = sparseArray.size() - 1; i2 >= 0; i2--) {
            e f2 = this.e.valueAt(i2);
            if (f2 != null) {
                e f3 = f2.f(who);
                e f4 = f3;
                if (f3 != null) {
                    return f4;
                }
            }
        }
        return null;
    }

    public final void k() {
        if (c()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
    }

    public boolean c() {
        return this.q || this.r;
    }

    public void S0() {
        synchronized (this) {
            if ((this.z != null && !this.z.isEmpty()) || 0 != 0) {
                this.l.g().removeCallbacks(this.B);
                this.l.g().post(this.B);
            }
        }
    }

    public void T0(int index, c bse) {
        synchronized (this) {
            if (this.h == null) {
                this.h = new ArrayList<>();
            }
            int N = this.h.size();
            if (index < N) {
                this.h.set(index, bse);
            } else {
                while (N < index) {
                    this.h.add((Object) null);
                    if (this.i == null) {
                        this.i = new ArrayList<>();
                    }
                    this.i.add(Integer.valueOf(N));
                    N++;
                }
                this.h.add(bse);
            }
        }
    }

    public void i0(int index) {
        synchronized (this) {
            this.h.set(index, (Object) null);
            if (this.i == null) {
                this.i = new ArrayList<>();
            }
            this.i.add(Integer.valueOf(index));
        }
    }

    public final void X(boolean allowStateLoss) {
        if (this.f79b) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        } else if (this.l == null) {
            throw new IllegalStateException("Fragment host has been destroyed");
        } else if (Looper.myLooper() == this.l.g().getLooper()) {
            if (!allowStateLoss) {
                k();
            }
            if (this.u == null) {
                this.u = new ArrayList<>();
                this.v = new ArrayList<>();
            }
            this.f79b = true;
            try {
                c0((ArrayList<c>) null, (ArrayList<Boolean>) null);
            } finally {
                this.f79b = false;
            }
        } else {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
    }

    public final void l() {
        this.f79b = false;
        this.v.clear();
        this.u.clear();
    }

    public boolean Z() {
        X(true);
        j0(this.u, this.v);
        V();
        j();
        return false;
    }

    public final void c0(ArrayList<c> records, ArrayList<Boolean> isRecordPop) {
        int index;
        ArrayList<l> arrayList = this.z;
        int numPostponed = arrayList == null ? 0 : arrayList.size();
        int i2 = 0;
        while (i2 < numPostponed) {
            l listener = this.z.get(i2);
            if (records != null && !listener.f101a && (index = records.indexOf(listener.f102b)) != -1 && isRecordPop.get(index).booleanValue()) {
                listener.a();
            } else if (listener.c() != 0 || (records != null && listener.f102b.j(records, 0, records.size()))) {
                this.z.remove(i2);
                i2--;
                numPostponed--;
                if (records != null && !listener.f101a) {
                    int indexOf = records.indexOf(listener.f102b);
                    int index2 = indexOf;
                    if (indexOf != -1 && isRecordPop.get(index2).booleanValue()) {
                        listener.a();
                    }
                }
                listener.b();
            }
            i2++;
        }
    }

    public final void J0(ArrayList<c> records, ArrayList<Boolean> isRecordPop) {
        if (records != null && !records.isEmpty()) {
            if (isRecordPop == null || records.size() != isRecordPop.size()) {
                throw new IllegalStateException("Internal error with the back stack records");
            }
            c0(records, isRecordPop);
            int numRecords = records.size();
            int startIndex = 0;
            int recordNum = 0;
            while (recordNum < numRecords) {
                if (!records.get(recordNum).r) {
                    if (startIndex != recordNum) {
                        b0(records, isRecordPop, startIndex, recordNum);
                    }
                    int reorderingEnd = recordNum + 1;
                    if (isRecordPop.get(recordNum).booleanValue()) {
                        while (reorderingEnd < numRecords && isRecordPop.get(reorderingEnd).booleanValue() && !records.get(reorderingEnd).r) {
                            reorderingEnd++;
                        }
                    }
                    b0(records, isRecordPop, recordNum, reorderingEnd);
                    startIndex = reorderingEnd;
                    recordNum = reorderingEnd - 1;
                }
                recordNum++;
            }
            if (startIndex != numRecords) {
                b0(records, isRecordPop, startIndex, numRecords);
            }
        }
    }

    public final void b0(ArrayList<c> records, ArrayList<Boolean> isRecordPop, int startIndex, int endIndex) {
        int i2;
        ArrayList<c> arrayList = records;
        ArrayList<Boolean> arrayList2 = isRecordPop;
        int i3 = startIndex;
        int i4 = endIndex;
        boolean allowReordering = arrayList.get(i3).r;
        ArrayList<e> arrayList3 = this.w;
        if (arrayList3 == null) {
            this.w = new ArrayList<>();
        } else {
            arrayList3.clear();
        }
        this.w.addAll(this.d);
        int recordNum = startIndex;
        boolean addToBackStack = false;
        e oldPrimaryNav = n0();
        while (true) {
            boolean z2 = true;
            if (recordNum >= i4) {
                break;
            }
            c record = arrayList.get(recordNum);
            if (!arrayList2.get(recordNum).booleanValue()) {
                oldPrimaryNav = record.g(this.w, oldPrimaryNav);
            } else {
                oldPrimaryNav = record.o(this.w, oldPrimaryNav);
            }
            if (!addToBackStack && !record.i) {
                z2 = false;
            }
            addToBackStack = z2;
            recordNum++;
        }
        this.w.clear();
        if (!allowReordering) {
            p.C(this, records, isRecordPop, startIndex, endIndex, false);
        }
        a0(records, isRecordPop, startIndex, endIndex);
        int postponeIndex = endIndex;
        if (allowReordering) {
            a.b.c.g.b bVar = new a.b.c.g.b();
            e(bVar);
            postponeIndex = G0(records, isRecordPop, startIndex, endIndex, bVar);
            v0(bVar);
        }
        if (postponeIndex != i3 && allowReordering) {
            p.C(this, records, isRecordPop, startIndex, postponeIndex, true);
            z0(this.k, true);
        }
        for (int recordNum2 = startIndex; recordNum2 < i4; recordNum2++) {
            c record2 = arrayList.get(recordNum2);
            if (arrayList2.get(recordNum2).booleanValue() && (i2 = record2.k) >= 0) {
                i0(i2);
                record2.k = -1;
            }
            record2.m();
        }
        if (addToBackStack) {
            K0();
        }
    }

    public final void v0(a.b.c.g.b<e> fragments) {
        int numAdded = fragments.size();
        for (int i2 = 0; i2 < numAdded; i2++) {
            e fragment = fragments.i(i2);
            if (!fragment.l) {
                View view = fragment.C();
                fragment.Q = view.getAlpha();
                view.setAlpha(0.0f);
            }
        }
    }

    public final int G0(ArrayList<c> records, ArrayList<Boolean> isRecordPop, int startIndex, int endIndex, a.b.c.g.b<e> added) {
        int postponeIndex = endIndex;
        for (int i2 = endIndex - 1; i2 >= startIndex; i2--) {
            c record = records.get(i2);
            boolean isPop = isRecordPop.get(i2).booleanValue();
            if (record.l() && !record.j(records, i2 + 1, endIndex)) {
                if (this.z == null) {
                    this.z = new ArrayList<>();
                }
                l listener = new l(record, isPop);
                this.z.add(listener);
                record.n(listener);
                if (isPop) {
                    record.e();
                } else {
                    record.f(false);
                }
                postponeIndex--;
                if (i2 != postponeIndex) {
                    records.remove(i2);
                    records.add(postponeIndex, record);
                }
                e(added);
            }
        }
        return postponeIndex;
    }

    public void m(c record, boolean isPop, boolean runTransitions, boolean moveToState) {
        if (isPop) {
            record.f(moveToState);
        } else {
            record.e();
        }
        ArrayList<BackStackRecord> records = new ArrayList<>(1);
        ArrayList arrayList = new ArrayList(1);
        records.add(record);
        arrayList.add(Boolean.valueOf(isPop));
        if (runTransitions) {
            p.C(this, records, arrayList, 0, 1, true);
        }
        if (moveToState) {
            z0(this.k, true);
        }
        SparseArray<e> sparseArray = this.e;
        if (sparseArray != null) {
            int numActive = sparseArray.size();
            for (int i2 = 0; i2 < numActive; i2++) {
                e fragment = this.e.valueAt(i2);
                if (fragment != null && fragment.J != null && fragment.O && record.i(fragment.z)) {
                    float f2 = fragment.Q;
                    if (f2 > 0.0f) {
                        fragment.J.setAlpha(f2);
                    }
                    if (moveToState) {
                        fragment.Q = 0.0f;
                    } else {
                        fragment.Q = -1.0f;
                        fragment.O = false;
                    }
                }
            }
        }
    }

    public final e g0(e f2) {
        ViewGroup container = f2.I;
        View view = f2.J;
        if (container == null || view == null) {
            return null;
        }
        for (int i2 = this.d.indexOf(f2) - 1; i2 >= 0; i2--) {
            e underFragment = this.d.get(i2);
            if (underFragment.I == container && underFragment.J != null) {
                return underFragment;
            }
        }
        return null;
    }

    public static void a0(ArrayList<c> records, ArrayList<Boolean> isRecordPop, int startIndex, int endIndex) {
        for (int i2 = startIndex; i2 < endIndex; i2++) {
            c record = records.get(i2);
            boolean moveToState = true;
            if (isRecordPop.get(i2).booleanValue()) {
                record.b(-1);
                if (i2 != endIndex - 1) {
                    moveToState = false;
                }
                record.f(moveToState);
            } else {
                record.b(1);
                record.e();
            }
        }
    }

    public final void e(a.b.c.g.b<e> added) {
        int i2 = this.k;
        if (i2 >= 1) {
            int state = Math.min(i2, 3);
            int numAdded = this.d.size();
            for (int i3 = 0; i3 < numAdded; i3++) {
                e fragment = this.d.get(i3);
                if (fragment.f63b < state) {
                    B0(fragment, state, fragment.t(), fragment.u(), false);
                    if (fragment.J != null && !fragment.B && fragment.O) {
                        added.add(fragment);
                    }
                }
            }
        }
    }

    public final void h0() {
        if (this.z != null) {
            while (!this.z.isEmpty()) {
                this.z.remove(0).b();
            }
        }
    }

    public final void W() {
        SparseArray<e> sparseArray = this.e;
        int numFragments = sparseArray == null ? 0 : sparseArray.size();
        for (int i2 = 0; i2 < numFragments; i2++) {
            e fragment = this.e.valueAt(i2);
            if (fragment != null) {
                if (fragment.j() != null) {
                    int stateAfterAnimating = fragment.B();
                    View animatingAway = fragment.j();
                    Animation animation = animatingAway.getAnimation();
                    if (animation != null) {
                        animation.cancel();
                        animatingAway.clearAnimation();
                    }
                    fragment.N0((View) null);
                    B0(fragment, stateAfterAnimating, 0, 0, false);
                } else if (fragment.k() != null) {
                    fragment.k().end();
                }
            }
        }
    }

    public final boolean j0(ArrayList<c> arrayList, ArrayList<Boolean> arrayList2) {
        synchronized (this) {
        }
        return false;
    }

    public void V() {
        if (this.t) {
            this.t = false;
            Z0();
        }
    }

    public void K0() {
    }

    public boolean F0(ArrayList<c> records, ArrayList<Boolean> isRecordPop, String name, int id, int flags) {
        ArrayList<c> arrayList = this.f;
        if (arrayList == null) {
            return false;
        }
        if (name == null && id < 0 && (flags & 1) == 0) {
            int last = arrayList.size() - 1;
            if (last < 0) {
                return false;
            }
            records.add(this.f.remove(last));
            isRecordPop.add(true);
        } else {
            int index = -1;
            if (name != null || id >= 0) {
                int index2 = this.f.size() - 1;
                while (index >= 0) {
                    c bss = this.f.get(index);
                    if ((name != null && name.equals(bss.h())) || (id >= 0 && id == bss.k)) {
                        break;
                    }
                    index2 = index - 1;
                }
                if (index < 0) {
                    return false;
                }
                if ((flags & 1) != 0) {
                    index--;
                    while (index >= 0) {
                        c bss2 = this.f.get(index);
                        if ((name == null || !name.equals(bss2.h())) && (id < 0 || id != bss2.k)) {
                            break;
                        }
                        index--;
                    }
                }
            }
            if (index == this.f.size() - 1) {
                return false;
            }
            for (int i2 = this.f.size() - 1; i2 > index; i2--) {
                records.add(this.f.remove(i2));
                isRecordPop.add(true);
            }
        }
        return true;
    }

    public l M0() {
        W0(this.A);
        return this.A;
    }

    public static void W0(l nonConfig) {
        if (nonConfig != null) {
            List<e> b2 = nonConfig.b();
            if (b2 != null) {
                for (e fragment : b2) {
                    fragment.E = true;
                }
            }
            List<l> a2 = nonConfig.a();
            if (a2 != null) {
                for (l child : a2) {
                    W0(child);
                }
            }
        }
    }

    public void R0() {
        l child;
        ArrayList<Fragment> fragments = null;
        ArrayList<FragmentManagerNonConfig> childFragments = null;
        ArrayList<ViewModelStore> viewModelStores = null;
        if (this.e != null) {
            for (int i2 = 0; i2 < this.e.size(); i2++) {
                e f2 = this.e.valueAt(i2);
                if (f2 != null) {
                    if (f2.D) {
                        if (fragments == null) {
                            fragments = new ArrayList<>();
                        }
                        fragments.add(f2);
                        e eVar = f2.i;
                        f2.j = eVar != null ? eVar.f : -1;
                    }
                    k kVar = f2.u;
                    if (kVar != null) {
                        kVar.R0();
                        child = f2.u.A;
                    } else {
                        child = f2.v;
                    }
                    if (childFragments == null && child != null) {
                        childFragments = new ArrayList<>(this.e.size());
                        for (int j2 = 0; j2 < i2; j2++) {
                            childFragments.add((Object) null);
                        }
                    }
                    if (childFragments != null) {
                        childFragments.add(child);
                    }
                    if (viewModelStores == null && f2.w != null) {
                        viewModelStores = new ArrayList<>(this.e.size());
                        for (int j3 = 0; j3 < i2; j3++) {
                            viewModelStores.add((Object) null);
                        }
                    }
                    if (viewModelStores != null) {
                        viewModelStores.add(f2.w);
                    }
                }
            }
        }
        if (fragments == null && childFragments == null && viewModelStores == null) {
            this.A = null;
        } else {
            this.A = new l(fragments, childFragments, viewModelStores);
        }
    }

    public void Q0(e f2) {
        if (f2.K != null) {
            SparseArray<Parcelable> sparseArray = this.y;
            if (sparseArray == null) {
                this.y = new SparseArray<>();
            } else {
                sparseArray.clear();
            }
            f2.K.saveHierarchyState(this.y);
            if (this.y.size() > 0) {
                f2.d = this.y;
                this.y = null;
            }
        }
    }

    public Bundle P0(e eVar) {
        if (this.x == null) {
            this.x = new Bundle();
        }
        eVar.H0(this.x);
        H(eVar, this.x, false);
        Bundle bundle = null;
        if (!this.x.isEmpty()) {
            Bundle bundle2 = this.x;
            this.x = null;
            bundle = bundle2;
        }
        if (eVar.J != null) {
            Q0(eVar);
        }
        if (eVar.d != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray("android:view_state", eVar.d);
        }
        if (!eVar.M) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", eVar.M);
        }
        return bundle;
    }

    public Parcelable O0() {
        int N;
        h0();
        W();
        Z();
        this.q = true;
        this.A = null;
        SparseArray<e> sparseArray = this.e;
        if (sparseArray == null || sparseArray.size() <= 0) {
            return null;
        }
        int N2 = this.e.size();
        n[] active = new n[N2];
        boolean haveFragments = false;
        for (int i2 = 0; i2 < N2; i2++) {
            e f2 = this.e.valueAt(i2);
            if (f2 != null) {
                if (f2.f >= 0) {
                    haveFragments = true;
                    n fs = new n(f2);
                    active[i2] = fs;
                    if (f2.f63b <= 0 || fs.l != null) {
                        fs.l = f2.f64c;
                    } else {
                        Bundle P0 = P0(f2);
                        fs.l = P0;
                        e eVar = f2.i;
                        if (eVar == null) {
                            continue;
                        } else if (eVar.f >= 0) {
                            if (P0 == null) {
                                fs.l = new Bundle();
                            }
                            H0(fs.l, "android:target_state", f2.i);
                            int i3 = f2.k;
                            if (i3 != 0) {
                                fs.l.putInt("android:target_req_state", i3);
                            }
                        } else {
                            a1(new IllegalStateException("Failure saving state: " + f2 + " has target not in fragment manager: " + f2.i));
                            throw null;
                        }
                    }
                } else {
                    a1(new IllegalStateException("Failure saving state: active " + f2 + " has cleared index: " + f2.f));
                    throw null;
                }
            }
        }
        if (!haveFragments) {
            return null;
        }
        int[] added = null;
        d[] backStack = null;
        int N3 = this.d.size();
        if (N3 > 0) {
            added = new int[N3];
            int i4 = 0;
            while (i4 < N3) {
                added[i4] = this.d.get(i4).f;
                if (added[i4] >= 0) {
                    i4++;
                } else {
                    a1(new IllegalStateException("Failure saving state: active " + this.d.get(i4) + " has cleared index: " + added[i4]));
                    throw null;
                }
            }
        }
        ArrayList<c> arrayList = this.f;
        if (arrayList != null && (N = arrayList.size()) > 0) {
            backStack = new d[N];
            for (int i5 = 0; i5 < N; i5++) {
                backStack[i5] = new d(this.f.get(i5));
            }
        }
        m fms = new m();
        fms.f107b = active;
        fms.f108c = added;
        fms.d = backStack;
        e eVar2 = this.o;
        if (eVar2 != null) {
            fms.e = eVar2.f;
        }
        fms.f = this.f80c;
        R0();
        return fms;
    }

    public void L0(Parcelable state, l nonConfig) {
        List<n> list;
        List<l> list2;
        n viewModelStore;
        if (state != null) {
            m fms = (m) state;
            if (fms.f107b != null) {
                int count = 0;
                if (nonConfig != null) {
                    List<e> b2 = nonConfig.b();
                    List<l> a2 = nonConfig.a();
                    List<n> c2 = nonConfig.c();
                    int count2 = b2 != null ? b2.size() : 0;
                    int i2 = 0;
                    while (i2 < count2) {
                        e f2 = b2.get(i2);
                        int index = 0;
                        while (true) {
                            n[] nVarArr = fms.f107b;
                            if (index >= nVarArr.length || nVarArr[index].f110c == f2.f) {
                                n[] nVarArr2 = fms.f107b;
                            } else {
                                index++;
                            }
                        }
                        n[] nVarArr22 = fms.f107b;
                        if (index != nVarArr22.length) {
                            n fs = nVarArr22[index];
                            fs.m = f2;
                            f2.d = null;
                            f2.r = 0;
                            f2.o = false;
                            f2.l = false;
                            f2.i = null;
                            Bundle bundle = fs.l;
                            if (bundle != null) {
                                bundle.setClassLoader(this.l.e().getClassLoader());
                                f2.d = fs.l.getSparseParcelableArray("android:view_state");
                                f2.f64c = fs.l;
                            }
                            i2++;
                        } else {
                            a1(new IllegalStateException("Could not find active fragment with index " + f2.f));
                            throw null;
                        }
                    }
                    list = c2;
                    list2 = a2;
                } else {
                    list = null;
                    list2 = null;
                }
                this.e = new SparseArray<>(fms.f107b.length);
                int i3 = 0;
                while (true) {
                    n[] nVarArr3 = fms.f107b;
                    if (i3 >= nVarArr3.length) {
                        break;
                    }
                    n fs2 = nVarArr3[i3];
                    if (fs2 != null) {
                        l childNonConfig = null;
                        if (list2 != null && i3 < list2.size()) {
                            childNonConfig = list2.get(i3);
                        }
                        if (list == null || i3 >= list.size()) {
                            viewModelStore = null;
                        } else {
                            viewModelStore = list.get(i3);
                        }
                        e f3 = fs2.a(this.l, this.m, this.n, childNonConfig, viewModelStore);
                        this.e.put(f3.f, f3);
                        fs2.m = null;
                    }
                    i3++;
                }
                if (nonConfig != null) {
                    List<e> b3 = nonConfig.b();
                    if (b3 != null) {
                        count = b3.size();
                    }
                    for (int i4 = 0; i4 < count; i4++) {
                        e f4 = b3.get(i4);
                        int i5 = f4.j;
                        if (i5 >= 0) {
                            e eVar = this.e.get(i5);
                            f4.i = eVar;
                            if (eVar == null) {
                                Log.w("FragmentManager", "Re-attaching retained fragment " + f4 + " target no longer exists: " + f4.j);
                            }
                        }
                    }
                }
                this.d.clear();
                if (fms.f108c != null) {
                    int i6 = 0;
                    while (true) {
                        int[] iArr = fms.f108c;
                        if (i6 >= iArr.length) {
                            break;
                        }
                        e f5 = this.e.get(iArr[i6]);
                        if (f5 != null) {
                            f5.l = true;
                            if (!this.d.contains(f5)) {
                                synchronized (this.d) {
                                    this.d.add(f5);
                                }
                                i6++;
                            } else {
                                throw new IllegalStateException("Already added!");
                            }
                        } else {
                            a1(new IllegalStateException("No instantiated fragment for index #" + fms.f108c[i6]));
                            throw null;
                        }
                    }
                }
                if (fms.d != null) {
                    this.f = new ArrayList<>(fms.d.length);
                    int i7 = 0;
                    while (true) {
                        d[] dVarArr = fms.d;
                        if (i7 >= dVarArr.length) {
                            break;
                        }
                        c bse = dVarArr[i7].a(this);
                        this.f.add(bse);
                        int i8 = bse.k;
                        if (i8 >= 0) {
                            T0(i8, bse);
                        }
                        i7++;
                    }
                } else {
                    this.f = null;
                }
                int i9 = fms.e;
                if (i9 >= 0) {
                    this.o = this.e.get(i9);
                }
                this.f80c = fms.f;
            }
        }
    }

    public final void j() {
        SparseArray<e> sparseArray = this.e;
        if (sparseArray != null) {
            for (int i2 = sparseArray.size() - 1; i2 >= 0; i2--) {
                if (this.e.valueAt(i2) == null) {
                    SparseArray<e> sparseArray2 = this.e;
                    sparseArray2.delete(sparseArray2.keyAt(i2));
                }
            }
        }
    }

    public void h(i host, g container, e parent) {
        if (this.l == null) {
            this.l = host;
            this.m = container;
            this.n = parent;
            return;
        }
        throw new IllegalStateException("Already attached");
    }

    public void C0() {
        this.A = null;
        this.q = false;
        this.r = false;
        int addedCount = this.d.size();
        for (int i2 = 0; i2 < addedCount; i2++) {
            e fragment = this.d.get(i2);
            if (fragment != null) {
                fragment.L();
            }
        }
    }

    public void s() {
        this.q = false;
        this.r = false;
        T(1);
    }

    public void p() {
        this.q = false;
        this.r = false;
        T(2);
    }

    public void S() {
        this.q = false;
        this.r = false;
        T(3);
    }

    public void R() {
        this.q = false;
        this.r = false;
        T(4);
    }

    public void O() {
        T(3);
    }

    public void U() {
        this.r = true;
        T(2);
    }

    public void v() {
        T(1);
    }

    public void u() {
        this.s = true;
        Z();
        T(0);
        this.l = null;
        this.m = null;
        this.n = null;
    }

    /* JADX INFO: finally extract failed */
    public final void T(int nextState) {
        try {
            this.f79b = true;
            z0(nextState, false);
            this.f79b = false;
            Z();
        } catch (Throwable th) {
            this.f79b = false;
            throw th;
        }
    }

    public void x(boolean z2) {
        int size = this.d.size();
        while (true) {
            size--;
            if (size >= 0) {
                e eVar = this.d.get(size);
                if (eVar != null) {
                    eVar.A0(z2);
                }
            } else {
                return;
            }
        }
    }

    public void P(boolean z2) {
        int size = this.d.size();
        while (true) {
            size--;
            if (size >= 0) {
                e eVar = this.d.get(size);
                if (eVar != null) {
                    eVar.E0(z2);
                }
            } else {
                return;
            }
        }
    }

    public void q(Configuration configuration) {
        for (int i2 = 0; i2 < this.d.size(); i2++) {
            e eVar = this.d.get(i2);
            if (eVar != null) {
                eVar.q0(configuration);
            }
        }
    }

    public void w() {
        for (int i2 = 0; i2 < this.d.size(); i2++) {
            e eVar = this.d.get(i2);
            if (eVar != null) {
                eVar.z0();
            }
        }
    }

    public boolean t(Menu menu, MenuInflater menuInflater) {
        if (this.k < 1) {
            return false;
        }
        ArrayList<e> arrayList = null;
        boolean z2 = false;
        for (int i2 = 0; i2 < this.d.size(); i2++) {
            e eVar = this.d.get(i2);
            if (eVar != null && eVar.t0(menu, menuInflater)) {
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                }
                arrayList.add(eVar);
                z2 = true;
            }
        }
        if (this.g != null) {
            for (int i3 = 0; i3 < this.g.size(); i3++) {
                e eVar2 = this.g.get(i3);
                if (arrayList == null || !arrayList.contains(eVar2)) {
                    eVar2.X();
                }
            }
        }
        this.g = arrayList;
        return z2;
    }

    public boolean Q(Menu menu) {
        if (this.k < 1) {
            return false;
        }
        boolean z2 = false;
        for (int i2 = 0; i2 < this.d.size(); i2++) {
            e eVar = this.d.get(i2);
            if (eVar != null && eVar.F0(menu)) {
                z2 = true;
            }
        }
        return z2;
    }

    public boolean M(MenuItem menuItem) {
        if (this.k < 1) {
            return false;
        }
        for (int i2 = 0; i2 < this.d.size(); i2++) {
            e eVar = this.d.get(i2);
            if (eVar != null && eVar.B0(menuItem)) {
                return true;
            }
        }
        return false;
    }

    public boolean r(MenuItem menuItem) {
        if (this.k < 1) {
            return false;
        }
        for (int i2 = 0; i2 < this.d.size(); i2++) {
            e eVar = this.d.get(i2);
            if (eVar != null && eVar.r0(menuItem)) {
                return true;
            }
        }
        return false;
    }

    public void N(Menu menu) {
        if (this.k >= 1) {
            for (int i2 = 0; i2 < this.d.size(); i2++) {
                e eVar = this.d.get(i2);
                if (eVar != null) {
                    eVar.C0(menu);
                }
            }
        }
    }

    public void V0(e f2) {
        if (f2 == null || (this.e.get(f2.f) == f2 && (f2.t == null || f2.r() == this))) {
            this.o = f2;
            return;
        }
        throw new IllegalArgumentException("Fragment " + f2 + " is not an active fragment of FragmentManager " + this);
    }

    public e n0() {
        return this.o;
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void E(a.b.c.a.e r4, android.content.Context r5, boolean r6) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.E(r4, r5, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r6 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r6 = 0
            throw r6
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.E(a.b.c.a.e, android.content.Context, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void z(a.b.c.a.e r4, android.content.Context r5, boolean r6) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.z(r4, r5, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r6 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r6 = 0
            throw r6
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.z(a.b.c.a.e, android.content.Context, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void F(a.b.c.a.e r4, android.os.Bundle r5, boolean r6) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.F(r4, r5, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r6 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r6 = 0
            throw r6
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.F(a.b.c.a.e, android.os.Bundle, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void A(a.b.c.a.e r4, android.os.Bundle r5, boolean r6) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.A(r4, r5, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r6 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r6 = 0
            throw r6
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.A(a.b.c.a.e, android.os.Bundle, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void y(a.b.c.a.e r4, android.os.Bundle r5, boolean r6) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.y(r4, r5, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r6 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r6 = 0
            throw r6
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.y(a.b.c.a.e, android.os.Bundle, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void K(a.b.c.a.e r4, android.view.View r5, android.os.Bundle r6, boolean r7) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.K(r4, r5, r6, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r7 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r7 = 0
            throw r7
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.K(a.b.c.a.e, android.view.View, android.os.Bundle, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void I(a.b.c.a.e r4, boolean r5) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.I(r4, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r5 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r5 = 0
            throw r5
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.I(a.b.c.a.e, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void G(a.b.c.a.e r4, boolean r5) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.G(r4, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r5 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r5 = 0
            throw r5
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.G(a.b.c.a.e, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void D(a.b.c.a.e r4, boolean r5) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.D(r4, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r5 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r5 = 0
            throw r5
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.D(a.b.c.a.e, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void J(a.b.c.a.e r4, boolean r5) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.J(r4, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r5 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r5 = 0
            throw r5
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.J(a.b.c.a.e, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void H(a.b.c.a.e r4, android.os.Bundle r5, boolean r6) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.H(r4, r5, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r6 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r6 = 0
            throw r6
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.H(a.b.c.a.e, android.os.Bundle, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void L(a.b.c.a.e r4, boolean r5) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.L(r4, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r5 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r5 = 0
            throw r5
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.L(a.b.c.a.e, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void B(a.b.c.a.e r4, boolean r5) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.B(r4, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r5 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r5 = 0
            throw r5
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.B(a.b.c.a.e, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void C(a.b.c.a.e r4, boolean r5) {
        /*
            r3 = this;
            a.b.c.a.e r0 = r3.n
            if (r0 == 0) goto L_0x0013
            a.b.c.a.j r0 = r0.r()
            boolean r1 = r0 instanceof a.b.c.a.k
            if (r1 == 0) goto L_0x0013
            r1 = r0
            a.b.c.a.k r1 = (a.b.c.a.k) r1
            r2 = 1
            r1.C(r4, r2)
        L_0x0013:
            java.util.concurrent.CopyOnWriteArrayList<a.b.c.a.k$j> r0 = r3.j
            java.util.Iterator r0 = r0.iterator()
        L_0x0019:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002e
            java.lang.Object r1 = r0.next()
            a.b.c.a.k$j r1 = (a.b.c.a.k.j) r1
            if (r5 == 0) goto L_0x002c
            boolean r2 = r1.f99a
            if (r2 != 0) goto L_0x002c
            goto L_0x0019
        L_0x002c:
            r5 = 0
            throw r5
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.k.C(a.b.c.a.e, boolean):void");
    }

    public static int N0(int transit) {
        if (transit == 4097) {
            return 8194;
        }
        if (transit == 4099) {
            return 4099;
        }
        if (transit != 8194) {
            return 0;
        }
        return 4097;
    }

    public static int b1(int transit, boolean enter) {
        if (transit == 4097) {
            return enter ? 1 : 2;
        } else if (transit == 4099) {
            return enter ? 5 : 6;
        } else if (transit != 8194) {
            return -1;
        } else {
            return enter ? 3 : 4;
        }
    }

    public View onCreateView(View parent, String name, Context context, AttributeSet attrs) {
        String fname;
        e fragment;
        Context context2 = context;
        AttributeSet attributeSet = attrs;
        if (!"fragment".equals(name)) {
            return null;
        }
        String fname2 = attributeSet.getAttributeValue((String) null, "class");
        TypedArray a2 = context2.obtainStyledAttributes(attributeSet, C0006k.f100a);
        int i2 = 0;
        if (fname2 == null) {
            fname = a2.getString(0);
        } else {
            fname = fname2;
        }
        int id = a2.getResourceId(1, -1);
        String tag = a2.getString(2);
        a2.recycle();
        if (!e.K(this.l.e(), fname)) {
            return null;
        }
        if (parent != null) {
            i2 = parent.getId();
        }
        int containerId = i2;
        if (containerId == -1 && id == -1 && tag == null) {
            throw new IllegalArgumentException(attrs.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + fname);
        }
        e fragment2 = id != -1 ? d0(id) : null;
        if (fragment2 == null && tag != null) {
            fragment2 = e0(tag);
        }
        if (fragment2 == null && containerId != -1) {
            fragment2 = d0(containerId);
        }
        if (fragment2 == null) {
            e fragment3 = this.m.a(context2, fname, (Bundle) null);
            fragment3.n = true;
            fragment3.y = id != 0 ? id : containerId;
            fragment3.z = containerId;
            fragment3.A = tag;
            fragment3.o = true;
            fragment3.s = this;
            i iVar = this.l;
            fragment3.t = iVar;
            iVar.e();
            fragment3.d0(attributeSet, fragment3.f64c);
            f(fragment3, true);
            fragment = fragment3;
        } else if (!fragment2.o) {
            fragment2.o = true;
            i iVar2 = this.l;
            fragment2.t = iVar2;
            if (!fragment2.E) {
                iVar2.e();
                fragment2.d0(attributeSet, fragment2.f64c);
            }
            fragment = fragment2;
        } else {
            throw new IllegalArgumentException(attrs.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(id) + ", tag " + tag + ", or parent id 0x" + Integer.toHexString(containerId) + " with another fragment for " + fname);
        }
        if (this.k >= 1 || !fragment.n) {
            A0(fragment);
        } else {
            B0(fragment, 1, 0, 0, false);
        }
        View view = fragment.J;
        if (view != null) {
            if (id != 0) {
                view.setId(id);
            }
            if (fragment.J.getTag() == null) {
                fragment.J.setTag(tag);
            }
            return fragment.J;
        }
        throw new IllegalStateException("Fragment " + fname + " did not create a view.");
    }

    public View onCreateView(String name, Context context, AttributeSet attrs) {
        return onCreateView((View) null, name, context, attrs);
    }

    public LayoutInflater.Factory2 m0() {
        return this;
    }

    public static class l implements e.f {

        /* renamed from: a  reason: collision with root package name */
        public final boolean f101a;

        /* renamed from: b  reason: collision with root package name */
        public final c f102b;

        /* renamed from: c  reason: collision with root package name */
        public int f103c;

        public l(c record, boolean isBack) {
            this.f101a = isBack;
            this.f102b = record;
        }

        public void d() {
            int i = this.f103c - 1;
            this.f103c = i;
            if (i == 0) {
                this.f102b.f55a.S0();
            }
        }

        public void e() {
            this.f103c++;
        }

        public boolean c() {
            return this.f103c == 0;
        }

        public void b() {
            boolean z = false;
            boolean canceled = this.f103c > 0;
            k manager = this.f102b.f55a;
            int numAdded = manager.d.size();
            for (int i = 0; i < numAdded; i++) {
                e fragment = manager.d.get(i);
                fragment.U0((e.f) null);
                if (canceled && fragment.I()) {
                    fragment.W0();
                }
            }
            c cVar = this.f102b;
            k kVar = cVar.f55a;
            boolean z2 = this.f101a;
            if (!canceled) {
                z = true;
            }
            kVar.m(cVar, z2, z, true);
        }

        public void a() {
            c cVar = this.f102b;
            cVar.f55a.m(cVar, this.f101a, false, false);
        }
    }

    public static class g {

        /* renamed from: a  reason: collision with root package name */
        public final Animation f94a;

        /* renamed from: b  reason: collision with root package name */
        public final Animator f95b;

        public g(Animation animation) {
            this.f94a = animation;
            this.f95b = null;
            if (animation == null) {
                throw new IllegalStateException("Animation cannot be null");
            }
        }

        public g(Animator animator) {
            this.f94a = null;
            this.f95b = animator;
            if (animator == null) {
                throw new IllegalStateException("Animator cannot be null");
            }
        }
    }

    public static class f implements Animation.AnimationListener {

        /* renamed from: a  reason: collision with root package name */
        public final Animation.AnimationListener f93a;

        public f(Animation.AnimationListener wrapped) {
            this.f93a = wrapped;
        }

        public void onAnimationStart(Animation animation) {
            Animation.AnimationListener animationListener = this.f93a;
            if (animationListener != null) {
                animationListener.onAnimationStart(animation);
            }
        }

        public void onAnimationEnd(Animation animation) {
            Animation.AnimationListener animationListener = this.f93a;
            if (animationListener != null) {
                animationListener.onAnimationEnd(animation);
            }
        }

        public void onAnimationRepeat(Animation animation) {
            Animation.AnimationListener animationListener = this.f93a;
            if (animationListener != null) {
                animationListener.onAnimationRepeat(animation);
            }
        }
    }

    public static class e extends f {

        /* renamed from: b  reason: collision with root package name */
        public View f91b;

        public e(View v, Animation.AnimationListener listener) {
            super(listener);
            this.f91b = v;
        }

        public class a implements Runnable {
            public a() {
            }

            public void run() {
                e.this.f91b.setLayerType(0, (Paint) null);
            }
        }

        public void onAnimationEnd(Animation animation) {
            if (p.l(this.f91b) || Build.VERSION.SDK_INT >= 24) {
                this.f91b.post(new a());
            } else {
                this.f91b.setLayerType(0, (Paint) null);
            }
            super.onAnimationEnd(animation);
        }
    }

    public static class h extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        public View f96a;

        public h(View v) {
            this.f96a = v;
        }

        public void onAnimationStart(Animator animation) {
            this.f96a.setLayerType(2, (Paint) null);
        }

        public void onAnimationEnd(Animator animation) {
            this.f96a.setLayerType(0, (Paint) null);
            animation.removeListener(this);
        }
    }

    public static class i extends AnimationSet implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        public final ViewGroup f97b;

        /* renamed from: c  reason: collision with root package name */
        public final View f98c;
        public boolean d;
        public boolean e;
        public boolean f = true;

        public i(Animation animation, ViewGroup parent, View child) {
            super(false);
            this.f97b = parent;
            this.f98c = child;
            addAnimation(animation);
            this.f97b.post(this);
        }

        public boolean getTransformation(long currentTime, Transformation t) {
            this.f = true;
            if (this.d) {
                return true ^ this.e;
            }
            if (!super.getTransformation(currentTime, t)) {
                this.d = true;
                u.a(this.f97b, this);
            }
            return true;
        }

        public boolean getTransformation(long currentTime, Transformation outTransformation, float scale) {
            this.f = true;
            if (this.d) {
                return true ^ this.e;
            }
            if (!super.getTransformation(currentTime, outTransformation, scale)) {
                this.d = true;
                u.a(this.f97b, this);
            }
            return true;
        }

        public void run() {
            if (this.d || !this.f) {
                this.f97b.endViewTransition(this.f98c);
                this.e = true;
                return;
            }
            this.f = false;
            this.f97b.post(this);
        }
    }
}
