package a.b.c.h.y;

import android.view.accessibility.AccessibilityRecord;

public class c {
    public static void a(AccessibilityRecord record, int maxScrollX) {
        record.setMaxScrollX(maxScrollX);
    }

    public static void b(AccessibilityRecord record, int maxScrollY) {
        record.setMaxScrollY(maxScrollY);
    }
}
