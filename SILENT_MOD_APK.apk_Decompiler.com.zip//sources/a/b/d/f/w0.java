package a.b.d.f;

import android.os.Build;
import android.view.View;

public class w0 {
    public static void a(View view, CharSequence tooltipText) {
        if (Build.VERSION.SDK_INT >= 26) {
            view.setTooltipText(tooltipText);
        } else {
            x0.f(view, tooltipText);
        }
    }
}
