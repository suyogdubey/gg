package android.arch.lifecycle;

import a.a.b.l;

public class AndroidViewModel extends l {
}
