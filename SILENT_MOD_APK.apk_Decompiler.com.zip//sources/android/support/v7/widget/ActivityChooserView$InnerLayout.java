package android.support.v7.widget;

import a.b.d.f.t0;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class ActivityChooserView$InnerLayout extends LinearLayout {

    /* renamed from: b  reason: collision with root package name */
    public static final int[] f622b = {16842964};

    public ActivityChooserView$InnerLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        t0 a2 = t0.s(context, attrs, f622b);
        setBackgroundDrawable(a2.f(0));
        a2.u();
    }
}
