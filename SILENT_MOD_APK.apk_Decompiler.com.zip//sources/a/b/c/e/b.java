package a.b.c.e;

import a.b.c.b.c.f;
import a.b.c.c.i;
import a.b.c.e.c;
import a.b.c.g.j;
import a.b.c.g.k;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.Handler;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

public class b {

    /* renamed from: a  reason: collision with root package name */
    public static final a.b.c.g.g<String, Typeface> f182a = new a.b.c.g.g<>(16);

    /* renamed from: b  reason: collision with root package name */
    public static final c f183b = new c("fonts", 10, 10000);

    /* renamed from: c  reason: collision with root package name */
    public static final Object f184c = new Object();
    public static final k<String, ArrayList<c.d<g>>> d = new k<>();
    public static final Comparator<byte[]> e = new d();

    public static g f(Context context, a request, int style) {
        try {
            e result = c(context, (CancellationSignal) null, request);
            int resultCode = -3;
            if (result.b() == 0) {
                Typeface typeface = a.b.c.c.c.a(context, (CancellationSignal) null, result.a(), style);
                if (typeface != null) {
                    resultCode = 0;
                }
                return new g(typeface, resultCode);
            }
            if (result.b() == 1) {
                resultCode = -2;
            }
            return new g((Typeface) null, resultCode);
        } catch (PackageManager.NameNotFoundException e2) {
            return new g((Typeface) null, -1);
        }
    }

    public static final class g {

        /* renamed from: a  reason: collision with root package name */
        public final Typeface f196a;

        /* renamed from: b  reason: collision with root package name */
        public final int f197b;

        public g(Typeface typeface, int result) {
            this.f196a = typeface;
            this.f197b = result;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:34:0x007a, code lost:
        return null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x008b, code lost:
        f183b.d(r2, new a.b.c.e.b.c(r0));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x0095, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.graphics.Typeface g(android.content.Context r8, a.b.c.e.a r9, a.b.c.b.c.f.a r10, android.os.Handler r11, boolean r12, int r13, int r14) {
        /*
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = r9.c()
            r0.append(r1)
            java.lang.String r1 = "-"
            r0.append(r1)
            r0.append(r14)
            java.lang.String r0 = r0.toString()
            a.b.c.g.g<java.lang.String, android.graphics.Typeface> r1 = f182a
            java.lang.Object r1 = r1.c(r0)
            android.graphics.Typeface r1 = (android.graphics.Typeface) r1
            if (r1 == 0) goto L_0x0028
            if (r10 == 0) goto L_0x0027
            r10.d(r1)
        L_0x0027:
            return r1
        L_0x0028:
            if (r12 == 0) goto L_0x0043
            r2 = -1
            if (r13 != r2) goto L_0x0043
            a.b.c.e.b$g r2 = f(r8, r9, r14)
            if (r10 == 0) goto L_0x0040
            int r3 = r2.f197b
            if (r3 != 0) goto L_0x003d
            android.graphics.Typeface r3 = r2.f196a
            r10.b(r3, r11)
            goto L_0x0040
        L_0x003d:
            r10.a(r3, r11)
        L_0x0040:
            android.graphics.Typeface r3 = r2.f196a
            return r3
        L_0x0043:
            a.b.c.e.b$a r2 = new a.b.c.e.b$a
            r2.<init>(r8, r9, r14, r0)
            r3 = 0
            if (r12 == 0) goto L_0x0058
            a.b.c.e.c r4 = f183b     // Catch:{ InterruptedException -> 0x0056 }
            java.lang.Object r4 = r4.e(r2, r13)     // Catch:{ InterruptedException -> 0x0056 }
            a.b.c.e.b$g r4 = (a.b.c.e.b.g) r4     // Catch:{ InterruptedException -> 0x0056 }
            android.graphics.Typeface r3 = r4.f196a     // Catch:{ InterruptedException -> 0x0056 }
            return r3
        L_0x0056:
            r4 = move-exception
            return r3
        L_0x0058:
            if (r10 != 0) goto L_0x005c
            r4 = r3
            goto L_0x0061
        L_0x005c:
            a.b.c.e.b$b r4 = new a.b.c.e.b$b
            r4.<init>(r10, r11)
        L_0x0061:
            java.lang.Object r5 = f184c
            monitor-enter(r5)
            a.b.c.g.k<java.lang.String, java.util.ArrayList<a.b.c.e.c$d<a.b.c.e.b$g>>> r6 = d     // Catch:{ all -> 0x0096 }
            boolean r6 = r6.containsKey(r0)     // Catch:{ all -> 0x0096 }
            if (r6 == 0) goto L_0x007b
            if (r4 == 0) goto L_0x0079
            a.b.c.g.k<java.lang.String, java.util.ArrayList<a.b.c.e.c$d<a.b.c.e.b$g>>> r6 = d     // Catch:{ all -> 0x0096 }
            java.lang.Object r6 = r6.get(r0)     // Catch:{ all -> 0x0096 }
            java.util.ArrayList r6 = (java.util.ArrayList) r6     // Catch:{ all -> 0x0096 }
            r6.add(r4)     // Catch:{ all -> 0x0096 }
        L_0x0079:
            monitor-exit(r5)     // Catch:{ all -> 0x0096 }
            return r3
        L_0x007b:
            if (r4 == 0) goto L_0x008a
            java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ all -> 0x0096 }
            r6.<init>()     // Catch:{ all -> 0x0096 }
            r6.add(r4)     // Catch:{ all -> 0x0096 }
            a.b.c.g.k<java.lang.String, java.util.ArrayList<a.b.c.e.c$d<a.b.c.e.b$g>>> r7 = d     // Catch:{ all -> 0x0096 }
            r7.put(r0, r6)     // Catch:{ all -> 0x0096 }
        L_0x008a:
            monitor-exit(r5)     // Catch:{ all -> 0x0096 }
            a.b.c.e.c r5 = f183b
            a.b.c.e.b$c r6 = new a.b.c.e.b$c
            r6.<init>(r0)
            r5.d(r2, r6)
            return r3
        L_0x0096:
            r3 = move-exception
            monitor-exit(r5)     // Catch:{ all -> 0x0096 }
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.e.b.g(android.content.Context, a.b.c.e.a, a.b.c.b.c.f$a, android.os.Handler, boolean, int, int):android.graphics.Typeface");
    }

    public static class a implements Callable<g> {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ Context f185a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ a f186b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ int f187c;
        public final /* synthetic */ String d;

        public a(Context context, a aVar, int i, String str) {
            this.f185a = context;
            this.f186b = aVar;
            this.f187c = i;
            this.d = str;
        }

        /* renamed from: a */
        public g call() {
            g typeface = b.f(this.f185a, this.f186b, this.f187c);
            Typeface typeface2 = typeface.f196a;
            if (typeface2 != null) {
                b.f182a.d(this.d, typeface2);
            }
            return typeface;
        }
    }

    /* renamed from: a.b.c.e.b$b  reason: collision with other inner class name */
    public static class C0010b implements c.d<g> {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ f.a f188a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ Handler f189b;

        public C0010b(f.a aVar, Handler handler) {
            this.f188a = aVar;
            this.f189b = handler;
        }

        /* renamed from: b */
        public void a(g typeface) {
            if (typeface == null) {
                this.f188a.a(1, this.f189b);
                return;
            }
            int i = typeface.f197b;
            if (i == 0) {
                this.f188a.b(typeface.f196a, this.f189b);
            } else {
                this.f188a.a(i, this.f189b);
            }
        }
    }

    public static class c implements c.d<g> {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ String f190a;

        public c(String str) {
            this.f190a = str;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:12:0x001b, code lost:
            r0 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:14:0x0020, code lost:
            if (r0 >= r1.size()) goto L_0x002e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x0022, code lost:
            ((a.b.c.e.c.d) r1.get(r0)).a(r5);
            r0 = r0 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x002e, code lost:
            return;
         */
        /* renamed from: b */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void a(a.b.c.e.b.g r5) {
            /*
                r4 = this;
                java.lang.Object r0 = a.b.c.e.b.f184c
                monitor-enter(r0)
                r1 = 0
                a.b.c.g.k<java.lang.String, java.util.ArrayList<a.b.c.e.c$d<a.b.c.e.b$g>>> r2 = a.b.c.e.b.d     // Catch:{ all -> 0x002f }
                java.lang.String r3 = r4.f190a     // Catch:{ all -> 0x002f }
                java.lang.Object r2 = r2.get(r3)     // Catch:{ all -> 0x002f }
                java.util.ArrayList r2 = (java.util.ArrayList) r2     // Catch:{ all -> 0x002f }
                r1 = r2
                if (r1 != 0) goto L_0x0013
                monitor-exit(r0)     // Catch:{ all -> 0x0032 }
                return
            L_0x0013:
                a.b.c.g.k<java.lang.String, java.util.ArrayList<a.b.c.e.c$d<a.b.c.e.b$g>>> r2 = a.b.c.e.b.d     // Catch:{ all -> 0x0032 }
                java.lang.String r3 = r4.f190a     // Catch:{ all -> 0x0032 }
                r2.remove(r3)     // Catch:{ all -> 0x0032 }
                monitor-exit(r0)     // Catch:{ all -> 0x0032 }
                r0 = 0
            L_0x001c:
                int r2 = r1.size()
                if (r0 >= r2) goto L_0x002e
                java.lang.Object r2 = r1.get(r0)
                a.b.c.e.c$d r2 = (a.b.c.e.c.d) r2
                r2.a(r5)
                int r0 = r0 + 1
                goto L_0x001c
            L_0x002e:
                return
            L_0x002f:
                r2 = move-exception
            L_0x0030:
                monitor-exit(r0)     // Catch:{ all -> 0x0032 }
                throw r2
            L_0x0032:
                r2 = move-exception
                goto L_0x0030
            */
            throw new UnsupportedOperationException("Method not decompiled: a.b.c.e.b.c.a(a.b.c.e.b$g):void");
        }
    }

    public static class f {

        /* renamed from: a  reason: collision with root package name */
        public final Uri f193a;

        /* renamed from: b  reason: collision with root package name */
        public final int f194b;

        /* renamed from: c  reason: collision with root package name */
        public final int f195c;
        public final boolean d;
        public final int e;

        public f(Uri uri, int ttcIndex, int weight, boolean italic, int resultCode) {
            j.b(uri);
            this.f193a = uri;
            this.f194b = ttcIndex;
            this.f195c = weight;
            this.d = italic;
            this.e = resultCode;
        }

        public Uri c() {
            return this.f193a;
        }

        public int b() {
            return this.f194b;
        }

        public int d() {
            return this.f195c;
        }

        public boolean e() {
            return this.d;
        }

        public int a() {
            return this.e;
        }
    }

    public static class e {

        /* renamed from: a  reason: collision with root package name */
        public final int f191a;

        /* renamed from: b  reason: collision with root package name */
        public final f[] f192b;

        public e(int statusCode, f[] fonts) {
            this.f191a = statusCode;
            this.f192b = fonts;
        }

        public int b() {
            return this.f191a;
        }

        public f[] a() {
            return this.f192b;
        }
    }

    public static Map<Uri, ByteBuffer> i(Context context, f[] fonts, CancellationSignal cancellationSignal) {
        HashMap<Uri, ByteBuffer> out = new HashMap<>();
        for (f font : fonts) {
            if (font.a() == 0) {
                Uri uri = font.c();
                if (!out.containsKey(uri)) {
                    out.put(uri, i.f(context, cancellationSignal, uri));
                }
            }
        }
        return Collections.unmodifiableMap(out);
    }

    public static e c(Context context, CancellationSignal cancellationSignal, a request) {
        ProviderInfo providerInfo = h(context.getPackageManager(), request, context.getResources());
        if (providerInfo == null) {
            return new e(1, (f[]) null);
        }
        return new e(0, e(context, request, providerInfo.authority, cancellationSignal));
    }

    public static ProviderInfo h(PackageManager packageManager, a request, Resources resources) {
        String providerAuthority = request.d();
        ProviderInfo info = packageManager.resolveContentProvider(providerAuthority, 0);
        if (info == null) {
            throw new PackageManager.NameNotFoundException("No package found for authority: " + providerAuthority);
        } else if (info.packageName.equals(request.e())) {
            List<byte[]> signatures = a(packageManager.getPackageInfo(info.packageName, 64).signatures);
            Collections.sort(signatures, e);
            List<List<byte[]>> requestCertificatesList = d(request, resources);
            for (int i = 0; i < requestCertificatesList.size(); i++) {
                List<byte[]> requestSignatures = new ArrayList<>(requestCertificatesList.get(i));
                Collections.sort(requestSignatures, e);
                if (b(signatures, requestSignatures)) {
                    return info;
                }
            }
            return null;
        } else {
            throw new PackageManager.NameNotFoundException("Found content provider " + providerAuthority + ", but package was not " + request.e());
        }
    }

    public static List<List<byte[]>> d(a request, Resources resources) {
        if (request.a() != null) {
            return request.a();
        }
        return a.b.c.b.c.c.c(resources, request.b());
    }

    public static class d implements Comparator<byte[]> {
        /* renamed from: a */
        public int compare(byte[] l, byte[] r) {
            if (l.length != r.length) {
                return l.length - r.length;
            }
            for (int i = 0; i < l.length; i++) {
                if (l[i] != r[i]) {
                    return l[i] - r[i];
                }
            }
            return 0;
        }
    }

    public static boolean b(List<byte[]> signatures, List<byte[]> requestSignatures) {
        if (signatures.size() != requestSignatures.size()) {
            return false;
        }
        for (int i = 0; i < signatures.size(); i++) {
            if (!Arrays.equals(signatures.get(i), requestSignatures.get(i))) {
                return false;
            }
        }
        return true;
    }

    public static List<byte[]> a(Signature[] signatures) {
        List<byte[]> shas = new ArrayList<>();
        for (Signature byteArray : signatures) {
            shas.add(byteArray.toByteArray());
        }
        return shas;
    }

    /* JADX WARNING: Removed duplicated region for block: B:37:0x010e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static a.b.c.e.b.f[] e(android.content.Context r25, a.b.c.e.a r26, java.lang.String r27, android.os.CancellationSignal r28) {
        /*
            r1 = r27
            java.lang.String r0 = "result_code"
            java.lang.String r2 = "font_italic"
            java.lang.String r3 = "font_weight"
            java.lang.String r4 = "font_ttc_index"
            java.lang.String r5 = "file_id"
            java.lang.String r6 = "_id"
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
            android.net.Uri$Builder r8 = new android.net.Uri$Builder
            r8.<init>()
            java.lang.String r9 = "content"
            android.net.Uri$Builder r8 = r8.scheme(r9)
            android.net.Uri$Builder r8 = r8.authority(r1)
            android.net.Uri r8 = r8.build()
            android.net.Uri$Builder r10 = new android.net.Uri$Builder
            r10.<init>()
            android.net.Uri$Builder r9 = r10.scheme(r9)
            android.net.Uri$Builder r9 = r9.authority(r1)
            java.lang.String r10 = "file"
            android.net.Uri$Builder r9 = r9.appendPath(r10)
            android.net.Uri r9 = r9.build()
            r17 = 0
            android.content.ContentResolver r10 = r25.getContentResolver()     // Catch:{ all -> 0x010b }
            r11 = 7
            java.lang.String[] r12 = new java.lang.String[r11]     // Catch:{ all -> 0x010b }
            r15 = 0
            r12[r15] = r6     // Catch:{ all -> 0x010b }
            r14 = 1
            r12[r14] = r5     // Catch:{ all -> 0x010b }
            r11 = 2
            r12[r11] = r4     // Catch:{ all -> 0x010b }
            r11 = 3
            java.lang.String r13 = "font_variation_settings"
            r12[r11] = r13     // Catch:{ all -> 0x010b }
            r11 = 4
            r12[r11] = r3     // Catch:{ all -> 0x010b }
            r11 = 5
            r12[r11] = r2     // Catch:{ all -> 0x010b }
            r11 = 6
            r12[r11] = r0     // Catch:{ all -> 0x010b }
            java.lang.String r13 = "query = ?"
            java.lang.String[] r11 = new java.lang.String[r14]     // Catch:{ all -> 0x010b }
            java.lang.String r16 = r26.f()     // Catch:{ all -> 0x010b }
            r11[r15] = r16     // Catch:{ all -> 0x010b }
            r16 = 0
            r18 = r11
            r11 = r8
            r1 = 1
            r14 = r18
            r15 = r16
            r16 = r28
            android.database.Cursor r10 = r10.query(r11, r12, r13, r14, r15, r16)     // Catch:{ all -> 0x010b }
            if (r10 == 0) goto L_0x00fc
            int r11 = r10.getCount()     // Catch:{ all -> 0x00f8 }
            if (r11 <= 0) goto L_0x00fc
            int r0 = r10.getColumnIndex(r0)     // Catch:{ all -> 0x00f8 }
            java.util.ArrayList r11 = new java.util.ArrayList     // Catch:{ all -> 0x00f8 }
            r11.<init>()     // Catch:{ all -> 0x00f8 }
            r7 = r11
            int r6 = r10.getColumnIndex(r6)     // Catch:{ all -> 0x00f8 }
            int r5 = r10.getColumnIndex(r5)     // Catch:{ all -> 0x00f8 }
            int r4 = r10.getColumnIndex(r4)     // Catch:{ all -> 0x00f8 }
            int r3 = r10.getColumnIndex(r3)     // Catch:{ all -> 0x00f8 }
            int r2 = r10.getColumnIndex(r2)     // Catch:{ all -> 0x00f8 }
        L_0x009e:
            boolean r11 = r10.moveToNext()     // Catch:{ all -> 0x00f8 }
            if (r11 == 0) goto L_0x00fc
            r11 = -1
            if (r0 == r11) goto L_0x00ae
            int r15 = r10.getInt(r0)     // Catch:{ all -> 0x00f8 }
            r24 = r15
            goto L_0x00b0
        L_0x00ae:
            r24 = 0
        L_0x00b0:
            if (r4 == r11) goto L_0x00b9
            int r15 = r10.getInt(r4)     // Catch:{ all -> 0x00f8 }
            r21 = r15
            goto L_0x00bb
        L_0x00b9:
            r21 = 0
        L_0x00bb:
            if (r5 != r11) goto L_0x00c7
            long r12 = r10.getLong(r6)     // Catch:{ all -> 0x00f8 }
            android.net.Uri r14 = android.content.ContentUris.withAppendedId(r8, r12)     // Catch:{ all -> 0x00f8 }
            r12 = r14
            goto L_0x00d0
        L_0x00c7:
            long r12 = r10.getLong(r5)     // Catch:{ all -> 0x00f8 }
            android.net.Uri r14 = android.content.ContentUris.withAppendedId(r9, r12)     // Catch:{ all -> 0x00f8 }
            r12 = r14
        L_0x00d0:
            if (r3 == r11) goto L_0x00d9
            int r13 = r10.getInt(r3)     // Catch:{ all -> 0x00f8 }
            r22 = r13
            goto L_0x00dd
        L_0x00d9:
            r13 = 400(0x190, float:5.6E-43)
            r22 = 400(0x190, float:5.6E-43)
        L_0x00dd:
            if (r2 == r11) goto L_0x00e8
            int r11 = r10.getInt(r2)     // Catch:{ all -> 0x00f8 }
            if (r11 != r1) goto L_0x00e8
            r23 = 1
            goto L_0x00ea
        L_0x00e8:
            r23 = 0
        L_0x00ea:
            a.b.c.e.b$f r11 = new a.b.c.e.b$f     // Catch:{ all -> 0x00f8 }
            r19 = r11
            r20 = r12
            r19.<init>(r20, r21, r22, r23, r24)     // Catch:{ all -> 0x00f8 }
            r7.add(r11)     // Catch:{ all -> 0x00f8 }
            goto L_0x009e
        L_0x00f8:
            r0 = move-exception
            r17 = r10
            goto L_0x010c
        L_0x00fc:
            if (r10 == 0) goto L_0x0101
            r10.close()
        L_0x0101:
            r0 = 0
            a.b.c.e.b$f[] r0 = new a.b.c.e.b.f[r0]
            java.lang.Object[] r0 = r7.toArray(r0)
            a.b.c.e.b$f[] r0 = (a.b.c.e.b.f[]) r0
            return r0
        L_0x010b:
            r0 = move-exception
        L_0x010c:
            if (r17 == 0) goto L_0x0111
            r17.close()
        L_0x0111:
            goto L_0x0113
        L_0x0112:
            throw r0
        L_0x0113:
            goto L_0x0112
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.e.b.e(android.content.Context, a.b.c.e.a, java.lang.String, android.os.CancellationSignal):a.b.c.e.b$f[]");
    }
}
