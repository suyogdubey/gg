package a.b.c.b.c;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;

public final class f {
    public static Drawable a(Resources res, int id, Resources.Theme theme) {
        if (Build.VERSION.SDK_INT >= 21) {
            return res.getDrawable(id, theme);
        }
        return res.getDrawable(id);
    }

    public static abstract class a {
        public abstract void c(int i);

        public abstract void d(Typeface typeface);

        public final void b(Typeface typeface, Handler handler) {
            if (handler == null) {
                handler = new Handler(Looper.getMainLooper());
            }
            handler.post(new C0008a(typeface));
        }

        /* renamed from: a.b.c.b.c.f$a$a  reason: collision with other inner class name */
        public class C0008a implements Runnable {

            /* renamed from: b  reason: collision with root package name */
            public final /* synthetic */ Typeface f155b;

            public C0008a(Typeface typeface) {
                this.f155b = typeface;
            }

            public void run() {
                a.this.d(this.f155b);
            }
        }

        public final void a(int reason, Handler handler) {
            if (handler == null) {
                handler = new Handler(Looper.getMainLooper());
            }
            handler.post(new b(reason));
        }

        public class b implements Runnable {

            /* renamed from: b  reason: collision with root package name */
            public final /* synthetic */ int f157b;

            public b(int i) {
                this.f157b = i;
            }

            public void run() {
                a.this.c(this.f157b);
            }
        }
    }

    public static Typeface b(Context context, int id, TypedValue value, int style, a fontCallback) {
        if (context.isRestricted()) {
            return null;
        }
        return c(context, id, value, style, fontCallback, (Handler) null, true);
    }

    public static Typeface c(Context context, int id, TypedValue value, int style, a fontCallback, Handler handler, boolean isRequestFromLayoutInflator) {
        Resources resources = context.getResources();
        resources.getValue(id, value, true);
        Typeface typeface = d(context, resources, value, id, style, fontCallback, handler, isRequestFromLayoutInflator);
        if (typeface != null || fontCallback != null) {
            return typeface;
        }
        throw new Resources.NotFoundException("Font resource ID #0x" + Integer.toHexString(id) + " could not be retrieved.");
    }

    /* JADX WARNING: Removed duplicated region for block: B:64:0x00ee  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.graphics.Typeface d(android.content.Context r19, android.content.res.Resources r20, android.util.TypedValue r21, int r22, int r23, a.b.c.b.c.f.a r24, android.os.Handler r25, boolean r26) {
        /*
            r9 = r20
            r10 = r21
            r11 = r22
            r12 = r23
            r13 = r24
            r14 = r25
            java.lang.String r15 = "ResourcesCompat"
            java.lang.CharSequence r0 = r10.string
            if (r0 == 0) goto L_0x00f3
            java.lang.String r8 = r0.toString()
            java.lang.String r0 = "res/"
            boolean r0 = r8.startsWith(r0)
            r16 = 0
            r7 = -3
            if (r0 != 0) goto L_0x0027
            if (r13 == 0) goto L_0x0026
            r13.a(r7, r14)
        L_0x0026:
            return r16
        L_0x0027:
            android.graphics.Typeface r6 = a.b.c.c.c.e(r9, r11, r12)
            if (r6 == 0) goto L_0x0033
            if (r13 == 0) goto L_0x0032
            r13.b(r6, r14)
        L_0x0032:
            return r6
        L_0x0033:
            java.lang.String r0 = r8.toLowerCase()     // Catch:{ XmlPullParserException -> 0x00d1, IOException -> 0x00b6 }
            java.lang.String r1 = ".xml"
            boolean r0 = r0.endsWith(r1)     // Catch:{ XmlPullParserException -> 0x00d1, IOException -> 0x00b6 }
            if (r0 == 0) goto L_0x0092
            android.content.res.XmlResourceParser r0 = r9.getXml(r11)     // Catch:{ XmlPullParserException -> 0x008b, IOException -> 0x0084 }
            a.b.c.b.c.c$a r1 = a.b.c.b.c.c.b(r0, r9)     // Catch:{ XmlPullParserException -> 0x008b, IOException -> 0x0084 }
            r17 = r1
            if (r17 != 0) goto L_0x0063
            java.lang.String r1 = "Failed to find font-family tag"
            android.util.Log.e(r15, r1)     // Catch:{ XmlPullParserException -> 0x005d, IOException -> 0x0057 }
            if (r13 == 0) goto L_0x0056
            r13.a(r7, r14)     // Catch:{ XmlPullParserException -> 0x005d, IOException -> 0x0057 }
        L_0x0056:
            return r16
        L_0x0057:
            r0 = move-exception
            r1 = r19
            r10 = r8
            goto L_0x00bc
        L_0x005d:
            r0 = move-exception
            r1 = r19
            r10 = r8
            goto L_0x00d7
        L_0x0063:
            r1 = r19
            r2 = r17
            r3 = r20
            r4 = r22
            r5 = r23
            r18 = r6
            r6 = r24
            r10 = -3
            r7 = r25
            r10 = r8
            r8 = r26
            android.graphics.Typeface r1 = a.b.c.c.c.b(r1, r2, r3, r4, r5, r6, r7, r8)     // Catch:{ XmlPullParserException -> 0x0080, IOException -> 0x007c }
            return r1
        L_0x007c:
            r0 = move-exception
            r1 = r19
            goto L_0x00af
        L_0x0080:
            r0 = move-exception
            r1 = r19
            goto L_0x00b3
        L_0x0084:
            r0 = move-exception
            r18 = r6
            r10 = r8
            r1 = r19
            goto L_0x00bc
        L_0x008b:
            r0 = move-exception
            r18 = r6
            r10 = r8
            r1 = r19
            goto L_0x00d7
        L_0x0092:
            r18 = r6
            r10 = r8
            r1 = r19
            android.graphics.Typeface r0 = a.b.c.c.c.c(r1, r9, r11, r10, r12)     // Catch:{ XmlPullParserException -> 0x00b2, IOException -> 0x00ae }
            r6 = r0
            if (r13 == 0) goto L_0x00ad
            if (r6 == 0) goto L_0x00a4
            r13.b(r6, r14)     // Catch:{ XmlPullParserException -> 0x00ab, IOException -> 0x00a9 }
            goto L_0x00ad
        L_0x00a4:
            r2 = -3
            r13.a(r2, r14)     // Catch:{ XmlPullParserException -> 0x00ab, IOException -> 0x00a9 }
            goto L_0x00ad
        L_0x00a9:
            r0 = move-exception
            goto L_0x00bc
        L_0x00ab:
            r0 = move-exception
            goto L_0x00d7
        L_0x00ad:
            return r6
        L_0x00ae:
            r0 = move-exception
        L_0x00af:
            r6 = r18
            goto L_0x00bc
        L_0x00b2:
            r0 = move-exception
        L_0x00b3:
            r6 = r18
            goto L_0x00d7
        L_0x00b6:
            r0 = move-exception
            r1 = r19
            r18 = r6
            r10 = r8
        L_0x00bc:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "Failed to read xml resource "
            r2.append(r3)
            r2.append(r10)
            java.lang.String r2 = r2.toString()
            android.util.Log.e(r15, r2, r0)
            goto L_0x00ec
        L_0x00d1:
            r0 = move-exception
            r1 = r19
            r18 = r6
            r10 = r8
        L_0x00d7:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "Failed to parse xml resource "
            r2.append(r3)
            r2.append(r10)
            java.lang.String r2 = r2.toString()
            android.util.Log.e(r15, r2, r0)
        L_0x00ec:
            if (r13 == 0) goto L_0x00f2
            r2 = -3
            r13.a(r2, r14)
        L_0x00f2:
            return r16
        L_0x00f3:
            r1 = r19
            android.content.res.Resources$NotFoundException r0 = new android.content.res.Resources$NotFoundException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "Resource \""
            r2.append(r3)
            java.lang.String r3 = r9.getResourceName(r11)
            r2.append(r3)
            java.lang.String r3 = "\" ("
            r2.append(r3)
            java.lang.String r3 = java.lang.Integer.toHexString(r22)
            r2.append(r3)
            java.lang.String r3 = ") is not a Font: "
            r2.append(r3)
            r3 = r21
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r0.<init>(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.b.c.f.d(android.content.Context, android.content.res.Resources, android.util.TypedValue, int, int, a.b.c.b.c.f$a, android.os.Handler, boolean):android.graphics.Typeface");
    }
}
