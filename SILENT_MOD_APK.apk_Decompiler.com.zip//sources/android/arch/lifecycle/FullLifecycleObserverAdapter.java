package android.arch.lifecycle;

import a.a.b.c;
import a.a.b.e;

public class FullLifecycleObserverAdapter implements GenericLifecycleObserver {

    /* renamed from: a  reason: collision with root package name */
    public final FullLifecycleObserver f561a;

    public void g(e source, c.a event) {
        switch (event.ordinal()) {
            case 0:
                this.f561a.c(source);
                return;
            case 1:
                this.f561a.b(source);
                return;
            case 2:
                this.f561a.f(source);
                return;
            case 3:
                this.f561a.d(source);
                return;
            case 4:
                this.f561a.e(source);
                return;
            case 5:
                this.f561a.a(source);
                return;
            case 6:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
            default:
                return;
        }
    }
}
