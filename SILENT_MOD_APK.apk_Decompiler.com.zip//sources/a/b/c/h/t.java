package a.b.c.h;

import a.b.d.a.k;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.os.Build;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

public final class t {

    /* renamed from: a  reason: collision with root package name */
    public WeakReference<View> f261a;

    /* renamed from: b  reason: collision with root package name */
    public Runnable f262b = null;

    /* renamed from: c  reason: collision with root package name */
    public Runnable f263c = null;
    public int d = -1;

    public t(View view) {
        this.f261a = new WeakReference<>(view);
    }

    public t d(long value) {
        View view = (View) this.f261a.get();
        View view2 = view;
        if (view != null) {
            view2.animate().setDuration(value);
        }
        return this;
    }

    public t a(float value) {
        View view = (View) this.f261a.get();
        View view2 = view;
        if (view != null) {
            view2.animate().alpha(value);
        }
        return this;
    }

    public t k(float value) {
        View view = (View) this.f261a.get();
        View view2 = view;
        if (view != null) {
            view2.animate().translationY(value);
        }
        return this;
    }

    public long c() {
        View view = (View) this.f261a.get();
        View view2 = view;
        if (view != null) {
            return view2.animate().getDuration();
        }
        return 0;
    }

    public t e(Interpolator value) {
        View view = (View) this.f261a.get();
        View view2 = view;
        if (view != null) {
            view2.animate().setInterpolator(value);
        }
        return this;
    }

    public t h(long value) {
        View view = (View) this.f261a.get();
        View view2 = view;
        if (view != null) {
            view2.animate().setStartDelay(value);
        }
        return this;
    }

    public void b() {
        View view = (View) this.f261a.get();
        View view2 = view;
        if (view != null) {
            view2.animate().cancel();
        }
    }

    public void j() {
        View view = (View) this.f261a.get();
        View view2 = view;
        if (view != null) {
            view2.animate().start();
        }
    }

    public t f(u listener) {
        View view = (View) this.f261a.get();
        View view2 = view;
        if (view != null) {
            g(view2, listener);
        }
        return this;
    }

    public class a extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ u f264a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ View f265b;

        public a(t this$0, u uVar, View view) {
            this.f264a = uVar;
            this.f265b = view;
        }

        public void onAnimationCancel(Animator animation) {
            this.f264a.c(this.f265b);
        }

        public void onAnimationEnd(Animator animation) {
            this.f264a.a(this.f265b);
        }

        public void onAnimationStart(Animator animation) {
            this.f264a.b(this.f265b);
        }
    }

    public final void g(View view, u listener) {
        if (listener != null) {
            view.animate().setListener(new a(this, listener, view));
        } else {
            view.animate().setListener((Animator.AnimatorListener) null);
        }
    }

    public t i(w listener) {
        View view = (View) this.f261a.get();
        View view2 = view;
        if (view != null && Build.VERSION.SDK_INT >= 19) {
            ValueAnimator.AnimatorUpdateListener wrapped = null;
            if (listener != null) {
                wrapped = new b(this, listener, view2);
            }
            view2.animate().setUpdateListener(wrapped);
        }
        return this;
    }

    public class b implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ w f266a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ View f267b;

        public b(t this$0, w wVar, View view) {
            this.f266a = wVar;
            this.f267b = view;
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            ((k.c) this.f266a).a(this.f267b);
        }
    }
}
