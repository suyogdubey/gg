package a.b.c.a;

import android.graphics.Rect;
import android.os.Build;
import android.support.v4.app.FragmentTransition;
import android.support.v4.util.ArrayMap;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class p {

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f111a = {0, 3, 0, 1, 5, 4, 7, 6, 9, 8};

    /* renamed from: b  reason: collision with root package name */
    public static final r f112b = (Build.VERSION.SDK_INT >= 21 ? new q() : null);

    /* renamed from: c  reason: collision with root package name */
    public static final r f113c = x();

    public static class e {

        /* renamed from: a  reason: collision with root package name */
        public e f121a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f122b;

        /* renamed from: c  reason: collision with root package name */
        public c f123c;
        public e d;
        public boolean e;
        public c f;
    }

    public static r x() {
        try {
            return (r) Class.forName("android.support.transition.FragmentTransitionSupport").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception e2) {
            return null;
        }
    }

    public static void C(k fragmentManager, ArrayList<c> records, ArrayList<Boolean> isRecordPop, int startIndex, int endIndex, boolean isReordered) {
        if (fragmentManager.k >= 1) {
            SparseArray<FragmentTransition.FragmentContainerTransition> transitioningFragments = new SparseArray<>();
            for (int i = startIndex; i < endIndex; i++) {
                c record = records.get(i);
                if (isRecordPop.get(i).booleanValue()) {
                    e(record, transitioningFragments, isReordered);
                } else {
                    c(record, transitioningFragments, isReordered);
                }
            }
            if (transitioningFragments.size() != 0) {
                View nonExistentView = new View(fragmentManager.l.e());
                int numContainers = transitioningFragments.size();
                for (int i2 = 0; i2 < numContainers; i2++) {
                    int containerId = transitioningFragments.keyAt(i2);
                    ArrayMap<String, String> nameOverrides = d(containerId, records, isRecordPop, startIndex, endIndex);
                    e containerTransition = (e) transitioningFragments.valueAt(i2);
                    if (isReordered) {
                        o(fragmentManager, containerId, containerTransition, nonExistentView, nameOverrides);
                    } else {
                        n(fragmentManager, containerId, containerTransition, nonExistentView, nameOverrides);
                    }
                }
            }
        }
    }

    public static a.b.c.g.a<String, String> d(int containerId, ArrayList<c> records, ArrayList<Boolean> isRecordPop, int startIndex, int endIndex) {
        ArrayList<String> sources;
        ArrayList<String> targets;
        ArrayMap<String, String> nameOverrides = new a.b.c.g.a<>();
        for (int recordNum = endIndex - 1; recordNum >= startIndex; recordNum--) {
            c record = records.get(recordNum);
            if (record.i(containerId)) {
                boolean isPop = isRecordPop.get(recordNum).booleanValue();
                ArrayList<String> arrayList = record.p;
                if (arrayList != null) {
                    int numSharedElements = arrayList.size();
                    if (isPop) {
                        targets = record.p;
                        sources = record.q;
                    } else {
                        sources = record.p;
                        targets = record.q;
                    }
                    for (int i = 0; i < numSharedElements; i++) {
                        String sourceName = sources.get(i);
                        String targetName = targets.get(i);
                        String previousTarget = nameOverrides.remove(targetName);
                        if (previousTarget != null) {
                            nameOverrides.put(sourceName, previousTarget);
                        } else {
                            nameOverrides.put(sourceName, targetName);
                        }
                    }
                }
            }
        }
        return nameOverrides;
    }

    /* JADX WARNING: type inference failed for: r2v9, types: [android.view.View] */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0022, code lost:
        r14 = r10.f121a;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void o(a.b.c.a.k r23, int r24, a.b.c.a.p.e r25, android.view.View r26, a.b.c.g.a<java.lang.String, java.lang.String> r27) {
        /*
            r0 = r23
            r10 = r25
            r11 = r26
            r1 = 0
            a.b.c.a.g r2 = r0.m
            boolean r2 = r2.c()
            if (r2 == 0) goto L_0x001c
            a.b.c.a.g r2 = r0.m
            r12 = r24
            android.view.View r2 = r2.b(r12)
            r1 = r2
            android.view.ViewGroup r1 = (android.view.ViewGroup) r1
            r13 = r1
            goto L_0x001f
        L_0x001c:
            r12 = r24
            r13 = r1
        L_0x001f:
            if (r13 != 0) goto L_0x0022
            return
        L_0x0022:
            a.b.c.a.e r14 = r10.f121a
            a.b.c.a.e r15 = r10.d
            a.b.c.a.r r9 = j(r15, r14)
            if (r9 != 0) goto L_0x002d
            return
        L_0x002d:
            boolean r8 = r10.f122b
            boolean r7 = r10.e
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r6 = r1
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r5 = r1
            java.lang.Object r4 = r(r9, r14, r8)
            java.lang.Object r3 = s(r9, r15, r7)
            r1 = r9
            r2 = r13
            r16 = r3
            r3 = r26
            r17 = r4
            r4 = r27
            r18 = r5
            r5 = r25
            r19 = r6
            r6 = r18
            r20 = r7
            r7 = r19
            r21 = r8
            r8 = r17
            r0 = r9
            r9 = r16
            java.lang.Object r9 = m(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            if (r8 != 0) goto L_0x0070
            if (r9 != 0) goto L_0x0070
            r7 = r16
            if (r7 != 0) goto L_0x0072
            return
        L_0x0070:
            r7 = r16
        L_0x0072:
            r6 = r18
            java.util.ArrayList r5 = k(r0, r7, r15, r6, r11)
            r4 = r19
            java.util.ArrayList r3 = k(r0, r8, r14, r4, r11)
            r1 = 4
            B(r3, r1)
            r1 = r0
            r2 = r8
            r16 = r3
            r3 = r7
            r10 = r4
            r4 = r9
            r11 = r5
            r5 = r14
            r6 = r21
            java.lang.Object r6 = v(r1, r2, r3, r4, r5, r6)
            if (r6 == 0) goto L_0x00c7
            w(r0, r7, r15, r11)
            java.util.ArrayList r17 = r0.o(r10)
            r1 = r0
            r2 = r6
            r3 = r8
            r4 = r16
            r5 = r7
            r12 = r6
            r6 = r11
            r19 = r7
            r7 = r9
            r22 = r8
            r8 = r10
            r1.t(r2, r3, r4, r5, r6, r7, r8)
            r0.c(r13, r12)
            r2 = r0
            r3 = r13
            r4 = r18
            r5 = r10
            r6 = r17
            r7 = r27
            r2.x(r3, r4, r5, r6, r7)
            r1 = 0
            r2 = r16
            B(r2, r1)
            r1 = r18
            r0.z(r9, r1, r10)
            goto L_0x00d0
        L_0x00c7:
            r12 = r6
            r19 = r7
            r22 = r8
            r2 = r16
            r1 = r18
        L_0x00d0:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.p.o(a.b.c.a.k, int, a.b.c.a.p$e, android.view.View, a.b.c.g.a):void");
    }

    public static void w(r impl, Object exitTransition, e exitingFragment, ArrayList<View> exitingViews) {
        if (exitingFragment != null && exitTransition != null && exitingFragment.l && exitingFragment.B && exitingFragment.P) {
            exitingFragment.Q0(true);
            impl.r(exitTransition, exitingFragment.C(), exitingViews);
            u.a(exitingFragment.I, new a(exitingViews));
        }
    }

    public static class a implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ ArrayList f114b;

        public a(ArrayList arrayList) {
            this.f114b = arrayList;
        }

        public void run() {
            p.B(this.f114b, 4);
        }
    }

    /* JADX WARNING: type inference failed for: r2v8, types: [android.view.View] */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0024, code lost:
        r15 = r10.f121a;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void n(a.b.c.a.k r30, int r31, a.b.c.a.p.e r32, android.view.View r33, a.b.c.g.a<java.lang.String, java.lang.String> r34) {
        /*
            r0 = r30
            r10 = r32
            r11 = r33
            r12 = r34
            r1 = 0
            a.b.c.a.g r2 = r0.m
            boolean r2 = r2.c()
            if (r2 == 0) goto L_0x001e
            a.b.c.a.g r2 = r0.m
            r13 = r31
            android.view.View r2 = r2.b(r13)
            r1 = r2
            android.view.ViewGroup r1 = (android.view.ViewGroup) r1
            r14 = r1
            goto L_0x0021
        L_0x001e:
            r13 = r31
            r14 = r1
        L_0x0021:
            if (r14 != 0) goto L_0x0024
            return
        L_0x0024:
            a.b.c.a.e r15 = r10.f121a
            a.b.c.a.e r9 = r10.d
            a.b.c.a.r r8 = j(r9, r15)
            if (r8 != 0) goto L_0x002f
            return
        L_0x002f:
            boolean r7 = r10.f122b
            boolean r6 = r10.e
            java.lang.Object r5 = r(r8, r15, r7)
            java.lang.Object r4 = s(r8, r9, r6)
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r3 = r1
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r2 = r1
            r1 = r8
            r24 = r2
            r2 = r14
            r25 = r3
            r3 = r33
            r16 = r4
            r4 = r34
            r26 = r5
            r5 = r32
            r27 = r6
            r6 = r25
            r28 = r7
            r7 = r24
            r0 = r8
            r8 = r26
            r13 = r9
            r9 = r16
            java.lang.Object r29 = l(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            r9 = r26
            if (r9 != 0) goto L_0x0074
            if (r29 != 0) goto L_0x0074
            r1 = r16
            if (r1 != 0) goto L_0x0076
            return
        L_0x0074:
            r1 = r16
        L_0x0076:
            r8 = r25
            java.util.ArrayList r25 = k(r0, r1, r13, r8, r11)
            if (r25 == 0) goto L_0x0088
            boolean r2 = r25.isEmpty()
            if (r2 == 0) goto L_0x0085
            goto L_0x0088
        L_0x0085:
            r26 = r1
            goto L_0x008b
        L_0x0088:
            r4 = 0
            r26 = r4
        L_0x008b:
            r0.a(r9, r11)
            boolean r6 = r10.f122b
            r1 = r0
            r2 = r9
            r3 = r26
            r4 = r29
            r5 = r15
            java.lang.Object r7 = v(r1, r2, r3, r4, r5, r6)
            if (r7 == 0) goto L_0x00d5
            java.util.ArrayList r19 = new java.util.ArrayList
            r19.<init>()
            r16 = r0
            r17 = r7
            r18 = r9
            r20 = r26
            r21 = r25
            r22 = r29
            r23 = r24
            r16.t(r17, r18, r19, r20, r21, r22, r23)
            r1 = r0
            r2 = r14
            r3 = r15
            r4 = r33
            r5 = r24
            r6 = r9
            r10 = r7
            r7 = r19
            r16 = r8
            r8 = r26
            r17 = r9
            r9 = r25
            z(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            r1 = r24
            r0.w(r14, r1, r12)
            r0.c(r14, r10)
            r0.s(r14, r1, r12)
            goto L_0x00dc
        L_0x00d5:
            r10 = r7
            r16 = r8
            r17 = r9
            r1 = r24
        L_0x00dc:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.p.n(a.b.c.a.k, int, a.b.c.a.p$e, android.view.View, a.b.c.g.a):void");
    }

    public static class b implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ Object f115b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ r f116c;
        public final /* synthetic */ View d;
        public final /* synthetic */ e e;
        public final /* synthetic */ ArrayList f;
        public final /* synthetic */ ArrayList g;
        public final /* synthetic */ ArrayList h;
        public final /* synthetic */ Object i;

        public b(Object obj, r rVar, View view, e eVar, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, Object obj2) {
            this.f115b = obj;
            this.f116c = rVar;
            this.d = view;
            this.e = eVar;
            this.f = arrayList;
            this.g = arrayList2;
            this.h = arrayList3;
            this.i = obj2;
        }

        public void run() {
            Object obj = this.f115b;
            if (obj != null) {
                this.f116c.p(obj, this.d);
                this.g.addAll(p.k(this.f116c, this.f115b, this.e, this.f, this.d));
            }
            if (this.h != null) {
                if (this.i != null) {
                    ArrayList<View> tempExiting = new ArrayList<>();
                    tempExiting.add(this.d);
                    this.f116c.q(this.i, this.h, tempExiting);
                }
                this.h.clear();
                this.h.add(this.d);
            }
        }
    }

    public static void z(r impl, ViewGroup sceneRoot, e inFragment, View nonExistentView, ArrayList<View> sharedElementsIn, Object enterTransition, ArrayList<View> enteringViews, Object exitTransition, ArrayList<View> exitingViews) {
        ViewGroup viewGroup = sceneRoot;
        u.a(sceneRoot, new b(enterTransition, impl, nonExistentView, inFragment, sharedElementsIn, enteringViews, exitingViews, exitTransition));
    }

    public static r j(e outFragment, e inFragment) {
        ArrayList<Object> transitions = new ArrayList<>();
        if (outFragment != null) {
            Object exitTransition = outFragment.p();
            if (exitTransition != null) {
                transitions.add(exitTransition);
            }
            Object returnTransition = outFragment.y();
            if (returnTransition != null) {
                transitions.add(returnTransition);
            }
            Object sharedReturnTransition = outFragment.A();
            if (sharedReturnTransition != null) {
                transitions.add(sharedReturnTransition);
            }
        }
        if (inFragment != null) {
            Object enterTransition = inFragment.n();
            if (enterTransition != null) {
                transitions.add(enterTransition);
            }
            Object reenterTransition = inFragment.w();
            if (reenterTransition != null) {
                transitions.add(reenterTransition);
            }
            Object sharedEnterTransition = inFragment.z();
            if (sharedEnterTransition != null) {
                transitions.add(sharedEnterTransition);
            }
        }
        if (transitions.isEmpty()) {
            return null;
        }
        r rVar = f112b;
        if (rVar != null && g(rVar, transitions)) {
            return f112b;
        }
        r rVar2 = f113c;
        if (rVar2 != null && g(rVar2, transitions)) {
            return f113c;
        }
        if (f112b == null && f113c == null) {
            return null;
        }
        throw new IllegalArgumentException("Invalid Transition types");
    }

    public static boolean g(r impl, List<Object> transitions) {
        int size = transitions.size();
        for (int i = 0; i < size; i++) {
            if (!impl.e(transitions.get(i))) {
                return false;
            }
        }
        return true;
    }

    public static Object u(r impl, e inFragment, e outFragment, boolean isPop) {
        Object obj;
        if (inFragment == null || outFragment == null) {
            return null;
        }
        if (isPop) {
            obj = outFragment.A();
        } else {
            obj = inFragment.z();
        }
        return impl.A(impl.g(obj));
    }

    public static Object r(r impl, e inFragment, boolean isPop) {
        Object obj;
        if (inFragment == null) {
            return null;
        }
        if (isPop) {
            obj = inFragment.w();
        } else {
            obj = inFragment.n();
        }
        return impl.g(obj);
    }

    public static Object s(r impl, e outFragment, boolean isPop) {
        Object obj;
        if (outFragment == null) {
            return null;
        }
        if (isPop) {
            obj = outFragment.y();
        } else {
            obj = outFragment.p();
        }
        return impl.g(obj);
    }

    public static Object m(r impl, ViewGroup sceneRoot, View nonExistentView, a.b.c.g.a<String, String> nameOverrides, e fragments, ArrayList<View> sharedElementsOut, ArrayList<View> sharedElementsIn, Object enterTransition, Object exitTransition) {
        Object sharedElementTransition;
        Object sharedElementTransition2;
        Object sharedElementTransition3;
        View epicenterView;
        Rect epicenter;
        ArrayMap<String, View> inSharedElements;
        r rVar = impl;
        View view = nonExistentView;
        a.b.c.g.a<String, String> aVar = nameOverrides;
        e eVar = fragments;
        ArrayList<View> arrayList = sharedElementsOut;
        ArrayList<View> arrayList2 = sharedElementsIn;
        Object obj = enterTransition;
        e inFragment = eVar.f121a;
        e outFragment = eVar.d;
        if (inFragment != null) {
            inFragment.C().setVisibility(0);
        }
        if (inFragment == null) {
            ViewGroup viewGroup = sceneRoot;
            e eVar2 = outFragment;
        } else if (outFragment == null) {
            ViewGroup viewGroup2 = sceneRoot;
            e eVar3 = outFragment;
        } else {
            boolean inIsPop = eVar.f122b;
            if (nameOverrides.isEmpty()) {
                sharedElementTransition = null;
            } else {
                sharedElementTransition = u(rVar, inFragment, outFragment, inIsPop);
            }
            a.b.c.g.a<String, View> i = i(rVar, aVar, sharedElementTransition, eVar);
            ArrayMap<String, View> inSharedElements2 = h(rVar, aVar, sharedElementTransition, eVar);
            if (nameOverrides.isEmpty()) {
                if (i != null) {
                    i.clear();
                }
                if (inSharedElements2 != null) {
                    inSharedElements2.clear();
                }
                sharedElementTransition2 = null;
            } else {
                a(arrayList, i, nameOverrides.keySet());
                a(arrayList2, inSharedElements2, nameOverrides.values());
                sharedElementTransition2 = sharedElementTransition;
            }
            if (obj == null && exitTransition == null && sharedElementTransition2 == null) {
                return null;
            }
            f(inFragment, outFragment, inIsPop, i, true);
            if (sharedElementTransition2 != null) {
                arrayList2.add(view);
                rVar.y(sharedElementTransition2, view, arrayList);
                sharedElementTransition3 = sharedElementTransition2;
                inSharedElements = inSharedElements2;
                a.b.c.g.a<String, View> aVar2 = i;
                A(impl, sharedElementTransition2, exitTransition, i, eVar.e, eVar.f);
                Rect epicenter2 = new Rect();
                View epicenterView2 = t(inSharedElements, eVar, obj, inIsPop);
                if (epicenterView2 != null) {
                    rVar.u(obj, epicenter2);
                }
                epicenter = epicenter2;
                epicenterView = epicenterView2;
            } else {
                sharedElementTransition3 = sharedElementTransition2;
                inSharedElements = inSharedElements2;
                a.b.c.g.a<String, View> aVar3 = i;
                epicenter = null;
                epicenterView = null;
            }
            c cVar = r0;
            boolean z = inIsPop;
            e eVar4 = outFragment;
            c cVar2 = new c(inFragment, outFragment, inIsPop, inSharedElements, epicenterView, impl, epicenter);
            u.a(sceneRoot, cVar);
            return sharedElementTransition3;
        }
        return null;
    }

    public static class c implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ e f117b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ e f118c;
        public final /* synthetic */ boolean d;
        public final /* synthetic */ a.b.c.g.a e;
        public final /* synthetic */ View f;
        public final /* synthetic */ r g;
        public final /* synthetic */ Rect h;

        public c(e eVar, e eVar2, boolean z, a.b.c.g.a aVar, View view, r rVar, Rect rect) {
            this.f117b = eVar;
            this.f118c = eVar2;
            this.d = z;
            this.e = aVar;
            this.f = view;
            this.g = rVar;
            this.h = rect;
        }

        public void run() {
            p.f(this.f117b, this.f118c, this.d, this.e, false);
            View view = this.f;
            if (view != null) {
                this.g.k(view, this.h);
            }
        }
    }

    public static void a(ArrayList<View> views, a.b.c.g.a<String, View> sharedElements, Collection<String> nameOverridesSet) {
        for (int i = sharedElements.size() - 1; i >= 0; i--) {
            View view = sharedElements.l(i);
            if (nameOverridesSet.contains(a.b.c.h.p.h(view))) {
                views.add(view);
            }
        }
    }

    public static Object l(r impl, ViewGroup sceneRoot, View nonExistentView, a.b.c.g.a<String, String> nameOverrides, e fragments, ArrayList<View> sharedElementsOut, ArrayList<View> sharedElementsIn, Object enterTransition, Object exitTransition) {
        Object sharedElementTransition;
        Object sharedElementTransition2;
        ArrayMap<String, View> inEpicenter;
        r rVar = impl;
        e eVar = fragments;
        ArrayList<View> arrayList = sharedElementsOut;
        Object obj = enterTransition;
        e inFragment = eVar.f121a;
        e outFragment = eVar.d;
        if (inFragment == null) {
            ViewGroup viewGroup = sceneRoot;
            e eVar2 = outFragment;
            e eVar3 = inFragment;
        } else if (outFragment == null) {
            ViewGroup viewGroup2 = sceneRoot;
            e eVar4 = outFragment;
            e eVar5 = inFragment;
        } else {
            boolean inIsPop = eVar.f122b;
            if (nameOverrides.isEmpty()) {
                sharedElementTransition = null;
            } else {
                sharedElementTransition = u(rVar, inFragment, outFragment, inIsPop);
            }
            a.b.c.g.a<String, View> i = i(rVar, nameOverrides, sharedElementTransition, eVar);
            if (nameOverrides.isEmpty()) {
                sharedElementTransition2 = null;
            } else {
                arrayList.addAll(i.values());
                sharedElementTransition2 = sharedElementTransition;
            }
            if (obj == null && exitTransition == null && sharedElementTransition2 == null) {
                return null;
            }
            f(inFragment, outFragment, inIsPop, i, true);
            if (sharedElementTransition2 != null) {
                ArrayMap<String, View> inEpicenter2 = new Rect<>();
                rVar.y(sharedElementTransition2, nonExistentView, arrayList);
                a.b.c.g.a<String, View> aVar = i;
                ArrayMap<String, View> outSharedElements = inEpicenter2;
                A(impl, sharedElementTransition2, exitTransition, i, eVar.e, eVar.f);
                if (obj != null) {
                    rVar.u(obj, outSharedElements);
                }
                inEpicenter = outSharedElements;
            } else {
                a.b.c.g.a<String, View> aVar2 = i;
                inEpicenter = null;
            }
            Object sharedElementTransition3 = sharedElementTransition2;
            d dVar = r0;
            boolean z = inIsPop;
            e eVar6 = outFragment;
            e eVar7 = inFragment;
            d dVar2 = new d(impl, nameOverrides, sharedElementTransition2, fragments, sharedElementsIn, nonExistentView, inFragment, outFragment, inIsPop, sharedElementsOut, enterTransition, inEpicenter);
            u.a(sceneRoot, dVar);
            return sharedElementTransition3;
        }
        return null;
    }

    public static class d implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ r f119b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ a.b.c.g.a f120c;
        public final /* synthetic */ Object d;
        public final /* synthetic */ e e;
        public final /* synthetic */ ArrayList f;
        public final /* synthetic */ View g;
        public final /* synthetic */ e h;
        public final /* synthetic */ e i;
        public final /* synthetic */ boolean j;
        public final /* synthetic */ ArrayList k;
        public final /* synthetic */ Object l;
        public final /* synthetic */ Rect m;

        public d(r rVar, a.b.c.g.a aVar, Object obj, e eVar, ArrayList arrayList, View view, e eVar2, e eVar3, boolean z, ArrayList arrayList2, Object obj2, Rect rect) {
            this.f119b = rVar;
            this.f120c = aVar;
            this.d = obj;
            this.e = eVar;
            this.f = arrayList;
            this.g = view;
            this.h = eVar2;
            this.i = eVar3;
            this.j = z;
            this.k = arrayList2;
            this.l = obj2;
            this.m = rect;
        }

        public void run() {
            ArrayMap<String, View> inSharedElements = p.h(this.f119b, this.f120c, this.d, this.e);
            if (inSharedElements != null) {
                this.f.addAll(inSharedElements.values());
                this.f.add(this.g);
            }
            p.f(this.h, this.i, this.j, inSharedElements, false);
            Object obj = this.d;
            if (obj != null) {
                this.f119b.z(obj, this.k, this.f);
                View inEpicenterView = p.t(inSharedElements, this.e, this.l, this.j);
                if (inEpicenterView != null) {
                    this.f119b.k(inEpicenterView, this.m);
                }
            }
        }
    }

    public static a.b.c.g.a<String, View> i(r impl, a.b.c.g.a<String, String> nameOverrides, Object sharedElementTransition, e fragments) {
        ArrayList<String> names;
        v sharedElementCallback;
        if (nameOverrides.isEmpty() || sharedElementTransition == null) {
            nameOverrides.clear();
            return null;
        }
        e outFragment = fragments.d;
        ArrayMap<String, View> outSharedElements = new a.b.c.g.a<>();
        impl.j(outSharedElements, outFragment.C());
        c outTransaction = fragments.f;
        if (fragments.e) {
            outFragment.o();
            sharedElementCallback = null;
            names = outTransaction.q;
        } else {
            outFragment.q();
            sharedElementCallback = null;
            names = outTransaction.p;
        }
        outSharedElements.n(names);
        if (sharedElementCallback != null) {
            sharedElementCallback.a(names, outSharedElements);
            for (int i = names.size() - 1; i >= 0; i--) {
                String name = names.get(i);
                View view = outSharedElements.get(name);
                if (view == null) {
                    nameOverrides.remove(name);
                } else if (!name.equals(a.b.c.h.p.h(view))) {
                    nameOverrides.put(a.b.c.h.p.h(view), nameOverrides.remove(name));
                }
            }
        } else {
            nameOverrides.n(outSharedElements.keySet());
        }
        return outSharedElements;
    }

    public static a.b.c.g.a<String, View> h(r impl, a.b.c.g.a<String, String> nameOverrides, Object sharedElementTransition, e fragments) {
        ArrayList<String> names;
        v sharedElementCallback;
        String key;
        e inFragment = fragments.f121a;
        View fragmentView = inFragment.C();
        if (nameOverrides.isEmpty() || sharedElementTransition == null || fragmentView == null) {
            nameOverrides.clear();
            return null;
        }
        ArrayMap<String, View> inSharedElements = new a.b.c.g.a<>();
        impl.j(inSharedElements, fragmentView);
        c inTransaction = fragments.f123c;
        if (fragments.f122b) {
            inFragment.q();
            sharedElementCallback = null;
            names = inTransaction.p;
        } else {
            inFragment.o();
            sharedElementCallback = null;
            names = inTransaction.q;
        }
        if (names != null) {
            inSharedElements.n(names);
            inSharedElements.n(nameOverrides.values());
        }
        if (sharedElementCallback != null) {
            sharedElementCallback.a(names, inSharedElements);
            for (int i = names.size() - 1; i >= 0; i--) {
                String name = names.get(i);
                View view = inSharedElements.get(name);
                if (view == null) {
                    String key2 = q(nameOverrides, name);
                    if (key2 != null) {
                        nameOverrides.remove(key2);
                    }
                } else if (!name.equals(a.b.c.h.p.h(view)) && (key = q(nameOverrides, name)) != null) {
                    nameOverrides.put(key, a.b.c.h.p.h(view));
                }
            }
        } else {
            y(nameOverrides, inSharedElements);
        }
        return inSharedElements;
    }

    public static String q(a.b.c.g.a<String, String> map, String value) {
        int numElements = map.size();
        for (int i = 0; i < numElements; i++) {
            if (value.equals(map.l(i))) {
                return map.i(i);
            }
        }
        return null;
    }

    public static View t(a.b.c.g.a<String, View> inSharedElements, e fragments, Object enterTransition, boolean inIsPop) {
        ArrayList<String> arrayList;
        String targetName;
        c inTransaction = fragments.f123c;
        if (enterTransition == null || inSharedElements == null || (arrayList = inTransaction.p) == null || arrayList.isEmpty()) {
            return null;
        }
        if (inIsPop) {
            targetName = inTransaction.p.get(0);
        } else {
            targetName = inTransaction.q.get(0);
        }
        return inSharedElements.get(targetName);
    }

    public static void A(r impl, Object sharedElementTransition, Object exitTransition, a.b.c.g.a<String, View> outSharedElements, boolean outIsPop, c outTransaction) {
        String sourceName;
        ArrayList<String> arrayList = outTransaction.p;
        if (arrayList != null && !arrayList.isEmpty()) {
            if (outIsPop) {
                sourceName = outTransaction.q.get(0);
            } else {
                sourceName = outTransaction.p.get(0);
            }
            View outEpicenterView = outSharedElements.get(sourceName);
            impl.v(sharedElementTransition, outEpicenterView);
            if (exitTransition != null) {
                impl.v(exitTransition, outEpicenterView);
            }
        }
    }

    public static void y(a.b.c.g.a<String, String> nameOverrides, a.b.c.g.a<String, View> namedViews) {
        for (int i = nameOverrides.size() - 1; i >= 0; i--) {
            if (!namedViews.containsKey(nameOverrides.l(i))) {
                nameOverrides.j(i);
            }
        }
    }

    public static void f(e inFragment, e outFragment, boolean isPop, a.b.c.g.a<String, View> sharedElements, boolean isStart) {
        if (isPop) {
            outFragment.o();
        } else {
            inFragment.o();
        }
        v sharedElementCallback = null;
        if (sharedElementCallback != null) {
            ArrayList<View> views = new ArrayList<>();
            ArrayList<String> names = new ArrayList<>();
            int count = sharedElements == null ? 0 : sharedElements.size();
            for (int i = 0; i < count; i++) {
                names.add(sharedElements.i(i));
                views.add(sharedElements.l(i));
            }
            if (isStart) {
                sharedElementCallback.c(names, views, (List<View>) null);
            } else {
                sharedElementCallback.b(names, views, (List<View>) null);
            }
        }
    }

    public static ArrayList<View> k(r impl, Object transition, e fragment, ArrayList<View> sharedElements, View nonExistentView) {
        ArrayList<View> viewList = null;
        if (transition != null) {
            viewList = new ArrayList<>();
            View root = fragment.C();
            if (root != null) {
                impl.f(viewList, root);
            }
            if (sharedElements != null) {
                viewList.removeAll(sharedElements);
            }
            if (!viewList.isEmpty()) {
                viewList.add(nonExistentView);
                impl.b(transition, viewList);
            }
        }
        return viewList;
    }

    public static void B(ArrayList<View> views, int visibility) {
        if (views != null) {
            for (int i = views.size() - 1; i >= 0; i--) {
                views.get(i).setVisibility(visibility);
            }
        }
    }

    public static Object v(r impl, Object enterTransition, Object exitTransition, Object sharedElementTransition, e inFragment, boolean isPop) {
        boolean z;
        boolean overlap = true;
        if (!(enterTransition == null || exitTransition == null || inFragment == null)) {
            if (isPop) {
                z = inFragment.i();
            } else {
                z = inFragment.h();
            }
            overlap = z;
        }
        if (overlap) {
            return impl.n(exitTransition, enterTransition, sharedElementTransition);
        }
        return impl.m(exitTransition, enterTransition, sharedElementTransition);
    }

    public static void c(c transaction, SparseArray<e> transitioningFragments, boolean isReordered) {
        int numOps = transaction.f56b.size();
        for (int opNum = 0; opNum < numOps; opNum++) {
            b(transaction, transaction.f56b.get(opNum), transitioningFragments, false, isReordered);
        }
    }

    public static void e(c transaction, SparseArray<e> transitioningFragments, boolean isReordered) {
        if (transaction.f55a.m.c()) {
            for (int opNum = transaction.f56b.size() - 1; opNum >= 0; opNum--) {
                b(transaction, transaction.f56b.get(opNum), transitioningFragments, true, isReordered);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:102:0x0128  */
    /* JADX WARNING: Removed duplicated region for block: B:105:0x012d A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:111:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x00c3  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x00d0  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x00d4 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:97:0x0114  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void b(a.b.c.a.c r22, a.b.c.a.c.a r23, android.util.SparseArray<a.b.c.a.p.e> r24, boolean r25, boolean r26) {
        /*
            r0 = r22
            r1 = r23
            r2 = r24
            r3 = r25
            a.b.c.a.e r10 = r1.f59b
            if (r10 != 0) goto L_0x000d
            return
        L_0x000d:
            int r11 = r10.z
            if (r11 != 0) goto L_0x0012
            return
        L_0x0012:
            if (r3 == 0) goto L_0x001b
            int[] r4 = f111a
            int r5 = r1.f58a
            r4 = r4[r5]
            goto L_0x001d
        L_0x001b:
            int r4 = r1.f58a
        L_0x001d:
            r12 = r4
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            r9 = 1
            if (r12 == r9) goto L_0x00a6
            r13 = 3
            if (r12 == r13) goto L_0x0079
            r13 = 4
            if (r12 == r13) goto L_0x0057
            r13 = 5
            if (r12 == r13) goto L_0x003c
            r13 = 6
            if (r12 == r13) goto L_0x0079
            r13 = 7
            if (r12 == r13) goto L_0x00a6
            r13 = r4
            r14 = r5
            r15 = r6
            r16 = r7
            goto L_0x00bb
        L_0x003c:
            if (r26 == 0) goto L_0x004d
            boolean r13 = r10.P
            if (r13 == 0) goto L_0x004b
            boolean r13 = r10.B
            if (r13 != 0) goto L_0x004b
            boolean r13 = r10.l
            if (r13 == 0) goto L_0x004b
            r8 = 1
        L_0x004b:
            r4 = r8
            goto L_0x004f
        L_0x004d:
            boolean r4 = r10.B
        L_0x004f:
            r7 = 1
            r13 = r4
            r14 = r5
            r15 = r6
            r16 = r7
            goto L_0x00bb
        L_0x0057:
            if (r26 == 0) goto L_0x0068
            boolean r13 = r10.P
            if (r13 == 0) goto L_0x0066
            boolean r13 = r10.l
            if (r13 == 0) goto L_0x0066
            boolean r13 = r10.B
            if (r13 == 0) goto L_0x0066
            r8 = 1
        L_0x0066:
            r6 = r8
            goto L_0x0072
        L_0x0068:
            boolean r13 = r10.l
            if (r13 == 0) goto L_0x0071
            boolean r13 = r10.B
            if (r13 != 0) goto L_0x0071
            r8 = 1
        L_0x0071:
            r6 = r8
        L_0x0072:
            r5 = 1
            r13 = r4
            r14 = r5
            r15 = r6
            r16 = r7
            goto L_0x00bb
        L_0x0079:
            if (r26 == 0) goto L_0x0095
            boolean r13 = r10.l
            if (r13 != 0) goto L_0x0092
            android.view.View r13 = r10.J
            if (r13 == 0) goto L_0x0092
            int r13 = r13.getVisibility()
            if (r13 != 0) goto L_0x0092
            float r13 = r10.Q
            r14 = 0
            int r13 = (r13 > r14 ? 1 : (r13 == r14 ? 0 : -1))
            if (r13 < 0) goto L_0x0092
            r8 = 1
            goto L_0x0093
        L_0x0092:
        L_0x0093:
            r6 = r8
            goto L_0x009f
        L_0x0095:
            boolean r13 = r10.l
            if (r13 == 0) goto L_0x009e
            boolean r13 = r10.B
            if (r13 != 0) goto L_0x009e
            r8 = 1
        L_0x009e:
            r6 = r8
        L_0x009f:
            r5 = 1
            r13 = r4
            r14 = r5
            r15 = r6
            r16 = r7
            goto L_0x00bb
        L_0x00a6:
            if (r26 == 0) goto L_0x00ab
            boolean r4 = r10.O
            goto L_0x00b5
        L_0x00ab:
            boolean r13 = r10.l
            if (r13 != 0) goto L_0x00b4
            boolean r13 = r10.B
            if (r13 != 0) goto L_0x00b4
            r8 = 1
        L_0x00b4:
            r4 = r8
        L_0x00b5:
            r7 = 1
            r13 = r4
            r14 = r5
            r15 = r6
            r16 = r7
        L_0x00bb:
            java.lang.Object r4 = r2.get(r11)
            a.b.c.a.p$e r4 = (a.b.c.a.p.e) r4
            if (r13 == 0) goto L_0x00d0
            a.b.c.a.p$e r4 = p(r4, r2, r11)
            r4.f121a = r10
            r4.f122b = r3
            r4.f123c = r0
            r8 = r4
            goto L_0x00d1
        L_0x00d0:
            r8 = r4
        L_0x00d1:
            r7 = 0
            if (r26 != 0) goto L_0x010f
            if (r16 == 0) goto L_0x010f
            if (r8 == 0) goto L_0x00de
            a.b.c.a.e r4 = r8.d
            if (r4 != r10) goto L_0x00de
            r8.d = r7
        L_0x00de:
            a.b.c.a.k r6 = r0.f55a
            int r4 = r10.f63b
            if (r4 >= r9) goto L_0x0109
            int r4 = r6.k
            if (r4 < r9) goto L_0x0109
            boolean r4 = r0.r
            if (r4 != 0) goto L_0x0109
            r6.r0(r10)
            r9 = 1
            r17 = 0
            r18 = 0
            r19 = 0
            r4 = r6
            r5 = r10
            r20 = r6
            r6 = r9
            r9 = r7
            r7 = r17
            r21 = r8
            r8 = r18
            r1 = r9
            r9 = r19
            r4.B0(r5, r6, r7, r8, r9)
            goto L_0x0112
        L_0x0109:
            r20 = r6
            r1 = r7
            r21 = r8
            goto L_0x0112
        L_0x010f:
            r1 = r7
            r21 = r8
        L_0x0112:
            if (r15 == 0) goto L_0x0128
            r4 = r21
            if (r4 == 0) goto L_0x011c
            a.b.c.a.e r5 = r4.d
            if (r5 != 0) goto L_0x012a
        L_0x011c:
            a.b.c.a.p$e r8 = p(r4, r2, r11)
            r8.d = r10
            r8.e = r3
            r8.f = r0
            goto L_0x012b
        L_0x0128:
            r4 = r21
        L_0x012a:
            r8 = r4
        L_0x012b:
            if (r26 != 0) goto L_0x0137
            if (r14 == 0) goto L_0x0137
            if (r8 == 0) goto L_0x0137
            a.b.c.a.e r4 = r8.f121a
            if (r4 != r10) goto L_0x0137
            r8.f121a = r1
        L_0x0137:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.a.p.b(a.b.c.a.c, a.b.c.a.c$a, android.util.SparseArray, boolean, boolean):void");
    }

    public static e p(e containerTransition, SparseArray<e> transitioningFragments, int containerId) {
        if (containerTransition != null) {
            return containerTransition;
        }
        e containerTransition2 = new e();
        transitioningFragments.put(containerId, containerTransition2);
        return containerTransition2;
    }
}
