package a.b.c.h;

import android.view.View;

public class v implements u {
    public void b(View view) {
    }

    public void c(View view) {
    }
}
