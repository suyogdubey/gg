package b.b;

public interface c {
}
