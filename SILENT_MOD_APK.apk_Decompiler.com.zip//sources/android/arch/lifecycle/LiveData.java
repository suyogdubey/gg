package android.arch.lifecycle;

import a.a.b.c;
import a.a.b.e;
import a.a.b.j;
import java.util.Map;

public abstract class LiveData<T> {
    public static final Object i = new Object();

    /* renamed from: a  reason: collision with root package name */
    public final Object f562a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public a.a.a.b.b<j<T>, LiveData<T>.b> f563b = new a.a.a.b.b<>();

    /* renamed from: c  reason: collision with root package name */
    public int f564c = 0;
    public volatile Object d = i;
    public volatile Object e = i;
    public int f = -1;
    public boolean g;
    public boolean h;

    public LiveData() {
        new a();
    }

    public class a implements Runnable {
        public a() {
        }

        public void run() {
            synchronized (LiveData.this.f562a) {
                try {
                    Object newValue = LiveData.this.e;
                    try {
                        Object unused = LiveData.this.e = LiveData.i;
                        LiveData.this.n(newValue);
                    } catch (Throwable th) {
                        th = th;
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    throw th;
                }
            }
        }
    }

    public final void i(LiveData<T>.b observer) {
        if (observer.f567b) {
            if (!observer.j()) {
                observer.h(false);
                return;
            }
            int i2 = observer.f568c;
            int i3 = this.f;
            if (i2 < i3) {
                observer.f568c = i3;
                observer.f566a.a(this.d);
            }
        }
    }

    public final void j(LiveData<T>.ObserverWrapper initiator) {
        if (this.g) {
            this.h = true;
            return;
        }
        this.g = true;
        do {
            this.h = false;
            if (initiator == null) {
                a.a.a.b.b<K, V>.e e2 = this.f563b.e();
                while (e2.hasNext()) {
                    i((b) ((Map.Entry) e2.next()).getValue());
                    if (this.h) {
                        break;
                    }
                }
            } else {
                i(initiator);
                initiator = null;
            }
        } while (this.h);
        this.g = false;
    }

    public void m(j<T> observer) {
        h("removeObserver");
        LiveData<T>.ObserverWrapper removed = (b) this.f563b.g(observer);
        if (removed != null) {
            removed.i();
            removed.h(false);
        }
    }

    public void n(T value) {
        h("setValue");
        this.f++;
        this.d = value;
        j((LiveData<T>.b) null);
    }

    public void k() {
    }

    public void l() {
    }

    public class LifecycleBoundObserver extends LiveData<T>.b implements GenericLifecycleObserver {
        public final e e;
        public final /* synthetic */ LiveData f;

        public boolean j() {
            return this.e.a().a().a(c.b.STARTED);
        }

        public void g(e source, c.a event) {
            if (this.e.a().a() == c.b.DESTROYED) {
                this.f.m(this.f566a);
            } else {
                h(j());
            }
        }

        public void i() {
            this.e.a().b(this);
        }
    }

    public abstract class b {

        /* renamed from: a  reason: collision with root package name */
        public final j<T> f566a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f567b;

        /* renamed from: c  reason: collision with root package name */
        public int f568c;
        public final /* synthetic */ LiveData d;

        public abstract boolean j();

        public void i() {
        }

        public void h(boolean newActive) {
            if (newActive != this.f567b) {
                this.f567b = newActive;
                int i = 1;
                boolean wasInactive = this.d.f564c == 0;
                LiveData liveData = this.d;
                int e = liveData.f564c;
                if (!this.f567b) {
                    i = -1;
                }
                int unused = liveData.f564c = e + i;
                if (wasInactive && this.f567b) {
                    this.d.k();
                }
                if (this.d.f564c == 0 && !this.f567b) {
                    this.d.l();
                }
                if (this.f567b) {
                    this.d.j(this);
                }
            }
        }
    }

    public static void h(String methodName) {
        if (!a.a.a.a.a.d().b()) {
            throw new IllegalStateException("Cannot invoke " + methodName + " on a background" + " thread");
        }
    }
}
