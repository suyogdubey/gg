package b.a;

public final class a {
    public static final int cardBackgroundColor = 2130837574;
    public static final int cardCornerRadius = 2130837575;
    public static final int cardElevation = 2130837576;
    public static final int cardMaxElevation = 2130837577;
    public static final int cardPreventCornerOverlap = 2130837578;
    public static final int cardUseCompatPadding = 2130837579;
    public static final int cardViewStyle = 2130837580;
    public static final int contentPadding = 2130837610;
    public static final int contentPaddingBottom = 2130837611;
    public static final int contentPaddingLeft = 2130837612;
    public static final int contentPaddingRight = 2130837613;
    public static final int contentPaddingTop = 2130837614;
}
