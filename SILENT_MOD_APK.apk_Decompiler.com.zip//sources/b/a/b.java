package b.a;

public final class b {
    public static final int cardview_dark_background = 2130968616;
    public static final int cardview_light_background = 2130968617;
    public static final int cardview_shadow_end_color = 2130968618;
    public static final int cardview_shadow_start_color = 2130968619;
}
