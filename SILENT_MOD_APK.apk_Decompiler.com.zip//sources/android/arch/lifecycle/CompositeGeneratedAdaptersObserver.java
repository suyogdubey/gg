package android.arch.lifecycle;

import a.a.b.b;
import a.a.b.c;
import a.a.b.e;
import a.a.b.h;

public class CompositeGeneratedAdaptersObserver implements GenericLifecycleObserver {

    /* renamed from: a  reason: collision with root package name */
    public final b[] f560a;

    public void g(e source, c.a event) {
        h logger = new h();
        for (b mGenerated : this.f560a) {
            mGenerated.a(source, event, false, logger);
        }
        for (b mGenerated2 : this.f560a) {
            mGenerated2.a(source, event, true, logger);
        }
    }
}
