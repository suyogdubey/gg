package android.support.v7.widget;

import a.b.d.a.f;
import a.b.d.f.e0;
import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class FitWindowsLinearLayout extends LinearLayout implements e0 {

    /* renamed from: b  reason: collision with root package name */
    public e0.a f628b;

    public FitWindowsLinearLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setOnFitSystemWindowsListener(e0.a listener) {
        this.f628b = listener;
    }

    public boolean fitSystemWindows(Rect insets) {
        e0.a aVar = this.f628b;
        if (aVar != null) {
            ((f.d) aVar).a(insets);
        }
        return super.fitSystemWindows(insets);
    }
}
