package android.support.v7.widget;

import a.b.d.e.j.h;
import a.b.d.e.j.j;
import a.b.d.e.j.o;
import a.b.d.e.j.p;
import a.b.d.f.a1;
import a.b.d.f.g0;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

public class ActionMenuView extends g0 implements h.b, p {
    public int A;
    public e B;
    public h q;
    public Context r;
    public int s;
    public boolean t;
    public a.b.d.f.c u;
    public o.a v;
    public h.a w;
    public boolean x;
    public int y;
    public int z;

    public interface a {
        boolean a();

        boolean b();
    }

    public interface e {
    }

    public ActionMenuView(Context context) {
        this(context, (AttributeSet) null);
    }

    public ActionMenuView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBaselineAligned(false);
        float density = context.getResources().getDisplayMetrics().density;
        this.z = (int) (56.0f * density);
        this.A = (int) (4.0f * density);
        this.r = context;
        this.s = 0;
    }

    public void setPopupTheme(int resId) {
        if (this.s != resId) {
            this.s = resId;
            if (resId == 0) {
                this.r = getContext();
            } else {
                this.r = new ContextThemeWrapper(getContext(), resId);
            }
        }
    }

    public int getPopupTheme() {
        return this.s;
    }

    public void setPresenter(a.b.d.f.c presenter) {
        this.u = presenter;
        presenter.G(this);
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        a.b.d.f.c cVar = this.u;
        if (cVar != null) {
            cVar.i(false);
            if (this.u.D()) {
                this.u.A();
                this.u.J();
            }
        }
    }

    public void setOnMenuItemClickListener(e listener) {
        this.B = listener;
    }

    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        h hVar;
        boolean wasFormatted = this.x;
        boolean z2 = View.MeasureSpec.getMode(widthMeasureSpec) == 1073741824;
        this.x = z2;
        if (wasFormatted != z2) {
            this.y = 0;
        }
        int widthSize = View.MeasureSpec.getSize(widthMeasureSpec);
        if (!(!this.x || (hVar = this.q) == null || widthSize == this.y)) {
            this.y = widthSize;
            hVar.K(true);
        }
        int childCount = getChildCount();
        if (!this.x || childCount <= 0) {
            for (int i = 0; i < childCount; i++) {
                c lp = (c) getChildAt(i).getLayoutParams();
                lp.rightMargin = 0;
                lp.leftMargin = 0;
            }
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            return;
        }
        K(widthMeasureSpec, heightMeasureSpec);
    }

    /* JADX WARNING: Removed duplicated region for block: B:130:0x0285  */
    /* JADX WARNING: Removed duplicated region for block: B:138:0x02b3  */
    /* JADX WARNING: Removed duplicated region for block: B:141:0x02bb  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x02bd  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void K(int r41, int r42) {
        /*
            r40 = this;
            r0 = r40
            int r1 = android.view.View.MeasureSpec.getMode(r42)
            int r2 = android.view.View.MeasureSpec.getSize(r41)
            int r3 = android.view.View.MeasureSpec.getSize(r42)
            int r4 = r40.getPaddingLeft()
            int r5 = r40.getPaddingRight()
            int r4 = r4 + r5
            int r5 = r40.getPaddingTop()
            int r6 = r40.getPaddingBottom()
            int r5 = r5 + r6
            r6 = -2
            r7 = r42
            int r6 = android.view.ViewGroup.getChildMeasureSpec(r7, r5, r6)
            int r2 = r2 - r4
            int r8 = r0.z
            int r9 = r2 / r8
            int r10 = r2 % r8
            r11 = 0
            if (r9 != 0) goto L_0x0035
            r0.setMeasuredDimension(r2, r11)
            return
        L_0x0035:
            int r12 = r10 / r9
            int r8 = r8 + r12
            r12 = r9
            r13 = 0
            r14 = 0
            r15 = 0
            r16 = 0
            r17 = 0
            r18 = 0
            int r11 = r40.getChildCount()
            r21 = 0
            r38 = r16
            r16 = r3
            r3 = r38
            r39 = r21
            r21 = r4
            r4 = r39
        L_0x0054:
            if (r4 >= r11) goto L_0x00e6
            android.view.View r7 = r0.getChildAt(r4)
            r23 = r9
            int r9 = r7.getVisibility()
            r24 = r10
            r10 = 8
            if (r9 != r10) goto L_0x0068
            goto L_0x00dc
        L_0x0068:
            boolean r9 = r7 instanceof android.support.v7.view.menu.ActionMenuItemView
            int r3 = r3 + 1
            if (r9 == 0) goto L_0x0077
            int r10 = r0.A
            r25 = r3
            r3 = 0
            r7.setPadding(r10, r3, r10, r3)
            goto L_0x007a
        L_0x0077:
            r25 = r3
            r3 = 0
        L_0x007a:
            android.view.ViewGroup$LayoutParams r10 = r7.getLayoutParams()
            android.support.v7.widget.ActionMenuView$c r10 = (android.support.v7.widget.ActionMenuView.c) r10
            r10.h = r3
            r10.e = r3
            r10.d = r3
            r10.f = r3
            r10.leftMargin = r3
            r10.rightMargin = r3
            if (r9 == 0) goto L_0x0099
            r3 = r7
            android.support.v7.view.menu.ActionMenuItemView r3 = (android.support.v7.view.menu.ActionMenuItemView) r3
            boolean r3 = r3.f()
            if (r3 == 0) goto L_0x0099
            r3 = 1
            goto L_0x009a
        L_0x0099:
            r3 = 0
        L_0x009a:
            r10.g = r3
            boolean r3 = r10.f620c
            if (r3 == 0) goto L_0x00a2
            r3 = 1
            goto L_0x00a3
        L_0x00a2:
            r3 = r12
        L_0x00a3:
            r26 = r9
            int r9 = J(r7, r8, r3, r6, r5)
            int r14 = java.lang.Math.max(r14, r9)
            r27 = r3
            boolean r3 = r10.f
            if (r3 == 0) goto L_0x00b5
            int r15 = r15 + 1
        L_0x00b5:
            boolean r3 = r10.f620c
            if (r3 == 0) goto L_0x00bb
            r17 = 1
        L_0x00bb:
            int r12 = r12 - r9
            int r3 = r7.getMeasuredHeight()
            int r3 = java.lang.Math.max(r13, r3)
            r13 = 1
            if (r9 != r13) goto L_0x00d5
            int r13 = r13 << r4
            r28 = r9
            r22 = r10
            long r9 = (long) r13
            long r9 = r18 | r9
            r13 = r3
            r18 = r9
            r3 = r25
            goto L_0x00dc
        L_0x00d5:
            r28 = r9
            r22 = r10
            r13 = r3
            r3 = r25
        L_0x00dc:
            int r4 = r4 + 1
            r7 = r42
            r9 = r23
            r10 = r24
            goto L_0x0054
        L_0x00e6:
            r23 = r9
            r24 = r10
            r4 = 2
            if (r17 == 0) goto L_0x00f1
            if (r3 != r4) goto L_0x00f1
            r7 = 1
            goto L_0x00f2
        L_0x00f1:
            r7 = 0
        L_0x00f2:
            r9 = 0
        L_0x00f3:
            r25 = 1
            r27 = 0
            if (r15 <= 0) goto L_0x01a6
            if (r12 <= 0) goto L_0x01a6
            r10 = 2147483647(0x7fffffff, float:NaN)
            r29 = 0
            r31 = 0
            r32 = 0
            r4 = r31
            r38 = r32
            r32 = r5
            r5 = r38
        L_0x010c:
            if (r5 >= r11) goto L_0x013c
            android.view.View r33 = r0.getChildAt(r5)
            android.view.ViewGroup$LayoutParams r34 = r33.getLayoutParams()
            r35 = r9
            r9 = r34
            android.support.v7.widget.ActionMenuView$c r9 = (android.support.v7.widget.ActionMenuView.c) r9
            r34 = r15
            boolean r15 = r9.f
            if (r15 != 0) goto L_0x0123
            goto L_0x0135
        L_0x0123:
            int r15 = r9.d
            if (r15 >= r10) goto L_0x012d
            int r10 = r9.d
            long r29 = r25 << r5
            r4 = 1
            goto L_0x0135
        L_0x012d:
            if (r15 != r10) goto L_0x0135
            long r36 = r25 << r5
            long r29 = r29 | r36
            int r4 = r4 + 1
        L_0x0135:
            int r5 = r5 + 1
            r15 = r34
            r9 = r35
            goto L_0x010c
        L_0x013c:
            r35 = r9
            r34 = r15
            long r18 = r18 | r29
            if (r4 <= r12) goto L_0x014a
            r36 = r1
            r37 = r2
            goto L_0x01b0
        L_0x014a:
            int r10 = r10 + 1
            r5 = 0
        L_0x014d:
            if (r5 >= r11) goto L_0x0198
            android.view.View r9 = r0.getChildAt(r5)
            android.view.ViewGroup$LayoutParams r15 = r9.getLayoutParams()
            android.support.v7.widget.ActionMenuView$c r15 = (android.support.v7.widget.ActionMenuView.c) r15
            r33 = r4
            r22 = 1
            int r4 = r22 << r5
            r36 = r1
            r37 = r2
            long r1 = (long) r4
            long r1 = r29 & r1
            int r4 = (r1 > r27 ? 1 : (r1 == r27 ? 0 : -1))
            if (r4 != 0) goto L_0x0174
            int r1 = r15.d
            if (r1 != r10) goto L_0x018f
            int r1 = r22 << r5
            long r1 = (long) r1
            long r18 = r18 | r1
            goto L_0x018f
        L_0x0174:
            if (r7 == 0) goto L_0x0185
            boolean r1 = r15.g
            if (r1 == 0) goto L_0x0185
            r1 = 1
            if (r12 != r1) goto L_0x0185
            int r1 = r0.A
            int r2 = r1 + r8
            r4 = 0
            r9.setPadding(r2, r4, r1, r4)
        L_0x0185:
            int r1 = r15.d
            r2 = 1
            int r1 = r1 + r2
            r15.d = r1
            r15.h = r2
            int r12 = r12 + -1
        L_0x018f:
            int r5 = r5 + 1
            r4 = r33
            r1 = r36
            r2 = r37
            goto L_0x014d
        L_0x0198:
            r36 = r1
            r37 = r2
            r33 = r4
            r9 = 1
            r5 = r32
            r15 = r34
            r4 = 2
            goto L_0x00f3
        L_0x01a6:
            r36 = r1
            r37 = r2
            r32 = r5
            r35 = r9
            r34 = r15
        L_0x01b0:
            if (r17 != 0) goto L_0x01b7
            r1 = 1
            if (r3 != r1) goto L_0x01b7
            r1 = 1
            goto L_0x01b8
        L_0x01b7:
            r1 = 0
        L_0x01b8:
            if (r12 <= 0) goto L_0x0280
            int r2 = (r18 > r27 ? 1 : (r18 == r27 ? 0 : -1))
            if (r2 == 0) goto L_0x0280
            int r2 = r3 + -1
            if (r12 < r2) goto L_0x01cb
            if (r1 != 0) goto L_0x01cb
            r2 = 1
            if (r14 <= r2) goto L_0x01c8
            goto L_0x01cb
        L_0x01c8:
            r10 = r1
            goto L_0x0281
        L_0x01cb:
            int r2 = java.lang.Long.bitCount(r18)
            float r2 = (float) r2
            if (r1 != 0) goto L_0x0209
            long r4 = r18 & r25
            r9 = 1056964608(0x3f000000, float:0.5)
            int r10 = (r4 > r27 ? 1 : (r4 == r27 ? 0 : -1))
            if (r10 == 0) goto L_0x01eb
            r4 = 0
            android.view.View r5 = r0.getChildAt(r4)
            android.view.ViewGroup$LayoutParams r5 = r5.getLayoutParams()
            android.support.v7.widget.ActionMenuView$c r5 = (android.support.v7.widget.ActionMenuView.c) r5
            boolean r10 = r5.g
            if (r10 != 0) goto L_0x01ec
            float r2 = r2 - r9
            goto L_0x01ec
        L_0x01eb:
            r4 = 0
        L_0x01ec:
            int r5 = r11 + -1
            r10 = 1
            int r5 = r10 << r5
            long r4 = (long) r5
            long r4 = r18 & r4
            int r10 = (r4 > r27 ? 1 : (r4 == r27 ? 0 : -1))
            if (r10 == 0) goto L_0x0209
            int r4 = r11 + -1
            android.view.View r4 = r0.getChildAt(r4)
            android.view.ViewGroup$LayoutParams r4 = r4.getLayoutParams()
            android.support.v7.widget.ActionMenuView$c r4 = (android.support.v7.widget.ActionMenuView.c) r4
            boolean r5 = r4.g
            if (r5 != 0) goto L_0x0209
            float r2 = r2 - r9
        L_0x0209:
            r4 = 0
            int r4 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r4 <= 0) goto L_0x0216
            int r4 = r12 * r8
            float r4 = (float) r4
            float r4 = r4 / r2
            int r4 = (int) r4
            r20 = r4
            goto L_0x0218
        L_0x0216:
            r20 = 0
        L_0x0218:
            r4 = r20
            r5 = 0
            r9 = r35
        L_0x021d:
            if (r5 >= r11) goto L_0x027b
            r10 = 1
            int r15 = r10 << r5
            r10 = r1
            r20 = r2
            long r1 = (long) r15
            long r1 = r18 & r1
            int r15 = (r1 > r27 ? 1 : (r1 == r27 ? 0 : -1))
            if (r15 != 0) goto L_0x022f
            r25 = 2
            goto L_0x0275
        L_0x022f:
            android.view.View r1 = r0.getChildAt(r5)
            android.view.ViewGroup$LayoutParams r2 = r1.getLayoutParams()
            android.support.v7.widget.ActionMenuView$c r2 = (android.support.v7.widget.ActionMenuView.c) r2
            boolean r15 = r1 instanceof android.support.v7.view.menu.ActionMenuItemView
            if (r15 == 0) goto L_0x0253
            r2.e = r4
            r15 = 1
            r2.h = r15
            if (r5 != 0) goto L_0x024f
            boolean r15 = r2.g
            if (r15 != 0) goto L_0x024f
            int r15 = -r4
            r25 = 2
            int r15 = r15 / 2
            r2.leftMargin = r15
        L_0x024f:
            r9 = 1
            r25 = 2
            goto L_0x0275
        L_0x0253:
            boolean r15 = r2.f620c
            if (r15 == 0) goto L_0x0265
            r2.e = r4
            r15 = 1
            r2.h = r15
            int r15 = -r4
            r25 = 2
            int r15 = r15 / 2
            r2.rightMargin = r15
            r9 = 1
            goto L_0x0275
        L_0x0265:
            r25 = 2
            if (r5 == 0) goto L_0x026d
            int r15 = r4 / 2
            r2.leftMargin = r15
        L_0x026d:
            int r15 = r11 + -1
            if (r5 == r15) goto L_0x0275
            int r15 = r4 / 2
            r2.rightMargin = r15
        L_0x0275:
            int r5 = r5 + 1
            r1 = r10
            r2 = r20
            goto L_0x021d
        L_0x027b:
            r10 = r1
            r20 = r2
            r12 = 0
            goto L_0x0283
        L_0x0280:
            r10 = r1
        L_0x0281:
            r9 = r35
        L_0x0283:
            if (r9 == 0) goto L_0x02b3
            r2 = 0
        L_0x0286:
            if (r2 >= r11) goto L_0x02b0
            android.view.View r4 = r0.getChildAt(r2)
            android.view.ViewGroup$LayoutParams r5 = r4.getLayoutParams()
            android.support.v7.widget.ActionMenuView$c r5 = (android.support.v7.widget.ActionMenuView.c) r5
            boolean r15 = r5.h
            if (r15 != 0) goto L_0x0299
            r22 = r3
            goto L_0x02ab
        L_0x0299:
            int r15 = r5.d
            int r15 = r15 * r8
            int r1 = r5.e
            int r15 = r15 + r1
            r22 = r3
            r1 = 1073741824(0x40000000, float:2.0)
            int r3 = android.view.View.MeasureSpec.makeMeasureSpec(r15, r1)
            r4.measure(r3, r6)
        L_0x02ab:
            int r2 = r2 + 1
            r3 = r22
            goto L_0x0286
        L_0x02b0:
            r22 = r3
            goto L_0x02b5
        L_0x02b3:
            r22 = r3
        L_0x02b5:
            r1 = r36
            r2 = 1073741824(0x40000000, float:2.0)
            if (r1 == r2) goto L_0x02bd
            r3 = r13
            goto L_0x02bf
        L_0x02bd:
            r3 = r16
        L_0x02bf:
            r2 = r37
            r0.setMeasuredDimension(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.ActionMenuView.K(int, int):void");
    }

    public static int J(View child, int cellSize, int cellsRemaining, int parentHeightMeasureSpec, int parentHeightPadding) {
        View view = child;
        int i = cellsRemaining;
        c lp = (c) child.getLayoutParams();
        int childHeightSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(parentHeightMeasureSpec) - parentHeightPadding, View.MeasureSpec.getMode(parentHeightMeasureSpec));
        ActionMenuItemView itemView = view instanceof ActionMenuItemView ? (ActionMenuItemView) view : null;
        boolean expandable = false;
        boolean hasText = itemView != null && itemView.f();
        int cellsUsed = 0;
        if (i > 0 && (!hasText || i >= 2)) {
            child.measure(View.MeasureSpec.makeMeasureSpec(cellSize * i, Integer.MIN_VALUE), childHeightSpec);
            int measuredWidth = child.getMeasuredWidth();
            cellsUsed = measuredWidth / cellSize;
            if (measuredWidth % cellSize != 0) {
                cellsUsed++;
            }
            if (hasText && cellsUsed < 2) {
                cellsUsed = 2;
            }
        }
        if (!lp.f620c && hasText) {
            expandable = true;
        }
        lp.f = expandable;
        lp.d = cellsUsed;
        child.measure(View.MeasureSpec.makeMeasureSpec(cellsUsed * cellSize, 1073741824), childHeightSpec);
        return cellsUsed;
    }

    public void onLayout(boolean changed, int left, int top, int right, int bottom) {
        int i;
        int overflowWidth;
        int dividerWidth;
        boolean isLayoutRtl;
        int midVertical;
        int r2;
        int l;
        ActionMenuView actionMenuView = this;
        if (!actionMenuView.x) {
            super.onLayout(changed, left, top, right, bottom);
            return;
        }
        int childCount = getChildCount();
        int midVertical2 = (bottom - top) / 2;
        int dividerWidth2 = getDividerWidth();
        int overflowWidth2 = 0;
        int nonOverflowWidth = 0;
        int nonOverflowCount = 0;
        int widthRemaining = ((right - left) - getPaddingRight()) - getPaddingLeft();
        boolean hasOverflow = false;
        boolean isLayoutRtl2 = a1.b(this);
        int i2 = 0;
        while (true) {
            i = 8;
            if (i2 >= childCount) {
                break;
            }
            View v2 = actionMenuView.getChildAt(i2);
            if (v2.getVisibility() == 8) {
                midVertical = midVertical2;
                isLayoutRtl = isLayoutRtl2;
            } else {
                c p = (c) v2.getLayoutParams();
                if (p.f620c) {
                    overflowWidth2 = v2.getMeasuredWidth();
                    if (actionMenuView.E(i2)) {
                        overflowWidth2 += dividerWidth2;
                    }
                    int height = v2.getMeasuredHeight();
                    if (isLayoutRtl2) {
                        l = getPaddingLeft() + p.leftMargin;
                        r2 = l + overflowWidth2;
                    } else {
                        r2 = (getWidth() - getPaddingRight()) - p.rightMargin;
                        l = r2 - overflowWidth2;
                    }
                    isLayoutRtl = isLayoutRtl2;
                    int t2 = midVertical2 - (height / 2);
                    midVertical = midVertical2;
                    v2.layout(l, t2, r2, t2 + height);
                    widthRemaining -= overflowWidth2;
                    hasOverflow = true;
                } else {
                    midVertical = midVertical2;
                    isLayoutRtl = isLayoutRtl2;
                    int size = v2.getMeasuredWidth() + p.leftMargin + p.rightMargin;
                    nonOverflowWidth += size;
                    widthRemaining -= size;
                    if (actionMenuView.E(i2)) {
                        nonOverflowWidth += dividerWidth2;
                    }
                    nonOverflowCount++;
                }
            }
            i2++;
            midVertical2 = midVertical;
            isLayoutRtl2 = isLayoutRtl;
        }
        int midVertical3 = midVertical2;
        boolean isLayoutRtl3 = isLayoutRtl2;
        if (childCount != 1 || hasOverflow) {
            int spacerCount = nonOverflowCount - (!hasOverflow);
            int spacerSize = Math.max(0, spacerCount > 0 ? widthRemaining / spacerCount : 0);
            if (isLayoutRtl3) {
                int startRight = getWidth() - getPaddingRight();
                int i3 = 0;
                while (i3 < childCount) {
                    View v3 = actionMenuView.getChildAt(i3);
                    c lp = (c) v3.getLayoutParams();
                    if (v3.getVisibility() == i) {
                        dividerWidth = dividerWidth2;
                        overflowWidth = overflowWidth2;
                    } else if (lp.f620c) {
                        dividerWidth = dividerWidth2;
                        overflowWidth = overflowWidth2;
                    } else {
                        int startRight2 = startRight - lp.rightMargin;
                        int width = v3.getMeasuredWidth();
                        int height2 = v3.getMeasuredHeight();
                        int t3 = midVertical3 - (height2 / 2);
                        dividerWidth = dividerWidth2;
                        overflowWidth = overflowWidth2;
                        v3.layout(startRight2 - width, t3, startRight2, t3 + height2);
                        startRight = startRight2 - ((lp.leftMargin + width) + spacerSize);
                    }
                    i3++;
                    dividerWidth2 = dividerWidth;
                    overflowWidth2 = overflowWidth;
                    i = 8;
                }
                int i4 = overflowWidth2;
                return;
            }
            int i5 = overflowWidth2;
            int startLeft = getPaddingLeft();
            int i6 = 0;
            while (i6 < childCount) {
                View v4 = actionMenuView.getChildAt(i6);
                c lp2 = (c) v4.getLayoutParams();
                if (v4.getVisibility() != 8 && !lp2.f620c) {
                    int startLeft2 = startLeft + lp2.leftMargin;
                    int width2 = v4.getMeasuredWidth();
                    int height3 = v4.getMeasuredHeight();
                    int t4 = midVertical3 - (height3 / 2);
                    v4.layout(startLeft2, t4, startLeft2 + width2, t4 + height3);
                    startLeft = startLeft2 + lp2.rightMargin + width2 + spacerSize;
                }
                i6++;
                actionMenuView = this;
            }
            return;
        }
        View v5 = actionMenuView.getChildAt(0);
        int width3 = v5.getMeasuredWidth();
        int height4 = v5.getMeasuredHeight();
        int l2 = ((right - left) / 2) - (width3 / 2);
        int t5 = midVertical3 - (height4 / 2);
        v5.layout(l2, t5, l2 + width3, t5 + height4);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        z();
    }

    public void setOverflowIcon(Drawable icon) {
        getMenu();
        this.u.H(icon);
    }

    public Drawable getOverflowIcon() {
        getMenu();
        return this.u.z();
    }

    public boolean I() {
        return this.t;
    }

    public void setOverflowReserved(boolean reserveOverflow) {
        this.t = reserveOverflow;
    }

    /* renamed from: A */
    public c k() {
        c params = new c(-2, -2);
        params.f464b = 16;
        return params;
    }

    /* renamed from: B */
    public c l(AttributeSet attrs) {
        return new c(getContext(), attrs);
    }

    /* renamed from: C */
    public c m(ViewGroup.LayoutParams p) {
        if (p == null) {
            return k();
        }
        c result = p instanceof c ? new c((c) p) : new c(p);
        if (result.f464b <= 0) {
            result.f464b = 16;
        }
        return result;
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams p) {
        return p != null && (p instanceof c);
    }

    public c D() {
        c result = k();
        result.f620c = true;
        return result;
    }

    public boolean c(j item) {
        return this.q.L(item, 0);
    }

    public int getWindowAnimations() {
        return 0;
    }

    public void b(h menu) {
        this.q = menu;
    }

    public Menu getMenu() {
        if (this.q == null) {
            Context context = getContext();
            h hVar = new h(context);
            this.q = hVar;
            hVar.R(new d());
            a.b.d.f.c cVar = new a.b.d.f.c(context);
            this.u = cVar;
            cVar.I(true);
            a.b.d.f.c cVar2 = this.u;
            o.a aVar = this.v;
            if (aVar == null) {
                aVar = new b();
            }
            cVar2.j(aVar);
            this.q.c(this.u, this.r);
            this.u.G(this);
        }
        return this.q;
    }

    public void M(o.a pcb, h.a mcb) {
        this.v = pcb;
        this.w = mcb;
    }

    public h L() {
        return this.q;
    }

    public boolean N() {
        a.b.d.f.c cVar = this.u;
        return cVar != null && cVar.J();
    }

    public boolean F() {
        a.b.d.f.c cVar = this.u;
        return cVar != null && cVar.A();
    }

    public boolean H() {
        a.b.d.f.c cVar = this.u;
        return cVar != null && cVar.D();
    }

    public boolean G() {
        a.b.d.f.c cVar = this.u;
        return cVar != null && cVar.C();
    }

    public void z() {
        a.b.d.f.c cVar = this.u;
        if (cVar != null) {
            cVar.x();
        }
    }

    public boolean E(int childIndex) {
        if (childIndex == 0) {
            return false;
        }
        View childBefore = getChildAt(childIndex - 1);
        View child = getChildAt(childIndex);
        boolean result = false;
        if (childIndex < getChildCount() && (childBefore instanceof a)) {
            result = false | ((a) childBefore).b();
        }
        if (childIndex <= 0 || !(child instanceof a)) {
            return result;
        }
        return result | ((a) child).a();
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent event) {
        return false;
    }

    public void setExpandedActionViewsExclusive(boolean exclusive) {
        this.u.F(exclusive);
    }

    public class d implements h.a {
        public d() {
        }

        public boolean b(h menu, MenuItem item) {
            e eVar = ActionMenuView.this.B;
            return eVar != null && ((Toolbar.a) eVar).a(item);
        }

        public void a(h menu) {
            h.a aVar = ActionMenuView.this.w;
            if (aVar != null) {
                aVar.a(menu);
            }
        }
    }

    public static class b implements o.a {
        public void a(h menu, boolean allMenusAreClosing) {
        }

        public boolean b(h subMenu) {
            return false;
        }
    }

    public static class c extends g0.a {
        @ViewDebug.ExportedProperty

        /* renamed from: c  reason: collision with root package name */
        public boolean f620c;
        @ViewDebug.ExportedProperty
        public int d;
        @ViewDebug.ExportedProperty
        public int e;
        @ViewDebug.ExportedProperty
        public boolean f;
        @ViewDebug.ExportedProperty
        public boolean g;
        public boolean h;

        public c(Context c2, AttributeSet attrs) {
            super(c2, attrs);
        }

        public c(ViewGroup.LayoutParams other) {
            super(other);
        }

        public c(c other) {
            super(other);
            this.f620c = other.f620c;
        }

        public c(int width, int height) {
            super(width, height);
            this.f620c = false;
        }
    }
}
