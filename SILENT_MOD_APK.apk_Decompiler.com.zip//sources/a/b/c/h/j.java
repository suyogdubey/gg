package a.b.c.h;

import android.view.View;
import android.view.ViewParent;

public class j {

    /* renamed from: a  reason: collision with root package name */
    public ViewParent f251a;

    /* renamed from: b  reason: collision with root package name */
    public ViewParent f252b;

    /* renamed from: c  reason: collision with root package name */
    public final View f253c;
    public boolean d;
    public int[] e;

    public j(View view) {
        this.f253c = view;
    }

    public void h(boolean enabled) {
        if (this.d) {
            p.A(this.f253c);
        }
        this.d = enabled;
    }

    public boolean g() {
        return this.d;
    }

    public boolean f(int type) {
        return e(type) != null;
    }

    public boolean j(int axes, int type) {
        if (f(type)) {
            return true;
        }
        if (!g()) {
            return false;
        }
        View child = this.f253c;
        for (ViewParent p = this.f253c.getParent(); p != null; p = p.getParent()) {
            if (s.f(p, child, this.f253c, axes, type)) {
                i(type, p);
                s.e(p, child, this.f253c, axes, type);
                return true;
            }
            if (p instanceof View) {
                child = (View) p;
            }
        }
        return false;
    }

    public void k(int type) {
        ViewParent parent = e(type);
        if (parent != null) {
            s.g(parent, this.f253c, type);
            i(type, (ViewParent) null);
        }
    }

    public boolean d(int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed, int[] offsetInWindow, int type) {
        int startY;
        int startX;
        int[] iArr = offsetInWindow;
        if (g()) {
            ViewParent parent = e(type);
            if (parent == null) {
                return false;
            }
            if (dxConsumed != 0 || dyConsumed != 0 || dxUnconsumed != 0 || dyUnconsumed != 0) {
                if (iArr != null) {
                    this.f253c.getLocationInWindow(iArr);
                    startX = iArr[0];
                    startY = iArr[1];
                } else {
                    startX = 0;
                    startY = 0;
                }
                s.d(parent, this.f253c, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed, type);
                if (iArr != null) {
                    this.f253c.getLocationInWindow(iArr);
                    iArr[0] = iArr[0] - startX;
                    iArr[1] = iArr[1] - startY;
                }
                return true;
            } else if (iArr != null) {
                iArr[0] = 0;
                iArr[1] = 0;
            }
        } else {
            int i = type;
        }
        return false;
    }

    public boolean c(int dx, int dy, int[] consumed, int[] offsetInWindow, int type) {
        int startY;
        int startX;
        int[] consumed2;
        int[] iArr = offsetInWindow;
        if (g()) {
            ViewParent parent = e(type);
            if (parent == null) {
                return false;
            }
            if (dx != 0 || dy != 0) {
                if (iArr != null) {
                    this.f253c.getLocationInWindow(iArr);
                    startX = iArr[0];
                    startY = iArr[1];
                } else {
                    startX = 0;
                    startY = 0;
                }
                if (consumed == null) {
                    if (this.e == null) {
                        this.e = new int[2];
                    }
                    consumed2 = this.e;
                } else {
                    consumed2 = consumed;
                }
                consumed2[0] = 0;
                consumed2[1] = 0;
                s.c(parent, this.f253c, dx, dy, consumed2, type);
                if (iArr != null) {
                    this.f253c.getLocationInWindow(iArr);
                    iArr[0] = iArr[0] - startX;
                    iArr[1] = iArr[1] - startY;
                }
                return (consumed2[0] == 0 && consumed2[1] == 0) ? false : true;
            } else if (iArr != null) {
                iArr[0] = 0;
                iArr[1] = 0;
            }
        } else {
            int i = type;
        }
        return false;
    }

    public boolean a(float velocityX, float velocityY, boolean consumed) {
        ViewParent parent;
        if (!g() || (parent = e(0)) == null) {
            return false;
        }
        return s.a(parent, this.f253c, velocityX, velocityY, consumed);
    }

    public boolean b(float velocityX, float velocityY) {
        ViewParent parent;
        if (!g() || (parent = e(0)) == null) {
            return false;
        }
        return s.b(parent, this.f253c, velocityX, velocityY);
    }

    public final ViewParent e(int type) {
        if (type == 0) {
            return this.f251a;
        }
        if (type != 1) {
            return null;
        }
        return this.f252b;
    }

    public final void i(int type, ViewParent p) {
        if (type == 0) {
            this.f251a = p;
        } else if (type == 1) {
            this.f252b = p;
        }
    }
}
