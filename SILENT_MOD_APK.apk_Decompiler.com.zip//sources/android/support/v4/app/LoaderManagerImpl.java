package android.support.v4.app;

import a.a.b.e;
import a.a.b.i;
import a.a.b.j;
import a.a.b.l;
import a.a.b.m;
import a.a.b.n;
import a.b.c.a.s;
import a.b.c.g.d;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class LoaderManagerImpl extends s {

    /* renamed from: c  reason: collision with root package name */
    public static boolean f572c = false;

    /* renamed from: a  reason: collision with root package name */
    public final e f573a;

    /* renamed from: b  reason: collision with root package name */
    public final LoaderViewModel f574b;

    public static class b<D> implements j<D> {
    }

    public static class a<D> extends i<D> {
        public e j;
        public b<D> k;

        public void k() {
            throw null;
        }

        public void l() {
            throw null;
        }

        public void q() {
            if (this.j != null) {
            }
        }

        public void m(j<? super D> observer) {
            super.m(observer);
            this.j = null;
            this.k = null;
        }

        public Object<D> o(boolean reset) {
            throw null;
        }

        public void n(D value) {
            super.n(value);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(64);
            sb.append("LoaderInfo{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" #");
            sb.append(0);
            sb.append(" : ");
            d.a((Object) null, sb);
            sb.append("}}");
            return sb.toString();
        }

        public void p(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
            writer.print(prefix);
            writer.print("mId=");
            writer.print(0);
            writer.print(" mArgs=");
            writer.println((Object) null);
            writer.print(prefix);
            writer.print("mLoader=");
            writer.println((Object) null);
            prefix + "  ";
            throw null;
        }
    }

    public static class LoaderViewModel extends l {

        /* renamed from: b  reason: collision with root package name */
        public static final m.a f575b = new a();

        /* renamed from: a  reason: collision with root package name */
        public a.b.c.g.l<a> f576a = new a.b.c.g.l<>();

        public static class a implements m.a {
            public <T extends l> T a(Class<T> cls) {
                return new LoaderViewModel();
            }
        }

        public static LoaderViewModel c(n viewModelStore) {
            return (LoaderViewModel) new m(viewModelStore, f575b).a(LoaderViewModel.class);
        }

        public void d() {
            int size = this.f576a.k();
            for (int index = 0; index < size; index++) {
                this.f576a.l(index).q();
            }
        }

        public void a() {
            super.a();
            if (0 >= this.f576a.k()) {
                this.f576a.b();
            } else {
                this.f576a.l(0).o(true);
                throw null;
            }
        }

        public void b(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
            if (this.f576a.k() > 0) {
                writer.print(prefix);
                writer.println("Loaders:");
                String str = prefix + "    ";
                if (0 < this.f576a.k()) {
                    a info = this.f576a.l(0);
                    writer.print(prefix);
                    writer.print("  #");
                    writer.print(this.f576a.h(0));
                    writer.print(": ");
                    writer.println(info.toString());
                    info.p(str, fd, writer, args);
                    throw null;
                }
            }
        }
    }

    public LoaderManagerImpl(e lifecycleOwner, n viewModelStore) {
        this.f573a = lifecycleOwner;
        this.f574b = LoaderViewModel.c(viewModelStore);
    }

    public void c() {
        this.f574b.d();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("LoaderManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        d.a(this.f573a, sb);
        sb.append("}}");
        return sb.toString();
    }

    @Deprecated
    public void a(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
        this.f574b.b(prefix, fd, writer, args);
    }
}
