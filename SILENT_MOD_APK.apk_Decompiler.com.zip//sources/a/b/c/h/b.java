package a.b.c.h;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;

public class b {

    /* renamed from: b  reason: collision with root package name */
    public static final View.AccessibilityDelegate f242b = new View.AccessibilityDelegate();

    /* renamed from: a  reason: collision with root package name */
    public final View.AccessibilityDelegate f243a = new a(this);

    public static final class a extends View.AccessibilityDelegate {

        /* renamed from: a  reason: collision with root package name */
        public final b f244a;

        public a(b compat) {
            this.f244a = compat;
        }

        public boolean dispatchPopulateAccessibilityEvent(View host, AccessibilityEvent event) {
            return this.f244a.a(host, event);
        }

        public void onInitializeAccessibilityEvent(View host, AccessibilityEvent event) {
            this.f244a.d(host, event);
        }

        public void onInitializeAccessibilityNodeInfo(View host, AccessibilityNodeInfo info) {
            this.f244a.e(host, a.b.c.h.y.a.x(info));
        }

        public void onPopulateAccessibilityEvent(View host, AccessibilityEvent event) {
            this.f244a.f(host, event);
        }

        public boolean onRequestSendAccessibilityEvent(ViewGroup host, View child, AccessibilityEvent event) {
            return this.f244a.g(host, child, event);
        }

        public void sendAccessibilityEvent(View host, int eventType) {
            this.f244a.i(host, eventType);
        }

        public void sendAccessibilityEventUnchecked(View host, AccessibilityEvent event) {
            this.f244a.j(host, event);
        }

        public AccessibilityNodeProvider getAccessibilityNodeProvider(View host) {
            a.b.c.h.y.b provider = this.f244a.b(host);
            if (provider != null) {
                return (AccessibilityNodeProvider) provider.a();
            }
            return null;
        }

        public boolean performAccessibilityAction(View host, int action, Bundle args) {
            return this.f244a.h(host, action, args);
        }
    }

    public View.AccessibilityDelegate c() {
        return this.f243a;
    }

    public void i(View host, int eventType) {
        f242b.sendAccessibilityEvent(host, eventType);
    }

    public void j(View host, AccessibilityEvent event) {
        f242b.sendAccessibilityEventUnchecked(host, event);
    }

    public boolean a(View host, AccessibilityEvent event) {
        return f242b.dispatchPopulateAccessibilityEvent(host, event);
    }

    public void f(View host, AccessibilityEvent event) {
        f242b.onPopulateAccessibilityEvent(host, event);
    }

    public void d(View host, AccessibilityEvent event) {
        f242b.onInitializeAccessibilityEvent(host, event);
    }

    public void e(View host, a.b.c.h.y.a info) {
        f242b.onInitializeAccessibilityNodeInfo(host, info.w());
    }

    public boolean g(ViewGroup host, View child, AccessibilityEvent event) {
        return f242b.onRequestSendAccessibilityEvent(host, child, event);
    }

    public a.b.c.h.y.b b(View host) {
        Object provider = f242b.getAccessibilityNodeProvider(host);
        if (provider != null) {
            return new a.b.c.h.y.b(provider);
        }
        return null;
    }

    public boolean h(View host, int action, Bundle args) {
        return f242b.performAccessibilityAction(host, action, args);
    }
}
