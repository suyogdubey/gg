package a.b.c.a;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public class h {

    /* renamed from: a  reason: collision with root package name */
    public final i<?> f75a;

    public static h b(i<?> callbacks) {
        return new h(callbacks);
    }

    public h(i<?> callbacks) {
        this.f75a = callbacks;
    }

    public j u() {
        return this.f75a.f();
    }

    public e t(String who) {
        return this.f75a.d.f0(who);
    }

    public void a(e parent) {
        i<?> iVar = this.f75a;
        iVar.d.h(iVar, iVar, parent);
    }

    public View w(View parent, String name, Context context, AttributeSet attrs) {
        return this.f75a.d.onCreateView(parent, name, context, attrs);
    }

    public void v() {
        this.f75a.d.C0();
    }

    public Parcelable z() {
        return this.f75a.d.O0();
    }

    public void x(Parcelable state, l nonConfig) {
        this.f75a.d.L0(state, nonConfig);
    }

    public l y() {
        return this.f75a.d.M0();
    }

    public void f() {
        this.f75a.d.s();
    }

    public void c() {
        this.f75a.d.p();
    }

    public void q() {
        this.f75a.d.S();
    }

    public void p() {
        this.f75a.d.R();
    }

    public void m() {
        this.f75a.d.O();
    }

    public void r() {
        this.f75a.d.U();
    }

    public void h() {
        this.f75a.d.u();
    }

    public void j(boolean isInMultiWindowMode) {
        this.f75a.d.x(isInMultiWindowMode);
    }

    public void n(boolean isInPictureInPictureMode) {
        this.f75a.d.P(isInPictureInPictureMode);
    }

    public void d(Configuration newConfig) {
        this.f75a.d.q(newConfig);
    }

    public void i() {
        this.f75a.d.w();
    }

    public boolean g(Menu menu, MenuInflater inflater) {
        return this.f75a.d.t(menu, inflater);
    }

    public boolean o(Menu menu) {
        return this.f75a.d.Q(menu);
    }

    public boolean k(MenuItem item) {
        return this.f75a.d.M(item);
    }

    public boolean e(MenuItem item) {
        return this.f75a.d.r(item);
    }

    public void l(Menu menu) {
        this.f75a.d.N(menu);
    }

    public boolean s() {
        this.f75a.d.Z();
        return false;
    }
}
