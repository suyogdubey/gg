package android.support.v7.app;

import a.b.d.b.j;
import a.b.d.f.d;
import a.b.d.f.f;
import a.b.d.f.g;
import a.b.d.f.h;
import a.b.d.f.k;
import a.b.d.f.m;
import a.b.d.f.o;
import a.b.d.f.p;
import a.b.d.f.q0;
import a.b.d.f.s;
import a.b.d.f.t;
import a.b.d.f.u;
import a.b.d.f.w;
import a.b.d.f.y;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

public class AppCompatViewInflater {

    /* renamed from: b  reason: collision with root package name */
    public static final Class<?>[] f603b = {Context.class, AttributeSet.class};

    /* renamed from: c  reason: collision with root package name */
    public static final int[] f604c = {16843375};
    public static final String[] d = {"android.widget.", "android.view.", "android.webkit."};
    public static final Map<String, Constructor<? extends View>> e = new a.b.c.g.a();

    /* renamed from: a  reason: collision with root package name */
    public final Object[] f605a = new Object[2];

    public final View p(View parent, String name, Context context, AttributeSet attrs, boolean inheritContext, boolean readAndroidTheme, boolean readAppTheme, boolean wrapContext) {
        View view;
        Context originalContext = context;
        if (inheritContext && parent != null) {
            context = parent.getContext();
        }
        if (readAndroidTheme || readAppTheme) {
            context = s(context, attrs, readAndroidTheme, readAppTheme);
        }
        if (wrapContext) {
            context = q0.b(context);
        }
        char c2 = 65535;
        switch (name.hashCode()) {
            case -1946472170:
                if (name.equals("RatingBar")) {
                    c2 = 11;
                    break;
                }
                break;
            case -1455429095:
                if (name.equals("CheckedTextView")) {
                    c2 = 8;
                    break;
                }
                break;
            case -1346021293:
                if (name.equals("MultiAutoCompleteTextView")) {
                    c2 = 10;
                    break;
                }
                break;
            case -938935918:
                if (name.equals("TextView")) {
                    c2 = 0;
                    break;
                }
                break;
            case -937446323:
                if (name.equals("ImageButton")) {
                    c2 = 5;
                    break;
                }
                break;
            case -658531749:
                if (name.equals("SeekBar")) {
                    c2 = 12;
                    break;
                }
                break;
            case -339785223:
                if (name.equals("Spinner")) {
                    c2 = 4;
                    break;
                }
                break;
            case 776382189:
                if (name.equals("RadioButton")) {
                    c2 = 7;
                    break;
                }
                break;
            case 1125864064:
                if (name.equals("ImageView")) {
                    c2 = 1;
                    break;
                }
                break;
            case 1413872058:
                if (name.equals("AutoCompleteTextView")) {
                    c2 = 9;
                    break;
                }
                break;
            case 1601505219:
                if (name.equals("CheckBox")) {
                    c2 = 6;
                    break;
                }
                break;
            case 1666676343:
                if (name.equals("EditText")) {
                    c2 = 3;
                    break;
                }
                break;
            case 2001146706:
                if (name.equals("Button")) {
                    c2 = 2;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                view = n(context, attrs);
                t(view, name);
                break;
            case 1:
                view = h(context, attrs);
                t(view, name);
                break;
            case 2:
                view = c(context, attrs);
                t(view, name);
                break;
            case 3:
                view = f(context, attrs);
                t(view, name);
                break;
            case 4:
                view = m(context, attrs);
                t(view, name);
                break;
            case 5:
                view = g(context, attrs);
                t(view, name);
                break;
            case 6:
                view = d(context, attrs);
                t(view, name);
                break;
            case 7:
                view = j(context, attrs);
                t(view, name);
                break;
            case 8:
                view = e(context, attrs);
                t(view, name);
                break;
            case 9:
                view = b(context, attrs);
                t(view, name);
                break;
            case 10:
                view = i(context, attrs);
                t(view, name);
                break;
            case 11:
                view = k(context, attrs);
                t(view, name);
                break;
            case 12:
                view = l(context, attrs);
                t(view, name);
                break;
            default:
                o();
                view = null;
                break;
        }
        if (view == null && originalContext != context) {
            view = r(context, name, attrs);
        }
        if (view != null) {
            a(view, attrs);
        }
        return view;
    }

    public y n(Context context, AttributeSet attrs) {
        return new y(context, attrs);
    }

    public o h(Context context, AttributeSet attrs) {
        return new o(context, attrs);
    }

    public f c(Context context, AttributeSet attrs) {
        return new f(context, attrs);
    }

    public k f(Context context, AttributeSet attrs) {
        return new k(context, attrs);
    }

    public w m(Context context, AttributeSet attrs) {
        return new w(context, attrs);
    }

    public m g(Context context, AttributeSet attrs) {
        return new m(context, attrs);
    }

    public g d(Context context, AttributeSet attrs) {
        return new g(context, attrs);
    }

    public s j(Context context, AttributeSet attrs) {
        return new s(context, attrs);
    }

    public h e(Context context, AttributeSet attrs) {
        return new h(context, attrs);
    }

    public d b(Context context, AttributeSet attrs) {
        return new d(context, attrs);
    }

    public p i(Context context, AttributeSet attrs) {
        return new p(context, attrs);
    }

    public t k(Context context, AttributeSet attrs) {
        return new t(context, attrs);
    }

    public u l(Context context, AttributeSet attrs) {
        return new u(context, attrs);
    }

    public final void t(View view, String name) {
        if (view == null) {
            throw new IllegalStateException(getClass().getName() + " asked to inflate view for <" + name + ">, but returned null");
        }
    }

    public View o() {
        return null;
    }

    public final View r(Context context, String name, AttributeSet attrs) {
        if (name.equals("view")) {
            name = attrs.getAttributeValue((String) null, "class");
        }
        try {
            this.f605a[0] = context;
            this.f605a[1] = attrs;
            if (-1 == name.indexOf(46)) {
                for (String q : d) {
                    View view = q(context, name, q);
                    if (view != null) {
                        return view;
                    }
                }
                Object[] objArr = this.f605a;
                objArr[0] = null;
                objArr[1] = null;
                return null;
            }
            View q2 = q(context, name, (String) null);
            Object[] objArr2 = this.f605a;
            objArr2[0] = null;
            objArr2[1] = null;
            return q2;
        } catch (Exception e2) {
            return null;
        } finally {
            Object[] objArr3 = this.f605a;
            objArr3[0] = null;
            objArr3[1] = null;
        }
    }

    public final void a(View view, AttributeSet attrs) {
        Context context = view.getContext();
        if ((context instanceof ContextWrapper) && a.b.c.h.p.j(view)) {
            TypedArray a2 = context.obtainStyledAttributes(attrs, f604c);
            String handlerName = a2.getString(0);
            if (handlerName != null) {
                view.setOnClickListener(new a(view, handlerName));
            }
            a2.recycle();
        }
    }

    public final View q(Context context, String name, String prefix) {
        String str;
        Constructor<? extends U> constructor = e.get(name);
        if (constructor == null) {
            try {
                ClassLoader classLoader = context.getClassLoader();
                if (prefix != null) {
                    str = prefix + name;
                } else {
                    str = name;
                }
                constructor = classLoader.loadClass(str).asSubclass(View.class).getConstructor(f603b);
                e.put(name, constructor);
            } catch (Exception e2) {
                return null;
            }
        }
        constructor.setAccessible(true);
        return (View) constructor.newInstance(this.f605a);
    }

    public static Context s(Context context, AttributeSet attrs, boolean useAndroidTheme, boolean useAppTheme) {
        TypedArray a2 = context.obtainStyledAttributes(attrs, j.View, 0, 0);
        int themeId = 0;
        if (useAndroidTheme) {
            themeId = a2.getResourceId(j.View_android_theme, 0);
        }
        if (useAppTheme && themeId == 0 && (themeId = a2.getResourceId(j.View_theme, 0)) != 0) {
            Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
        }
        a2.recycle();
        if (themeId == 0) {
            return context;
        }
        if (!(context instanceof a.b.d.e.d) || ((a.b.d.e.d) context).b() != themeId) {
            return new a.b.d.e.d(context, themeId);
        }
        return context;
    }

    public static class a implements View.OnClickListener {

        /* renamed from: b  reason: collision with root package name */
        public final View f606b;

        /* renamed from: c  reason: collision with root package name */
        public final String f607c;
        public Method d;
        public Context e;

        public a(View hostView, String methodName) {
            this.f606b = hostView;
            this.f607c = methodName;
        }

        public void onClick(View v) {
            if (this.d == null) {
                a(this.f606b.getContext());
            }
            try {
                this.d.invoke(this.e, new Object[]{v});
            } catch (IllegalAccessException e2) {
                throw new IllegalStateException("Could not execute non-public method for android:onClick", e2);
            } catch (InvocationTargetException e3) {
                throw new IllegalStateException("Could not execute method for android:onClick", e3);
            }
        }

        public final void a(Context context) {
            String idText;
            Method method;
            while (context != null) {
                try {
                    if (!context.isRestricted() && (method = context.getClass().getMethod(this.f607c, new Class[]{View.class})) != null) {
                        this.d = method;
                        this.e = context;
                        return;
                    }
                } catch (NoSuchMethodException e2) {
                }
                if (context instanceof ContextWrapper) {
                    context = ((ContextWrapper) context).getBaseContext();
                } else {
                    context = null;
                }
            }
            int id = this.f606b.getId();
            if (id == -1) {
                idText = "";
            } else {
                idText = " with id '" + this.f606b.getContext().getResources().getResourceEntryName(id) + "'";
            }
            throw new IllegalStateException("Could not find method " + this.f607c + "(View) in a parent or ancestor Context for android:onClick " + "attribute defined on view " + this.f606b.getClass() + idText);
        }
    }
}
