package a.b.d.f;

import a.b.d.e.j.s;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;

public abstract class f0 implements View.OnTouchListener, View.OnAttachStateChangeListener {

    /* renamed from: b  reason: collision with root package name */
    public final float f456b;

    /* renamed from: c  reason: collision with root package name */
    public final int f457c;
    public final int d;
    public final View e;
    public Runnable f;
    public Runnable g;
    public boolean h;
    public int i;
    public final int[] j = new int[2];

    public abstract s b();

    public abstract boolean c();

    public f0(View src) {
        this.e = src;
        src.setLongClickable(true);
        src.addOnAttachStateChangeListener(this);
        this.f456b = (float) ViewConfiguration.get(src.getContext()).getScaledTouchSlop();
        int tapTimeout = ViewConfiguration.getTapTimeout();
        this.f457c = tapTimeout;
        this.d = (tapTimeout + ViewConfiguration.getLongPressTimeout()) / 2;
    }

    public boolean onTouch(View v, MotionEvent event) {
        boolean forwarding;
        MotionEvent motionEvent = event;
        boolean wasForwarding = this.h;
        if (wasForwarding) {
            forwarding = f(motionEvent) || !d();
        } else {
            forwarding = g(motionEvent) && c();
            if (forwarding) {
                long now = SystemClock.uptimeMillis();
                MotionEvent e2 = MotionEvent.obtain(now, now, 3, 0.0f, 0.0f, 0);
                this.e.onTouchEvent(e2);
                e2.recycle();
            }
        }
        this.h = forwarding;
        if (forwarding || wasForwarding) {
            return true;
        }
        return false;
    }

    public void onViewAttachedToWindow(View v) {
    }

    public void onViewDetachedFromWindow(View v) {
        this.h = false;
        this.i = -1;
        Runnable runnable = this.f;
        if (runnable != null) {
            this.e.removeCallbacks(runnable);
        }
    }

    public boolean d() {
        s popup = b();
        if (popup == null || !popup.c()) {
            return true;
        }
        popup.dismiss();
        return true;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0017, code lost:
        if (r1 != 3) goto L_0x006f;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean g(android.view.MotionEvent r9) {
        /*
            r8 = this;
            android.view.View r0 = r8.e
            boolean r1 = r0.isEnabled()
            r2 = 0
            if (r1 != 0) goto L_0x000a
            return r2
        L_0x000a:
            int r1 = r9.getActionMasked()
            if (r1 == 0) goto L_0x0042
            r3 = 1
            if (r1 == r3) goto L_0x003e
            r4 = 2
            if (r1 == r4) goto L_0x001a
            r3 = 3
            if (r1 == r3) goto L_0x003e
            goto L_0x006f
        L_0x001a:
            int r4 = r8.i
            int r4 = r9.findPointerIndex(r4)
            if (r4 < 0) goto L_0x006f
            float r5 = r9.getX(r4)
            float r6 = r9.getY(r4)
            float r7 = r8.f456b
            boolean r7 = h(r0, r5, r6, r7)
            if (r7 != 0) goto L_0x003d
            r8.a()
            android.view.ViewParent r2 = r0.getParent()
            r2.requestDisallowInterceptTouchEvent(r3)
            return r3
        L_0x003d:
            goto L_0x006f
        L_0x003e:
            r8.a()
            goto L_0x006f
        L_0x0042:
            int r3 = r9.getPointerId(r2)
            r8.i = r3
            java.lang.Runnable r3 = r8.f
            if (r3 != 0) goto L_0x0053
            a.b.d.f.f0$a r3 = new a.b.d.f.f0$a
            r3.<init>()
            r8.f = r3
        L_0x0053:
            java.lang.Runnable r3 = r8.f
            int r4 = r8.f457c
            long r4 = (long) r4
            r0.postDelayed(r3, r4)
            java.lang.Runnable r3 = r8.g
            if (r3 != 0) goto L_0x0066
            a.b.d.f.f0$b r3 = new a.b.d.f.f0$b
            r3.<init>()
            r8.g = r3
        L_0x0066:
            java.lang.Runnable r3 = r8.g
            int r4 = r8.d
            long r4 = (long) r4
            r0.postDelayed(r3, r4)
        L_0x006f:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.d.f.f0.g(android.view.MotionEvent):boolean");
    }

    public final void a() {
        Runnable runnable = this.g;
        if (runnable != null) {
            this.e.removeCallbacks(runnable);
        }
        Runnable runnable2 = this.f;
        if (runnable2 != null) {
            this.e.removeCallbacks(runnable2);
        }
    }

    public void e() {
        a();
        View src = this.e;
        if (src.isEnabled() && !src.isLongClickable() && c()) {
            src.getParent().requestDisallowInterceptTouchEvent(true);
            long now = SystemClock.uptimeMillis();
            MotionEvent e2 = MotionEvent.obtain(now, now, 3, 0.0f, 0.0f, 0);
            src.onTouchEvent(e2);
            e2.recycle();
            this.h = true;
        }
    }

    public final boolean f(MotionEvent srcEvent) {
        d0 dst;
        View src = this.e;
        s popup = b();
        if (popup == null || !popup.c() || (dst = (d0) popup.d()) == null || !dst.isShown()) {
            return false;
        }
        MotionEvent dstEvent = MotionEvent.obtainNoHistory(srcEvent);
        i(src, dstEvent);
        j(dst, dstEvent);
        boolean handled = dst.e(dstEvent, this.i);
        dstEvent.recycle();
        int action = srcEvent.getActionMasked();
        boolean keepForwarding = (action == 1 || action == 3) ? false : true;
        if (!handled || !keepForwarding) {
            return false;
        }
        return true;
    }

    public static boolean h(View view, float localX, float localY, float slop) {
        return localX >= (-slop) && localY >= (-slop) && localX < ((float) (view.getRight() - view.getLeft())) + slop && localY < ((float) (view.getBottom() - view.getTop())) + slop;
    }

    public final boolean j(View view, MotionEvent event) {
        int[] loc = this.j;
        view.getLocationOnScreen(loc);
        event.offsetLocation((float) (-loc[0]), (float) (-loc[1]));
        return true;
    }

    public final boolean i(View view, MotionEvent event) {
        int[] loc = this.j;
        view.getLocationOnScreen(loc);
        event.offsetLocation((float) loc[0], (float) loc[1]);
        return true;
    }

    public class a implements Runnable {
        public a() {
        }

        public void run() {
            ViewParent parent = f0.this.e.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }
    }

    public class b implements Runnable {
        public b() {
        }

        public void run() {
            f0.this.e();
        }
    }
}
