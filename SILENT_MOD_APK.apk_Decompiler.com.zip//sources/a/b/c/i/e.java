package a.b.c.i;

import a.b.d.f.n0;
import android.database.Cursor;
import android.widget.Filter;

public class e extends Filter {

    /* renamed from: a  reason: collision with root package name */
    public a f289a;

    public interface a {
    }

    public e(a client) {
        this.f289a = client;
    }

    public CharSequence convertResultToString(Object resultValue) {
        return ((n0) this.f289a).c((Cursor) resultValue);
    }

    public Filter.FilterResults performFiltering(CharSequence constraint) {
        Cursor cursor = ((n0) this.f289a).w(constraint);
        Filter.FilterResults results = new Filter.FilterResults();
        if (cursor != null) {
            results.count = cursor.getCount();
            results.values = cursor;
        } else {
            results.count = 0;
            results.values = null;
        }
        return results;
    }

    public void publishResults(CharSequence constraint, Filter.FilterResults results) {
        Cursor oldCursor = ((d) this.f289a).d();
        Object obj = results.values;
        if (obj != null && obj != oldCursor) {
            ((n0) this.f289a).b((Cursor) obj);
        }
    }
}
