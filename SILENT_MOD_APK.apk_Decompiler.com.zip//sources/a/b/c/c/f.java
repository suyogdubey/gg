package a.b.c.c;

import a.b.c.b.c.c;
import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.util.Log;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;

public class f extends d {

    /* renamed from: a  reason: collision with root package name */
    public final Class f168a;

    /* renamed from: b  reason: collision with root package name */
    public final Constructor f169b;

    /* renamed from: c  reason: collision with root package name */
    public final Method f170c;
    public final Method d;
    public final Method e;
    public final Method f;
    public final Method g;

    public f() {
        Method abortCreation;
        Method freeze;
        Method addFontFromBuffer;
        Method addFontFromAssetManager;
        Method addFontFromAssetManager2;
        Constructor fontFamilyCtor;
        Class fontFamily;
        try {
            fontFamily = t();
            fontFamilyCtor = u(fontFamily);
            addFontFromAssetManager2 = q(fontFamily);
            addFontFromAssetManager = r(fontFamily);
            addFontFromBuffer = v(fontFamily);
            freeze = p(fontFamily);
            abortCreation = s(fontFamily);
        } catch (ClassNotFoundException | NoSuchMethodException e2) {
            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class " + e2.getClass().getName(), e2);
            fontFamily = null;
            fontFamilyCtor = null;
            addFontFromAssetManager2 = null;
            addFontFromAssetManager = null;
            addFontFromBuffer = null;
            freeze = null;
            abortCreation = null;
        }
        this.f168a = fontFamily;
        this.f169b = fontFamilyCtor;
        this.f170c = addFontFromAssetManager2;
        this.d = addFontFromAssetManager;
        this.e = addFontFromBuffer;
        this.f = freeze;
        this.g = abortCreation;
    }

    public final boolean n() {
        if (this.f170c == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        return this.f170c != null;
    }

    public final Object o() {
        try {
            return this.f169b.newInstance(new Object[0]);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    public final boolean j(Context context, Object family, String fileName, int ttcIndex, int weight, int style, FontVariationAxis[] axes) {
        try {
            return ((Boolean) this.f170c.invoke(family, new Object[]{context.getAssets(), fileName, 0, false, Integer.valueOf(ttcIndex), Integer.valueOf(weight), Integer.valueOf(style), axes})).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    public final boolean k(Object family, ByteBuffer buffer, int ttcIndex, int weight, int style) {
        try {
            return ((Boolean) this.d.invoke(family, new Object[]{buffer, Integer.valueOf(ttcIndex), null, Integer.valueOf(weight), Integer.valueOf(style)})).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    public Typeface l(Object family) {
        try {
            Object familyArray = Array.newInstance(this.f168a, 1);
            Array.set(familyArray, 0, family);
            return (Typeface) this.g.invoke((Object) null, new Object[]{familyArray, -1, -1});
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    public final boolean m(Object family) {
        try {
            return ((Boolean) this.e.invoke(family, new Object[0])).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    public final void i(Object family) {
        try {
            this.f.invoke(family, new Object[0]);
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    public Typeface a(Context context, c.b entry, Resources resources, int style) {
        if (!n()) {
            return super.a(context, entry, resources, style);
        }
        Object fontFamily = o();
        for (c.C0007c fontFile : entry.a()) {
            if (!j(context, fontFamily, fontFile.a(), fontFile.c(), fontFile.e(), fontFile.f() ? 1 : 0, FontVariationAxis.fromFontVariationSettings(fontFile.d()))) {
                i(fontFamily);
                return null;
            }
        }
        if (!m(fontFamily)) {
            return null;
        }
        return l(fontFamily);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0055, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0056, code lost:
        r4 = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:?, code lost:
        r3.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:?, code lost:
        throw r4;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.Typeface b(android.content.Context r21, android.os.CancellationSignal r22, a.b.c.e.b.f[] r23, int r24) {
        /*
            r20 = this;
            r7 = r20
            r8 = r22
            r9 = r23
            r10 = r24
            int r0 = r9.length
            r1 = 1
            r11 = 0
            if (r0 >= r1) goto L_0x000e
            return r11
        L_0x000e:
            boolean r0 = r20.n()
            if (r0 != 0) goto L_0x005f
            a.b.c.e.b$f r1 = r7.g(r9, r10)
            android.content.ContentResolver r2 = r21.getContentResolver()
            android.net.Uri r0 = r1.c()     // Catch:{ IOException -> 0x005d }
            java.lang.String r3 = "r"
            android.os.ParcelFileDescriptor r0 = r2.openFileDescriptor(r0, r3, r8)     // Catch:{ IOException -> 0x005d }
            r3 = r0
            if (r3 != 0) goto L_0x0032
            if (r3 == 0) goto L_0x0031
            r3.close()     // Catch:{ IOException -> 0x005d }
        L_0x0031:
            return r11
        L_0x0032:
            android.graphics.Typeface$Builder r0 = new android.graphics.Typeface$Builder     // Catch:{ all -> 0x0053 }
            java.io.FileDescriptor r4 = r3.getFileDescriptor()     // Catch:{ all -> 0x0053 }
            r0.<init>(r4)     // Catch:{ all -> 0x0053 }
            int r4 = r1.d()     // Catch:{ all -> 0x0053 }
            android.graphics.Typeface$Builder r0 = r0.setWeight(r4)     // Catch:{ all -> 0x0053 }
            boolean r4 = r1.e()     // Catch:{ all -> 0x0053 }
            android.graphics.Typeface$Builder r0 = r0.setItalic(r4)     // Catch:{ all -> 0x0053 }
            android.graphics.Typeface r0 = r0.build()     // Catch:{ all -> 0x0053 }
            r3.close()     // Catch:{ IOException -> 0x005d }
            return r0
        L_0x0053:
            r0 = move-exception
            throw r0     // Catch:{ all -> 0x0055 }
        L_0x0055:
            r0 = move-exception
            r4 = r0
            r3.close()     // Catch:{ all -> 0x005b }
            goto L_0x005c
        L_0x005b:
            r0 = move-exception
        L_0x005c:
            throw r4     // Catch:{ IOException -> 0x005d }
        L_0x005d:
            r0 = move-exception
            return r11
        L_0x005f:
            r12 = r21
            java.util.Map r0 = a.b.c.e.b.i(r12, r9, r8)
            java.lang.Object r13 = r20.o()
            r1 = 0
            int r14 = r9.length
            r2 = 0
            r15 = r1
            r6 = 0
        L_0x006e:
            if (r6 >= r14) goto L_0x00a8
            r16 = r9[r6]
            android.net.Uri r1 = r16.c()
            java.lang.Object r1 = r0.get(r1)
            r17 = r1
            java.nio.ByteBuffer r17 = (java.nio.ByteBuffer) r17
            if (r17 != 0) goto L_0x0083
            r19 = r6
            goto L_0x00a5
        L_0x0083:
            int r4 = r16.b()
            int r5 = r16.d()
            boolean r18 = r16.e()
            r1 = r20
            r2 = r13
            r3 = r17
            r19 = r6
            r6 = r18
            boolean r1 = r1.k(r2, r3, r4, r5, r6)
            if (r1 != 0) goto L_0x00a3
            r7.i(r13)
            return r11
        L_0x00a3:
            r2 = 1
            r15 = r2
        L_0x00a5:
            int r6 = r19 + 1
            goto L_0x006e
        L_0x00a8:
            if (r15 != 0) goto L_0x00ae
            r7.i(r13)
            return r11
        L_0x00ae:
            boolean r1 = r7.m(r13)
            if (r1 != 0) goto L_0x00b5
            return r11
        L_0x00b5:
            android.graphics.Typeface r1 = r7.l(r13)
            android.graphics.Typeface r2 = android.graphics.Typeface.create(r1, r10)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.c.f.b(android.content.Context, android.os.CancellationSignal, a.b.c.e.b$f[], int):android.graphics.Typeface");
    }

    public Typeface d(Context context, Resources resources, int id, String path, int style) {
        if (!n()) {
            return super.d(context, resources, id, path, style);
        }
        Object fontFamily = o();
        if (!j(context, fontFamily, path, 0, -1, -1, (FontVariationAxis[]) null)) {
            i(fontFamily);
            return null;
        } else if (!m(fontFamily)) {
            return null;
        } else {
            return l(fontFamily);
        }
    }

    public Class t() {
        return Class.forName("android.graphics.FontFamily");
    }

    public Constructor u(Class fontFamily) {
        return fontFamily.getConstructor(new Class[0]);
    }

    public Method q(Class fontFamily) {
        Class cls = Integer.TYPE;
        return fontFamily.getMethod("addFontFromAssetManager", new Class[]{AssetManager.class, String.class, Integer.TYPE, Boolean.TYPE, cls, cls, cls, FontVariationAxis[].class});
    }

    public Method r(Class fontFamily) {
        Class cls = Integer.TYPE;
        return fontFamily.getMethod("addFontFromBuffer", new Class[]{ByteBuffer.class, cls, FontVariationAxis[].class, cls, cls});
    }

    public Method v(Class fontFamily) {
        return fontFamily.getMethod("freeze", new Class[0]);
    }

    public Method p(Class fontFamily) {
        return fontFamily.getMethod("abortCreation", new Class[0]);
    }

    public Method s(Class fontFamily) {
        Class cls = Integer.TYPE;
        Method m = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", new Class[]{Array.newInstance(fontFamily, 1).getClass(), cls, cls});
        m.setAccessible(true);
        return m;
    }
}
