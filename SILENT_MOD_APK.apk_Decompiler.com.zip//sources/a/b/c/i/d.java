package a.b.c.i;

import a.b.c.i.e;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;

public abstract class d extends BaseAdapter implements Filterable, e.a {

    /* renamed from: b  reason: collision with root package name */
    public boolean f285b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f286c;
    public Cursor d;
    public Context e;
    public int f;
    public a g;
    public DataSetObserver h;
    public e i;

    public abstract void a(View view, Context context, Cursor cursor);

    public abstract CharSequence c(Cursor cursor);

    public abstract View f(Context context, Cursor cursor, ViewGroup viewGroup);

    public abstract View g(Context context, Cursor cursor, ViewGroup viewGroup);

    public d(Context context, Cursor c2, boolean autoRequery) {
        e(context, c2, autoRequery ? 1 : 2);
    }

    public void e(Context context, Cursor c2, int flags) {
        boolean z = false;
        if ((flags & 1) == 1) {
            flags |= 2;
            this.f286c = true;
        } else {
            this.f286c = false;
        }
        if (c2 != null) {
            z = true;
        }
        boolean cursorPresent = z;
        this.d = c2;
        this.f285b = cursorPresent;
        this.e = context;
        this.f = cursorPresent ? c2.getColumnIndexOrThrow("_id") : -1;
        if ((flags & 2) == 2) {
            this.g = new a();
            this.h = new b();
        } else {
            this.g = null;
            this.h = null;
        }
        if (cursorPresent) {
            a aVar = this.g;
            if (aVar != null) {
                c2.registerContentObserver(aVar);
            }
            DataSetObserver dataSetObserver = this.h;
            if (dataSetObserver != null) {
                c2.registerDataSetObserver(dataSetObserver);
            }
        }
    }

    public Cursor d() {
        return this.d;
    }

    public int getCount() {
        Cursor cursor;
        if (!this.f285b || (cursor = this.d) == null) {
            return 0;
        }
        return cursor.getCount();
    }

    public Object getItem(int position) {
        Cursor cursor;
        if (!this.f285b || (cursor = this.d) == null) {
            return null;
        }
        cursor.moveToPosition(position);
        return this.d;
    }

    public long getItemId(int position) {
        Cursor cursor;
        if (!this.f285b || (cursor = this.d) == null || !cursor.moveToPosition(position)) {
            return 0;
        }
        return this.d.getLong(this.f);
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View v;
        if (!this.f285b) {
            throw new IllegalStateException("this should only be called when the cursor is valid");
        } else if (this.d.moveToPosition(position)) {
            if (convertView == null) {
                v = g(this.e, this.d, parent);
            } else {
                v = convertView;
            }
            a(v, this.e, this.d);
            return v;
        } else {
            throw new IllegalStateException("couldn't move cursor to position " + position);
        }
    }

    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        View v;
        if (!this.f285b) {
            return null;
        }
        this.d.moveToPosition(position);
        if (convertView == null) {
            v = f(this.e, this.d, parent);
        } else {
            v = convertView;
        }
        a(v, this.e, this.d);
        return v;
    }

    public void b(Cursor cursor) {
        Cursor old = i(cursor);
        if (old != null) {
            old.close();
        }
    }

    public Cursor i(Cursor newCursor) {
        if (newCursor == this.d) {
            return null;
        }
        Cursor oldCursor = this.d;
        if (oldCursor != null) {
            a aVar = this.g;
            if (aVar != null) {
                oldCursor.unregisterContentObserver(aVar);
            }
            DataSetObserver dataSetObserver = this.h;
            if (dataSetObserver != null) {
                oldCursor.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.d = newCursor;
        if (newCursor != null) {
            a aVar2 = this.g;
            if (aVar2 != null) {
                newCursor.registerContentObserver(aVar2);
            }
            DataSetObserver dataSetObserver2 = this.h;
            if (dataSetObserver2 != null) {
                newCursor.registerDataSetObserver(dataSetObserver2);
            }
            this.f = newCursor.getColumnIndexOrThrow("_id");
            this.f285b = true;
            notifyDataSetChanged();
        } else {
            this.f = -1;
            this.f285b = false;
            notifyDataSetInvalidated();
        }
        return oldCursor;
    }

    public Filter getFilter() {
        if (this.i == null) {
            this.i = new e(this);
        }
        return this.i;
    }

    public void h() {
        Cursor cursor;
        if (this.f286c && (cursor = this.d) != null && !cursor.isClosed()) {
            this.f285b = this.d.requery();
        }
    }

    public class a extends ContentObserver {
        public a() {
            super(new Handler());
        }

        public boolean deliverSelfNotifications() {
            return true;
        }

        public void onChange(boolean selfChange) {
            d.this.h();
        }
    }

    public class b extends DataSetObserver {
        public b() {
        }

        public void onChanged() {
            d dVar = d.this;
            dVar.f285b = true;
            dVar.notifyDataSetChanged();
        }

        public void onInvalidated() {
            d dVar = d.this;
            dVar.f285b = false;
            dVar.notifyDataSetInvalidated();
        }
    }
}
