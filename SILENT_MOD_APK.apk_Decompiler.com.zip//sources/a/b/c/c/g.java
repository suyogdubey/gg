package a.b.c.c;

import android.graphics.Typeface;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class g extends f {
    public Typeface l(Object family) {
        try {
            Object familyArray = Array.newInstance(this.f168a, 1);
            Array.set(familyArray, 0, family);
            return (Typeface) this.g.invoke((Object) null, new Object[]{familyArray, "sans-serif", -1, -1});
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    public Method s(Class fontFamily) {
        Class cls = Integer.TYPE;
        Method m = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", new Class[]{Array.newInstance(fontFamily, 1).getClass(), String.class, cls, cls});
        m.setAccessible(true);
        return m;
    }
}
