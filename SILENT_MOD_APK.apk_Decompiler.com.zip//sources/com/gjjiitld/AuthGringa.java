package com.gjjiitld;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Toast;
import c.a.c;
import c.a.d;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.X509Certificate;
import java.security.spec.X509EncodedKeySpec;
import java.util.Collections;
import java.util.Iterator;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.json.JSONObject;

public class AuthGringa extends AsyncTask<String, Void, String> {

    /* renamed from: a  reason: collision with root package name */
    public String f676a = "";

    /* renamed from: b  reason: collision with root package name */
    public String f677b = "";

    /* renamed from: c  reason: collision with root package name */
    public WeakReference<LoginActivity> f678c;
    public ProgressDialog d;
    public byte[] e = {48, -127, -97, 48, 13, 6, 9, 42, -122, 72, -122, -9, 13, 1, 1, 1, 5, 0, 3, -127, -115, 0, 48, -127, -119, 2, -127, -127, 0, -35, 81, 3, 33, -25, -58, 90, 40, -85, 46, 34, 69, 104, -10, -85, 123, Byte.MIN_VALUE, -89, 92, 53, 39, -78, -57, 51, -31, -61, 32, 28, 117, -40, -5, 105, -96, 88, -69, 87, -68, 7, Byte.MAX_VALUE, 29, -79, 44, 122, 28, 41, 61, 109, -61, -28, -30, 97, 91, 98, -17, 103, 82, -51, 63, 16, -122, 32, -125, 122, 57, 79, -40, -39, 77, 21, -109, -84, -39, -28, -97, 55, -51, -48, 108, 39, 103, -104, -42, 39, 91, 64, 7, -30, -20, 104, -45, 70, -83, 94, 49, -44, 47, Byte.MIN_VALUE, 23, 124, -114, 21, -48, 75, Byte.MIN_VALUE, 80, -34, -77, -30, -4, -102, 69, -54, -115, -105, 117, 126, -26, 108, -75, -37, -72, -12, -58, -26, -56, -14, -122, 97, 2, 3, 1, 0, 1};
    public String f = "DTEXPIRE";

    public static native void HackerDk(String str, String str2);

    public final native String AuthURL();

    public static void a() {
        TrustManager[] trustAllCerts = {new a()};
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init((KeyManager[]) null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (KeyManagementException e2) {
            e2.printStackTrace();
        } catch (NoSuchAlgorithmException e3) {
            e3.printStackTrace();
        }
    }

    public static class a implements X509TrustManager {
        public X509Certificate[] getAcceptedIssuers() {
            return null;
        }

        public void checkClientTrusted(X509Certificate[] arg0, String arg1) {
        }

        public void checkServerTrusted(X509Certificate[] arg0, String arg1) {
        }
    }

    public class b implements X509TrustManager {
        public b(AuthGringa this$0) {
        }

        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }

        public void checkClientTrusted(X509Certificate[] chain, String authType) {
        }

        public void checkServerTrusted(X509Certificate[] chain, String authType) {
        }
    }

    public AuthGringa(LoginActivity activity) {
        new TrustManager[1][0] = new b(this);
        this.f678c = new WeakReference<>(activity);
        ProgressDialog dialog = new ProgressDialog(activity);
        dialog.setCancelable(false);
        this.d = dialog;
    }

    /* renamed from: b */
    public String doInBackground(String... strings) {
        if (!l(d())) {
            return "Connect to the internet first.";
        }
        try {
            a();
            this.f676a = strings[0];
            this.f677b = strings[1];
            JSONObject token = new JSONObject();
            JSONObject data = new JSONObject();
            data.put("User_hk", strings[0]);
            data.put("Load_hk", "69");
            data.put("Uid_hk", k(d()));
            token.put("Dados_hk", c(data.toString(), this.e));
            token.put("Hash_hk", c.a(data.toString()));
            token.put("Tok_hk", this.f677b);
            HttpURLConnection urlConnection = (HttpURLConnection) new URL(AuthURL()).openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            String postParameters = "tokserver_hk=" + c.h(token.toString());
            urlConnection.setFixedLengthStreamingMode(postParameters.getBytes().length);
            PrintWriter out = new PrintWriter(urlConnection.getOutputStream());
            out.print(postParameters);
            out.close();
            return c.d(c.g(urlConnection.getInputStream()));
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    /* renamed from: m */
    public void onPostExecute(String s) {
        Activity activity = d();
        if (activity != null) {
            if (g() != null) {
                g().dismiss();
            }
            if (s == null || s.isEmpty()) {
                ((LoginActivity) this.f678c.get()).c("404: Unknown error!", "Erro", "#ffffff", "#ff0000");
            } else if (s.equals("Sem acesso a internet")) {
                ((LoginActivity) this.f678c.get()).c("No internet access!", "Erro", "#ffffff", "#ff0000");
            } else {
                try {
                    JSONObject ack = new JSONObject(s);
                    String decData = c.f(ack.get("Dados_hk").toString(), ack.get("Hash_hk").toString());
                    if (!n(decData, ack.get("Sign_hk").toString(), this.e)) {
                        ((LoginActivity) this.f678c.get()).c("Login credentials are incorrect!", "ERROR", "#fff700", "#ff0000");
                        return;
                    }
                    JSONObject data = new JSONObject(decData);
                    if (!data.get("ConnectSt_hk").toString().equals("HasBeenSucceeded")) {
                        ((LoginActivity) this.f678c.get()).c(data.get("MessageFromSv").toString(), "ERROR", "#fff700", "#ff0000");
                    } else if (!data.getString("Logged_UserHK").toLowerCase().equals(this.f676a.toLowerCase())) {
                        ((LoginActivity) this.f678c.get()).c("User is invalid!", "ERROR", "#fff700", "#ff0000");
                    } else if (!data.getString("Logged_TokHK").equals(this.f677b)) {
                        ((LoginActivity) this.f678c.get()).c("The token is invalid!", "ERROR", "#fff700", "#ff0000");
                    } else {
                        c.a.b prefs = c.a.b.d(d());
                        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(d())) {
                            d.d(d().getApplicationContext(), c.c(data.get("Bolsonaro").toString()));
                            HackerDk(c.a.b.d((Context) null).b("USER"), k(d()));
                            ((LoginActivity) this.f678c.get()).c("Logged in successfully!", "ONLINE", "#ff0000", "#00ff4e");
                            Intent intent = new Intent(d(), MainActivity.class);
                            intent.putExtra("EXPIRYDAYS", Integer.parseInt(data.get("ExpireDays").toString()));
                            intent.putExtra("CURRVERSION", data.get("ApkVersion_hk").toString());
                            intent.putExtra("DOWNLINK", data.getString("DownLink_hk"));
                            prefs.e(this.f, data.get("ExpireDays").toString());
                            d().startActivity(intent);
                            d().finish();
                        } else {
                            d().startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + d().getPackageName())), 123);
                            Process.killProcess(Process.myPid());
                        }
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                    Toast.makeText(activity, e2.toString(), 1).show();
                }
            }
        }
    }

    public static boolean l(Context ctx) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) ctx.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public final LoginActivity d() {
        return (LoginActivity) this.f678c.get();
    }

    public final ProgressDialog g() {
        return this.d;
    }

    public final PublicKey j(byte[] keyBytes) {
        return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(keyBytes));
    }

    public final String c(String plainText, byte[] keyBytes) {
        Cipher encryptCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        encryptCipher.init(1, j(keyBytes));
        return c.i(encryptCipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8)));
    }

    public final boolean n(String plainText, String signature, byte[] keyBytes) {
        Signature publicSignature = Signature.getInstance("SHA256withRSA");
        publicSignature.initVerify(j(keyBytes));
        publicSignature.update(plainText.getBytes(StandardCharsets.UTF_8));
        return publicSignature.verify(c.c(signature));
    }

    public static String k(Context ctx) {
        return UUID.nameUUIDFromBytes((f() + e(ctx) + h(ctx)).replace(" ", "").getBytes()).toString().replace("-", "");
    }

    public static String f() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return model;
        }
        return manufacturer + " " + model;
    }

    public static String e(Context ctx) {
        return Settings.Secure.getString(ctx.getContentResolver(), "android_id");
    }

    public static String h(Context ctx) {
        return Build.HARDWARE + Build.SERIAL + i(ctx);
    }

    public static String i(Context ctx) {
        byte[] macBytes;
        try {
            WifiManager wifiManager = (WifiManager) ctx.getApplicationContext().getSystemService("wifi");
            if (wifiManager != null) {
                String macAddress = wifiManager.getConnectionInfo().getMacAddress();
                if (!TextUtils.isEmpty(macAddress)) {
                    return macAddress;
                }
            }
            Iterator<T> it = Collections.list(NetworkInterface.getNetworkInterfaces()).iterator();
            while (it.hasNext()) {
                NetworkInterface networkInterface = (NetworkInterface) it.next();
                if (networkInterface.getName().equalsIgnoreCase("wlan0") && (macBytes = networkInterface.getHardwareAddress()) != null) {
                    StringBuilder macAddress2 = new StringBuilder();
                    int length = macBytes.length;
                    for (int i = 0; i < length; i++) {
                        macAddress2.append(String.format("%02X:", new Object[]{Byte.valueOf(macBytes[i])}));
                    }
                    if (macAddress2.length() > 0) {
                        macAddress2.deleteCharAt(macAddress2.length() - 1);
                    }
                    return macAddress2.toString();
                }
            }
            return "UNKNOWN";
        } catch (Exception e2) {
            e2.printStackTrace();
            return "UNKNOWN";
        }
    }
}
