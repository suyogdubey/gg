package a.b.c.c;

import a.b.c.b.c.c;
import a.b.c.b.c.f;
import a.b.c.e.b;
import a.b.c.g.g;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;

public class c {

    /* renamed from: a  reason: collision with root package name */
    public static final h f163a;

    /* renamed from: b  reason: collision with root package name */
    public static final g<String, Typeface> f164b = new g<>(16);

    static {
        int i = Build.VERSION.SDK_INT;
        if (i >= 28) {
            f163a = new g();
        } else if (i >= 26) {
            f163a = new f();
        } else if (i >= 24 && e.j()) {
            f163a = new e();
        } else if (Build.VERSION.SDK_INT >= 21) {
            f163a = new d();
        } else {
            f163a = new h();
        }
    }

    public static Typeface e(Resources resources, int id, int style) {
        return f164b.c(d(resources, id, style));
    }

    public static String d(Resources resources, int id, int style) {
        return resources.getResourcePackageName(id) + "-" + id + "-" + style;
    }

    public static Typeface b(Context context, c.a entry, Resources resources, int id, int style, f.a fontCallback, Handler handler, boolean isRequestFromLayoutInflator) {
        Typeface typeface;
        c.a aVar = entry;
        f.a aVar2 = fontCallback;
        Handler handler2 = handler;
        if (aVar instanceof c.d) {
            c.d providerEntry = (c.d) aVar;
            typeface = b.g(context, providerEntry.b(), fontCallback, handler, !isRequestFromLayoutInflator ? aVar2 == null : providerEntry.a() == 0, isRequestFromLayoutInflator ? providerEntry.c() : -1, style);
            Context context2 = context;
            Resources resources2 = resources;
            int i = style;
        } else {
            Context context3 = context;
            Resources resources3 = resources;
            int i2 = style;
            typeface = f163a.a(context, (c.b) aVar, resources, style);
            if (aVar2 != null) {
                if (typeface != null) {
                    aVar2.b(typeface, handler2);
                } else {
                    aVar2.a(-3, handler2);
                }
            }
        }
        if (typeface != null) {
            f164b.d(d(resources, id, style), typeface);
        }
        return typeface;
    }

    public static Typeface c(Context context, Resources resources, int id, String path, int style) {
        Typeface typeface = f163a.d(context, resources, id, path, style);
        if (typeface != null) {
            f164b.d(d(resources, id, style), typeface);
        }
        return typeface;
    }

    public static Typeface a(Context context, CancellationSignal cancellationSignal, b.f[] fonts, int style) {
        return f163a.b(context, cancellationSignal, fonts, style);
    }
}
