package a.b.d.f;

import a.b.c.i.c;
import a.b.d.b.j;
import a.b.d.c.a.a;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CompoundButton;

public class i {

    /* renamed from: a  reason: collision with root package name */
    public final CompoundButton f476a;

    /* renamed from: b  reason: collision with root package name */
    public ColorStateList f477b = null;

    /* renamed from: c  reason: collision with root package name */
    public PorterDuff.Mode f478c = null;
    public boolean d = false;
    public boolean e = false;
    public boolean f;

    public i(CompoundButton view) {
        this.f476a = view;
    }

    public void e(AttributeSet attrs, int defStyleAttr) {
        int resourceId;
        TypedArray a2 = this.f476a.getContext().obtainStyledAttributes(attrs, j.CompoundButton, defStyleAttr, 0);
        try {
            if (a2.hasValue(j.CompoundButton_android_button) && (resourceId = a2.getResourceId(j.CompoundButton_android_button, 0)) != 0) {
                this.f476a.setButtonDrawable(a.d(this.f476a.getContext(), resourceId));
            }
            if (a2.hasValue(j.CompoundButton_buttonTint)) {
                c.b(this.f476a, a2.getColorStateList(j.CompoundButton_buttonTint));
            }
            if (a2.hasValue(j.CompoundButton_buttonTintMode)) {
                c.c(this.f476a, c0.d(a2.getInt(j.CompoundButton_buttonTintMode, -1), (PorterDuff.Mode) null));
            }
        } finally {
            a2.recycle();
        }
    }

    public void g(ColorStateList tint) {
        this.f477b = tint;
        this.d = true;
        a();
    }

    public ColorStateList c() {
        return this.f477b;
    }

    public void h(PorterDuff.Mode tintMode) {
        this.f478c = tintMode;
        this.e = true;
        a();
    }

    public PorterDuff.Mode d() {
        return this.f478c;
    }

    public void f() {
        if (this.f) {
            this.f = false;
            return;
        }
        this.f = true;
        a();
    }

    public void a() {
        Drawable buttonDrawable = c.a(this.f476a);
        if (buttonDrawable == null) {
            return;
        }
        if (this.d || this.e) {
            Drawable buttonDrawable2 = a.b.c.c.j.a.p(buttonDrawable).mutate();
            if (this.d) {
                a.b.c.c.j.a.n(buttonDrawable2, this.f477b);
            }
            if (this.e) {
                a.b.c.c.j.a.o(buttonDrawable2, this.f478c);
            }
            if (buttonDrawable2.isStateful()) {
                buttonDrawable2.setState(this.f476a.getDrawableState());
            }
            this.f476a.setButtonDrawable(buttonDrawable2);
        }
    }

    public int b(int superValue) {
        return superValue;
    }
}
