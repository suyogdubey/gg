package a.b.c.h;

import android.os.Build;
import android.view.WindowInsets;

public class x {

    /* renamed from: a  reason: collision with root package name */
    public final Object f268a;

    public x(Object insets) {
        this.f268a = insets;
    }

    public int b() {
        if (Build.VERSION.SDK_INT >= 20) {
            return ((WindowInsets) this.f268a).getSystemWindowInsetLeft();
        }
        return 0;
    }

    public int d() {
        if (Build.VERSION.SDK_INT >= 20) {
            return ((WindowInsets) this.f268a).getSystemWindowInsetTop();
        }
        return 0;
    }

    public int c() {
        if (Build.VERSION.SDK_INT >= 20) {
            return ((WindowInsets) this.f268a).getSystemWindowInsetRight();
        }
        return 0;
    }

    public int a() {
        if (Build.VERSION.SDK_INT >= 20) {
            return ((WindowInsets) this.f268a).getSystemWindowInsetBottom();
        }
        return 0;
    }

    public x e(int left, int top, int right, int bottom) {
        if (Build.VERSION.SDK_INT >= 20) {
            return new x(((WindowInsets) this.f268a).replaceSystemWindowInsets(left, top, right, bottom));
        }
        return null;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        x other = (x) o;
        Object obj = this.f268a;
        if (obj != null) {
            return obj.equals(other.f268a);
        }
        if (other.f268a == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        Object obj = this.f268a;
        if (obj == null) {
            return 0;
        }
        return obj.hashCode();
    }

    public static x g(Object insets) {
        if (insets == null) {
            return null;
        }
        return new x(insets);
    }

    public static Object f(x insets) {
        if (insets == null) {
            return null;
        }
        return insets.f268a;
    }
}
