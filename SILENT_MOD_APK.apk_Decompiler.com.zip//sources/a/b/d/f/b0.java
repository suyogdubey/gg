package a.b.d.f;

import a.b.c.h.t;
import a.b.d.e.j.o;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;

public interface b0 {
    boolean a();

    boolean b();

    void c();

    void collapseActionView();

    boolean d();

    boolean e();

    void f(Menu menu, o.a aVar);

    boolean g();

    CharSequence getTitle();

    void h();

    void i(m0 m0Var);

    t j(int i, long j);

    int k();

    void l(int i);

    void m();

    boolean n();

    void o(int i);

    ViewGroup p();

    void q(boolean z);

    void r();

    void s(boolean z);

    void setIcon(int i);

    void setIcon(Drawable drawable);

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);

    Context t();

    void u(int i);

    int v();
}
