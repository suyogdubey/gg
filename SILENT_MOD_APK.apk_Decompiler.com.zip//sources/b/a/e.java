package b.a;

import com.gjjiitld.R;

public final class e {
    public static final int[] CardView = {16843071, 16843072, R.attr.cardBackgroundColor, R.attr.cardCornerRadius, R.attr.cardElevation, R.attr.cardMaxElevation, R.attr.cardPreventCornerOverlap, R.attr.cardUseCompatPadding, R.attr.contentPadding, R.attr.contentPaddingBottom, R.attr.contentPaddingLeft, R.attr.contentPaddingRight, R.attr.contentPaddingTop};
    public static final int CardView_android_minHeight = 1;
    public static final int CardView_android_minWidth = 0;
    public static final int CardView_cardBackgroundColor = 2;
    public static final int CardView_cardCornerRadius = 3;
    public static final int CardView_cardElevation = 4;
    public static final int CardView_cardMaxElevation = 5;
    public static final int CardView_cardPreventCornerOverlap = 6;
    public static final int CardView_cardUseCompatPadding = 7;
    public static final int CardView_contentPadding = 8;
    public static final int CardView_contentPaddingBottom = 9;
    public static final int CardView_contentPaddingLeft = 10;
    public static final int CardView_contentPaddingRight = 11;
    public static final int CardView_contentPaddingTop = 12;
}
