package b.a.f;

import android.content.Context;
import android.content.res.ColorStateList;

public interface e {
    float a(d dVar);

    float b(d dVar);

    void c(d dVar);

    void d(d dVar, ColorStateList colorStateList);

    float e(d dVar);

    float f(d dVar);

    float g(d dVar);

    void h(d dVar);

    ColorStateList i(d dVar);

    void j(d dVar, float f);

    void k(d dVar, float f);

    void l();

    void m(d dVar, Context context, ColorStateList colorStateList, float f, float f2, float f3);

    void n(d dVar, float f);
}
