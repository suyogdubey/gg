package a.b.c.h.y;

public class b {

    /* renamed from: a  reason: collision with root package name */
    public final Object f270a;

    public b(Object provider) {
        this.f270a = provider;
    }

    public Object a() {
        return this.f270a;
    }
}
