package a.b.d.f;

public interface b1 {
    CharSequence a();
}
