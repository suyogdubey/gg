package a.b.c.h;

import android.view.View;
import android.view.ViewGroup;

public class m {

    /* renamed from: a  reason: collision with root package name */
    public int f254a;

    public m(ViewGroup viewGroup) {
    }

    public void c(View child, View target, int axes) {
        b(axes);
    }

    public void b(int axes) {
        this.f254a = axes;
    }

    public int a() {
        return this.f254a;
    }

    public void d() {
        this.f254a = 0;
    }
}
