package a.b.c.h;

import android.content.Context;
import android.util.Log;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public abstract class c {

    /* renamed from: a  reason: collision with root package name */
    public b f245a;

    public interface a {
    }

    public interface b {
    }

    public abstract View c();

    public c(Context context) {
    }

    public View d(MenuItem forItem) {
        return c();
    }

    public boolean g() {
        return false;
    }

    public boolean b() {
        return true;
    }

    public boolean e() {
        return false;
    }

    public boolean a() {
        return false;
    }

    public void f(SubMenu subMenu) {
    }

    public void i(a listener) {
    }

    public void j(b listener) {
        if (!(this.f245a == null || listener == null)) {
            Log.w("ActionProvider(support)", "setVisibilityListener: Setting a new ActionProvider.VisibilityListener when one is already set. Are you reusing this " + getClass().getSimpleName() + " instance while it is still in use somewhere else?");
        }
        this.f245a = listener;
    }

    public void h() {
        this.f245a = null;
    }
}
