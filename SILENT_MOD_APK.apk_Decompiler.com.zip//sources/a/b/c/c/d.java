package a.b.c.c;

import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import java.io.File;

public class d extends h {
    public final File h(ParcelFileDescriptor fd) {
        try {
            String path = Os.readlink("/proc/self/fd/" + fd.getFd());
            if (OsConstants.S_ISREG(Os.stat(path).st_mode)) {
                return new File(path);
            }
            return null;
        } catch (ErrnoException e) {
            return null;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0047, code lost:
        r6 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:?, code lost:
        r5.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:?, code lost:
        throw r6;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.Typeface b(android.content.Context r9, android.os.CancellationSignal r10, a.b.c.e.b.f[] r11, int r12) {
        /*
            r8 = this;
            int r0 = r11.length
            r1 = 0
            r2 = 1
            if (r0 >= r2) goto L_0x0006
            return r1
        L_0x0006:
            a.b.c.e.b$f r0 = r8.g(r11, r12)
            android.content.ContentResolver r2 = r9.getContentResolver()
            android.net.Uri r3 = r0.c()     // Catch:{ IOException -> 0x0059 }
            java.lang.String r4 = "r"
            android.os.ParcelFileDescriptor r3 = r2.openFileDescriptor(r3, r4, r10)     // Catch:{ IOException -> 0x0059 }
            java.io.File r4 = r8.h(r3)     // Catch:{ all -> 0x004e }
            if (r4 == 0) goto L_0x0031
            boolean r5 = r4.canRead()     // Catch:{ all -> 0x004e }
            if (r5 != 0) goto L_0x0027
            goto L_0x0031
        L_0x0027:
            android.graphics.Typeface r5 = android.graphics.Typeface.createFromFile(r4)     // Catch:{ all -> 0x004e }
            if (r3 == 0) goto L_0x0030
            r3.close()     // Catch:{ IOException -> 0x0059 }
        L_0x0030:
            return r5
        L_0x0031:
            java.io.FileInputStream r5 = new java.io.FileInputStream     // Catch:{ all -> 0x004e }
            java.io.FileDescriptor r6 = r3.getFileDescriptor()     // Catch:{ all -> 0x004e }
            r5.<init>(r6)     // Catch:{ all -> 0x004e }
            android.graphics.Typeface r6 = super.c(r9, r5)     // Catch:{ all -> 0x0045 }
            r5.close()     // Catch:{ all -> 0x004e }
            r3.close()     // Catch:{ IOException -> 0x0059 }
            return r6
        L_0x0045:
            r6 = move-exception
            throw r6     // Catch:{ all -> 0x0047 }
        L_0x0047:
            r6 = move-exception
            r5.close()     // Catch:{ all -> 0x004c }
            goto L_0x004d
        L_0x004c:
            r7 = move-exception
        L_0x004d:
            throw r6     // Catch:{ all -> 0x004e }
        L_0x004e:
            r4 = move-exception
            throw r4     // Catch:{ all -> 0x0050 }
        L_0x0050:
            r4 = move-exception
            if (r3 == 0) goto L_0x0058
            r3.close()     // Catch:{ all -> 0x0057 }
            goto L_0x0058
        L_0x0057:
            r5 = move-exception
        L_0x0058:
            throw r4     // Catch:{ IOException -> 0x0059 }
        L_0x0059:
            r3 = move-exception
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.c.d.b(android.content.Context, android.os.CancellationSignal, a.b.c.e.b$f[], int):android.graphics.Typeface");
    }
}
