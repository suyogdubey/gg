package a.b.d.f;

import a.b.c.i.m;
import a.b.d.b.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CheckBox;

public class g extends CheckBox implements m {

    /* renamed from: b  reason: collision with root package name */
    public final i f460b;

    public g(Context context, AttributeSet attrs) {
        this(context, attrs, a.checkboxStyle);
    }

    public g(Context context, AttributeSet attrs, int defStyleAttr) {
        super(q0.b(context), attrs, defStyleAttr);
        i iVar = new i(this);
        this.f460b = iVar;
        iVar.e(attrs, defStyleAttr);
    }

    public void setButtonDrawable(Drawable buttonDrawable) {
        super.setButtonDrawable(buttonDrawable);
        i iVar = this.f460b;
        if (iVar != null) {
            iVar.f();
        }
    }

    public void setButtonDrawable(int resId) {
        setButtonDrawable(a.b.d.c.a.a.d(getContext(), resId));
    }

    public int getCompoundPaddingLeft() {
        int value = super.getCompoundPaddingLeft();
        i iVar = this.f460b;
        if (iVar != null) {
            iVar.b(value);
        }
        return value;
    }

    public void setSupportButtonTintList(ColorStateList tint) {
        i iVar = this.f460b;
        if (iVar != null) {
            iVar.g(tint);
        }
    }

    public ColorStateList getSupportButtonTintList() {
        i iVar = this.f460b;
        if (iVar != null) {
            return iVar.c();
        }
        return null;
    }

    public void setSupportButtonTintMode(PorterDuff.Mode tintMode) {
        i iVar = this.f460b;
        if (iVar != null) {
            iVar.h(tintMode);
        }
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        i iVar = this.f460b;
        if (iVar != null) {
            return iVar.d();
        }
        return null;
    }
}
