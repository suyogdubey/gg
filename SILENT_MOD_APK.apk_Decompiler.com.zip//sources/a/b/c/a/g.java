package a.b.c.a;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public abstract class g {
    public abstract View b(int i);

    public abstract boolean c();

    public e a(Context context, String className, Bundle arguments) {
        return e.E(context, className, arguments);
    }
}
