package a.b.d.f;

import a.b.c.h.p;
import a.b.c.h.t;
import a.b.c.h.v;
import a.b.d.b.f;
import a.b.d.b.h;
import a.b.d.b.j;
import a.b.d.e.j.o;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

public class v0 implements b0 {

    /* renamed from: a  reason: collision with root package name */
    public Toolbar f528a;

    /* renamed from: b  reason: collision with root package name */
    public int f529b;

    /* renamed from: c  reason: collision with root package name */
    public View f530c;
    public View d;
    public Drawable e;
    public Drawable f;
    public Drawable g;
    public boolean h;
    public CharSequence i;
    public CharSequence j;
    public CharSequence k;
    public Window.Callback l;
    public boolean m;
    public c n;
    public int o;
    public int p;
    public Drawable q;

    public v0(Toolbar toolbar, boolean style) {
        this(toolbar, style, h.abc_action_bar_up_description);
    }

    public v0(Toolbar toolbar, boolean style, int defaultNavigationContentDescription) {
        Drawable drawable;
        this.o = 0;
        this.p = 0;
        this.f528a = toolbar;
        this.i = toolbar.getTitle();
        this.j = toolbar.getSubtitle();
        this.h = this.i != null;
        this.g = toolbar.getNavigationIcon();
        t0 a2 = t0.t(toolbar.getContext(), (AttributeSet) null, j.ActionBar, a.b.d.b.a.actionBarStyle, 0);
        this.q = a2.f(j.ActionBar_homeAsUpIndicator);
        if (style) {
            CharSequence title = a2.o(j.ActionBar_title);
            if (!TextUtils.isEmpty(title)) {
                E(title);
            }
            CharSequence subtitle = a2.o(j.ActionBar_subtitle);
            if (!TextUtils.isEmpty(subtitle)) {
                D(subtitle);
            }
            Drawable logo = a2.f(j.ActionBar_logo);
            if (logo != null) {
                z(logo);
            }
            Drawable icon = a2.f(j.ActionBar_icon);
            if (icon != null) {
                setIcon(icon);
            }
            if (this.g == null && (drawable = this.q) != null) {
                C(drawable);
            }
            u(a2.j(j.ActionBar_displayOptions, 0));
            int customNavId = a2.m(j.ActionBar_customNavigationLayout, 0);
            if (customNavId != 0) {
                x(LayoutInflater.from(this.f528a.getContext()).inflate(customNavId, this.f528a, false));
                u(this.f529b | 16);
            }
            int height = a2.l(j.ActionBar_height, 0);
            if (height > 0) {
                ViewGroup.LayoutParams lp = this.f528a.getLayoutParams();
                lp.height = height;
                this.f528a.setLayoutParams(lp);
            }
            int contentInsetStart = a2.d(j.ActionBar_contentInsetStart, -1);
            int contentInsetEnd = a2.d(j.ActionBar_contentInsetEnd, -1);
            if (contentInsetStart >= 0 || contentInsetEnd >= 0) {
                this.f528a.G(Math.max(contentInsetStart, 0), Math.max(contentInsetEnd, 0));
            }
            int titleTextStyle = a2.m(j.ActionBar_titleTextStyle, 0);
            if (titleTextStyle != 0) {
                Toolbar toolbar2 = this.f528a;
                toolbar2.J(toolbar2.getContext(), titleTextStyle);
            }
            int subtitleTextStyle = a2.m(j.ActionBar_subtitleTextStyle, 0);
            if (subtitleTextStyle != 0) {
                Toolbar toolbar3 = this.f528a;
                toolbar3.I(toolbar3.getContext(), subtitleTextStyle);
            }
            int popupTheme = a2.m(j.ActionBar_popupTheme, 0);
            if (popupTheme != 0) {
                this.f528a.setPopupTheme(popupTheme);
            }
        } else {
            this.f529b = w();
        }
        a2.u();
        y(defaultNavigationContentDescription);
        this.k = this.f528a.getNavigationContentDescription();
        this.f528a.setNavigationOnClickListener(new u0(this));
    }

    public void y(int defaultNavigationContentDescription) {
        if (defaultNavigationContentDescription != this.p) {
            this.p = defaultNavigationContentDescription;
            if (TextUtils.isEmpty(this.f528a.getNavigationContentDescription())) {
                A(this.p);
            }
        }
    }

    public final int w() {
        if (this.f528a.getNavigationIcon() == null) {
            return 11;
        }
        int opts = 11 | 4;
        this.q = this.f528a.getNavigationIcon();
        return opts;
    }

    public ViewGroup p() {
        return this.f528a;
    }

    public Context t() {
        return this.f528a.getContext();
    }

    public boolean n() {
        return this.f528a.v();
    }

    public void collapseActionView() {
        this.f528a.e();
    }

    public void setWindowCallback(Window.Callback cb) {
        this.l = cb;
    }

    public void setWindowTitle(CharSequence title) {
        if (!this.h) {
            F(title);
        }
    }

    public CharSequence getTitle() {
        return this.f528a.getTitle();
    }

    public void E(CharSequence title) {
        this.h = true;
        F(title);
    }

    public final void F(CharSequence title) {
        this.i = title;
        if ((this.f529b & 8) != 0) {
            this.f528a.setTitle(title);
        }
    }

    public void D(CharSequence subtitle) {
        this.j = subtitle;
        if ((this.f529b & 8) != 0) {
            this.f528a.setSubtitle(subtitle);
        }
    }

    public void m() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    public void r() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    public void setIcon(int resId) {
        setIcon(resId != 0 ? a.b.d.c.a.a.d(t(), resId) : null);
    }

    public void setIcon(Drawable d2) {
        this.e = d2;
        I();
    }

    public void o(int resId) {
        z(resId != 0 ? a.b.d.c.a.a.d(t(), resId) : null);
    }

    public void z(Drawable d2) {
        this.f = d2;
        I();
    }

    public final void I() {
        Drawable logo = null;
        int i2 = this.f529b;
        if ((i2 & 2) != 0) {
            if ((i2 & 1) != 0) {
                Drawable drawable = this.f;
                if (drawable == null) {
                    drawable = this.e;
                }
                logo = drawable;
            } else {
                logo = this.e;
            }
        }
        this.f528a.setLogo(logo);
    }

    public boolean e() {
        return this.f528a.d();
    }

    public boolean d() {
        return this.f528a.z();
    }

    public boolean b() {
        return this.f528a.y();
    }

    public boolean a() {
        return this.f528a.M();
    }

    public boolean g() {
        return this.f528a.w();
    }

    public void c() {
        this.m = true;
    }

    public void f(Menu menu, o.a cb) {
        if (this.n == null) {
            c cVar = new c(this.f528a.getContext());
            this.n = cVar;
            cVar.p(f.action_menu_presenter);
        }
        this.n.j(cb);
        this.f528a.H((a.b.d.e.j.h) menu, this.n);
    }

    public void h() {
        this.f528a.f();
    }

    public int k() {
        return this.f529b;
    }

    public void u(int newOpts) {
        View view;
        int changed = this.f529b ^ newOpts;
        this.f529b = newOpts;
        if (changed != 0) {
            if ((changed & 4) != 0) {
                if ((newOpts & 4) != 0) {
                    G();
                }
                H();
            }
            if ((changed & 3) != 0) {
                I();
            }
            if ((changed & 8) != 0) {
                if ((newOpts & 8) != 0) {
                    this.f528a.setTitle(this.i);
                    this.f528a.setSubtitle(this.j);
                } else {
                    this.f528a.setTitle((CharSequence) null);
                    this.f528a.setSubtitle((CharSequence) null);
                }
            }
            if ((changed & 16) != 0 && (view = this.d) != null) {
                if ((newOpts & 16) != 0) {
                    this.f528a.addView(view);
                } else {
                    this.f528a.removeView(view);
                }
            }
        }
    }

    public void i(m0 tabView) {
        Toolbar toolbar;
        View view = this.f530c;
        if (view != null && view.getParent() == (toolbar = this.f528a)) {
            toolbar.removeView(this.f530c);
        }
        this.f530c = tabView;
        if (tabView != null && this.o == 2) {
            this.f528a.addView(tabView, 0);
            Toolbar.e lp = (Toolbar.e) this.f530c.getLayoutParams();
            lp.width = -2;
            lp.height = -2;
            lp.f296a = 8388691;
            tabView.setAllowCollapse(true);
        }
    }

    public void s(boolean collapsible) {
        this.f528a.setCollapsible(collapsible);
    }

    public void q(boolean enable) {
    }

    public int v() {
        return this.o;
    }

    public void x(View view) {
        View view2 = this.d;
        if (!(view2 == null || (this.f529b & 16) == 0)) {
            this.f528a.removeView(view2);
        }
        this.d = view;
        if (view != null && (this.f529b & 16) != 0) {
            this.f528a.addView(view);
        }
    }

    public t j(int visibility, long duration) {
        t a2 = p.a(this.f528a);
        a2.a(visibility == 0 ? 1.0f : 0.0f);
        a2.d(duration);
        a2.f(new a(visibility));
        return a2;
    }

    public class a extends v {

        /* renamed from: a  reason: collision with root package name */
        public boolean f531a = false;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ int f532b;

        public a(int i) {
            this.f532b = i;
        }

        public void b(View view) {
            v0.this.f528a.setVisibility(0);
        }

        public void a(View view) {
            if (!this.f531a) {
                v0.this.f528a.setVisibility(this.f532b);
            }
        }

        public void c(View view) {
            this.f531a = true;
        }
    }

    public void C(Drawable icon) {
        this.g = icon;
        H();
    }

    public final void H() {
        if ((this.f529b & 4) != 0) {
            Toolbar toolbar = this.f528a;
            Drawable drawable = this.g;
            if (drawable == null) {
                drawable = this.q;
            }
            toolbar.setNavigationIcon(drawable);
            return;
        }
        this.f528a.setNavigationIcon((Drawable) null);
    }

    public void B(CharSequence description) {
        this.k = description;
        G();
    }

    public void A(int resId) {
        B(resId == 0 ? null : t().getString(resId));
    }

    public final void G() {
        if ((this.f529b & 4) == 0) {
            return;
        }
        if (TextUtils.isEmpty(this.k)) {
            this.f528a.setNavigationContentDescription(this.p);
        } else {
            this.f528a.setNavigationContentDescription(this.k);
        }
    }

    public void l(int visible) {
        this.f528a.setVisibility(visible);
    }
}
