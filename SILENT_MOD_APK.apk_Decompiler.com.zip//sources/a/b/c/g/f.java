package a.b.c.g;

import android.support.v4.util.LongSparseArray;

public class f<E> implements Cloneable {
    public static final Object f = new Object();

    /* renamed from: b  reason: collision with root package name */
    public boolean f221b;

    /* renamed from: c  reason: collision with root package name */
    public long[] f222c;
    public Object[] d;
    public int e;

    public f() {
        this(10);
    }

    public f(int initialCapacity) {
        this.f221b = false;
        if (initialCapacity == 0) {
            this.f222c = c.f217b;
            this.d = c.f218c;
        } else {
            int initialCapacity2 = c.f(initialCapacity);
            this.f222c = new long[initialCapacity2];
            this.d = new Object[initialCapacity2];
        }
        this.e = 0;
    }

    /* renamed from: c */
    public f<E> clone() {
        try {
            LongSparseArray<E> clone = (f) super.clone();
            clone.f222c = (long[]) this.f222c.clone();
            clone.d = (Object[]) this.d.clone();
            return clone;
        } catch (CloneNotSupportedException e2) {
            throw new AssertionError(e2);
        }
    }

    public E f(long key) {
        return g(key, (Object) null);
    }

    public E g(long key, E valueIfKeyNotFound) {
        int i = c.b(this.f222c, this.e, key);
        if (i >= 0) {
            E[] eArr = this.d;
            if (eArr[i] != f) {
                return eArr[i];
            }
        }
        return valueIfKeyNotFound;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x000a, code lost:
        r1 = r4.d;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void d(long r5) {
        /*
            r4 = this;
            long[] r0 = r4.f222c
            int r1 = r4.e
            int r0 = a.b.c.g.c.b(r0, r1, r5)
            if (r0 < 0) goto L_0x0017
            java.lang.Object[] r1 = r4.d
            r2 = r1[r0]
            java.lang.Object r3 = f
            if (r2 == r3) goto L_0x0017
            r1[r0] = r3
            r1 = 1
            r4.f221b = r1
        L_0x0017:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a.b.c.g.f.d(long):void");
    }

    public final void e() {
        int n = this.e;
        int o = 0;
        long[] keys = this.f222c;
        Object[] values = this.d;
        for (int i = 0; i < n; i++) {
            Object val = values[i];
            if (val != f) {
                if (i != o) {
                    keys[o] = keys[i];
                    values[o] = val;
                    values[i] = null;
                }
                o++;
            }
        }
        this.f221b = false;
        this.e = o;
    }

    public void i(long key, E value) {
        int i = c.b(this.f222c, this.e, key);
        if (i >= 0) {
            this.d[i] = value;
            return;
        }
        int i2 = i ^ -1;
        if (i2 < this.e) {
            Object[] objArr = this.d;
            if (objArr[i2] == f) {
                this.f222c[i2] = key;
                objArr[i2] = value;
                return;
            }
        }
        if (this.f221b && this.e >= this.f222c.length) {
            e();
            i2 = c.b(this.f222c, this.e, key) ^ -1;
        }
        int i3 = this.e;
        if (i3 >= this.f222c.length) {
            int n = c.f(i3 + 1);
            long[] nkeys = new long[n];
            Object[] nvalues = new Object[n];
            long[] jArr = this.f222c;
            System.arraycopy(jArr, 0, nkeys, 0, jArr.length);
            Object[] objArr2 = this.d;
            System.arraycopy(objArr2, 0, nvalues, 0, objArr2.length);
            this.f222c = nkeys;
            this.d = nvalues;
        }
        int n2 = this.e;
        if (n2 - i2 != 0) {
            long[] jArr2 = this.f222c;
            System.arraycopy(jArr2, i2, jArr2, i2 + 1, n2 - i2);
            Object[] objArr3 = this.d;
            System.arraycopy(objArr3, i2, objArr3, i2 + 1, this.e - i2);
        }
        this.f222c[i2] = key;
        this.d[i2] = value;
        this.e++;
    }

    public int j() {
        if (this.f221b) {
            e();
        }
        return this.e;
    }

    public long h(int index) {
        if (this.f221b) {
            e();
        }
        return this.f222c[index];
    }

    public E k(int index) {
        if (this.f221b) {
            e();
        }
        return this.d[index];
    }

    public void b() {
        int n = this.e;
        Object[] values = this.d;
        for (int i = 0; i < n; i++) {
            values[i] = null;
        }
        this.e = 0;
        this.f221b = false;
    }

    public void a(long key, E value) {
        int i = this.e;
        if (i == 0 || key > this.f222c[i - 1]) {
            if (this.f221b && this.e >= this.f222c.length) {
                e();
            }
            int pos = this.e;
            if (pos >= this.f222c.length) {
                int n = c.f(pos + 1);
                long[] nkeys = new long[n];
                Object[] nvalues = new Object[n];
                long[] jArr = this.f222c;
                System.arraycopy(jArr, 0, nkeys, 0, jArr.length);
                Object[] objArr = this.d;
                System.arraycopy(objArr, 0, nvalues, 0, objArr.length);
                this.f222c = nkeys;
                this.d = nvalues;
            }
            this.f222c[pos] = key;
            this.d[pos] = value;
            this.e = pos + 1;
            return;
        }
        i(key, value);
    }

    public String toString() {
        if (j() <= 0) {
            return "{}";
        }
        StringBuilder buffer = new StringBuilder(this.e * 28);
        buffer.append('{');
        for (int i = 0; i < this.e; i++) {
            if (i > 0) {
                buffer.append(", ");
            }
            buffer.append(h(i));
            buffer.append('=');
            Object value = k(i);
            if (value != this) {
                buffer.append(value);
            } else {
                buffer.append("(this Map)");
            }
        }
        buffer.append('}');
        return buffer.toString();
    }
}
