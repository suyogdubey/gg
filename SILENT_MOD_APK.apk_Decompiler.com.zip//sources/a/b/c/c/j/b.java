package a.b.c.c.j;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public interface b {
    void setTint(int i);

    void setTintList(ColorStateList colorStateList);

    void setTintMode(PorterDuff.Mode mode);
}
