package a.b.c.a;

import android.os.Parcel;
import android.os.Parcelable;

public final class m implements Parcelable {
    public static final Parcelable.Creator<m> CREATOR = new a();

    /* renamed from: b  reason: collision with root package name */
    public n[] f107b;

    /* renamed from: c  reason: collision with root package name */
    public int[] f108c;
    public d[] d;
    public int e = -1;
    public int f;

    public m() {
    }

    public m(Parcel in) {
        this.f107b = (n[]) in.createTypedArray(n.CREATOR);
        this.f108c = in.createIntArray();
        this.d = (d[]) in.createTypedArray(d.CREATOR);
        this.e = in.readInt();
        this.f = in.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedArray(this.f107b, flags);
        dest.writeIntArray(this.f108c);
        dest.writeTypedArray(this.d, flags);
        dest.writeInt(this.e);
        dest.writeInt(this.f);
    }

    public static class a implements Parcelable.Creator<m> {
        /* renamed from: a */
        public m createFromParcel(Parcel in) {
            return new m(in);
        }

        /* renamed from: b */
        public m[] newArray(int size) {
            return new m[size];
        }
    }
}
