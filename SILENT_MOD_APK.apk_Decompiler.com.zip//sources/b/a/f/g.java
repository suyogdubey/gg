package b.a.f;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import b.a.b;
import b.a.c;

public class g extends Drawable {
    public static final double q = Math.cos(Math.toRadians(45.0d));
    public static a r;

    /* renamed from: a  reason: collision with root package name */
    public final int f665a;

    /* renamed from: b  reason: collision with root package name */
    public Paint f666b;

    /* renamed from: c  reason: collision with root package name */
    public Paint f667c;
    public Paint d;
    public final RectF e;
    public float f;
    public Path g;
    public float h;
    public float i;
    public float j;
    public ColorStateList k;
    public boolean l = true;
    public final int m;
    public final int n;
    public boolean o = true;
    public boolean p = false;

    public interface a {
        void a(Canvas canvas, RectF rectF, float f, Paint paint);
    }

    public g(Resources resources, ColorStateList backgroundColor, float radius, float shadowSize, float maxShadowSize) {
        this.m = resources.getColor(b.cardview_shadow_start_color);
        this.n = resources.getColor(b.cardview_shadow_end_color);
        this.f665a = resources.getDimensionPixelSize(c.cardview_compat_inset_shadow);
        this.f666b = new Paint(5);
        n(backgroundColor);
        Paint paint = new Paint(5);
        this.f667c = paint;
        paint.setStyle(Paint.Style.FILL);
        this.f = (float) ((int) (0.5f + radius));
        this.e = new RectF();
        Paint paint2 = new Paint(this.f667c);
        this.d = paint2;
        paint2.setAntiAlias(false);
        s(shadowSize, maxShadowSize);
    }

    public final void n(ColorStateList color) {
        ColorStateList valueOf = color == null ? ColorStateList.valueOf(0) : color;
        this.k = valueOf;
        this.f666b.setColor(valueOf.getColorForState(getState(), this.k.getDefaultColor()));
    }

    public final int t(float value) {
        int i2 = (int) (0.5f + value);
        if (i2 % 2 == 1) {
            return i2 - 1;
        }
        return i2;
    }

    public void m(boolean addPaddingForCorners) {
        this.o = addPaddingForCorners;
        invalidateSelf();
    }

    public void setAlpha(int alpha) {
        this.f666b.setAlpha(alpha);
        this.f667c.setAlpha(alpha);
        this.d.setAlpha(alpha);
    }

    public void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        this.l = true;
    }

    public final void s(float shadowSize, float maxShadowSize) {
        if (shadowSize < 0.0f) {
            throw new IllegalArgumentException("Invalid shadow size " + shadowSize + ". Must be >= 0");
        } else if (maxShadowSize >= 0.0f) {
            float shadowSize2 = (float) t(shadowSize);
            float maxShadowSize2 = (float) t(maxShadowSize);
            if (shadowSize2 > maxShadowSize2) {
                shadowSize2 = maxShadowSize2;
                if (!this.p) {
                    this.p = true;
                }
            }
            if (this.j != shadowSize2 || this.h != maxShadowSize2) {
                this.j = shadowSize2;
                this.h = maxShadowSize2;
                this.i = (float) ((int) ((1.5f * shadowSize2) + ((float) this.f665a) + 0.5f));
                this.l = true;
                invalidateSelf();
            }
        } else {
            throw new IllegalArgumentException("Invalid max shadow size " + maxShadowSize + ". Must be >= 0");
        }
    }

    public boolean getPadding(Rect padding) {
        int vOffset = (int) Math.ceil((double) d(this.h, this.f, this.o));
        int hOffset = (int) Math.ceil((double) c(this.h, this.f, this.o));
        padding.set(hOffset, vOffset, hOffset, vOffset);
        return true;
    }

    public static float d(float maxShadowSize, float cornerRadius, boolean addPaddingForCorners) {
        if (!addPaddingForCorners) {
            return 1.5f * maxShadowSize;
        }
        double d2 = (double) (1.5f * maxShadowSize);
        double d3 = 1.0d - q;
        double d4 = (double) cornerRadius;
        Double.isNaN(d4);
        Double.isNaN(d2);
        return (float) (d2 + (d3 * d4));
    }

    public static float c(float maxShadowSize, float cornerRadius, boolean addPaddingForCorners) {
        if (!addPaddingForCorners) {
            return maxShadowSize;
        }
        double d2 = (double) maxShadowSize;
        double d3 = 1.0d - q;
        double d4 = (double) cornerRadius;
        Double.isNaN(d4);
        Double.isNaN(d2);
        return (float) (d2 + (d3 * d4));
    }

    public boolean onStateChange(int[] stateSet) {
        ColorStateList colorStateList = this.k;
        int newColor = colorStateList.getColorForState(stateSet, colorStateList.getDefaultColor());
        if (this.f666b.getColor() == newColor) {
            return false;
        }
        this.f666b.setColor(newColor);
        this.l = true;
        invalidateSelf();
        return true;
    }

    public boolean isStateful() {
        ColorStateList colorStateList = this.k;
        return (colorStateList != null && colorStateList.isStateful()) || super.isStateful();
    }

    public void setColorFilter(ColorFilter cf) {
        this.f666b.setColorFilter(cf);
    }

    public int getOpacity() {
        return -3;
    }

    public void p(float radius) {
        if (radius >= 0.0f) {
            float radius2 = (float) ((int) (0.5f + radius));
            if (this.f != radius2) {
                this.f = radius2;
                this.l = true;
                invalidateSelf();
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Invalid radius " + radius + ". Must be >= 0");
    }

    public void draw(Canvas canvas) {
        if (this.l) {
            a(getBounds());
            this.l = false;
        }
        canvas.translate(0.0f, this.j / 2.0f);
        e(canvas);
        canvas.translate(0.0f, (-this.j) / 2.0f);
        r.a(canvas, this.e, this.f, this.f666b);
    }

    public final void e(Canvas canvas) {
        float f2 = this.f;
        float edgeShadowTop = (-f2) - this.i;
        float inset = f2 + ((float) this.f665a) + (this.j / 2.0f);
        boolean z = true;
        boolean drawHorizontalEdges = this.e.width() - (inset * 2.0f) > 0.0f;
        if (this.e.height() - (inset * 2.0f) <= 0.0f) {
            z = false;
        }
        boolean drawVerticalEdges = z;
        int saved = canvas.save();
        RectF rectF = this.e;
        canvas.translate(rectF.left + inset, rectF.top + inset);
        canvas.drawPath(this.g, this.f667c);
        if (drawHorizontalEdges) {
            canvas.drawRect(0.0f, edgeShadowTop, this.e.width() - (inset * 2.0f), -this.f, this.d);
        }
        canvas.restoreToCount(saved);
        int saved2 = canvas.save();
        RectF rectF2 = this.e;
        canvas.translate(rectF2.right - inset, rectF2.bottom - inset);
        canvas.rotate(180.0f);
        canvas.drawPath(this.g, this.f667c);
        if (drawHorizontalEdges) {
            canvas.drawRect(0.0f, edgeShadowTop, this.e.width() - (inset * 2.0f), (-this.f) + this.i, this.d);
        }
        canvas.restoreToCount(saved2);
        int saved3 = canvas.save();
        RectF rectF3 = this.e;
        canvas.translate(rectF3.left + inset, rectF3.bottom - inset);
        canvas.rotate(270.0f);
        canvas.drawPath(this.g, this.f667c);
        if (drawVerticalEdges) {
            canvas.drawRect(0.0f, edgeShadowTop, this.e.height() - (inset * 2.0f), -this.f, this.d);
        }
        canvas.restoreToCount(saved3);
        int saved4 = canvas.save();
        RectF rectF4 = this.e;
        canvas.translate(rectF4.right - inset, rectF4.top + inset);
        canvas.rotate(90.0f);
        canvas.drawPath(this.g, this.f667c);
        if (drawVerticalEdges) {
            canvas.drawRect(0.0f, edgeShadowTop, this.e.height() - (2.0f * inset), -this.f, this.d);
        }
        canvas.restoreToCount(saved4);
    }

    public final void b() {
        float f2 = this.f;
        RectF innerBounds = new RectF(-f2, -f2, f2, f2);
        RectF outerBounds = new RectF(innerBounds);
        float f3 = this.i;
        outerBounds.inset(-f3, -f3);
        Path path = this.g;
        if (path == null) {
            this.g = new Path();
        } else {
            path.reset();
        }
        this.g.setFillType(Path.FillType.EVEN_ODD);
        this.g.moveTo(-this.f, 0.0f);
        this.g.rLineTo(-this.i, 0.0f);
        this.g.arcTo(outerBounds, 180.0f, 90.0f, false);
        this.g.arcTo(innerBounds, 270.0f, -90.0f, false);
        this.g.close();
        float f4 = this.f;
        float startRatio = f4 / (this.i + f4);
        Paint paint = this.f667c;
        float f5 = this.i + this.f;
        int i2 = this.m;
        paint.setShader(new RadialGradient(0.0f, 0.0f, f5, new int[]{i2, i2, this.n}, new float[]{0.0f, startRatio, 1.0f}, Shader.TileMode.CLAMP));
        Paint paint2 = this.d;
        float f6 = this.f;
        float f7 = this.i;
        int i3 = this.m;
        paint2.setShader(new LinearGradient(0.0f, (-f6) + f7, 0.0f, (-f6) - f7, new int[]{i3, i3, this.n}, new float[]{0.0f, 0.5f, 1.0f}, Shader.TileMode.CLAMP));
        this.d.setAntiAlias(false);
    }

    public final void a(Rect bounds) {
        float f2 = this.h;
        float verticalOffset = 1.5f * f2;
        this.e.set(((float) bounds.left) + f2, ((float) bounds.top) + verticalOffset, ((float) bounds.right) - f2, ((float) bounds.bottom) - verticalOffset);
        b();
    }

    public float g() {
        return this.f;
    }

    public void h(Rect into) {
        getPadding(into);
    }

    public void r(float size) {
        s(size, this.h);
    }

    public void q(float size) {
        s(this.j, size);
    }

    public float l() {
        return this.j;
    }

    public float i() {
        return this.h;
    }

    public float k() {
        float f2 = this.h;
        return ((this.h + ((float) this.f665a)) * 2.0f) + (Math.max(f2, this.f + ((float) this.f665a) + (f2 / 2.0f)) * 2.0f);
    }

    public float j() {
        float f2 = this.h;
        return (((this.h * 1.5f) + ((float) this.f665a)) * 2.0f) + (Math.max(f2, this.f + ((float) this.f665a) + ((f2 * 1.5f) / 2.0f)) * 2.0f);
    }

    public void o(ColorStateList color) {
        n(color);
        invalidateSelf();
    }

    public ColorStateList f() {
        return this.k;
    }
}
