package a.b.c.a;

import a.b.c.g.j;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class i<E> extends g {

    /* renamed from: a  reason: collision with root package name */
    public final Activity f76a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f77b;

    /* renamed from: c  reason: collision with root package name */
    public final Handler f78c;
    public final k d;

    public abstract void h(e eVar);

    public abstract void i(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract LayoutInflater j();

    public abstract int k();

    public abstract boolean l();

    public abstract boolean m(e eVar);

    public abstract void n();

    public i(f activity) {
        this(activity, activity, activity.f71c, 0);
    }

    public i(Activity activity, Context context, Handler handler, int windowAnimations) {
        this.d = new k();
        this.f76a = activity;
        j.c(context, "context == null");
        this.f77b = context;
        j.c(handler, "handler == null");
        this.f78c = handler;
    }

    public Activity d() {
        return this.f76a;
    }

    public Context e() {
        return this.f77b;
    }

    public Handler g() {
        return this.f78c;
    }

    public k f() {
        return this.d;
    }
}
